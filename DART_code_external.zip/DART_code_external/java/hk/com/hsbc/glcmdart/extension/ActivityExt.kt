/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.extension

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import hk.com.hsbc.glcmdart.framework.BaseActivity

fun Activity.showLongToast(text: String) {
    runOnUiThread {
        Toast.makeText(applicationContext, text, Toast.LENGTH_LONG).show()
    }
}

fun Activity.showShortToast(text: String?) {
    runOnUiThread {
        Toast.makeText(applicationContext, text, Toast.LENGTH_SHORT).show()
    }
}

fun Activity.showLongToast(resId: Int) {
    runOnUiThread {
        Toast.makeText(applicationContext, resId, Toast.LENGTH_LONG).show()
    }
}

fun Activity.showShortToast(resId: Int) {
    runOnUiThread {
        Toast.makeText(applicationContext, resId, Toast.LENGTH_SHORT).show()
    }
}

fun Activity.showInput() {
    val view = window?.decorView
    val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    view?.let {
        inputMethodManager.showSoftInput(view, 0)
    }
}

fun Activity.hideInput() {
    val view = window?.decorView
    val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    view?.windowToken?.let {
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }
}

fun Activity.showInputDelayed(delayMillis: Long) {
    val handle = Handler(Looper.getMainLooper())
    handle.postDelayed({ showInput() }, delayMillis)
}

fun Activity.hideInputDelayed(delayMillis: Long) {
    val handle = Handler(Looper.getMainLooper())
    handle.postDelayed({ hideInput() }, delayMillis)
}

fun Activity.setSecurityFlag() {
    window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
}

fun addStatusViewWithColor(activity: Activity, color: Int) {
    val contentView = activity.findViewById(android.R.id.content) as ViewGroup
    contentView.setPadding(0, getStatusBarHeight(activity), 0, 0)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        activity.window.statusBarColor = color
    } else {
        val statusBarView = View(activity)
        val lp = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, getStatusBarHeight(activity))
        statusBarView.setBackgroundColor(color)
        contentView.addView(statusBarView, 0, lp)
    }
}

fun removeStatusView(activity: Activity) {
    val contentView = activity.findViewById(android.R.id.content) as ViewGroup
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        contentView.setPadding(0, 0, 0, 0)
    } else {
        contentView.removeViewAt(0)
    }
}

fun getStatusBarHeight(activity: Activity): Int {
    var result = 0
    val resourceId = activity.resources.getIdentifier("status_bar_height", "dimen", "android")
    if (resourceId > 0) {
        result = activity.resources.getDimensionPixelSize(resourceId)
    }
    return result
}

fun Activity.showLoadingDialogExt() {
    (this as? BaseActivity)?.showLoadingDialog()
}

fun Activity.hideLoadingDialogExt() {
    (this as? BaseActivity)?.hideLoadingDialog()
}