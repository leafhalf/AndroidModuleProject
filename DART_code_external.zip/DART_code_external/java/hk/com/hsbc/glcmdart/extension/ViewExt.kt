/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.extension

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.InputMethodManager

internal val View.handle: Handler
    get() = Handler(Looper.getMainLooper())

fun View.postOnMainThread(action: () -> Unit) {
    handle.post { action() }
}

fun View.postDelayedOnMainThread(action: () -> Unit, delayMillis: Long) {
    handle.postDelayed({ action() }, delayMillis)
}

fun View.showInput() {
    val inputMethodManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    inputMethodManager.showSoftInput(this, 0)
}

fun View.hideInput() {
    val inputMethodManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    windowToken?.let {
        inputMethodManager.hideSoftInputFromWindow(this.windowToken, 0)
    }
}

fun View.showInputDelayed(delayMillis: Long) {
    handle.postDelayed({ showInput() }, delayMillis)
}

fun View.hideInputDelayed(delayMillis: Long) {
    handle.postDelayed({ hideInput() }, delayMillis)
}