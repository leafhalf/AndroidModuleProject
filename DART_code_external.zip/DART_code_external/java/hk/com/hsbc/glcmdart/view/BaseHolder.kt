/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.view

import android.view.View
import androidx.recyclerview.widget.RecyclerView

@Suppress("DEPRECATION")
abstract class BaseHolder<T>(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
    protected var mOnViewClickListener: OnViewClickListener? = null
    protected val TAG = this.javaClass.simpleName

    init {
        itemView.setOnClickListener(this)//点击事件
    }

    abstract fun setData(data: T, position: Int)

    protected fun onRelease() {

    }

    override fun onClick(view: View) {
        if (mOnViewClickListener != null) {
            mOnViewClickListener?.onViewClick(view, this.position)
        }
    }

    interface OnViewClickListener {
        fun onViewClick(view: View, position: Int)
    }

    fun setOnItemClickListener(listener: OnViewClickListener?) {
        this.mOnViewClickListener = listener
    }
}
