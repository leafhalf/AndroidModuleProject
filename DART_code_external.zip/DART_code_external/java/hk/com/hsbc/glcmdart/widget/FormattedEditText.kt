/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.widget.AppCompatEditText
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache

/**
 * Created by Donut on 2018/11/9.
 */
class FormattedEditText @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : AppCompatEditText(context, attrs),
        View.OnClickListener, View.OnFocusChangeListener {

    var currency: String? = MemoryCache.defaultCurrency
    private val mInputMethodManager: InputMethodManager

    init {
        this.onFocusChangeListener = this
        this.setOnClickListener(this)
        mInputMethodManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        hint = "$currency 0${if (currency == "IDR") "," else "."}00"
    }

    override fun onClick(v: View?) {
        this.isFocusable = true
        this.isFocusableInTouchMode = true
        this.requestFocus()
        this.findFocus()
        mInputMethodManager.showSoftInput(this, InputMethodManager.SHOW_FORCED)
    }


    override fun onFocusChange(v: View?, hasFocus: Boolean) {
        val decimalSymbol = if (currency == "IDR") "," else "."
        val banDecimalSymbol = if (currency == "IDR") "." else ","
        val tmpText = if (hasFocus) {
            tag?.toString() ?: ""
        } else {
            tag = text.toString()
            val tagStr = this.tag.toString().replace(banDecimalSymbol, "").replace(decimalSymbol, ".")
            if (tagStr.isEmpty()) {
                ""
            } else {
                "$currency " + IndiaNumberUtil.formatNum(tagStr, currency ?: "")
            }
        }
        setEditText(showingText = tmpText)
    }

    fun setEditText(realText: String = "", showingText: String = "") {
        this.tag = if (realText.isNotBlank()) realText else tag
        this.setText(showingText)
    }

    fun changeFocus() {
        this.isFocusable = false
        if (mInputMethodManager.isActive) {
            mInputMethodManager.hideSoftInputFromWindow(this.windowToken, 0)
        }
    }

    fun updateHintCurrency() {
        val newHint = "$currency ${hint.substring(4)}"
        hint = newHint
        val decimalSymbol = if (currency == "IDR") "," else "."
        val banDecimalSymbol = if (currency == "IDR") "." else ","
        hint = newHint.replace(banDecimalSymbol, decimalSymbol)
        var tagText = tag?.toString() ?: ""
        if (tagText.isNotBlank()) {
            tagText = tagText.replace(banDecimalSymbol, decimalSymbol)
            tag = tagText
        }
        if (!text.isNullOrBlank()) {
            var tmpReplacement = text.toString().replace(decimalSymbol, "*")
            tmpReplacement = tmpReplacement.replace(banDecimalSymbol, decimalSymbol)
            tmpReplacement = tmpReplacement.replace("*", banDecimalSymbol)
            val newText = if (!Character.isDigit(text!![0])) {
                "$currency ${tmpReplacement.substring(4)}"
            } else {
                tmpReplacement
            }
            setText(newText)
        }
    }
}