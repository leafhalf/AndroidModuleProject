package hk.com.hsbc.glcmdart.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.ConvertUtil
import hk.com.hsbc.glcmdart.util.MemoryCache


class ProgressWebView: WebView {

    @JvmOverloads
    constructor(context: Context, attrs: AttributeSet? = null) : super(context, attrs) {
        init()
    }

    lateinit var mProgressBar: ProgressBar
//    private var mRadius = 0
//    private var vWidth = 0
//    private var vHeight = 0
//    private val path = Path()

//    fun setRadius(radius: Int) {
//        mRadius = radius
//        invalidate()
//    }

    private fun init() {
        val height = ConvertUtil.dp2px(context, 5.0f).toInt()
        mProgressBar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal)
        mProgressBar.progressDrawable = ContextCompat.getDrawable(context, R.drawable.bg_pb_webview)
        mProgressBar.layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                height,
                0, 0)
        mProgressBar.max = 100
        mProgressBar.progress = 30
        addView(mProgressBar, 0)
        if (MemoryCache.defaultCountry == "IN") {
            val logo = ImageView(context)
            val logoLp = LayoutParams(ConvertUtil.dp2px(context, 64f).toInt(),
                    ConvertUtil.dp2px(context, 32f).toInt(),
                    ConvertUtil.dp2px(context, 60f).toInt(),
                    ConvertUtil.dp2px(context, 10f).toInt())
            logo.layoutParams = logoLp
            logo.setImageDrawable(ContextCompat.getDrawable(context, R.mipmap.payu_logo))
            addView(logo, 0)
        }
        val indicator = View(context)
        val idLp = LayoutParams(ConvertUtil.dp2px(context, 64f).toInt(),
                ConvertUtil.dp2px(context, 5f).toInt(),
                ConvertUtil.dp2px(context, 200f).toInt(),
                ConvertUtil.dp2px(context, -30f).toInt())
        indicator.layoutParams = idLp
        indicator.setBackgroundColor(ContextCompat.getColor(context, R.color.primary_red))
        addView(indicator, 0)
    }

    fun removeLogo() {
        mProgressBar.visibility = View.GONE
    }

    fun showLogo() {
        mProgressBar.visibility = View.VISIBLE
    }

//    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
//        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
//        vWidth = measuredWidth
//        vHeight = measuredHeight
//    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        val progressLp = mProgressBar.layoutParams as LayoutParams
        progressLp.x = l
        progressLp.y = t
        mProgressBar.layoutParams = progressLp
        super.onScrollChanged(l, t, oldl, oldt)
    }

//    override fun onDraw(canvas: Canvas?) {
//        val crntScrollY = scrollY
//        val r = ConvertUtil.dp2px(context, mRadius.toFloat())
//
//        if (vWidth > r && height > r) {
//            path.moveTo(r, 0f)
//            path.lineTo(vWidth - r, 0f)
//            path.quadTo(vWidth.toFloat(), 0f, vWidth.toFloat(), r)
//            path.lineTo(vWidth.toFloat(),crntScrollY + vHeight - r)//1,r改为0
//            path.quadTo(vWidth.toFloat(), (crntScrollY + vHeight).toFloat(), vWidth - r, (crntScrollY + vHeight).toFloat()) //2,r改为0
//            path.lineTo(r, (crntScrollY + vHeight).toFloat())//3,r改为0
//            path.quadTo(0f, vHeight.toFloat(), 0f, crntScrollY + vHeight - r) //4,r改为0  这四处r改为0即可实现上左上右为圆角，否则四角皆为圆角
//            path.lineTo(0f, r)
//            path.quadTo(0f, 0f, r, 0f)
//            if(r >0) {
//                canvas?.clipPath(path);//将路径闭合构成控件的区域
//            }
//        }
//        super.onDraw(canvas)
//    }
}