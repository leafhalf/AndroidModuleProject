package hk.com.hsbc.glcmdart.widget

import android.content.Context
import android.net.Uri
import android.util.AttributeSet
import android.widget.VideoView
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.util.SSlUtiles.TrustAllHostnameVerifier
import hk.com.hsbc.glcmdart.util.SSlUtiles.createSSLSocketFactory
import javax.net.ssl.HttpsURLConnection


class MyVideoView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : VideoView(context, attrs) {

    override fun setVideoURI(uri: Uri?) {
        super.setVideoURI(uri)
        if (BuildConfig.FLAVOR_env != "prod") {
            try {
                HttpsURLConnection.setDefaultSSLSocketFactory(createSSLSocketFactory())
                HttpsURLConnection.setDefaultHostnameVerifier(TrustAllHostnameVerifier())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

}