/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.widget

import android.animation.Animator
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.view_loading_button.view.*


/**
 * Created by Donut on 2018/11/16.
 */
class LoadingButton@JvmOverloads constructor(private val mContext: Context, attrs: AttributeSet? = null) : RelativeLayout(mContext, attrs) {

    private val tvSubmit: TextView
    private val pbLoading: ProgressBar
    private val ivComplete: ImageView
    private var btnShowingString: String? = null
    var animationEndCallback: LoadingCompletedCallback? = null

    init{
        LayoutInflater.from(mContext).inflate(R.layout.view_loading_button, this)
        tvSubmit = tv_submit
        MemoryCache.getLabelText("s_next")?.let {
            if (!it.isBlank()) {
                tvSubmit.text = it
            }
        }
        tvSubmit.setAccessibilityDelegate(object: View.AccessibilityDelegate() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        })
        pbLoading = pb_loading
        ivComplete = iv_complete_tip
        val a = context.theme.obtainStyledAttributes(attrs, R.styleable.LoadingButton, 0, 0)
        val indexCount = a.indexCount
        for (i in 0 until indexCount) {
            when (val attr = a.getIndex(i)) {
                R.styleable.LoadingButton_btnText ->  {
                    tvSubmit.text = a.getString(attr)
                    btnShowingString = a.getString(attr)
                }
            }
        }
        a.recycle()
    }

    fun startLoadingAnimation() {
        tvSubmit.text = ""
        tvSubmit.setBackgroundColor(ContextCompat.getColor(mContext, R.color.dark_red))
        pbLoading.visibility = View.VISIBLE
        tvSubmit.isEnabled = false
        pbLoading.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading") ?: mContext.getString(R.string.talkBack_loading))
    }

    fun endLoadingAnimation(isLoadingSuccess: Boolean) {
        pbLoading.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete") ?: mContext.getString(R.string.talkBack_loading_complete))
        tvSubmit.isEnabled = true
        if (isLoadingSuccess) {
            loadSuccessAnimationEnd()
        } else {
            enableButton(false)
        }
    }

    fun setOnButtonClickListener(listener: OnClickListener?) {
        tvSubmit.setOnClickListener(listener)
    }

    private fun loadSuccessAnimationEnd() {
        pbLoading.visibility = View.GONE
        if (mContext is Activity && mContext.isFinishing) {
            return
        }
        val colorAnim = ObjectAnimator.ofInt(tvSubmit, "backgroundColor", ContextCompat.getColor(mContext, R.color.dark_red),  ContextCompat.getColor(mContext, R.color.primary_green)).apply {
            duration = 150
            setEvaluator(ArgbEvaluator())
        }
        colorAnim.addListener(object: Animator.AnimatorListener{
            override fun onAnimationRepeat(animation: Animator?) {
            }

            override fun onAnimationEnd(animation: Animator?) {
                animationEndCallback?.onAnimationCompleted()
            }

            override fun onAnimationCancel(animation: Animator?) {
            }

            override fun onAnimationStart(animation: Animator?) {
            }

        })
        colorAnim.start()
        ivComplete.visibility = View.VISIBLE
    }

    fun enableButton(enable: Boolean) {
        tvSubmit.isEnabled = enable
        pbLoading.visibility = View.GONE
        ivComplete.visibility = View.GONE
        if (!enable) {
            tvSubmit.background = ContextCompat.getDrawable(mContext, R.drawable.button_primary_red)
            // tvSubmit.text = btnShowingString
        }
    }

    fun setButtonText(text: CharSequence?) {
        tvSubmit.text = text
    }
}

interface LoadingCompletedCallback{
    fun onAnimationCompleted()
}