/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.widget

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.view.View
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R

class SpacesItemDecoration : RecyclerView.ItemDecoration{

    private var mDivider: Drawable? = null
    private var mDividerHeight: Int = 0

    constructor(activity: Activity, dividerHeight: Int) {
        mDivider = ContextCompat.getDrawable(activity, R.drawable.line_divider)
        mDividerHeight = dividerHeight
    }

    constructor(activity: Activity, divider: Drawable?, dividerHeight: Int) {
        mDivider = divider ?: ContextCompat.getDrawable(activity, R.drawable.line_divider)
        mDividerHeight = dividerHeight
    }

    override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
        super.getItemOffsets(outRect, view, parent, state)
        outRect.set(0, 0, 0, mDividerHeight)
    }

    override fun onDrawOver(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        val left = parent.paddingLeft
        val right = parent.width - parent.paddingRight

        val childCount = parent.childCount
        for (i in 0 until childCount) {
            val child = parent.getChildAt(i)

            val params = child.layoutParams as RecyclerView.LayoutParams

            val top = child.bottom + params.bottomMargin
            val bottom = top + mDividerHeight
            mDivider?.setBounds(left, top, right, bottom)
            mDivider?.draw(c)
        }
    }
}
