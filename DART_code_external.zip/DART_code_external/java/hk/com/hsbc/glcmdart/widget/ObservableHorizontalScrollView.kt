/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.widget

import android.content.Context
import android.util.AttributeSet
import android.widget.HorizontalScrollView

class ObservableHorizontalScrollView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0): HorizontalScrollView(context, attrs, defStyleAttr) {

    private var scrollChangeListener: ViewOnScrollListener? = null

    fun setScrollChangeListener(listener: ViewOnScrollListener) {
        scrollChangeListener = listener
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        scrollChangeListener?.onScroll(this, l, t, oldl, oldt)
    }
}

interface ViewOnScrollListener{
    fun onScroll(view: ObservableHorizontalScrollView, x: Int, y: Int, oldX: Int, oldY: Int)
}