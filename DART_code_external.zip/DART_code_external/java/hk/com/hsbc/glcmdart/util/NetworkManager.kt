/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.util

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import com.google.gson.GsonBuilder
import com.mobilefoundation.networking.MFCommonNetService
import com.mobilefoundation.networking.utils.MFNetworkingContextUtils
import hk.com.hsbc.glcmdart.BuildConfig
import okhttp3.*
import okhttp3.internal.huc.OkHttpsURLConnection
import okhttp3.internal.tls.OkHostnameVerifier
import okhttp3.logging.HttpLoggingInterceptor
import okio.ByteString
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.net.CookieManager
import java.net.CookiePolicy
import java.net.HttpCookie
import java.net.URI
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.*
import java.util.concurrent.TimeUnit
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

@SuppressLint("StaticFieldLeak")
/**
 * Manage the network.
 */
object NetworkManager {

    private var TAG = "NetworkManager"
    private var context: Context? = null
    private val retrofitCache = linkedMapOf<String?, Retrofit>()
    private val retrofitRedirectCache = linkedMapOf<String?, Retrofit>()
    private var mEnvironment: String = ""
    private var mDebug: Boolean = false
    private val mPublicKeys = mutableMapOf<String, String>()
    /*
     * 1: no certificate pinning/hostname verifying
     * 2: only certificate pinning
     * 3: only hostname verifying
     * 4: both certificate pinning/hostname verifying
     */
    private var mSecurityType = 1

    fun setEnvironment(e: String) {
        mEnvironment = e
        if (mDebug) {
            Log.i(TAG, "Environment：$mEnvironment")
        }
    }

    fun setDebug(flag: Boolean) {
        mDebug = flag
        if (mDebug) {
            Log.i(TAG, "Debug：$mDebug")
        }
    }

    fun setSecurityType(type: Int) {
        mSecurityType = type
        if (mDebug) {
            Log.i(TAG, "Security type：$mSecurityType")
        }
    }

    fun clearPublicKeys() {
        mPublicKeys.clear()
    }

    fun addPublicKeys(map: MutableMap<String, String>?) {
        map?.let {
            mPublicKeys.putAll(map)
        }
    }

    fun setPublicKeys(map: MutableMap<String, String>?) {
        map?.let {
            mPublicKeys.clear()
            mPublicKeys.putAll(map)
        }
        if (mDebug) {
            mPublicKeys.forEach {
                Log.i(TAG, "Public key：${it.key} - ${it.value}")
            }
        }
    }

    private val interceptors = arrayListOf<Interceptor>()

    fun addInterceptor(interceptor: Interceptor) {
        interceptors.add(interceptor)
    }

    const val DEFAULT_READ_TIMEOUT = 1000L
    const val DEFAULT_WRITE_TIMEOUT = 1000L
    const val DEFAULT_CONNECT_TIMEOUT = 1000L

    /**
     * The cookie manager.
     */
    val cookieManager by lazy {
        CookieManager().apply { setCookiePolicy(CookiePolicy.ACCEPT_ALL) }
    }

    fun addCookie(uri: URI, cookie: HttpCookie) {
        cookieManager.cookieStore.add(uri, cookie)
    }

    fun clearCookies() {
        cookieManager.cookieStore.removeAll()
    }

    /**
     * Generate a new http client.
     */
    @Suppress("DEPRECATION")
    private fun newClient(isRedirect: Boolean): OkHttpClient {
        val builder = OkHttpClient.Builder()
                .readTimeout(DEFAULT_READ_TIMEOUT, TimeUnit.SECONDS)
                .writeTimeout(DEFAULT_WRITE_TIMEOUT, TimeUnit.SECONDS)
                .connectTimeout(DEFAULT_CONNECT_TIMEOUT, TimeUnit.SECONDS)
                .cookieJar(JavaNetCookieJar(cookieManager))
                .followRedirects(isRedirect)
                .followSslRedirects(isRedirect)
        interceptors.forEach {
            builder.addInterceptor(it)
        }
        // Add logger
        val logger = HttpLoggingInterceptor().apply {
            level = if (mDebug) {
                HttpLoggingInterceptor.Level.BODY
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
        builder.addInterceptor(logger)
        // Add tls version and cipher suit
        val connectionSpec = ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
                .tlsVersions(TlsVersion.TLS_1_2)
                .cipherSuites(CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,
                        CipherSuite.TLS_DHE_RSA_WITH_AES_256_GCM_SHA384,CipherSuite.TLS_DHE_RSA_WITH_AES_256_CBC_SHA256,
                        CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,
                        CipherSuite.TLS_DHE_RSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_DHE_RSA_WITH_AES_128_CBC_SHA256)
                .build()
        if (mSecurityType in 1..4) {
            builder.connectionSpecs(Collections.singletonList(connectionSpec))
        }
        // Add trust manager or certificate pinner, hostname verifier
        val defaultSSLContext = SSLContext.getInstance("TLS").let { context ->
            val trustManager = object : X509TrustManager {

                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {

                }
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {

                }
                override fun getAcceptedIssuers(): Array<X509Certificate> {
                    return arrayOf()
                }
            }
            context.init(null, arrayOf(trustManager), SecureRandom())
            context
        }
        val certificatePinner = CertificatePinner.Builder().let { builder ->
            mPublicKeys.forEach {
                val pattern = it.key
                val pin = hexStringToSHA256(it.value)
                builder.add(pattern, pin)
            }
            builder
        }.build()
        val defaultHostnameVerifier = HostnameVerifier { _, _ -> true }
        val hostnameVerifier = HostnameVerifier { hostname, session ->
            OkHttpsURLConnection.getDefaultHostnameVerifier().run {
                verify(BuildConfig.CN, session)
            }
        }
        val okHostnameVerifier = OkHostnameVerifier.INSTANCE
        when (mSecurityType) {
            1 -> {
                builder.sslSocketFactory(defaultSSLContext.socketFactory)
                builder.hostnameVerifier(defaultHostnameVerifier)
            }
            2 -> {
                builder.certificatePinner(certificatePinner)
                builder.hostnameVerifier(defaultHostnameVerifier)
            }
            3 -> {
                builder.sslSocketFactory(defaultSSLContext.socketFactory)
                builder.hostnameVerifier(hostnameVerifier)
            }
            4 -> {
                builder.certificatePinner(certificatePinner)
                builder.hostnameVerifier(hostnameVerifier)
            }
        }
        return builder.build()
    }

    /**
     * Generate a new retrofit adapter.
     */
    private fun <T> obtainRetrofit(cls: Class<T>, url: String, client: OkHttpClient): Retrofit {
        var retrofit: Retrofit?
        if (client.followRedirects() && client.followSslRedirects()) {
            synchronized(retrofitRedirectCache) {
                retrofit = retrofitRedirectCache[cls.canonicalName]
                val baseUrl = retrofit?.baseUrl()?.url().toString()
                if (retrofit == null || baseUrl != url) {
                    retrofit = newRetrofitSec(url, client)
                    retrofitRedirectCache[cls.canonicalName] = retrofit as Retrofit
                }
            }
        } else {
            synchronized(retrofitCache) {
                retrofit = retrofitCache[cls.canonicalName]
                val baseUrl = retrofit?.baseUrl()?.url().toString()
                if (retrofit == null || baseUrl != url) {
                    retrofit = newRetrofitSec(url, client)
                    retrofitCache[cls.canonicalName] = retrofit as Retrofit
                }
            }
        }
        return retrofit as Retrofit
    }

    private fun newRetrofit(url: String, client: OkHttpClient): Retrofit{
        return Retrofit.Builder()
                .baseUrl(url)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(GsonBuilder()
                        .setDateFormat("yyyy-MM-dd HH:mm:ss")
                        .serializeNulls()
                        .create()))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build()
    }

    /**
     * Generate a new retrofit service.
     */
    fun <T> newService(cls: Class<T>, url: String, client: OkHttpClient): T {
        return obtainRetrofit(cls, url, client).create(cls)
    }

    /**
     * The http client without redirecting.
     */
    val normalClient by lazy {
        newClient(false)
    }

    /**
     * The http client with redirecting.
     */
    val redirectClient by lazy {
        newClient(true)
    }

    /**
     * Generate a new retrofit service without redirecting.
     */
    fun <T> getNormalService(cls: Class<T>, url: String): T {
        return obtainRetrofit(cls, url, normalClient).create(cls)
    }

    /**
     * Generate a new retrofit service with redirecting.
     */
    fun <T> getRedirectService(cls: Class<T>, url: String): T {
        return obtainRetrofit(cls, url, redirectClient).create(cls)
    }

    /**********************************************************************************************/

    /**
     * Initialize Mobile Foundation network and data storage kit.
     */
    fun initialize(context: Context) {
        this.context = context
        MFNetworkingContextUtils.init(context)
    }

    /**
     * Generate a new retrofit service from Mobile Foundation.
     */
    fun newRetrofitSec(url: String, client: OkHttpClient): Retrofit {
        return MFCommonNetService.getRetrofitBuilder(client, url).build()
    }

    /**********************************************************************************************/

    private fun hexStringToSHA256(hex: String): String {
        val byteArray = hexStringToByteArray(hex)
        return "sha256/" + ByteString.of(byteArray, 0, byteArray.size).sha256().base64()
    }

    private fun hexStringToByteArray(hex: String): ByteArray {
        val len = hex.length
        val byteArray = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            byteArray[i / 2] = ((Character.digit(hex[i], 16) shl 4) + Character.digit(hex[i + 1], 16)).toByte()
            i += 2
        }
        return byteArray
    }
}