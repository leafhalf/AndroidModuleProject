/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.util

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Application
import android.content.Context
import java.util.*
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.exitProcess

@SuppressLint("StaticFieldLeak")
object ApplicationManager {

    private lateinit var context: Context
    private lateinit var application: Application

    fun initialize(application: Application) {
        this.application = application
        this.context = application.baseContext
    }

    fun getContext(): Context {
        return context
    }

    fun getApplication(): Application {
        return application
    }

    private val activityStack = Stack<Activity>()

    fun addActivity(act: Activity) {
        activityStack.add(act)
    }

    fun removeActivity(act: Activity) {
        activityStack.remove(act)
    }

    fun finishAllActivity() {
        activityStack.forEach {
            it.finish()
        }
        activityStack.clear()
    }

    fun <T: Activity> finishActivity(cls: Class<T>) {
        val list = activityStack.filter {
            it::class.java.name.contentEquals(cls.name)
        } as List<T>
        list.forEach {
            it.finish()
        }
        list.also {
            activityStack.removeAll(it)
        }
    }

    fun <T: Activity> finishOtherActivities(cls: Class<T>) {
        val list = activityStack.filter {
            !it::class.java.name.contentEquals(cls.name)
        } as List<T>
        list.forEach {
            it.finish()
        }
        list.also {
            activityStack.removeAll(it)
        }
    }

    fun getAllActivities(): List<Activity> {
        return activityStack
    }

    fun <T: Activity> getActivities(cls: Class<T>): List<T> {
        return activityStack.filter {
            it::class.java.name.contentEquals(cls.name)
        } as List<T>
    }

    fun <T: Activity> getTopActivity(cls: Class<T>): T? {
        val list = getActivities(cls)
        if (list.isNotEmpty()) {
            return list[list.lastIndex]
        } else {
            return null
        }
    }

    fun getTopActivity(): Activity? {
        val list = getAllActivities()
        list.also {
            if (list.isNotEmpty()) {
                return list[list.lastIndex]
            }
        }
        return null
    }

    @Synchronized
    fun exitApplication() {
        finishAllActivity()
        try {
            android.os.Process.killProcess(android.os.Process.myPid())
            exitProcess(0)
        } catch (e: Exception) {
            // e.printStackTrace()
        }
    }

    val ACTIVITY_COUNT = AtomicInteger(0)

    val isApplicationBackground: Boolean
        get() = ACTIVITY_COUNT.get() == 0
}