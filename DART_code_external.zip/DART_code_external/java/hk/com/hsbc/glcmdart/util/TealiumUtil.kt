/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.util

import com.tealium.library.Tealium
import hk.com.hsbc.glcmdart.BuildConfig

object TealiumUtil {

    fun eventTag(eventAction: String,
                 eventContent: String,
                 eventCategory: String = "content") {
        Tealium.getInstance("DART").trackEvent(eventAction, HashMap<String, String>().also {
            it["event_category"] = eventCategory
            it["event_action"] = eventAction
            it["event_content"] = eventContent
        })
    }

    fun pageTag(pageName: String,
                pageURL: String,
                pageType: String,
                pageCategory: String,
                pageSubCategory: String,
                pageChannel: String = "mobile",
                language: String = "en",
                funnelName: String? = null,
                funnelStep: String? = null,
                funnelStepNAme: String? = null,
                eventAction: String? = null,
                eventCategory: String? = null,
                eventContent: String? = null) {
        Tealium.getInstance("DART").trackView(pageName, HashMap<String, String>().also {
            it["page_channel"] = pageChannel
            it["site_domain"] = BuildConfig.APPLICATION_ID
            it["site_region"] = "global"
            it["site_subregion"] = "global"
            it["site_country"] = "global"
            it["site_entity"] = "HSBC Bank Plc"
            it["site_brand"] = "HSBC"
            it["page_business_line"] = "GBM"
            it["page_customer_group"] = "Business"
            it["page_name"] = pageName
            it["page_url"] = pageURL
            it["page_language"] = language
            it["page_type"] = pageType
            it["page_category"] = pageCategory
            it["page_subcategory"] = pageSubCategory
            funnelName?.let { name ->
                it["funnel_name"] = name
            }
            funnelStep?.let{ step ->
                it["funnel_step"] = step
            }
            funnelStepNAme?.let { stepName ->
                it["funnel_step_name"] = stepName
            }
            eventAction?.let { eventAction ->
                it["event_action"] = eventAction
            }
            eventCategory?.let { eventCategory ->
                it["event_category"] = eventCategory
            }
            eventContent?.let { eventContent ->
                it["event_content"] = eventContent
            }
        })
    }

    fun pageRawTag(pageName: String, map: Map<String,String?>) {
        Tealium.getInstance("DART").trackView(pageName, map)
    }

    fun eventRawTag(eventAction: String, map: Map<String, String?>) {
        Tealium.getInstance("DART").trackEvent(eventAction, map)
    }
}