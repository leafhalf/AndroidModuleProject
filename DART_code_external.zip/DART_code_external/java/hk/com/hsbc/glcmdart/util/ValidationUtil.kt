/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.util

import java.util.regex.Pattern

object ValidationUtil {

    fun validatePassword(s: String): Boolean {
        return Pattern.compile("^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@_\\-'.])[A-Za-z0-9@_\\-'.]{8,30}").matcher(s).matches()
    }

    fun validateVersion(s: String, regex: String): Boolean {
        val subRegex = regex.replace("^","").replace("\$", "").replace("\\", "").split(".")
        val subVersion = s.split(".")
        if (subRegex.isEmpty() || subVersion.isEmpty()) {
            return false
        }

        for (i in subVersion.indices) {
            return if (subRegex[i].toInt() > subVersion[i].toInt()) {
                true
            } else if (subRegex[i].toInt() == subVersion[i].toInt()) {
                continue
            } else {
                false
            }
        }
        return false
    }
}