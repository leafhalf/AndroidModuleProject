package hk.com.hsbc.glcmdart.util

import java.security.SecureRandom
import javax.net.ssl.*
import java.security.cert.CertificateException
import java.security.cert.X509Certificate

object SSlUtiles {
    /**
     * 默认信任所有的证书
     *
     */
    fun createSSLSocketFactory(): SSLSocketFactory? {
        var sSLSocketFactory: SSLSocketFactory? = null
        try {
            val sc: SSLContext = SSLContext.getInstance("TLS")
            sc.init(null, arrayOf<TrustManager>(TrustAllManager()),
                    SecureRandom())
            sSLSocketFactory = sc.getSocketFactory()
        } catch (e: Exception) {
        }
        return sSLSocketFactory
    }

    class TrustAllManager : X509TrustManager {

        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        }

        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> {
            return arrayOf()
        }
    }

    class TrustAllHostnameVerifier : HostnameVerifier {
        override fun verify(hostname: String?, session: SSLSession?): Boolean {
            return true
        }
    }
}