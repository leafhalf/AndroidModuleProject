/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.util

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import hk.com.hsbc.glcmdart.domain.dart.CountryISO
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

object CountryUtil {

    fun getAllCountriesISOList(context: Context): List<CountryISO> {
        val allCountriesCodeStr: String
        val stringBuilder = StringBuilder()
        try {
            val ism = context.assets.open("CountryCode.json")
            val bufferedReader = BufferedReader(InputStreamReader(ism))
            var line: String?
            line = bufferedReader.readLine()
            while (line != null){
                stringBuilder.append(line)
                line = bufferedReader.readLine()
            }
        } catch (e: IOException) {
            return emptyList()
        }

        allCountriesCodeStr = stringBuilder.toString()
        return Gson().fromJson<List<CountryISO>>(allCountriesCodeStr, object : TypeToken<List<CountryISO>>() {
        }.type)
    }

    fun getFilterCountriesISOList(context: Context, filter: List<String>): List<CountryISO>? {
        val allCountryISO = getAllCountriesISOList(context)
        return try {
            allCountryISO.filter {
                filter.contains(it.countryCode)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}