/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import hk.com.hsbc.glcmdart.domain.dart.*

object RASPUtil {

    fun handleKeyboard() {
        val flag = MemoryCache.get(MemoryCache.KEYBOARD) as Boolean?
        val topActivity = ApplicationManager.getTopActivity()
        flag?.also {
            topActivity?.also {
                if (flag && topActivity !is KeyboardActivity) {
                    topActivity.startActivity(Intent(topActivity, KeyboardActivity::class.java))
                }
            }
        }
    }

    fun handleScreenCapture() {
        val topActivity = ApplicationManager.getTopActivity()
        val preFlag = MemoryCache.get(MemoryCache.PRE_SCREENREADER)as Boolean
        val flag = MemoryCache.get(MemoryCache.SCREENREADER)as Boolean
        topActivity?.also {
            if (it !is ScreenCaptureActivity) {
                if (flag && !preFlag) {
                    topActivity.startActivity(Intent(topActivity, ScreenCaptureActivity::class.java))
                }
            }
        }
    }

    fun handleDebugger() {
        val flag = MemoryCache.get(MemoryCache.DEBUGGER) as Boolean?
        val topActivity = ApplicationManager.getTopActivity()
        flag?.also {
            when {
                flag && topActivity == null -> {
                    val context = ApplicationManager.getContext()
                    val intent = Intent()
                    intent.setClass(context, DebuggerActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    val activity = PendingIntent.getActivity(context, 192837, intent, PendingIntent.FLAG_ONE_SHOT)
                    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000, activity)
                }
                flag && topActivity !is DebuggerActivity -> {
                    topActivity?.startActivity(Intent(topActivity, DebuggerActivity::class.java))
                }
            }
        }
    }

    fun handleLibraryInjection() {
        val a = MemoryCache.get(MemoryCache.HOOKING_FRAMEWORKS) as Boolean?
        val b = MemoryCache.get(MemoryCache.NATIVE_CODE_HOOKS) as Boolean?
        val flag = when {
            a != null && a -> true
            b != null && b -> true
            else -> false
        }
        val topActivity = ApplicationManager.getTopActivity()
        when {
            flag && topActivity == null -> {
                val context = ApplicationManager.getContext()
                val intent = Intent()
                intent.setClass(context, LibraryInjectionActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                val activity = PendingIntent.getActivity(context, 192837, intent, PendingIntent.FLAG_ONE_SHOT)
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000, activity)
            }
            flag && topActivity !is LibraryInjectionActivity -> {
                topActivity?.startActivity(Intent(topActivity, LibraryInjectionActivity::class.java))
            }
        }
    }

    fun handleEmulator() {
        val flag = MemoryCache.get(MemoryCache.EMULATOR) as Boolean?
        val topActivity = ApplicationManager.getTopActivity()
        flag?.also {
            when {
                flag && topActivity == null -> {
                    val context = ApplicationManager.getContext()
                    val intent = Intent()
                    intent.setClass(context, EmulatorActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    val activity = PendingIntent.getActivity(context, 192837, intent, PendingIntent.FLAG_ONE_SHOT)
                    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000, activity)
                }
                flag && topActivity !is EmulatorActivity -> {
                    topActivity?.startActivity(Intent(topActivity, EmulatorActivity::class.java))
                }
            }
        }
    }

    fun handleRooting() {
        val flag = MemoryCache.get(MemoryCache.ROOTING) as Boolean?
        val topActivity = ApplicationManager.getTopActivity()
        flag?.also {
            when {
                flag && topActivity == null -> {
                    val context = ApplicationManager.getContext()
                    val intent = Intent()
                    intent.setClass(context, RootingActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    val activity = PendingIntent.getActivity(context, 192837, intent, PendingIntent.FLAG_ONE_SHOT)
                    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000, activity)
                }
                flag && topActivity !is EmulatorActivity -> {
                    topActivity?.startActivity(Intent(topActivity, EmulatorActivity::class.java))
                }
            }
        }
    }

    fun handleRepackaging() {
        val flag = MemoryCache.get(MemoryCache.REPACKAGING) as Boolean?
        val topActivity = ApplicationManager.getTopActivity()
        flag?.also {
            when {
                flag && topActivity == null -> {
                    val context = ApplicationManager.getContext()
                    val intent = Intent()
                    intent.setClass(context, RepackagingActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    val activity = PendingIntent.getActivity(context, 192837, intent, PendingIntent.FLAG_ONE_SHOT)
                    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000, activity)
                }
                flag && topActivity !is EmulatorActivity -> {
                    topActivity?.startActivity(Intent(topActivity, EmulatorActivity::class.java))
                }
            }
        }
    }
}