package hk.com.hsbc.glcmdart.util

import org.json.JSONObject

object DynamicJsonUtil {
    fun deformatJsonOnce(str: String, res: MutableMap<String, Any?>) {
        if (str.indexOf(":") == -1) {
            return
        }
        val fromObject = JSONObject(str)
        val keys = fromObject.keys()
        while (keys.hasNext()) {
            val key = keys.next().toString()
            val value = fromObject.get(key)
            res[key] = value
        }
    }

    fun iteraJson(str: String, res: MutableMap<String, Any?>): Boolean {
        //因为json串中不一定有逗号，但是一定有：号，所以这里判断没有则已经value了
        if (str.indexOf(":") == -1) {
            return true
        }
        val fromObject = JSONObject(str)
        val keys = fromObject.keys()
        while (keys.hasNext()) {
            val key = keys.next().toString()
            val value = fromObject.get(key)
            if (iteraJson(value.toString(), res)) {
                res[key] = value
            }
        }
        return false
    }

    fun iteraJsonOrArray(source: String, map: MutableMap<String, Any?>): Boolean {
        if (source.indexOf(":") == -1) {
            return true
        }

        val fromObject = JSONObject(source)
        val keys = fromObject.keys()
        while (keys.hasNext()) {
            val key = keys.next().toString()
            val value = fromObject.get(key)
            val valStr = value.toString()
            if (valStr.indexOf("[{") == -1) {
                //说明不存在数组json即格式为："[{" 开头的数据。可以允许是[10,11,12]的非json数组
                if (valStr.indexOf(":") == -1 || valStr.matches(Regex("[\\d]{4}-[\\d]{2}-[\\d]{2}\\s[\\d]{2}:[\\d]{2}:[\\d]{2}"))) {
                    //当字符串中不存在：说明已经是值了，如果存在：也可能是日期类型的数据，所以用正则表达式匹配，如果是日期，就直接放入Map中
                    map[key] = valStr
                } else {
                    iteraJson(valStr, map)
                }
            } else if (valStr.indexOf("[{") != -1) {
                //说明存在数组json即格式为：[{开头的json数组
                if (valStr.indexOf("[{") == 0) {
                    //说明当前value就是一个json数组
                    // 去除[括号
                    var jsons = valStr.substring(1, valStr.lastIndexOf("]"))
                    //得到数据格式为：{...},{...},{...}
                    // 把上面得到jsons分割成数组
                    // 因为数据格式为{name:joker,age:20},{...},{...}，所以不能用逗号分割。否则会变"{name:joker" "age:20}"
                    // 使用正则表达式把},{替换成}|{
                    jsons = jsons.replace("\\}\\s?,\\s?\\{", "}|{")
                    val split = jsons.split("\\|")
                    val tmpList = mutableListOf<Any?>()
                    var tmpMap: MutableMap<String, Any?>?
                    for (i in 0 until split.size) {
                        tmpMap = mutableMapOf()
                        iteraJsonOrArray(split[i], tmpMap)
                        tmpList.add(tmpMap)
                    }
                    map[key] = tmpList
                }
            } else { //说明value可能是一个json，这个json中任然包含数组。例如：{inner:[{a:1,b:2,c:3}]}
                iteraJsonOrArray(valStr, map)
                //符合当前递归条件
            }
        }
        return false
    }
}