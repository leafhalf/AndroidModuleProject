/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.util

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*


/**
 * Created by Donut on 2018/10/24.
 */
object TimeZoneTransformsUtil {

    private val formatter = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
    private val dateParser = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val simpleDateParser = SimpleDateFormat("dd MM yyyy", Locale.US)

    fun transforms(utcTime: String): String? {
        val timeTmp = if (utcTime.contains("Z") || utcTime.contains("z")) {
            utcTime.replace("Z", "").replaceAfter("z", "")
        } else {
            utcTime
        }
        return transformByZone(timeTmp)
    }

//    private fun transformByZ(timeString: String): String? {
//
//        var finalUTCTime = ""
//        if (timeTmp.contains(".")) {
//            val utcTimeParts = timeTmp.split(".")
//            val millisecond = if (utcTimeParts[1].length < 3) {
//                (utcTimeParts[1] + "000").subSequence(0, 3)
//            } else {
//                utcTimeParts[1].subSequence(0, 3)
//            }
//            finalUTCTime = utcTimeParts[0] + "." + millisecond + "Z"
//        } else {
//            finalUTCTime = timeString
//        }
//        val utcFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")//UTC time format
//        utcFormatter.timeZone = TimeZone.getTimeZone("GMT+1")
//        val utcDate = try {
//            utcFormatter.parse(finalUTCTime)
//        } catch (e: ParseException) {
//            Date()
//        }
//
//        val localFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
//        TimeZone.getDefault()
//        localFormatter.timeZone = TimeZone.getDefault()
//        return localFormatter.format(utcDate.time)
////        } else {
////            val localFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
////            return localFormatter.format(Date())
////        }
//    }

    private fun transformByZone(timeString: String): String? {
        var finalUTCTime = ""
        val timeZone = timeString.subSequence(timeString.length - 6, timeString.length)
        val utcFormatter: SimpleDateFormat
        if (timeString.contains(".")) {
            val utcTimeParts = timeString.split(".")
            val millisecond = if (utcTimeParts[1].length < 3) {
                (utcTimeParts[1] + "000").subSequence(0, 3)
            } else {
                utcTimeParts[1].subSequence(0, 3)
            }
            finalUTCTime = utcTimeParts[0] + "." + millisecond + timeZone
            utcFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")//UTC time format
        } else {
            finalUTCTime = timeString
            utcFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
        }
//            utcFormatter.timeZone = TimeZone.getDefault()
        val utcDate = try {
            utcFormatter.parse(finalUTCTime)
        } catch (e: ParseException) {
            Date()
        }

        val baseMultiplier = if (timeZone.contains("+")) {
            val strArr = timeZone.subSequence(1, timeZone.length).split(":")
            strArr[0].toDouble() + strArr[1].toDouble() / 60
        } else if (timeZone.contains("-")) {
            val strArr = timeZone.subSequence(1, timeZone.length).split(":")
            -(strArr[0].toDouble() + strArr[1].toDouble() / 60)
        } else {
            1.0
        }
        val dateTime = (utcDate.time - baseMultiplier * 3600 * 1000 + TimeZone.getDefault().rawOffset).toLong()
        val resetDate = Date(dateTime)

        val localFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        localFormatter.timeZone = TimeZone.getDefault()
        return localFormatter.format(resetDate)
    }

    fun formatTime(date: String?): String {
        val parseDate = try {
            dateParser.parse(date)
        } catch (e: Exception) {
            Date()
        }
        return formatter.format(parseDate)
    }

    fun formatTimeInSimple(date: String?): String {
        val parseDate = try {
            dateParser.parse(date)
        } catch (e: Exception) {
            Date()
        }
        return simpleDateParser.format(parseDate)
    }

    fun formatTime(date: Date): String {
        return formatter.format(date)
    }

    fun formatParameterTime(date: Date): String {
        return dateParser.format(date)
    }

    fun calDaysBetween(fromDate: String?, toDate: String?): String {
        val tmpFromDate = if (fromDate.isNullOrBlank()) {
            dateParser.format(Date())
        } else {
            fromDate
        }

        val tmpToDate = if (toDate.isNullOrBlank()) {
            dateParser.format(Date())
        } else {
            toDate
        }

        val cal = Calendar.getInstance()
        cal.time = dateParser.parse(tmpFromDate)
        val time1 = cal.timeInMillis
        cal.time = dateParser.parse(tmpToDate)
        val time2 = cal.timeInMillis
        val days = (time2 - time1) / (1000 * 3600 * 24)
        return days.toString()
    }
}