/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.util

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.*

object DateUtil {

    fun stringConversionToTimestamp(date: String?): Long {
        val format = SimpleDateFormat("yyyy-MM-dd")
        format.isLenient = false
        val timestamp = Timestamp(format.parse(date).time)
        return timestamp.time
    }

    fun stringConversionToDate(date: String?): Date {
        val format = SimpleDateFormat("yyyy-MM-dd")
        format.isLenient = false
        return format.parse(date)
    }

    fun compareCurrentDate(date: String?): Boolean {
        val format = SimpleDateFormat("yyyy-MM-dd")
        format.isLenient = false
        return try {
            (format.parse(date).before(format.parse(format.format(Date())))) || (date == format.format(Date()))
        } catch (e: Exception) {
            false
        }
    }

    fun judgeDueDate(date: String?): Boolean {
        val format = SimpleDateFormat("yyyy-MM-dd")
        format.isLenient = false
        return try {
            format.parse(date).before(format.parse(format.format(Date())))
        } catch (e: Exception) {
            false
        }
    }

    fun isBeforeCurrentDate(date: String?): Boolean {
        val format = SimpleDateFormat("yyyy-MM-dd")
        format.isLenient = false
        return try {
            (format.parse(date)).before(format.parse(format.format(Date())))
        } catch (e: Exception) {
            false
        }
    }

    fun getDateStrBySimpleDateFormate(date: Date): String {
        val format = SimpleDateFormat("yyyy-MM-dd")
        format.isLenient = false
        return format.format(date)
    }

    fun countDaysWithToday(date: String?): Int {
        val format = SimpleDateFormat("yyyy-MM-dd")
        format.isLenient = false
        return try {
            val count = (((format.parse(format.format(Date()))).time) - (format.parse(date).time)) / (1000 * 3600 * 24)
            count.toInt()
        } catch (e: Exception) {
            0
        }
    }

    fun getLocalTodayDate(): String {
        val format = SimpleDateFormat("yyyy-MM-dd")
        format.isLenient = false
        return format.format(Date())
    }
}