/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.util

import hk.com.hsbc.glcmdart.client.VALUE_CURRENCY_LANGUAGE
import java.text.NumberFormat
import java.util.*

/**
 * Created by Donut on 2018/10/24.
 */
object IndiaNumberUtil {

    /**
     * format num to Location Number System, input parameter is string, can contain dot
     * caution: just split one decimal symbol, not check multi
     */
    fun formatNum(number: String, currencyCode: String): String {
        val initialNum = if (number.isBlank()) "0" else number.toBigDecimal().toPlainString()
        val tmpCurrencyCode = if (currencyCode.isBlank()) {
            MemoryCache.defaultCurrency
        } else {
            currencyCode
        }
        //find language for currency, find from script list
        val language = VALUE_CURRENCY_LANGUAGE[tmpCurrencyCode]
        val numFormatter = Locale(language).let {
            val formatter = NumberFormat.getCurrencyInstance(it)
            formatter.currency = Currency.getInstance(tmpCurrencyCode)
            formatter
        }

        //check existence of not number char and minus symbol, ASCII 45 '-', ASCII 48~57 '0~9'
        var tmpNum = initialNum
        var endIndex: Int
        //not number char index, init by length
        endIndex = tmpNum.length
        val reversedTmpNum = tmpNum.reversed()
        for (c in reversedTmpNum) {
            if (c.toByte() !in 48..57) {
                if (c.toByte() !in 45..45) {
                    break
                }
            }

            endIndex--
        }
        //get integer part
        if (endIndex != 0) {
            tmpNum = tmpNum.substring(0, endIndex)
        }
        //get decimal part
        var littleNum = if (endIndex > 0) number.substring(endIndex, number.length) else "0"
        val isHasLittleNum = littleNum.toFloat() > 0
        if (littleNum.length == 1) {
            littleNum += "0"
        }
        //clear thousand depart symbol, seems no need to do so in current single splitting mode
        if (number.contains(",")) {
            tmpNum = tmpNum.replace(",","")
        }
        if (tmpNum.contains(".")) {
            tmpNum = tmpNum.replace(".","")
        }
        if (tmpNum.contains(" ")) {
            tmpNum = tmpNum.replace(" ","")
        }

        if (tmpNum.isNullOrBlank()) {
            tmpNum = "0"
        }
        //default result = integer part
        val tmpResult = numFormatter.format(tmpNum.toBigDecimal())
        var numIndex = 0
        //check minus symbol
        var isHasMinus = false
        if (number[0].toByte() in 45..45) {
            isHasMinus = true
        }
        for (c in tmpResult) {
            if (c.toByte() in 48..57) {
                break
            }
            numIndex++
        }

        return if (tmpResult[tmpResult.length - 1].toByte() in 48..57) {
            if (isHasMinus) {
                if (isHasLittleNum) {
                    "-" + tmpResult.substring(numIndex, tmpResult.length - 2) + littleNum
                } else {
                    "-" + tmpResult.substring(numIndex)
                }
            } else {
                if (isHasLittleNum) {
                    tmpResult.substring(numIndex, tmpResult.length - 2) + littleNum
                } else {
                    tmpResult.substring(numIndex)
                }
            }
        } else {
            endIndex = tmpResult.length
            val reversedTmpResult = tmpResult.reversed()
            for (c in reversedTmpResult) {
                if (c.toByte() in 48..57) {
                    break
                }

                endIndex--
            }

            if (isHasMinus) {
                if (isHasLittleNum) {
                    "-" + tmpResult.substring(numIndex, endIndex - 2) + littleNum
                } else {
                    "-" + tmpResult.substring(numIndex, endIndex)
                }
            } else {
                if (isHasLittleNum) {
                    tmpResult.substring(numIndex, endIndex - 2) + littleNum
                } else {
                    tmpResult.substring(numIndex, endIndex)
                }
            }
        }
    }

    fun formatNumByDecimal(number: String, currency: String): String {
        return if (number.isEmpty()) {
            "0.00"
        } else {

            formatNum(MemoryCache.globalDecimal.format(number.toBigDecimal().divide(100.00.toBigDecimal())), currency)
        }
    }
}