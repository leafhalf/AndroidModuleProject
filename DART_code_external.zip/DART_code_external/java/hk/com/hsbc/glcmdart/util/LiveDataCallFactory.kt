package hk.com.hsbc.glcmdart.util

import androidx.lifecycle.LiveData
import retrofit2.*
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Type
import java.util.concurrent.atomic.AtomicBoolean

class LiveDataCallFactory: CallAdapter.Factory() {

    override fun get(returnType: Type, annotations: Array<Annotation>, retrofit: Retrofit): CallAdapter<*, *>? {
        require(returnType is ParameterizedType) { "return type must be parameterized type!" }

        val returnTypeClass = getRawType(returnType)
        require(returnTypeClass == LiveData::class.java) { "return type is not live data class!" }

        val type = getParameterUpperBound(0, returnType)
        return LiveDataCallAdapter<Any>(type)
    }
}

class LiveDataCallAdapter<T>(var type: Type): CallAdapter<T, LiveData<T>> {

    override fun adapt(call: Call<T>): LiveData<T> {
        return object: LiveData<T>() {
            val flag = AtomicBoolean(false)
            override fun onActive() {
                super.onActive()
                if (flag.compareAndSet(false, true)) {
                    call.enqueue(object: Callback<T> {

                        override fun onFailure(call: Call<T>, t: Throwable) {
                            postValue(null)
                        }

                        override fun onResponse(call: Call<T>, response: Response<T>) {
                            postValue(response.body())
                        }
                    })
                }
            }
        }
    }

    override fun responseType(): Type {
        return type
    }

}