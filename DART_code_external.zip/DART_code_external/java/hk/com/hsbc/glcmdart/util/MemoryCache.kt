/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.util

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.*
import hk.com.hsbc.glcmdart.domain.dashboard.ProfileDetailEntity
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListEntity
import hk.com.hsbc.glcmdart.domain.login.LoginEntity
import hk.com.hsbc.glcmdart.domain.login.ProfileEntity
import hk.com.hsbc.glcmdart.domain.login.SessionInfo
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.text.DecimalFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import kotlin.collections.LinkedHashMap

object MemoryCache {

    private val map = mutableMapOf<String, Any?>()
    private var localISOCountriesList: List<CountryISO>? = null
    var defaultCurrency: String? = MARKET_CURRENCY
    var defaultCountry: String? = MARKET_COUNTRY
//    var defaultLanguage: String? = GLOBAL_LANGUAGE
    var defaultLanguageFull: String? = "en-id"
    var bankCode = ""
    val globalDecimal = DecimalFormat("0.00")
    //for extension
    var valueLanguage = mutableListOf<String>()
    private var stringMap = mutableMapOf<String, String>()

    var initInvoiceList: InvoiceListEntity? = null
    var initITPList: PlannedPaymentListPayload? = null

    var departmentName = mutableListOf<String>()
    // for deduction active state (enable or disable)
    var deductionsActive: Boolean? = false
    var dcmsActive: Boolean? = false

    fun save(key: String, value: Any?) {
        map[key] = value
    }

    fun get(key: String): Any? {
        return map[key]
    }

    fun remove(key: String) {
        if (map.containsKey(key)) map.remove(key)
    }

    fun clear() {
        map.clear()
    }

    fun isEmpty(): Boolean {
        return map.isEmpty()
    }

    private const val KEY_AMTOKEN = "AMTOKEN"
    private const val KEY_I8TOKEN = "I8TOKEN"
    private const val KEY_LOGIN_ENTITY = "LOGIN_ENTITY"
    private const val KEY_PROFILE_ENTITY = "PROFILE_ENTITY"
    private const val KEY_ORGANISATIONS_ENTITY = "ORGANISATIONS_ENTITY"
    private const val KEY_PROFILE_DTAIL = "PROFILE_DETAIL"

    private const val KEY_CHANNEL_ID = "CHANNELID"
    private const val KEY_CURRENCY_MAP = "CURRENCYMAP"
    private const val KEY_DEDUCTION = "DEDUCTION_MAP"

    /* RASP */
    const val ROOTING = "ROOTING"
    const val REPACKAGING = "REPACKAGING"
    const val EMULATOR = "EMULATOR"
    const val DEBUGGER = "DEBUGGER"
    const val KEYBOARD = "KEYBOARD"
    const val PRE_SCREENREADER = "PRE_SCREENREADER"
    const val SCREENREADER = "SCREENREADER"
    const val NATIVE_CODE_HOOKS = "NATIVE_CODE_HOOKS"
    const val HOOKING_FRAMEWORKS = "HOOKING_FRAMEWORKS"
    const val FOREGROUND_OVERRIDE = "FOREGROUND_OVERRIDE"
    const val FILESYSTEM_SCANNING = "FILESYSTEM_SCANNING"
    const val FILESYSTEM_WATCHING = "FILESYSTEM_WATCHING"
    const val SCREEN_MIRRORING = "SCREEN_MIRRORING"
    const val VERSION_UPDATE = "VERSION_UPDATE"

    fun saveChannelId(value: String?) {
        map[KEY_CHANNEL_ID] = value
    }

    fun getChannelId(): String? {
        return map[KEY_CHANNEL_ID] as String?
    }

    fun saveVersionUpdate(value: VersionUpdateEntity) {
        map[VERSION_UPDATE] = value
    }

    fun getVersionUpdate(): VersionUpdateEntity? {
        return map[VERSION_UPDATE] as VersionUpdateEntity?
    }

    fun saveAMToken(value: String) {
        map[KEY_AMTOKEN] = value
    }

    fun getAMToken(): String? {
        return map[KEY_AMTOKEN] as String?
    }

    fun saveI8Token(value: String) {
        map[KEY_I8TOKEN] = value
    }

    fun getI8Token(): String? {
        return map[KEY_I8TOKEN] as String?
    }

    fun saveLoginEntity(value: LoginEntity) {
        map[KEY_LOGIN_ENTITY] = value
    }

    fun getLoginEntity(): LoginEntity? {
        return map[KEY_LOGIN_ENTITY] as LoginEntity?
    }

    fun getSessionEntity(): SessionInfo? {
        return getLoginEntity()?.payload?.SessionInfo
    }

    fun saveProfile(value: ProfileEntity?) {
        map[KEY_PROFILE_ENTITY] = value
    }

    fun getProfile(): ProfileEntity? {
        return map[KEY_PROFILE_ENTITY] as ProfileEntity?
    }

    fun saveOrganisations(value: PayeeEntity?) {
        map[KEY_ORGANISATIONS_ENTITY] = value
    }

    fun saveProfileDetail(value: ProfileDetailEntity?) {
        map[KEY_PROFILE_DTAIL] = value
    }

    fun getProfileDetail(): ProfileDetailEntity? {
        return map[KEY_PROFILE_DTAIL] as ProfileDetailEntity?
    }

    fun getOrganisations(): PayeeEntity? {
        return map[KEY_ORGANISATIONS_ENTITY] as PayeeEntity?
    }

    fun getOrganisationsMap(): Map<String, Payee> {
        val organizationsMap = mutableMapOf<String, Payee>()
        val organizations = getOrganisations()
        if (organizations != null) {
            if ("S" == getSessionEntity()?.type) {
                if (!organizations.payload.payors.isNullOrEmpty()) {
                    for (item in organizations.payload.payors) {
                        organizationsMap[item.reference ?: ""] = item
                    }
                }
            } else {
                if (!organizations.payload.payees.isNullOrEmpty()) {
                    for (item in organizations.payload.payees) {
                        organizationsMap[item.reference ?: ""] = item
                    }
                }
            }
        }
        return organizationsMap
    }

    fun saveCurrencyMap(currencies: Map<String, MutableList<String>?>) {
        map[KEY_CURRENCY_MAP] = currencies
    }

    fun getCurrencyMap(): Map<String, MutableList<String>> {
        return map[KEY_CURRENCY_MAP] as Map<String, MutableList<String>>
    }

    fun getLocalISOCurrencyList(): List<CountryISO> {
        if (localISOCountriesList == null) {
            val stringBuilder = StringBuilder()
            try {
                val fileIs = ApplicationManager.getContext().assets?.open("CountryCode.json")
                val bufferedReader = BufferedReader(InputStreamReader(fileIs))
                var line: String?
                while (true) {
                    line = bufferedReader.readLine() ?: break
                    stringBuilder.append(line)
                }
                bufferedReader.close()
                val localISOCurrencyStr = stringBuilder.toString()
                localISOCountriesList = Gson().fromJson(
                        localISOCurrencyStr,
                        object : TypeToken<List<CountryISO>>() {}.type
                )
            } catch (e: IOException) {
                // e.printStackTrace()
                return mutableListOf()
            }
        }
        return localISOCountriesList ?: mutableListOf()
    }

    fun getInvoiceExtraLabelObject(languageCode: String = ""): InvoiceExtraLabels {
        val tmpLanguageCode = if (languageCode.isBlank()) defaultLanguageFull else languageCode.toLowerCase()
        val fileName = when (tmpLanguageCode) {
            "en-hk" -> "invoice-extra-en-hk.json"
            "en-id" -> "invoice-extra-en-id.json"
            "en-in" -> "invoice-extra-en-in.json"
            "id-id" -> "invoice-extra-id-id.json"
            "zh-ch" -> "invoice-extra-zh-ch.json"
            "zh-hk" -> "invoice-extra-zh-hk.json"
            else -> "invoice-extra-en-in.json"
        }
        val stringBuilder = StringBuilder()
        try {
            val fileIs = ApplicationManager.getContext().assets?.open(fileName)
            val bufferedReader = BufferedReader(InputStreamReader(fileIs))
            var line: String?
            while (true) {
                line = bufferedReader.readLine() ?: break
                stringBuilder.append(line)
            }
            bufferedReader.close()
            val localISOCurrencyStr = stringBuilder.toString()
            return Gson().fromJson(
                    localISOCurrencyStr,
                    object : TypeToken<InvoiceExtraLabels>() {}.type
            )
        } catch (e: IOException) {
            // e.printStackTrace()
            return InvoiceExtraLabels(
                    SupplierAddressLabel("", "", ""),
                    BuyerAddressLabel("", "", ""),
                    ChargesLabel("", "", "", "", "", "", "", ""),
                    EwayLabel("", EwayHeading("", "", "", "")),
                    GSTNLabel("", GSTNHeading("", "", "", ""))
            )
        }
    }

    fun getLanguage(countryCode: String): String {
        for (item in getLocalISOCurrencyList()) {
            if (item.countryCode == countryCode) {
                return item.language
            }
        }
        return ""
    }


    fun getLabelText(key: String): String? {
        if (stringMap.isEmpty()) {
            return null
        }

        return stringMap[key]
    }

    fun saveStringsMap(language: String, rawStrings: String) {
        val tmpMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce(rawStrings, tmpMap)
        if (map[language] == null) {
            map[language] = tmpMap
        }
    }

    //return language map has been cache, equal change language success or not
    fun changeLanguage(language: String, countryCode: String = MARKET_COUNTRY): Boolean {
        var hasCache = false
        map[language]?.let {
            hasCache = true
            try {
                stringMap = it as MutableMap<String, String>
//                defaultLanguage = language
                //change country please change here as well
                defaultLanguageFull = language
            } catch (e: Exception) {
                return false
            }
        }
        return hasCache
    }

    fun getACHLimitation(context: Context, currency: String): Int {
        val configMap = mutableMapOf<String, Any?>()
        val savedConfiguration = context.getSharedPreferences(DartApplication.instance?.applicationInfo?.packageName, Context.MODE_PRIVATE)
                .getString(TAG_COUNTRY_CONFIGURATION, "")
        DynamicJsonUtil.deformatJsonOnce(savedConfiguration ?: "", configMap)
        val countryInfoMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((configMap[defaultCountry?.toLowerCase()] as JSONObject).toString(), countryInfoMap)
        val paymentMethodMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((countryInfoMap["payment_methods"] as JSONObject).toString(), paymentMethodMap)
        val paymentMethodCurrencyMAp = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((paymentMethodMap[currency] as JSONObject).toString(), paymentMethodCurrencyMAp)
        val achMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((paymentMethodCurrencyMAp["ach"] as JSONObject).toString(), achMap)
        return if (achMap.isNotEmpty()) {
            achMap["hours_before_payment_date"].toString().toInt()
        } else {
            48
        }
    }

    fun updateCountryInfo(countryConfiguration: String, language: String?) {
        val configMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce(countryConfiguration, configMap)
        val countryInfoMap = mutableMapOf<String, Any?>()
        if (configMap[defaultCountry?.toLowerCase(Locale.getDefault())] == null) {
            DynamicJsonUtil.deformatJsonOnce((configMap["in"] as JSONObject).toString(), countryInfoMap)
        } else {
            DynamicJsonUtil.deformatJsonOnce((configMap[defaultCountry?.toLowerCase(Locale.getDefault())] as JSONObject).toString(), countryInfoMap)
        }
//        val paymentMethodConfigMap = mutableMapOf<String, Any?>()
//        DynamicJsonUtil.deformatJsonOnce((countryInfoMap["payment_methods"] as JSONObject).toString(), paymentMethodConfigMap)
        val currencyMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((countryInfoMap["currency"] as JSONObject).toString(), currencyMap)
        defaultCurrency = currencyMap["default"].toString()
        bankCode = countryInfoMap["bankcode"].toString()
        val languageMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((countryInfoMap["language"] as JSONObject).toString(), languageMap)
        val originValueLanguage = languageMap["available"].toString()
        if (language == null) {
//            defaultLanguage = languageMap["default"].toString().substring(0, 2)
            defaultLanguageFull = languageMap["default"].toString()
        } else {
//            defaultLanguage = language
            defaultLanguageFull = language
            if (!originValueLanguage.contains(defaultLanguageFull!!)) {
//                defaultLanguage = languageMap["default"].toString().substring(0, 2)
                defaultLanguageFull = languageMap["default"].toString()
            }
        }

        val valueLanguageRawArray = originValueLanguage.split(",")
        if (valueLanguageRawArray.isNotEmpty()) {
            valueLanguage.clear()
            valueLanguageRawArray.forEach {
                var tmpStr = it.replace("[", "")
                tmpStr = tmpStr.replace("]", "")
                valueLanguage.add(tmpStr.substring(1, 3))
            }
        }
        //get deductions active configuration
        if (countryInfoMap.containsKey("deductions")) {
            val deductionsMap = mutableMapOf<String, Any?>()
            DynamicJsonUtil.deformatJsonOnce((countryInfoMap["deductions"] as JSONObject).toString(), deductionsMap)
            deductionsActive = deductionsMap["active"] as Boolean?
        }
    }

    fun checkDCMSEnable(context: Context?, currency: String?): Boolean {
        val savedConfiguration = context?.getSharedPreferences(DartApplication.instance?.applicationInfo?.packageName, Context.MODE_PRIVATE)
                ?.getString(TAG_COUNTRY_CONFIGURATION, "")
        val configMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce(savedConfiguration!!, configMap)
        val countryInfoMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((configMap[defaultCountry?.toLowerCase()] as JSONObject).toString(), countryInfoMap)
        val paymentMethodMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((countryInfoMap["payment_methods"] as JSONObject).toString(), paymentMethodMap)
        val currencyMethodMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((paymentMethodMap[currency ?: MARKET_CURRENCY] as JSONObject).toString(), currencyMethodMap)
        return if (currencyMethodMap.containsKey("dcms")) {
            val dcmsMap = mutableMapOf<String, Any?>()
            DynamicJsonUtil.deformatJsonOnce((currencyMethodMap["dcms"] as JSONObject).toString(), dcmsMap)
            dcmsMap["active"] as Boolean
        } else {
            false
        }
    }

    fun getPaymentChannelName(context: Context, channelCode: String?): String? {
        if (channelCode.isNullOrBlank()) {
            return null
        }
        val savedConfiguration = context.getSharedPreferences(DartApplication.instance?.applicationInfo?.packageName, Context.MODE_PRIVATE)
                .getString(TAG_COUNTRY_CONFIGURATION, "")
        val configMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce(savedConfiguration!!, configMap)
        val countryInfoMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((configMap[defaultCountry?.toLowerCase()] as JSONObject).toString(), countryInfoMap)
        val channelMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((countryInfoMap["payment_channel_code"] as JSONObject).toString(), channelMap)
        return channelMap[channelCode] as String?
    }

    fun getVABankNameMap(context: Context, code: String): String? {
        val savedConfiguration = context.getSharedPreferences(DartApplication.instance?.applicationInfo?.packageName, Context.MODE_PRIVATE)
                .getString(TAG_COUNTRY_CONFIGURATION, "")
        val configMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce(savedConfiguration!!, configMap)
        val countryInfoMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((configMap[defaultCountry?.toLowerCase()] as JSONObject).toString(), countryInfoMap)
        val vaBankMap = mutableMapOf<String, Any?>()
        DynamicJsonUtil.deformatJsonOnce((countryInfoMap["va_bank_name"] as JSONObject).toString(), vaBankMap)
        return vaBankMap[code] as String?
    }

    fun getPaymentMethodLabelsMap(): LinkedHashMap<String, String> {
        return when (defaultLanguageFull) {
            "en-in" -> VALUE_PAYMENTMETHOD_EN_IN_LABELS
            "en-hk" -> VALUE_PAYMENTMETHOD_EN_HK_LABELS
            "zh-hk" -> VALUE_PAYMENTMETHOD_ZH_HK_LABELS
            "zh-ch" -> VALUE_PAYMENTMETHOD_ZH_CH_LABELS
            "id-id" -> VALUE_PAYMENTMETHOD_ID_ID_LABELS
            "en-id" -> VALUE_PAYMENTMETHOD_EN_ID_LABELS
            else -> VALUE_PAYMENTMETHOD_EN_IN_LABELS
        }
    }

    fun getInvoiceStatusLabelsMap(): LinkedHashMap<String, String> {
        return if (defaultLanguageFull?.startsWith("en") != false) VALUE_PAY_EN_STATUS else VALUE_PAY_ID_STATUS
    }

    fun getPaymentStatusLabelsMap(): LinkedHashMap<String, String> {
        return if (defaultLanguageFull?.startsWith("en") != false) VALUE_PAYMENT_EN_STATUS else VALUE_PAYMENT_ID_STATUS
    }

    fun getCreditNoteStatusLabelsMap(): LinkedHashMap<String, String> {
        return if (defaultLanguageFull?.startsWith("en") != false) VALUE_CREDITNOTES_EN_STATUS else VALUE_CREDITNOTES_ID_STATUS
    }

    fun saveDeductionsMap(deductions: HashMap<String, ArrayList<TaxDeductionInfo>?>?) {
        map[KEY_DEDUCTION] = deductions
    }

    fun getCachedDeduction(): HashMap<String, ArrayList<TaxDeductionInfo>?>? = map[KEY_DEDUCTION] as HashMap<String, ArrayList<TaxDeductionInfo>?>?
}