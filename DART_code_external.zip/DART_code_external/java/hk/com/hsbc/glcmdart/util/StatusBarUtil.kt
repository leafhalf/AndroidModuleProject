/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.util

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.R
import java.util.*

/**
 * Created by Donut.
 */

object StatusBarUtil {

    private const val KEY_MIUI_VERSION_CODE = "ro.miui.ui.version.code"
    private const val KEY_MIUI_VERSION_NAME = "ro.miui.ui.version.name"
    private const val KEY_MIUI_INTERNAL_STORAGE = "ro.miui.internal.storage"

    /**
     * is XIAOMI OS
     */
    val isMIUI: Boolean
        get() {
            val prop = Properties()
            return (prop.getProperty(KEY_MIUI_VERSION_CODE, null) != null
                    || prop.getProperty(KEY_MIUI_VERSION_NAME, null) != null
                    || prop.getProperty(KEY_MIUI_INTERNAL_STORAGE, null) != null)
        }

    /**
     * is MEIZU OS
     */
    // Invoke Build.hasSmartBar()
    val isFlyme: Boolean
        get() {
            return try {
                val method = Build::class.java.getMethod("hasSmartBar")
                TextUtils.equals("Meizu", Build.MANUFACTURER)
            } catch (e: Exception) {
                TextUtils.equals("Meizu", Build.MANUFACTURER)
            }

        }

    /**
     * get status bar height
     */
    @SuppressLint("PrivateApi")
    fun getStatusBarHeight(context: Context): Int {
        try {
            val c = Class.forName("com.android.internal.R\$dimen")
            val obj = c.newInstance()
            val field = c.getField("status_bar_height")
            val x = Integer.parseInt(field.get(obj).toString())
            return context.resources.getDimensionPixelSize(x)
        } catch (e: Exception) {
            // e.printStackTrace()
        }

        return 0
    }

    /**
     * set status bar in transparent with theme or not
     */
    fun setTransparentStatusBar(activity: Activity, useThemeColor: Boolean) {
        val window = activity.window
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            val option = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            window.decorView.systemUiVisibility = option
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            if (useThemeColor) {
                activity.window.statusBarColor = ContextCompat.getColor(activity, R.color.primary_black)
            } else {
                activity.window.statusBarColor = Color.TRANSPARENT
            }
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        }
    }

    /**
     * set status bar in color and not in dark mode or not
     */
    fun setStatusBar(activity: Activity, useThemestatusBarColor: Boolean, withoutUseStatusBarColor: Boolean) {
        setTransparentStatusBar(activity, useThemestatusBarColor)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !withoutUseStatusBarColor) {
            activity.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
    }


    /**
     * change MEIZU OS status bar font color in back or white
     */
    private fun processFlyme(activity: Activity, darkmode: Boolean) {
        val window = activity.window
        if (window != null) {
            try {
                val lp = window.attributes
                val darkFlag = WindowManager.LayoutParams::class.java
                        .getDeclaredField("MEIZU_FLAG_DARK_STATUS_BAR_ICON")
                val meizuFlags = WindowManager.LayoutParams::class.java
                        .getDeclaredField("meizuFlags")
                darkFlag.isAccessible = true
                meizuFlags.isAccessible = true
                val bit = darkFlag.getInt(null as Any?)
                var value = meizuFlags.getInt(lp)
                if (darkmode) {
                    value = value or bit
                } else {
                    value = value and bit.inv()
                }

                meizuFlags.setInt(lp, value)
                window.attributes = lp
            } catch (var8: Exception) {
                if (BuildConfig.DEBUG) Log.w("StatusBarUtils", "setStatusBarDarkIcon: failed")
            }

        }
    }

    /**
     * change XIAOMI OS status bar font color in black or white
     */
    private fun processMIUI(activity: Activity, darkmode: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            compatHighMIUI(activity, darkmode)
        } else {
            compatLowMIUI(activity, darkmode)
        }
    }

    /**
     * high version XIAOMI OS operation
     */
    @TargetApi(Build.VERSION_CODES.M)
    private fun compatHighMIUI(activity: Activity, darkmode: Boolean) {
        val decorView = activity.window.decorView
        if (darkmode) {
            decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            val flag = decorView.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            decorView.systemUiVisibility = flag
        }
    }

    /**
     * low version XIAOMI OS operation
     */
    @SuppressLint("PrivateApi")
    private fun compatLowMIUI(activity: Activity, darkmode: Boolean) {
        val clazz = activity.window.javaClass
        try {
            val darkModeFlag: Int
            val layoutParams = Class.forName("android.view.MiuiWindowManager\$LayoutParams")
            val field = layoutParams.getField("EXTRA_FLAG_STATUS_BAR_DARK_MODE")
            darkModeFlag = field.getInt(layoutParams)
            val extraFlagField = clazz.getMethod("setExtraFlags", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            extraFlagField.invoke(activity.window, if (darkmode) darkModeFlag else 0, darkModeFlag)
        } catch (e: Exception) {
            // e.printStackTrace()
        }

    }

    /**
     * set status bar font in dark mode
     */
    fun setStatusTextColor(useDart: Boolean, activity: Activity) {
        when {
            isFlyme -> processFlyme(activity, useDart)
            isMIUI -> processMIUI(activity, useDart)
            else -> {
                if (useDart) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        activity.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    }
                } else {
                    activity.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                }
                activity.window.decorView.findViewById<View>(android.R.id.content).setPadding(0, 0, 0, 0)
            }
        }
    }

    fun setWindowStatusBarColor(activity: Activity, colorResId: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val window = activity.window
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                window.statusBarColor = colorResId
            }
        } catch (e: Exception) {
            if (BuildConfig.DEBUG) {
                // e.printStackTrace()
            }
        }
    }
}
