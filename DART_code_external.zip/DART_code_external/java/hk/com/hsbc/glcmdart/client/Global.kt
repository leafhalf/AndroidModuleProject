/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.client

import hk.com.hsbc.glcmdart.BuildConfig

const val MARKET_COUNTRY = "IN"
const val MARKET_CURRENCY = "INR"
const val GLOBAL_LANGUAGE = "en-in"
const val API_VERSION = "v20210215"
//const val API_VERSION = "v20201214"
//const val API_VERSION = "v20201016"
//const val API_VERSION = "v20200810"
//const val API_VERSION = "v20200228"
//const val API_VERSION = "v1"
const val INVOICE = "invoice"
const val CREDITNOTE = "creditNote"
const val DEDUCTION = "deduction"

const val HOST_URL_ = "https://www.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/"
const val HOST_URL_CONSENT_ = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/"
const val HOST_URL = "https://www.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/mobile/"
const val HOST_URL_CONSENT = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/mobile/"
var ACKNOWLEDGE_OF_3RD_PARTY_SOFTWARE = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/Acknowledgement.html"
var PRIVACY_AND_DATA_STATIC_URL = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/privacy-data-protection.html"
var COOKIE_POLICY_STATIC_URL = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/cookie-policy.html"
var EULA_STATIC_URL = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/EULA.html"
var EULA_SUPPLIER_STATIC_URL = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/supplier-terms.html"
var ACKNOWLEDGEMENT_STATIC_URL = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/Acknowledgement.html"
const val CONFIGURATION_STATIC_URL = "static/ID/config.json"
const val VERSION_UPDATE = "static/version_update.json"
const val PAGINATION_PER_PAGE = 15
const val TUTORIAL_LINK_PREFIX = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/"
var FAQ_BUYER_STATIC_URL = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/FAQBuyer.html"
var FAQ_SUPPLIER_STATIC_URL = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/FAQSupplier.html"
var TERMS_AND_CONDITIONS_STATIC_URL = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/TandC.html"
var TERMS_AND_CONDITIONS_SUPPLIER_STATIC_URL = "https://consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com/static/{country}/{language}/TandC_Supplier.html"
const val GOOGLE_PLAY_DART = "https://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}"
/***********     request url begin    *****************/

const val URL_INVOICE_LIST = "sapi/$API_VERSION/invoices"
const val URL_INVOICE_LIST_OVERDUE = "sapi/$API_VERSION/invoices/calendar"
const val URL_INVOICE_DETAIL = "sapi/$API_VERSION/invoices/{token}"
const val URL_INVOICE_DETAIL_TIME_LINE = "sapi/$API_VERSION/invoices/{token}/timeline"

const val URL_PLANNED_PAYMENT_LIST = "sapi/$API_VERSION/planned-payments"
const val URL_PAYMENT_METHODS = "sapi/$API_VERSION/payment-methods"
const val URL_BANK_CALENDAR = "sapi/$API_VERSION/bank-calendar"
const val URL_ITP_VALIDATE = "$URL_PLANNED_PAYMENT_LIST/validate"
const val URL_CREATE_ITP = "$URL_PLANNED_PAYMENT_LIST/create"
const val URL_CREDIT_NOTES = "sapi/$API_VERSION/creditnotes"
const val URL_ITP_REVOKE = "$URL_PLANNED_PAYMENT_LIST/revoke"
const val URL_UPDATE_ITP = "$URL_PLANNED_PAYMENT_LIST/update"
const val URL_PAYMENT_GATEWAY_REDIRECT = "sapi/$API_VERSION/planned-payments/pay/{token}"
const val URL_PAYMENT_GATEWAY_TRACK = "sapi/$API_VERSION/planned-payments/pay/{token}/track-payment"
const val URL_GET_DEDUCTION_LIST = "sapi/$API_VERSION/deductions/{payeeReference}/{countryCode}/{payeeAccountRef}"

const val URL_CALENDAR = "receivables/api/invoice/calendar"
const val URL_OVERDUE_CALENDAR = "receivables/api/invoice/calendar/overdue"

const val URL_REGISTRATIOM_SUPPLIER_DETAIL = "api/$API_VERSION/register/invitation/{invitation}"
const val URL_REGISTRATIOM_SECURE_QUESTIONS = "api/$API_VERSION/register/challenge/{invitation}"
const val URL_REGISTRATIOM_RECOVERY_QUESTIONS = "api/$API_VERSION/register/recovery"
const val URL_REGISTRATIOM_CHECK_USER_NAME = "api/$API_VERSION/register/account/check/{invitation}"
const val URL_REGISTRATIOM_CREATE_PROFILE = "api/$API_VERSION/register/account/create/{invitation}"
const val URL_REGISTRATION_EXPIRED_CODE_RECOVER = "api/$API_VERSION/recover/invitation/{invitation}"

const val URL_MORE_MY_PROFILE = "auth/me/details"
const val URL_MORE_HELP = "api/$API_VERSION/help"
const val URL_MORE_BUYER = "sapi/$API_VERSION/users"

const val URL_FORGET_PASSWORD_CHECK_USERNAME = "api/$API_VERSION/passwordreset/check"
const val URL_FORGET_PASSWORD_RESET = "api/$API_VERSION/passwordreset/new"
const val URL_FORGET_USERNAME_SECURE_QUESTIONS = "api/$API_VERSION/recover/challenge/{invitation}"

const val URL_LOGIN = "api/$API_VERSION/login"
const val URL_SESSION = "sapi/$API_VERSION/session"
const val URL_PROFILE = "sapi/$API_VERSION/profile"
const val URL_PROFILE_DETAIL = "$URL_PROFILE/details"
const val URL_ORGANISATIONS = "sapi/$API_VERSION/organisations"
const val URL_UPLOAD_URBAN_AIRSHIP = "sapi/$API_VERSION/push/users"
const val URL_DETACH_URBAN_AIRSHIP = "sapi/$API_VERSION/push/users/{userId}"

const val URL_HOME_FRAGMENT_CHANNEL = "sapi/$API_VERSION/dashboard/paymentchannels"
const val URL_HOME_INVOICES_WITH_STATUS = "sapi/$API_VERSION/dashboard/invoices/status"
const val URL_HOME_INVOICES_SUMMARY = "sapi/$API_VERSION/dashboard/invoices"
const val URL_HOME_TODAY_METRICS = "sapi/$API_VERSION/dashboard/metrics/today"

/************* request url end *************************/

/************* request and response code(including page request or network request begin ************/

const val REQUEST_CODE_SUPPLIER = 501
const val REQUEST_CODE_INVOICE_FILTER = 1001
const val REQUEST_CODE_DUE_INVOICE_FILTER = 1002
const val REQUEST_CODE_SELECT_INVOICE = 999
const val REQUEST_CODE_GET_PAYMENT_METHOD = 998
const val REQUEST_CODE_INVOICE_EDIT_DETAIL = 997
const val REQUEST_CODE_FRAGMENT_GET_SUPPLIER = 996
const val REQUEST_CODE_ADD_NEW_INVOICE = 995
const val REQUEST_CODE_UPDATE_PAYMENT_INFO = 994
const val REQUEST_CODE_UPDATE_PAYMENT_LIST = 993
const val REQUEST_CODE_CHOOSE_TAX_DEDUCTION_EXTEND = 991
const val REQUEST_CODE_CHOOSE_CREDIT_NOTE_LIST = 992
const val REQUEST_CODE_CHOOSE_TAX_DEDUCTION_LIST = 993
const val REQUEST_CODE_CHOOSE_VA_BANK_LIST = 994
const val REQUEST_CODE_REGISTER_ENTER_INVITATION_CODE = 1100
const val REQUEST_CODE_REGISTER_ANSWER_SECURITY_QUESTION = 1101
const val REQUEST_CODE_REGISTER_CONFIRM_INFORMATION = 1102
const val REQUEST_CODE_RESET_PWD_USERNAME = 1200
const val REQUEST_CODE_RESET_PWD_QUESTIONS = 1201
const val REQUEST_CODE_NOTIFICATION_POSITIVE = 1300
const val REQUEST_CODE_NOTIFICATION_NEGATIVE = 1301
const val REQUEST_CODE_CREDITNOTES_FILTER = 1302
const val REQUEST_CODE_PAYMENT_DUE_FILTER = 1303
const val REQUEST_CODE_PAYMENT_ALL_FILTER = 1304
const val REQUEST_CODE_PAYMENT_GATEWAY_CONFIRM = 1400
/************* request and response code end *******************************************/

/************* tag(including some intent tag,log e.t. begin ****************************/

const val TAG_CURRENCY = "defaultCurrency"
const val TAG_COUNTRY_CONFIGURATION = "countryConfiguration"
const val TAG_SAVED_LANGUAGE = "language"
const val TAG_SAVED_COUNTRY = "country"
const val TAG_CONFIG_UPDATE_DATE = "configUpdateDate"

//invoice list
const val TAG_INVOICE_TOKEN = "invoiceToken"
const val TAG_INVOICE_FILTER_FLAG = "invoiceFilterFlag"
const val TAG_INVOICE_FILTER_PARAMETER = "uploadParameter"
const val TAG_INVOICE_FILTER_PARAMETER_RESULT = "uploadParameterResult"
const val TAG_INVOICE_FILTER_COUNTRY_CODE_RESULT = "uploadCountryCodeResult"
const val TAG_SELECT_SUPPLIER_RESULT = "supplierResult"
const val TAG_SELECT_INVOICE_RESULT = "selectInvoiceResult"
const val TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN = "originName"
const val TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN_CURRENCY = "originCurrency"
const val TAG_FILTER_SUPPLIER_OR_CUSTOMERS_FROM_FLAG = "filterFrom"
const val TAG_FILTER_SELECT_SUPPLIER_OR_CUSTOMERS_FLAG = "supplierOrCustomer"
const val TAG_INVOICE_DUE_DATE = "invoiceDueDate"
const val TAG_INVOICE_DUE_DATE_HOME_PAGE_FLAG = "invoiceFromHomePage"
const val TAG_INVOICE_DUE_DATE_DEFAULT_LIST = "invoiceDueDefaultList"
const val TAG_INVOICE_OVERDUE_DAYS = "invoiceOverdueDays"
const val TAG_REQUEST_RESULT_INVOICE = "invoice"
const val TAG_DELETE_INVOICE = "deleteInvoiceFlag"
const val TAG_REQUEST_INTENT_DATA_INVOICE = "invoiceListItem"
const val TAG_REQUEST_INTENT_IS_CREDIT_NOTE_METHOD = "isCreditNoteMethod"
const val TAG_REQUEST_INTENT_DATA_INVOICE_CURRENCY = "invoiceListItem_currency"
const val TAG_REQUEST_INTENT_DATA_INVOICE_SELECTED = "invoiceListItem_selected"
const val TAG_REQUEST_INTENT_DATA_INVOICE_ADDED = "invoiceListItem_added"
const val TAG_INVOICE_FROM_PLANNED_PAYMENT_CREATION = "isFromPlannedPaymentCreation"
const val TAG_REQUEST_INTENT_DATA_DUEDAY_PLANNED_PAYMENT = "dueday_planned_payment"
const val TAG_INVOICE_DETAIL = "invoiceDetail"
//payment
const val TAG_PAYMENT_DUE_DATE = "paymentDueDate"
const val TAG_REQUEST_INTENT_DATA_CREDIT_NOTE = "credit_note"
const val TAG_REQUEST_INTENT_DATA_TAX_DEDUCTION = "tax_deduction"
const val TAG_REQUEST_INTENT_DATA_SELECTED_TAX_DEDUCTION = "selected_deduction"
const val TAG_REQUEST_INTENT_DATA_CREDIT_NOTE_SELECTED = "credit_note_selected"
const val TAG_REQUEST_INTENT_DATA_SELECTED_INVOICES = "selectedInvoices"
const val TAG_PAYMENT_GATEWAY_TOKEN = "pgToken"
const val TAG_PAYMENT_GATEWAY_TIP_TYPE = "pgTipType"
const val TAG_PAYMENT_GATEWAY_DETAIL = "pgPaymentDetail"
const val TAG_PAYMENT_GATEWAY_TRACK = "pgTrackInfo"
const val TAG_PAYMENT_GATEWAY_INVOICE_DETAIL = "pgInvoiceDetailList"
const val TAG_PAYU_ERROR = "isPayUError"
//registration
const val TAG_INVITATION_CODE = "invitationCode"
const val TAG_INVITATION_CODE_RESULT = "invitationCodeResult"
const val TAG_INVITATION_CODE_TYPE = "invitationCodeType"
const val TAG_INVITATION_CODE_COUNTRY = "invitationCodeCountry"
const val TAG_INVITATION_CODE_EXPIRED = "invitationCodeExpiredFlag"
const val TAG_INVITATION_CODE_COMPANY_NAME = "invitationCodeCompanyName"
const val TAG_ANSWER_SECURITY_QUESTION_RESULT = "answerResult"
const val TAG_ANSWER_SECURITY_QUESTION_INFO = "answerInfo"
const val TAG_FROM_REGISTER_FLAG = "isFromRegistration"
const val TAG_FORGET_TYPE_FLAG = "isForgetUserName"
const val TAG_REGISTRATION_FLAG = "isRegistration"
//more
const val TAG_REQUEST_INTENT_DATA_FAQ = "faq"
const val TAG_REQUEST_INTENT_DATA_LEGAL = "legal"
const val TAG_REQUEST_INTENT_DATA_LEGAL_FROM_FLAG = "fromLoginFlag"
const val TAG_REQUEST_INTENT_DATA_LEGAL_URL = "legal_url"
const val TAG_IS_NOTIFICATION_ON_FLAG = "isNotificationOn"
const val TAG_PAYEE_DETAIL = "payeeDetail"

//forget
const val TAG_FORGET_ANSWER_QUESTION_FLAG = "isShowQuestions"
const val TAG_FORGET_RESET_SUCCESS_FLAG = "isResetSuccess"
const val TAG_FORGET_RECOVERY_QUESTIONS_RESULT = "recoveryQuestions"
const val TAG_FORGET_RECOVERY_QUESTIONS = "questions"
const val TAG_FORGET_RECOVERY_QUESTIONS_FLAG = "isAnswerFail"
const val TAG_FORGET_ANSWER_RESULT = "questionsAnswer"
const val TAG_FORGET_ANSWERS = "answers"
const val TAG_FORGET_RESET_TOKEN = "resetToken"
const val TAG_FORGET_RESET_USERNAME = "username"

//home
const val TAG_HOME_ACCOUNTS = "accounts"
const val TAG_HOME_CUSTOMERS = "customers"
const val TAG_HOME_PARAMETER = "parameter"
const val TAG_HOME_FILTER_RESULT = "homeFilterResult"
const val TAG_CALENDAR_CURRENCY = "currencyTag"

/************** tag end *******************/

/*************** global value, not in res begin ******************/
val VALUE_PAY_EN_STATUS = linkedMapOf("U" to "Unpaid", "F" to "Fully paid", "O" to "Overpaid", "P" to "Partially paid", "C" to "Closed", "R" to "Removed")
val VALUE_PAY_ID_STATUS = linkedMapOf("U" to "Belum dibayar", "F" to "Dibayar", "O" to "Lebih bayar", "P" to "Sebagian terbayar", "C" to "Tutup", "R" to "Hapus")
val VALUE_TIMELINE_TYPE = linkedMapOf("invoice" to "New", "invoice.update" to "Update", "itp.create" to "Planned payment",
        "itp.update.amount" to "Planned payment", "itp.line.removed" to "Planned payment", "itp.status.creditnote" to "Credit note",
        "creditNote.applied" to "Credit note", "preallocatedcreditnote" to "Credit note", "itp.status.invoice" to "Payment",
        "openItem" to "Update", "itp.revoke.payor" to "Planned payment", "deduction.applied" to "Deduction", "invoice.delete" to "Delete",
        "invoice.delete" to "Update", "deduction.confirmed" to "Deduction confirmed", "deduction.rejected" to "Deduction rejected")
val VALUE_PAYMENT_EN_STATUS = linkedMapOf("created" to "Created", "revoked_payor" to "Revoked", "closed" to "Closed", "revoked" to "Revoked", "revoked_payee" to "Revoked (by Supplier", "rejected" to "Rejected", "pending" to "Pending", "updated" to "Updated", "processing" to "Processed", "payment_receive" to "Payment receive")
val VALUE_PAYMENT_ID_STATUS = linkedMapOf("created" to "Pembuatan", "revoked_payor" to "Pembatalan", "closed" to "Tutup", "revoked" to "Pembatalan", "revoked_payee" to "Pembatalan (oleh supplier / penjual", "rejected" to "Ditolak", "pending" to "Tertunda", "updated" to "Pengkinian", "processing" to "Pengolhan", "payment_receive" to "Payment receive")
val VALUE_TRACK_PAYMENT_IN_STATUS = linkedMapOf("progressing" to "In progress", "fail" to "Not successful", "success" to "Successful")
val VALUE_CREDITNOTES_EN_STATUS = linkedMapOf("U" to "Open", "P" to "Partial", "F" to "Utilised", "O" to "Overpaid", "C" to "Closed")
val VALUE_CREDITNOTES_ID_STATUS = linkedMapOf("U" to "Buka", "P" to "Sebagian", "F" to "Habis", "O" to "Lebih bayar", "C" to "Tutup")
val VALUE_CURRENCY_LANGUAGE = linkedMapOf("AED" to "ar", "AFN" to "fa", "ALL" to "sq", "AMD" to "hy", "ANG" to "nl", "AOA" to "pt", "ARS" to "es", "AUD" to "en", "AWG" to "nl", "AZN" to "az", "BAM" to "bs", "BBD" to "en", "BDT" to "bn",
        "BGN" to "bg", "BHD" to "ar", "BIF" to "fr", "BMD" to "en", "BND" to "ms", "BOB" to "es", "BRL" to "pt", "BSD" to "en", "BTN" to "dz", "BWP" to "en", "BYN" to "be", "BYR" to "be", "BZD" to "en", "CAD" to "en", "CDF" to "fr",
        "CHF" to "de", "CLP" to "es", "CNY" to "zh", "COP" to "es", "CRC" to "es", "CUP" to "es", "CVE" to "pt", "CZK" to "cs", "DJF" to "fr", "DKK" to "da", "DOP" to "es", "DZD" to "ar", "EGP" to "ar", "ERN" to "ti", "ETB" to "am",
        "EUR" to "de", "FJD" to "en", "FKP" to "en", "GBP" to "en", "GEL" to "ka", "GHS" to "en", "GIP" to "en", "GMD" to "en", "GNF" to "fr", "GTQ" to "es", "GYD" to "en", "HKD" to "zh", "HNL" to "es", "HRK" to "hr", "HTG" to "en",
        "HUF" to "hu", "IDR" to "id", "ILS" to "he", "INR" to "hi", "IQD" to "ar", "IRR" to "fa", "ISK" to "is", "JMD" to "en", "JOD" to "ar", "JPY" to "ja", "KES" to "en", "KGS" to "ky", "KHR" to "km", "KMF" to "ar", "KPW" to "ko",
        "KRW" to "ko", "KWD" to "ar", "KYD" to "en", "KZT" to "kk", "LAK" to "lo", "LBP" to "ar", "LKR" to "si", "LRD" to "en", "LSL" to "en", "LYD" to "ar", "MAD" to "ar", "MDL" to "ro", "MGA" to "fr", "MKD" to "mk", "MMK" to "my",
        "MNT" to "mn", "MOP" to "zh", "MRO" to "ar", "MRU" to "ar", "MUR" to "en", "MVR" to "en", "MWK" to "en", "MXN" to "es", "MYR" to "ms", "MZN" to "pt", "NAD" to "en", "NGN" to "en", "NIO" to "es", "NOK" to "nb", "NPR" to "ne",
        "NZD" to "en", "OMR" to "ar", "PAB" to "es", "PEN" to "es", "PGK" to "en", "PHP" to "fil", "PKR" to "ur", "PLN" to "pl", "PYG" to "es", "QAR" to "ar", "RON" to "ro", "RSD" to "sr", "RUB" to "ru", "RWF" to "rw", "SAR" to "ar",
        "SBD" to "en", "SCR" to "en", "SDG" to "ar", "SEK" to "sv", "SGD" to "en", "SHP" to "en", "SLL" to "en", "SOS" to "so", "SRD" to "nl", "SSP" to "en", "STD" to "pt", "STN" to "pt", "SYP" to "ar", "SZL" to "en", "THB" to "th",
        "TJS" to "en", "TMT" to "tk", "TND" to "ar", "TOP" to "to", "TRY" to "tr", "TTD" to "en", "TWD" to "zh", "TZS" to "sw", "UAH" to "uk", "UGX" to "en", "USD" to "en", "UYU" to "es", "UZS" to "uz", "VEF" to "es", "VND" to "vi",
        "VUV" to "en", "WST" to "en", "XAF" to "fr", "XCD" to "en", "XOF" to "fr", "XPF" to "fr", "YER" to "ar", "ZAR" to "zu", "ZMW" to "en", "ZWL" to "en")
val VALUE_PAYMENTMETHOD_EN_HK_LABELS = linkedMapOf(
        "ach" to "Autopay",
        "bank_transfer" to "Bank Transfer/FPS",
        "credit_note" to "Credit Note",
        "cheque" to "Cheque",
        "rtgs" to "NEFT/RTGS",
        "dcms" to "Online payment",
        "full_deduction" to "Deductions",
        "undefined" to "Not specified",
        "due" to "Payments overdue",
        "paid" to "Payments made",
        "planned" to "Payments pending")

val VALUE_PAYMENTMETHOD_EN_IN_LABELS = linkedMapOf(
        "ach" to "ACH",
        "bank_transfer" to "Bank transfer",
        "credit_note" to "Credit Note",
        "cheque" to "Cheque",
        "rtgs" to "NEFT/RTGS",
        "dcms" to "Online payment",
        // mock up method
        "virtual_account" to "VA payment code",
        "full_deduction" to "Deductions",
        "undefined" to "Not specified",
        "due" to "Payments overdue",
        "paid" to "Payments made",
        "planned" to "Payments pending")

val VALUE_PAYMENTMETHOD_ID_ID_LABELS = linkedMapOf(
        "ach" to "ACH",
        "bank_transfer" to "Bank Transfer",
        "credit_note" to "Nota kredit",
        "cheque" to "Cheque",
        "rtgs" to "NEFT / RTGS",
        "dcms" to "Online payment",
        // mock up method
        "virtual_account" to "Kode pembayaran VA",
        "full_deduction" to "Deductions",
        "undefined" to "Tidak ditentukan",
        "due" to "Pembayaran Terlambat",
        "paid" to "Pembayaran Terbuat",
        "planned" to "Pembayaran Tertunda")

val VALUE_PAYMENTMETHOD_ZH_CH_LABELS = linkedMapOf(
        "ach" to "自动转账",
        "bank_transfer" to "银行转帐/FPS",
        "credit_note" to "信用票据",
        "cheque" to "支票",
        "rtgs" to "RTGS",
        "dcms" to "Online payment",
        "full_deduction" to "Deductions",
        "undefined" to "未标明",
        "due" to "Payments overdue",
        "paid" to "Payments made",
        "planned" to "Payments pending")

val VALUE_PAYMENTMETHOD_ZH_HK_LABELS = linkedMapOf(
        "ach" to "自動轉賬",
        "bank_transfer" to "銀行轉帳/FPS",
        "credit_note" to "信用票據",
        "cheque" to "支票",
        "rtgs" to "RTGS",
        "dcms" to "Online payment",
        "full_deduction" to "Deductions",
        "undefined" to "未標明",
        "due" to "Payments overdue",
        "paid" to "Payments made",
        "planned" to "Payments pending")

val VALUE_PAYMENTMETHOD_EN_ID_LABELS = linkedMapOf(
        "ach" to "ACH",
        "bank_transfer" to "Bank Transfer",
        "credit_note" to "Credit Note",
        "cheque" to "Cheque",
        "rtgs" to "RTGS",
        "dcms" to "Online payment",
        // mock up method
        "virtual_account" to "VA payment code",
        "full_deduction" to "Deductions",
        "undefined" to "Not specified",
        "due" to "Payments overdue",
        "paid" to "Payments made",
        "planned" to "Payments pending")


val VALUE_BANK_CODE_LABEL = linkedMapOf(
        "IN" to linkedMapOf("en-in" to "IFSC code"),
        "HK" to linkedMapOf("en-hk" to "Clearing Code", "zh-hk" to "銀行代碼", "zh-cn" to "银行代码"),
        "ID" to linkedMapOf("en-id" to "Clearing Code", "id-id" to "Kode bank"),
        "SG" to linkedMapOf("en-sg" to "Bank Code", "zh-cn" to "银行代码"))


val VALUE_CHALLENGE_QUESTIONS = linkedMapOf(
        "IN" to linkedMapOf("en-in" to mutableListOf("Enter the Buyer ID provided by your supplier",
                "Enter the email address to which this registration invitation was sent to",
                "What is your business PAN number In India?")),
        "HK" to linkedMapOf("en-hk" to mutableListOf("Enter the Buyer ID provided by your supplier",
                "Enter the email address to which this registration invitation was sent to",
                "What is your business registration number in Hong Kong?"), "zh-hk" to mutableListOf("待补充","待补充","待补充"), "zh-cn" to mutableListOf("待补充","待补充","待补充")),
        "ID" to linkedMapOf("en-id" to mutableListOf("Enter the Buyer ID provided by your supplier",
                "Enter the email address to which this registration invitation was sent to",
                "What is your NPWP in Indonesia?"), "id-id" to mutableListOf("Apa ID Pembeli yang disediakan oleh supplier / penjual Anda?",
                "Apa ID Email yang supplier / penjual yang mengundang Anda?",
                "Apa NPWP Anda di Indonesia?")),
        "SG" to linkedMapOf("en-sg" to mutableListOf("","",""), "zh-cn" to mutableListOf("","","")))

/**************** global value end ***********************/
