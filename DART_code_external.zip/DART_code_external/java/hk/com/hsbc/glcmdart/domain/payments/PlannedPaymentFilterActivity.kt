/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.TealiumUtil

class PlannedPaymentFilterActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planned_payment_filter)
        initEventAndData()
    }

    @SuppressLint("ResourceAsColor")
    fun initEventAndData() {
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:planned payments:filter popup",
                "/dart/buyer-portal/planned-payments/filter-popup", "payment", "buyer portal",
                "planned payments")
    }

    companion object {
        fun showActivity(fragment: Fragment, requestCode: Int) {
            val intent = Intent(fragment.activity, PlannedPaymentFilterActivity::class.java)
            fragment.startActivityForResult(intent,requestCode)
        }
    }
}
