package hk.com.hsbc.glcmdart.domain.welcome

import android.annotation.SuppressLint
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import hk.com.hsbc.glcmdart.client.GLOBAL_LANGUAGE
import hk.com.hsbc.glcmdart.client.TAG_COUNTRY_CONFIGURATION
import hk.com.hsbc.glcmdart.client.TAG_SAVED_LANGUAGE
import hk.com.hsbc.glcmdart.domain.dart.*
import hk.com.hsbc.glcmdart.extension.json
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.MemoryCache
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

class ConfigViewModel : ViewModel() {

    val languageLiveData = MutableLiveData<Int>()
    val mModel by lazy { ConfigurationModel() }

    @SuppressLint("CheckResult")
    fun getConfiguration() {
        mModel.requestCountryConfiguration()
                .compose(SchedulerTransformer())
                .subscribe({
                    val sharePre = DartApplication.instance!!.getSharedPreferences(DartApplication.instance!!.packageName, Context.MODE_PRIVATE)
                    val editor = sharePre.edit()
                    val savedLanguage = sharePre.getString(TAG_SAVED_LANGUAGE, null)
                    if (it == null) {
//                        Toast.makeText(DartApplication.instance, "Get Configuration Fail!", Toast.LENGTH_SHORT).show()
                        val stringBuilder = StringBuilder()
                        try {
                            val fileIs = ApplicationManager.getContext().assets?.open("config.json")
                            val bufferedReader = BufferedReader(InputStreamReader(fileIs))
                            var line: String?
                            while (true) {
                                line = bufferedReader.readLine() ?: break
                                stringBuilder.append(line)
                            }
                            bufferedReader.close()
                            MemoryCache.updateCountryInfo(stringBuilder.toString(), savedLanguage)
                            editor.putString(TAG_COUNTRY_CONFIGURATION, stringBuilder.toString())
                            editor.apply()
                        } catch (e: IOException) {
                            // e.printStackTrace()
                            Toast.makeText(DartApplication.instance, "Get Configuration Fail!", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        it.also { configureString ->
                            MemoryCache.updateCountryInfo(configureString.json, savedLanguage)
                            editor.putString(TAG_COUNTRY_CONFIGURATION, configureString.json)
                            editor.apply()
                        }
                    }
                    getLanguageStringsFile(MemoryCache.defaultLanguageFull ?: GLOBAL_LANGUAGE)
                }, {
//                    Toast.makeText(DartApplication.instance, "Get Configuration Fail!", Toast.LENGTH_SHORT).show()
                    val sharePre = DartApplication.instance!!.getSharedPreferences(DartApplication.instance!!.packageName, Context.MODE_PRIVATE)
                    val editor = sharePre.edit()
                    val savedLanguage = sharePre.getString(TAG_SAVED_LANGUAGE, null)
//                        Toast.makeText(DartApplication.instance, "Get Configuration Fail!", Toast.LENGTH_SHORT).show()
                    val stringBuilder = StringBuilder()
                    try {
                        val fileIs = ApplicationManager.getContext().assets?.open("config.json")
                        val bufferedReader = BufferedReader(InputStreamReader(fileIs))
                        var line: String?
                        while (true) {
                            line = bufferedReader.readLine() ?: break
                            stringBuilder.append(line)
                        }
                        bufferedReader.close()
                        MemoryCache.updateCountryInfo(stringBuilder.toString(), savedLanguage)
                        editor.putString(TAG_COUNTRY_CONFIGURATION, stringBuilder.toString())
                        editor.apply()
                    } catch (e: IOException) {
                        // e.printStackTrace()
                        Toast.makeText(DartApplication.instance, "Get Configuration Fail!", Toast.LENGTH_SHORT).show()
                    }
                    getLanguageStringsFile(MemoryCache.defaultLanguageFull ?: GLOBAL_LANGUAGE)
                })
    }

    @SuppressLint("CheckResult")
    fun getLanguageStringsFile(language: String, callback: (() -> Unit)? = null) {
        val path = when (language) {
            "en-in" -> "in_strings.json"
            "en-id" -> "en_strings.json"
            "id-id" -> "id_strings.json"
            "en-au" -> "en_strings.json"
            "en-sg" -> "en_strings.json"
            else -> "en_strings.json"
        }

        val countryCode = when (language) {
            "en-in" -> "IN"
            "en-au" -> "IN"
            "en-sg" -> "IN"
            else -> "ID"
        }

        mModel.requestLanguageStringFile(path, countryCode)
                .compose(SchedulerTransformer())
                .subscribe({
                    val entity = it
                    MemoryCache.changeLanguage(language, countryCode)

                    if (entity.isJsonNull || entity.json.isNullOrBlank()) {
//                        Toast.makeText(DartApplication.instance, "Get Language File Fail!", Toast.LENGTH_SHORT).show()
                        val stringBuilder = StringBuilder()
                        try {
                            val pathLocal = when (language) {
                                "en-in" -> "in_strings.json"
                                "en-id" -> "en_id_strings.json"
                                "id-id" -> "id_id_strings.json"
                                else -> "in_strings.json"
                            }
                            val fileIs = ApplicationManager.getContext().assets?.open(pathLocal)
                            val bufferedReader = BufferedReader(InputStreamReader(fileIs))
                            var line: String?
                            while (true) {
                                line = bufferedReader.readLine() ?: break
                                stringBuilder.append(line)
                            }
                            bufferedReader.close()
                            MemoryCache.saveStringsMap(language, stringBuilder.toString())
                        } catch (e: IOException) {
                            // e.printStackTrace()
                            Toast.makeText(DartApplication.instance, "Get Language File Fail!", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        MemoryCache.saveStringsMap(language, it.json)
                    }

                    if (languageLiveData.value == null || languageLiveData.value!! < 0) {
                        languageLiveData.value = 1
                    } else {
                        languageLiveData.value = languageLiveData.value!! + 1
                    }

                    callback?.invoke()
                }, {
//                    Toast.makeText(DartApplication.instance, "Get Language File Fail!", Toast.LENGTH_SHORT).show()
                    //do not block flow, continue page jump
                    MemoryCache.changeLanguage(language, countryCode)
                    val stringBuilder = StringBuilder()
                    try {
                        val pathLocal = when (language) {
                            "en-in" -> "in_strings.json"
                            "en-id" -> "en_id_strings.json"
                            "id-id" -> "id_id_strings.json"
                            else -> "in_strings.json"
                        }
                        val fileIs = ApplicationManager.getContext().assets?.open(pathLocal)
                        val bufferedReader = BufferedReader(InputStreamReader(fileIs))
                        var line: String?
                        while (true) {
                            line = bufferedReader.readLine() ?: break
                            stringBuilder.append(line)
                        }
                        bufferedReader.close()
                        MemoryCache.saveStringsMap(language, stringBuilder.toString())
                    } catch (e: IOException) {
                        // e.printStackTrace()
                        Toast.makeText(DartApplication.instance, "Get Language File Fail!", Toast.LENGTH_SHORT).show()
                    }
                    languageLiveData.value = -1
                    callback?.invoke()
                })
    }
}