/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.login.LoginActivity
import hk.com.hsbc.glcmdart.domain.welcome.WelcomeActivity
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.widget.LoadingButton
import hk.com.hsbc.glcmdart.widget.LoadingCompletedCallback
import kotlinx.android.synthetic.main.activity_answer_security_question.*

/**
 * Created by Donut on 2018/11/14.
 */
class RegisterAnswerSecurityQuestionActivity: BaseActivity(), RegisterAnswerSecurityQuestionContract.View, TextWatcher, View.OnClickListener {

    private lateinit var mViewModel: RegisterAnswerSecurityQuestionViewModel
    //    private val mPresenter = RegisterAnswerSecurityQuestionPresenter()
    private var invitationCode = ""
    private var registerType = ""
    private var currentCountry = MemoryCache.defaultCountry
    private var isRecoveryUserName = false
    private var isInvitationCodeExpired: Boolean = false
    private lateinit var mRegisterSuccessfullyFragment: RegisterSuccessfullyFragment
    private var isTealiumQuestionRegisterEnterFirst = false
    private var isTealiumQuestionRegisterEnterSecond = false
    private var isTealiumQuestionRegisterEnterThird = false
    private var isTealiumQuestionRecoverEnterFirst = false
    private var isTealiumQuestionRecoverEnterSecond = false
    private var isTealiumQuestionRecoverEnterThird = false

    companion object {
        fun showActivity(activity: Activity, invitationCode: String, registerType: String, countryCode: String?, isExpired: Boolean = false, isCodeRecoveryFlag: Boolean = false) {
            activity.startActivityForResult(Intent(activity, RegisterAnswerSecurityQuestionActivity::class.java).apply {
                putExtra(TAG_INVITATION_CODE, invitationCode)
                putExtra(TAG_INVITATION_CODE_TYPE, registerType)
                putExtra(TAG_FORGET_TYPE_FLAG, isCodeRecoveryFlag)
                putExtra(TAG_INVITATION_CODE_EXPIRED, isExpired)
                putExtra(TAG_INVITATION_CODE_COUNTRY, countryCode)
            }, REQUEST_CODE_REGISTER_ANSWER_SECURITY_QUESTION)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_answer_security_question)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        removeStatusView(this)
        ll_main_container.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)

//        mPresenter.attachView(this)
        mViewModel = ViewModelProviders.of(this).get(RegisterAnswerSecurityQuestionViewModel::class.java)
        mViewModel.answerLiveData.observe(this, Observer {
            answerResult(it["isCorrect"] as Boolean, it["entity"] as RegistrationChallengeEntity?, it["wrongTime"] as Int)
        })
        mViewModel.expirationLiveData.observe(this, Observer {
            if (it) {
                RegisterExpiredRecoverSuccessActivity.showActivity(this)
            }
        })
        mViewModel.exceptionLiveData.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })
        invitationCode = intent.getStringExtra(TAG_INVITATION_CODE)
        registerType = intent.getStringExtra(TAG_INVITATION_CODE_TYPE)
        isRecoveryUserName = intent.getBooleanExtra(TAG_FORGET_TYPE_FLAG, false)
        isInvitationCodeExpired = intent.getBooleanExtra(TAG_INVITATION_CODE_EXPIRED, false)
        currentCountry = intent.getStringExtra(TAG_INVITATION_CODE_COUNTRY)

        if (isInvitationCodeExpired) {
            if (registerType == "S") {
                MemoryCache.getLabelText("s_answer_security_supplier_expired_question")?.let {
                    if (!it.isBlank()) {
                        tv_security_question_1.text = it
                    }
                }
            } else {
                MemoryCache.getLabelText("s_answer_security_buyer_expired_question")?.let {
                    if (!it.isBlank()) {
                        tv_security_question_1.text = it
                    }
                }
            }

            et_question1.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            tv_security_question_2.visibility = View.GONE
            tv_security_question_3.visibility = View.GONE
            et_question2.setText("*")
            et_question3.setText("*")
            et_question2.visibility = View.GONE
            et_question3.visibility = View.GONE
        } else {
            if (registerType == "S") {
                MemoryCache.getLabelText("s_answer_security_supplier_question1")?.let {
                    if (!it.isBlank()) {
                        tv_security_question_1.text = it
                    }
                }
                MemoryCache.getLabelText("s_answer_security_supplier_question2")?.let {
                    if (!it.isBlank()) {
                        tv_security_question_2.text = it
                    }
                }
                MemoryCache.getLabelText("s_answer_security_supplier_question3")?.let {
                    if (!it.isBlank()) {
                        tv_security_question_3.text = it
                    }
                }

                et_question2.inputType = InputType.TYPE_CLASS_TEXT
                et_question3.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            } else {
                MemoryCache.getLabelText("s_answer_security_buyer_question1")?.let {
                    if (!it.isBlank()) {
                        tv_security_question_1.text = it
                    }
                }
                MemoryCache.getLabelText("s_answer_security_buyer_question2")?.let {
                    if (!it.isBlank()) {
                        tv_security_question_2.text = it
                    }
                }
                MemoryCache.getLabelText("s_answer_security_buyer_question3")?.let {
                    if (!it.isBlank()) {
                        tv_security_question_3.text = it
                    }
                }
            }
        }

        iv_back.setOnClickListener(this)
        lb_submit.setOnButtonClickListener(this)

        et_question1.addTextChangedListener(this)
        et_question2.addTextChangedListener(this)
        et_question3.addTextChangedListener(this)
        lb_submit.enableButton(false)

        MemoryCache.getLabelText("s_talkback_back_button")?.let {
            if (!it.isBlank()) {
                iv_back.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_register_main_step2")?.let {
            if (!it.isBlank()) {
                tv_answer_security_question_title.text = it
            }
        }
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.iv_back -> {
                if (isRecoveryUserName) {
                    TealiumUtil.eventTag("button click", "recover username: security question: back")
                } else {
                    TealiumUtil.eventTag("button click", "registration: security question: back")
                }
                finish()
            }
            R.id.tv_submit -> {
                if (isRecoveryUserName) {
                    TealiumUtil.eventTag("button click", "recover username: security question: next")
                } else {
                    TealiumUtil.eventTag("button click", "registration: security question: submit and verify")
                }
                tv_answer_security_question_wrong_tip.visibility = View.GONE
                lb_submit.startLoadingAnimation()
                if (isInvitationCodeExpired) {
                    mViewModel.uploadExpiredAnswer(invitationCode, et_question1.text.toString().trim())
                } else {
                    mViewModel.uploadAnswer(invitationCode,
                            et_question1.text.toString().trim(),
                            et_question2.text.toString().trim(),
                            et_question3.text.toString().trim(), isRecoveryUserName)
                }
            }
            R.id.deleteButton -> {
                ApplicationManager.finishOtherActivities(RegisterAnswerSecurityQuestionActivity::class.java)
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            }
            R.id.logonButton -> {
                ApplicationManager.finishOtherActivities(RegisterAnswerSecurityQuestionActivity::class.java)
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }
    }

    override fun getActivity(): Activity {
        return this
    }

    override fun answerResult(isCorrect: Boolean, returnInfo: RegistrationChallengeEntity?, incorrectTime: Int) {
        if (isCorrect) {
            tv_answer_security_question_wrong_tip.visibility = View.GONE
            lb_submit.animationEndCallback = object: LoadingCompletedCallback{
                override fun onAnimationCompleted() {
                    if (isRecoveryUserName) {
                        mRegisterSuccessfullyFragment = RegisterSuccessfullyFragment.newInstance(isRecoveryUserName, returnInfo?.payload?.buyerUserName ?: "", registerType)
                        fl_recovery_success.visibility = View.VISIBLE
                        supportFragmentManager.beginTransaction()
                                .replace(R.id.fl_recovery_success, mRegisterSuccessfullyFragment)
                                .commitAllowingStateLoss()
                    } else {
                        val intent = Intent().apply {
                            putExtra(TAG_ANSWER_SECURITY_QUESTION_RESULT, returnInfo)
                        }
                        setResult(Activity.RESULT_OK, intent)
                        finish()
                    }
                }
            }
            lb_submit.endLoadingAnimation(isCorrect)
        } else {
            if (isRecoveryUserName) {
                TealiumUtil.eventTag("error", "recover username: security question: incorrect answer: ${3 - incorrectTime} attempts remaining")
            } else {
                TealiumUtil.eventTag("error", "registration: security question: incorrect answer: ${3 - incorrectTime} attempts remaining")
            }
            lb_submit.endLoadingAnimation(isCorrect)
            lb_submit.setButtonText(getString(R.string.s_answer_security_question_submit))
            tv_answer_security_question_wrong_tip.visibility = View.VISIBLE
            tv_answer_security_question_wrong_tip.text = getString(R.string.s_wrong_security_question_answer_tip)
            if (incorrectTime == 3) {
                Toast.makeText(this, getString(R.string.s_wrong_security_question_answer_toast), Toast.LENGTH_LONG).show()
                startActivity(Intent(this, WelcomeActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                })
                finish()
            }
        }
    }

    override fun afterTextChanged(editable: Editable?) {
        if (et_question1.text.toString().isNotEmpty()) {
            if (isRecoveryUserName) {
                if (!isTealiumQuestionRecoverEnterFirst) {
                    TealiumUtil.eventTag("text entry", "recover username: security question: buyer id entered")
                    isTealiumQuestionRecoverEnterFirst = true
                }
            } else {
                if (!isTealiumQuestionRegisterEnterFirst) {
                    TealiumUtil.eventTag("text entry", "registration: security question: buyer id entered")
                    isTealiumQuestionRegisterEnterFirst = true
                }
            }
        }

        if (et_question2.text.toString().isNotEmpty()) {
            if (isRecoveryUserName) {
                if (!isTealiumQuestionRecoverEnterSecond) {
                    TealiumUtil.eventTag("text entry", "recover username: security question: buyer email entered")
                    isTealiumQuestionRecoverEnterSecond = true
                }
            } else {
                if (!isTealiumQuestionRegisterEnterSecond) {
                    TealiumUtil.eventTag("text entry", "registration: security question: buyer email entered")
                    isTealiumQuestionRegisterEnterSecond = true
                }
            }
        }

        if (et_question3.text.toString().isNotEmpty()) {
            if (isRecoveryUserName) {
                if (!isTealiumQuestionRecoverEnterThird) {
                    TealiumUtil.eventTag("text entry", "recover username: security question: pan number entered")
                    isTealiumQuestionRecoverEnterThird = true
                }
            } else {
                if (!isTealiumQuestionRegisterEnterThird) {
                    TealiumUtil.eventTag("text entry", "registration: security question: business pan number entered")
                    isTealiumQuestionRegisterEnterThird = true
                }
            }
        }

        if (et_question1.text.toString().isNotEmpty() && et_question2.text.toString().isNotEmpty() && et_question3.text.toString().isNotEmpty()) {
            lb_submit.enableButton(true)
            lb_submit.setButtonText(getString(R.string.s_answer_security_question_submit))
        } else {
            lb_submit.enableButton(false)
            lb_submit.setButtonText(getString(R.string.s_answer_security_question_submit))
        }
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        if (tv_answer_security_question_wrong_tip.visibility == View.VISIBLE) {
            tv_answer_security_question_wrong_tip.visibility = View.GONE
        }
    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
    }

    override fun obtainLoadingButton(): LoadingButton {
        return lb_submit
    }

    override fun onBackPressed() {
        if (isRecoveryUserName) {
            startActivity(Intent(this, WelcomeActivity::class.java).let {
                ApplicationManager.finishActivity(RegisterMainActivity::class.java)
                finish()
                it
            })
        } else {
            super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        if (isRecoveryUserName) {
            TealiumUtil.pageTag("dart : buyer portal : recover username : security question",
                    "/dart/buyer portal/recover username/security question", "verification", "buyer portal",
                    "recover username", "mobile","en", "recover username", "3", "recover username - security question")
        } else {
            TealiumUtil.pageTag("dart : buyer portal : registration : security question",
                    "/dart/buyer portal/registration/security question", "verification", "buyer portal",
                    "registration", "mobile","en", "registration", "3", "registration - security question")
        }
    }
}