package hk.com.hsbc.glcmdart.domain.registration

import android.annotation.SuppressLint
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.dart.SchedulerTransformer
import hk.com.hsbc.glcmdart.framework.BaseViewModel

class RegisterCreateProfileViewModel: BaseViewModel() {

    private val mModel by lazy { RegistrationModel() }

    val questionsLiveData = MutableLiveData<List<Question>>()
    val validationLiveData = MutableLiveData<UsernameValidationBean?>()
    val expirationLiveData = MutableLiveData<Boolean>()
    val showCreationViewLiveData = MutableLiveData<Boolean>()

    @SuppressLint("CheckResult")
    fun doRequest() {
        mModel.requestRecoveryQuestions()
                    .compose(SchedulerTransformer())
                    .subscribe {
                        it?.payload?.questions?.let { questions ->
                            questionsLiveData.postValue(questions)
                        }
                    }
    }

    @SuppressLint("CheckResult")
    fun doValidation(code: String, token: String, body: UsernameValidationBean) {
         mModel.requestUsernameValidation(code, token, body)
                    .compose(SchedulerTransformer())
                    .subscribe({
                        it?.payload?.available?.let {
                            if (it) {
                                validationLiveData.postValue(body)
                                return@subscribe
                            }
                        }
                        if (it.payload.available == null) {
                            validationLiveData.postValue(null)
                            return@subscribe
                        }
                        validationLiveData.postValue(null)
                    }, {
                        validationLiveData.postValue(null)
                    })
    }

    @SuppressLint("CheckResult")
    fun doCreation(code: String, token: String, body: ProfileCreationBean) {
        mModel.requestProfileCreation(code, token, body)
                    .compose(SchedulerTransformer())
                    .subscribe({
                        it?.payload?.result?.let { result ->
                            showCreationViewLiveData.postValue(result)
                            return@subscribe
                        }
                        it?.payload?.let { payload ->
                            if (payload.code == 401 && "Token expired" == payload.errorText) {
                                expirationLiveData.postValue(true)
                                return@subscribe
                            }
                        }
                        showCreationViewLiveData.postValue(false)
                    }, {
                        expirationLiveData.postValue(true)
                        showCreationViewLiveData.postValue(false)
                    })
    }
}