/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.calendar

import android.app.Activity
import hk.com.hsbc.glcmdart.domain.dart.CalendarListItem
import hk.com.hsbc.glcmdart.domain.dashboard.ProfileDetailEntity
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.framework.IView
import io.reactivex.Observable
import okhttp3.RequestBody
import retrofit2.http.Body

interface CalendarContract {

    interface View: IView {
        fun showContentView(mCalendarGroup: MutableMap<String, CalendarListItem>)
        fun getActivityContext(): Activity?
    }

    interface Model {
        fun requestInvoiceList(@Body jsonBody: RequestBody): Observable<InvoiceListEntity>
        fun requestPlannedPaymentList(@Body jsonBody: RequestBody): Observable<PlannedPaymentListPayload>
        fun getProfileDetail(): Observable<ProfileDetailEntity>
    }
}