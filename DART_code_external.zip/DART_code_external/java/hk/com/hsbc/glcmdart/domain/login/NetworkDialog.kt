/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.login

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.ConnectivityUtil
import hk.com.hsbc.glcmdart.util.ConvertUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.dialog_network.*
import java.util.*

class NetworkDialog constructor(context: Context): Dialog(context, R.style.FullScreenDialogTheme) {

    private val netCheckHandler = Handler {
        if (ConnectivityUtil.isConnected()) {
            if (this.isShowing) {
                networkTimer.cancel()
                this.cancel()
            }
        }

        true
    }

    private var networkTimer = Timer()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window?.decorView?.setPadding(
                ConvertUtil.dp2px(context, 10.0f).toInt(),
                ConvertUtil.dp2px(context, 56.0f).toInt(),
                ConvertUtil.dp2px(context, 10.0f).toInt(),
                0
        )
        val lp = window?.attributes
        lp?.width = WindowManager.LayoutParams.MATCH_PARENT
        lp?.height = WindowManager.LayoutParams.WRAP_CONTENT
        window?.attributes = lp
        window?.setDimAmount(0.0f)
        window?.setGravity(Gravity.TOP)

        setContentView(R.layout.dialog_network)

        networkTimer.schedule(object: TimerTask() {
            override fun run() {
                netCheckHandler.sendEmptyMessage(0)
            }
        }, 5000, 5000)
        TealiumUtil.pageTag(
                "dart:buyer portal:logon:unable to connect",
                "/dart/buyer-portal/logon/unable-to-connect",
                "authentication",
                "buyer portal",
                "logon"
        )

        MemoryCache.getLabelText("message_no_network")?.let {
            if (!it.isBlank()) {
                tv_no_network_tip.text = it
            }
        }
    }
}

