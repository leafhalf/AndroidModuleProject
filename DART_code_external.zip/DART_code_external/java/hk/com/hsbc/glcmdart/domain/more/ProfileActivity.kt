/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_profile.*

class ProfileActivity: BaseActivity() {

    companion object {
        fun showActivity(activity: Activity?) {
            activity?.startActivity(Intent(activity, ProfileActivity::class.java))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        initViewAndData()
    }

    private fun initViewAndData() {
        tb_head.navigationIcon = ContextCompat.getDrawable(this, R.drawable.ic_arrow_back_white)
        tb_head.title = MemoryCache.getLabelText("s_my_profile") ?: getString(R.string.s_my_profile)
        tb_head.setTitleTextColor(Color.WHITE)
        tb_head.setNavigationOnClickListener { finish() }

        val sessionInfo = MemoryCache.getSessionEntity()
        val profileInfo = MemoryCache.getProfile()?.payload?.user
        tv_profile_name.text = sessionInfo?.name
        tv_profile_email.text = profileInfo?.email
        tv_profile_title.text = profileInfo?.userTitle
        tv_profile_company_name.text = sessionInfo?.org_name

        MemoryCache.getLabelText("s_name")?.let {
            if (!it.isBlank()) {
                tv_profile_name_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_title")?.let {
            if (!it.isBlank()) {
                tv_profile_title_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_email")?.let {
            if (!it.isBlank()) {
                tv_profile_email_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_company_name")?.let {
            if (!it.isBlank()) {
                tv_profile_company_name_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_company_address")?.let {
            if (!it.isBlank()) {
                tv_profile_company_adress_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_contact_phone")?.let {
            if (!it.isBlank()) {
                tv_profile_contact_phone_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_registration_date")?.let {
            if (!it.isBlank()) {
                tv_profile_registration_date_tag.text = it
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart:buyer portal:more:my profile",
                "/dart/buyer-portal/more/my-profile",
                "other",
                "buyer portal",
                "more")
    }
}