package hk.com.hsbc.glcmdart.domain.payments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_PAYMENT_GATEWAY_TOKEN
import hk.com.hsbc.glcmdart.domain.payments.presenter.PaymentGatewayViewModel
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.framework.BaseActivity
import kotlinx.android.synthetic.main.activity_payment_gateway.*

class PaymentGatewayActivity: BaseActivity() {

    companion object {
        fun showActivity(context: Context?, token: String) {
            context?.startActivity(Intent(context, PaymentGatewayActivity::class.java).apply {
                putExtra(TAG_PAYMENT_GATEWAY_TOKEN, token)
            })
        }
    }

    private lateinit var mViewModel: PaymentGatewayViewModel
    private var mToken = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_gateway)
        initViews()
    }

    private fun initViews() {
        tb_header.navigationIcon = ContextCompat.getDrawable(this, R.drawable.ic_close_on_light)
        tb_header.setNavigationOnClickListener { finish() }
        mToken = intent.getStringExtra(TAG_PAYMENT_GATEWAY_TOKEN)
        if (mToken.isBlank()) {
            if (BuildConfig.DEBUG) {
                Toast.makeText(this, "Empty token, Please retry", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Data error, Please retry", Toast.LENGTH_SHORT).show()
            }
            return
        }

        mViewModel = ViewModelProviders.of(this).get(PaymentGatewayViewModel::class.java)
        mViewModel.mGatewayLiveData.observe(this, Observer {
            if (it.isNotEmpty()) {
                wv_payment_gateway.loadData(it, "text/html", "utf-8")
            }
        })
        mViewModel.requestLoadingLiveData.observe(this, Observer {
            if (it) {
                showLoadingDialogExt()
            } else {
                hideLoadingDialogExt()
            }
        })
        mViewModel.paymentErrorLiveData.observe(this, Observer {
            Toast.makeText(this@PaymentGatewayActivity, it ?: "Unknown Error", Toast.LENGTH_SHORT).show()
        })

        mViewModel.getPaymentGateHtml(mToken)
    }

}