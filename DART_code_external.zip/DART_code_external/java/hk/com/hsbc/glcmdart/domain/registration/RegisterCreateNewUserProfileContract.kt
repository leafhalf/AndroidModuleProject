/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.registration

import hk.com.hsbc.glcmdart.framework.IView

interface RegisterCreateNewUserProfileContract {

    interface View: IView {
        fun showRequestView(list: List<Question>)
        fun showValidationView(body: UsernameValidationBean?, flag: Boolean?)
        fun showCreationView(flag: Boolean)
        fun showRegisterExpiredDialog()
    }

    interface ActivityCallback {
        fun getInvitationCode(): String?
        fun getRegistrationChallengeEntity(): RegistrationChallengeEntity?
        fun getQuestions(): MutableList<Question>?
        fun getUsernameValidationBean(): UsernameValidationBean?
        fun getProfileCreationBean(): ProfileCreationBean?
    }

    interface FragmentCallback {
        fun updateContentView()
    }
}