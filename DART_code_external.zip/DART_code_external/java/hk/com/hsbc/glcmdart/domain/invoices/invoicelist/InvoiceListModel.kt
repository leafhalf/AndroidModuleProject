/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import com.google.gson.Gson
import hk.com.hsbc.glcmdart.client.HOST_URL
import hk.com.hsbc.glcmdart.util.NetworkManager
import io.reactivex.Observable
import okhttp3.MediaType
import okhttp3.RequestBody

/**
 * Created by Donut
 *
 * all invoice model, getting invoice data from server
 */
class InvoiceListModel: InvoiceListContract.Model {

    override fun getInvoiceList(uploadParameter: InvoiceRequestParameter): Observable<InvoiceListEntity> {
        val parameterStr = Gson().toJson(uploadParameter)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(InvoiceListService::class.java, HOST_URL).getInvoiceList(requestBody)
    }
}