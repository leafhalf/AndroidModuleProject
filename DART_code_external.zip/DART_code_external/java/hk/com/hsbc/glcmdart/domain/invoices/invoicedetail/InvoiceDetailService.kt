/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicedetail

import hk.com.hsbc.glcmdart.client.URL_INVOICE_DETAIL
import hk.com.hsbc.glcmdart.client. URL_INVOICE_DETAIL_TIME_LINE
import io.reactivex.Observable
import okhttp3.RequestBody
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Created by Donut
 *
 * invoice detail server api
 */
interface InvoiceDetailService {

    @POST(URL_INVOICE_DETAIL)
    fun getInvoiceDetailInfo(@Path("token") pathToken: String, @Query("token") token: String): Observable<InvoiceDetailEntity>

    @POST(URL_INVOICE_DETAIL_TIME_LINE)
    fun getInvoiceDetailTimeLine(@Path("token") pathToken: String, @Body body: RequestBody): Observable<InvoiceDetailTimeLineEntity>
}