/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.model.bean

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import hk.com.hsbc.glcmdart.domain.dart.CreditNoteLocal
import hk.com.hsbc.glcmdart.domain.dart.ITP
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import java.io.Serializable

@Keep
data class PlannedPaymentListPayload(var payload: PlannedPaymentList? = null) : Serializable

@Keep
data class PlannedPaymentList(
        val id: String?,
        val tokens: List<String>?,
        val createdAts: List<String>?,
        val itps: List<ITP>?,
        val updatedAts: List<String>?,
        val statuses: List<String>?,
        val amounts: List<String>?
) : Serializable

@Keep
data class PlannedPaymentPayload(val payload: PlannedPaymentEntity) : Serializable

@Keep
data class PlannedPaymentEntity(
        val id: String?,
        val token: String?,
        val createdAt: String?,
        val itp: ITP?,
        val updatedAt: String?,
        val status: String?,
        val amount: String?
) : Serializable


@Keep
data class PaymentMethodsRequestParameter(
        var country: String?,
        var payee: String?
) : Serializable

@Keep
data class PlannedPaymentLocalEntity(
        var amount: String?,
        var createdAt: String?,
        var itp: ITP?,
        var statuse: String?,
        var token: String?,
        var updatedAt: String?,
        var organization: String?=null
) : Serializable

@Keep
data class PlannedPaymentDueDayLocalEntity(
        var currency:String?,
        var amount: String?,
        var createdAt: String?,
        var itp: ITP?,
        var statuse: String?,
        var token: String?,
        var updatedAt: String?,
        var expectedDate: String?,
        var header: Boolean?,
        var payeeReference: String?,
        var secondHeader: Boolean?,
        var dueDayTotal: Int?,
        var dueDayAmount: Long?
) : Serializable

@Keep
data class InvoiceAddEntity(
        val token: String?,
        val invoice: Invoice?,
        var amount: String?,
        var comment: String?,
        var creditNotes: List<CreditNoteLocal>?,
        var creditNotesSelected: ArrayList<CreditNoteLocal>?,
        var taxDeductions: List<TaxDeductionInfo>?,
        var taxDeductionSelected: ArrayList<TaxDeductionInfo>?,
        var useRunningBalance: Boolean = true,
        var overPaid: Boolean? = false,
        var active: Boolean? = true
//        var amountFromInput: String? = null
) : Serializable

@Keep
data class RevokePayload(
        val payload: Any?
)

//payment gateway pay form return
@Keep
data class PaymentGatewayEntity(
    val payload: PaymentPayInfo?
) : Serializable

@Keep
data class PaymentPayInfo(
        var redirectHtml: String?
) : Serializable

@Keep
data class PaymentTrackPayload(
        val payload: PaymentTrackInfo?
) : Serializable

@Keep
data class PaymentTrackInfo(
        var txnRef: String?,
        var txnStatus: String?,
        var txnDateTime: String?,
        var pmtAmount: String?,
        var pmtCurrency: String?
) : Serializable

@Keep
data class PaymentExpectedDate(
        var gt: Timestap?,
        var lt: Timestap?
): Serializable

@Keep
data class Timestap (
    var nano: Long
): Serializable

@Keep
data class TaxDeductionPayload(
        var payload: HashMap<String, List<TaxDeductionInfo>>?
): Serializable

@Keep
data class TaxDeductionInfo (
    var token: String?,
    var name: String?,
    var type: String?,
    var code: String?,
    @SerializedName("max_percentage")
    var maxRate: String?,
    var actualRate: String?,
    var active: Boolean?,
    @SerializedName("max_amount")
    var maxAmount: String?,
    var currency: String?,
    var status: String?,
    @SerializedName("reject_reason")
    var rejectReason: String?,
    @SerializedName("created_at")
    var createdAt: String?,
    var actualAmount: String? = null,
    var selected: Boolean = false
): Serializable

@Keep
data class TaxDeductionInfoGrouped (
        var taxDeductionOptions: MutableList<TaxDeductionInfo>,
        var selectedDeduction: TaxDeductionInfo?,
        var selected: Boolean = false
): Serializable