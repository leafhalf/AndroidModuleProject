/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.welcome

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.ConfigurationModel
import hk.com.hsbc.glcmdart.domain.dart.SchedulerTransformer
import hk.com.hsbc.glcmdart.domain.registration.RegisterTAndCActivity
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.*
import io.reactivex.Observable
import kotlinx.android.synthetic.main.activity_splash.*
import java.text.SimpleDateFormat
import java.util.*

open class SplashActivity : BaseActivity(), SelectLanguageCallback {

    private lateinit var mViewModel: ConfigViewModel
    private val model = ConfigurationModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        removeStatusView(this)
        mViewModel = ViewModelProviders.of(this).get(ConfigViewModel::class.java)
        if (getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).getBoolean("firstIn", true)) {
            logoImage.visibility = View.VISIBLE
            iv_splash_big_logo.visibility = View.GONE
            InitLanguageDialog.showLanguageDialog(this, this)
        } else {
            MemoryCache.defaultCountry = getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).getString(TAG_SAVED_COUNTRY, MARKET_COUNTRY)
            doExecute()
        }
    }

    private fun doExecute() {
        if (BuildConfig.FLAVOR_secure == "secure") {
            requestVersionUpdate()
        } else {
            val handle = Handler(Looper.getMainLooper())
            handle.postDelayed({
                handleConfiguration()
            }, 3000)
        }
    }

    @SuppressLint("CheckResult")
    private fun requestVersionUpdate() {
        Observable.just(0)
                .map {
                    val response = model.requestVersionUpdate()
                    response
                }
                .compose(SchedulerTransformer())
                .subscribe({
                    val entity = it.body()
                    entity?.also { versionEntity ->
                        MemoryCache.saveVersionUpdate(versionEntity)
                    }
                    handleVersionUpdate()
                }, {
                    handleVersionUpdate()
                })
    }

    private fun handleVersionUpdate() {
        val entity = MemoryCache.getVersionUpdate()
        val versionName = VersionUtil.getVersionName()
        val forceUpdate = entity?.forceUpdate?.android?.forceUpdate
        val forceUpdateVersion = entity?.forceUpdate?.android?.forceUpdateVersion
        val forceUpdateLink = entity?.forceUpdate?.android?.forceUpdateLink
        val forceUpdateMessage = entity?.forceUpdate?.android?.forceUpdateMessage?.en
        if (entity != null) {
            if (forceUpdate == 1 &&
                    versionName.isNotEmpty() &&
                    !forceUpdateVersion.isNullOrEmpty() &&
                    ValidationUtil.validateVersion(versionName, forceUpdateVersion)) {// matching
                val mDialog = Dialog(this, R.style.AlertDialog)
                val mContentView = LayoutInflater.from(this).inflate(R.layout.dialog_version_update, null)
                mContentView.findViewById<TextView>(R.id.descriptionText).also {
                    it.text = forceUpdateMessage
                }
                mContentView.findViewById<TextView>(R.id.updateButton).also {
                    it.setOnClickListener {
                        forceUpdateLink?.also {
                            startActivity(IntentUtil.getBrowser(it))
                        }
                    }
                }
                mDialog.setContentView(mContentView)
                mDialog.setCanceledOnTouchOutside(false)
                mDialog.setCancelable(false)
                mDialog.show()
            } else {// not matching
                handleMaintenancePage()
            }
        } else {// retry
            val mDialog = Dialog(this, R.style.AlertDialog)
            val mContentView = LayoutInflater.from(this).inflate(R.layout.dialog_version_retry, null)
            mContentView.findViewById<TextView>(R.id.retryButton).also {
                it.setOnClickListener {
                    requestVersionUpdate()
                    mDialog.dismiss()
                }
            }
            mDialog.setContentView(mContentView)
            mDialog.setCanceledOnTouchOutside(false)
            mDialog.setCancelable(false)
            mDialog.show()
        }
    }

    private fun handleMaintenancePage() {
        val entity = MemoryCache.getVersionUpdate()
        val maintenance = entity?.maintenance?.android?.maintenance
        val maintenanceMessage = entity?.maintenance?.android?.maintenanceMessage?.en
        if (maintenance == 1) {
            val mDialog = Dialog(this, R.style.AlertDialog)
            val mContentView = LayoutInflater.from(this).inflate(R.layout.dialog_maintenance, null)
            mContentView.findViewById<TextView>(R.id.descriptionText).also {
                it.text = maintenanceMessage
            }
            mContentView.findViewById<TextView>(R.id.quitButton).also {
                it.setOnClickListener {
                    mDialog.dismiss()
                    finish()
                    ApplicationManager.exitApplication()
                }
            }
            mDialog.setContentView(mContentView)
            mDialog.setCanceledOnTouchOutside(false)
            mDialog.setCancelable(false)
            mDialog.show()
        } else {
            handleConfiguration()
        }
    }

    private fun handleConfiguration() {
        val sharePre = getSharedPreferences(applicationInfo.packageName, Context.MODE_PRIVATE)
        val savedConfiguration = sharePre.getString(TAG_COUNTRY_CONFIGURATION, null)
        val savedLanguage = sharePre.getString(TAG_SAVED_LANGUAGE, null)
        val updateDate = sharePre.getString(TAG_CONFIG_UPDATE_DATE, null)
        MemoryCache.defaultCountry = sharePre.getString(TAG_SAVED_COUNTRY, MARKET_COUNTRY)
        val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (savedConfiguration == null || todayDate != updateDate) {
            getCountryConfiguration()
        } else {
            MemoryCache.updateCountryInfo(savedConfiguration, savedLanguage)
            if (savedLanguage == null) {
                getLanguageStringsFile(MemoryCache.defaultLanguageFull ?: GLOBAL_LANGUAGE)
            } else {
//                val savedLanguageShort = savedLanguage.substring(0, 2)
                MemoryCache.updateCountryInfo(savedConfiguration, savedLanguage)
//                MemoryCache.defaultLanguage = savedLanguageShort
                MemoryCache.defaultLanguageFull = savedLanguage
                getLanguageStringsFile(savedLanguage)
            }
        }
    }

    private fun getLanguageStringsFile(language: String) {
        mViewModel.getLanguageStringsFile(language)
    }

    private fun getCountryConfiguration() {
        mViewModel.languageLiveData.observe(this, Observer<Int> {
            showWelcomeActivity()
        })
        mViewModel.getConfiguration()
    }

    override fun onLanguageChange(language: String) {
        logoImage.visibility = View.GONE
        iv_splash_big_logo.visibility = View.VISIBLE
        doExecute()
    }

    private fun showWelcomeActivity() {
        if (getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).getBoolean("firstIn", true)) {
            RegisterTAndCActivity.showActivity(this)
            getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).edit().putBoolean("firstIn", false).apply()
        } else {
            startActivity(Intent(this, WelcomeActivity::class.java))
        }
        finish()
    }
}
