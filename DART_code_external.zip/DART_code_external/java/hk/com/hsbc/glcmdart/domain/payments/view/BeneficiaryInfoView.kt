/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.view

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_COUNTRY
import hk.com.hsbc.glcmdart.client.VALUE_BANK_CODE_LABEL
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.view_common_beneficiary_info.view.*

class BeneficiaryInfoView(context: Context?) : LinearLayout(context) {

    private var invoice: InvoiceListItem? = null
    private var llPaymentState: View? = null
    private var llPaymentStateMiddle: View? = null

    init {
        val mInflater = LayoutInflater.from(context)
        mInflater.inflate(R.layout.view_beneficiary_info, this, true)
    }

    fun setInvoiceEntity(entity: InvoiceListItem?) {
        invoice = entity
        updateContentView()
    }

    private fun updateContentView() {
        tv_bankname.text = MemoryCache.getLabelText("s_bank_name_value") ?: context.getString(R.string.s_bank_name_value)
        MemoryCache.getLabelText("s_ifsc_code_value")?.let {
            if (!it.isBlank()) {
                tv_IFSC_code.text = it
            } else {
                tv_IFSC_code.text = context.getString(R.string.s_ifsc_code_value)
            }
        }
        MemoryCache.getLabelText("s_beneficiary_info")?.let {
            if (!it.isBlank()) {
                tv_baneficiary_info_tag.text = it
            }
        }
        MemoryCache.getLabelText("head_payment_bank_name")?.let {
            if (!it.isBlank()) {
                tv_bankname_title.text = it
            }
        }
        MemoryCache.getLabelText("s_bank_code_label")?.let {
            if (!it.isBlank()) {
                tv_IFSC_code_title.text = it
            }
        }
        tv_IFSC_code.text = MemoryCache.bankCode
        MemoryCache.getLabelText("head_payment_account_number")?.let {
            if (!it.isBlank()) {
                tv_account_number_title.text = it
            }
        }
        MemoryCache.getLabelText("s_account_name")?.let {
            if (!it.isBlank()) {
                tv_account_name_title.text = it
            }
        }
        invoice?.invoice?.payee?.account?.display?.let {
            tv_account_number.text = it
        }
        invoice?.invoice?.payee?.name?.let {
            tv_account_name.text = it
        }
    }

    fun setMainPageWidget(llPaymentState: View?, llPaymentStateMiddle: View?){
        this.llPaymentState = llPaymentState
        this.llPaymentStateMiddle = llPaymentStateMiddle
    }

    fun updateMainPageWidgetState(){
        llPaymentState?.visibility = View.GONE
        llPaymentStateMiddle?.visibility = View.GONE
    }
}