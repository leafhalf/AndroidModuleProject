/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.google.gson.Gson
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.*
import hk.com.hsbc.glcmdart.domain.payments.contract.PaymentInfoUpdateContact
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentDetailEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentDetailEntityPayload
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.domain.payments.presenter.PaymentCreateViewModel
import hk.com.hsbc.glcmdart.domain.payments.presenter.PaymentInfoUpdateViewModel
import hk.com.hsbc.glcmdart.domain.payments.view.InvoiceTobePaidView
import hk.com.hsbc.glcmdart.domain.payments.view.ProvidePaymentInfoView
import hk.com.hsbc.glcmdart.domain.payments.view.ProvidePaymentInfoView.Companion.TYPE_PAYMENT_CHANGE
import hk.com.hsbc.glcmdart.domain.payments.view.ProvidePaymentInfoView.Companion.TYPE_PAYMENT_UPDATE
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showShortToast
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import kotlinx.android.synthetic.main.activity_payment_info_update.*
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.ceil

class PlannedPaymentUpdateActivity : BaseActivity(), PaymentInfoUpdateContact.View {

    private lateinit var mViewModel: PaymentInfoUpdateViewModel
    private lateinit var mCreateViewModel: PaymentCreateViewModel
    private val mProvidePaymentInfoView by lazy { ProvidePaymentInfoView(this, TYPE_PAYMENT_UPDATE) }
    private val mProvidePaymentInfoViewRevise by lazy { ProvidePaymentInfoView(this, TYPE_PAYMENT_CHANGE) }
    private val mInvoiceTobePaidView by lazy { InvoiceTobePaidView(this, 1) }
    private var paymentDetail: PaymentDetailEntity? = null
    private var updateType: Int? = -1
    private var creditNotesVar: List<CreditNoteLocal>? = null
    private var currency: String? = null
    private var isCreditNoteMethod = false
    private var isFullDeduction = false
    private var isChangeMethod = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_info_update)
        initViewAndEvent()
    }

    @SuppressLint("ResourceAsColor")
    private fun initViewAndEvent() {
        tl_head.title = ""
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        tl_head.title = MemoryCache.getLabelText("s_payment_infomation") ?: getString(R.string.s_payment_infomation)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            finish()
        }

//        mPresenter.attachView(this)
        mViewModel = ViewModelProviders.of(this).get(PaymentInfoUpdateViewModel::class.java)
        mCreateViewModel = ViewModelProviders.of(this).get(PaymentCreateViewModel::class.java)
        mCreateViewModel.bankHolidayLiveData.observe(this, Observer {
            hideLoadingDialogExt()
            setBankCalendar(it)
        })
        mViewModel.paymentUpdateResultLiveData.observe(this, Observer {
            setUpdateItpResult(it)
        })

        mViewModel.paymentErrorLiveData.observe(this, Observer {
            showRequestFailedMsg(it ?: "")
        })
        mViewModel.requestLoadingLiveData.observe(this, Observer {
            if (it) showLoadingDialogExt() else hideLoadingDialogExt()
        })
        mViewModel.deductionLiveData.observe(this, Observer {
            hideLoadingDialogExt()
            btn_update.isEnabled = true
            tl_head.title = MemoryCache.getLabelText("s_invoice_infomation") ?: getString(R.string.s_invoice_infomation)
            mInvoiceTobePaidView.setMainPageWidget(null,
                    null, null, null,
                    btn_update, null, null, null, currency)
            mInvoiceTobePaidView.setCreditNoteMethod(isCreditNoteMethod)
            mInvoiceTobePaidView.setFullDeduction(isFullDeduction)
            val remainDeductionMap = it as MutableMap<String, ArrayList<TaxDeductionInfo>?>
            paymentDetail?.itp?.lines?.forEach { line ->
                if (line.type == DEDUCTION) {
                    val remainDeductionList = remainDeductionMap[line.appliesTo]
                    // check if deduction in returned list
                    var isInList = false
                    remainDeductionList?.forEach { deduction ->
                        if (deduction.token == line.token) {
                            isInList = true
                        }
                    }
                    if (!isInList) {
                        paymentDetail?.deductions?.get(line.appliesTo)?.forEach { deductionUsed ->
                            if (deductionUsed.token == line.token) {
                                deductionUsed.selected = true
                                remainDeductionMap[line.appliesTo]?.add(0, deductionUsed)
                            }
                        }
                    }
                }
            }
            if (it.isNotEmpty()) {
                mInvoiceTobePaidView.setDeductions(it as MutableMap<String, ArrayList<TaxDeductionInfo>?>)
            }
            if (!creditNotesVar.isNullOrEmpty()) {
                mInvoiceTobePaidView.setInvoiceListWithCreditNotes(paymentDetail!!, creditNotesVar)
            } else {
                val creditNotes = paymentDetail?.creditNotes
                val creditNotesLocalMap = mutableMapOf<String, CreditNoteLocal>()
                val creditNotesLocal = mutableListOf<CreditNoteLocal>()
                if (creditNotes != null) {
                    for (item in creditNotes) {
                        item.creditNote?.outstanding = "0"
                        creditNotesLocalMap[item.token!!] = item
                    }
                    for (item in creditNotesLocalMap) {
                        creditNotesLocal.add(item.value)
                    }
                }
                mInvoiceTobePaidView.setInvoiceListWithCreditNotes(paymentDetail!!, creditNotesLocal)
            }
            ll_container.addView(mInvoiceTobePaidView)
        })
        updateType = intent.getIntExtra(INTENT_DATA_UPDATE_TYPE, -1)
        currency = intent.getStringExtra(INTENT_DATA_CURRENCY)
        if (intent.getSerializableExtra(INTENT_DATA_PAYMENT_METHOD) != null) {
            mProvidePaymentInfoView.setPaymentMethods(intent.getSerializableExtra(INTENT_DATA_PAYMENT_METHOD) as PaymentMethod)
            mProvidePaymentInfoViewRevise.setPaymentMethods(intent.getSerializableExtra(INTENT_DATA_PAYMENT_METHOD) as PaymentMethod)
        }
        if (intent.getSerializableExtra(INTENT_DATA_PAYMENT_DETAIL) != null) {
            paymentDetail = intent.getSerializableExtra(INTENT_DATA_PAYMENT_DETAIL) as PaymentDetailEntity
        }
        if (intent.getSerializableExtra(INTENT_DATA_PAYMENT_CREDITNOTE_VAR) != null) {
            creditNotesVar = intent.getSerializableExtra(INTENT_DATA_PAYMENT_CREDITNOTE_VAR) as List<CreditNoteLocal>?
        }
        isCreditNoteMethod = intent.getBooleanExtra(INTENT_DATA_IS_CREDIT_NOTE_METHOD, false)
        isFullDeduction = intent.getBooleanExtra(INTENT_DATA_IS_FULL_DEDUCTION, false)

        if (paymentDetail != null) {
            when (updateType) {
                UPDATE_TYPE_PAYMENT_INFO -> {
//                    showLoadingDialogExt()
//                    mPresenter.requestBankCalendar(MemoryCache.defaultCountry ?: MARKET_COUNTRY)
                    tl_head.title = MemoryCache.getLabelText("s_payment_infomation") ?: getString(R.string.s_payment_infomation)
                    showLoadingDialogExt()
                    mCreateViewModel.requestBankCalendar(MemoryCache.defaultCountry)
                    mProvidePaymentInfoView.setMainPageWidget(null,null,
                            null, null, null, btn_update,  null, "", currency)
                    mProvidePaymentInfoView.disablePaymentMethodClick()
                    mProvidePaymentInfoView.backfillCurrentViewData(paymentDetail)
                    ll_container.addView(mProvidePaymentInfoView)
                }
                UPDATE_TYPE_INVOICE_INFO -> {
                    showLoadingDialogExt()
                    mViewModel.requestDeductions(paymentDetail?.itp?.payeeReference, MemoryCache.defaultCountry, paymentDetail?.itp?.payeeAccount?.reference)
                }
            }
        }
        btn_update.setOnClickListener {
            if (btn_update.text.toString() == (MemoryCache.getLabelText("s_next") ?: getString(R.string.s_next))) {
                showLoadingDialogExt()
                mCreateViewModel.requestBankCalendar(MemoryCache.defaultCountry)
                mProvidePaymentInfoViewRevise.setMainPageWidget(null,null,
                        null, null, null, btn_update,  null, "", currency)
                mProvidePaymentInfoViewRevise.setNextButtonState()
                isChangeMethod = true
                btn_update.text = MemoryCache.getLabelText("s_update") ?: getString(R.string.s_update)
                ll_extra_method_container.addView(mProvidePaymentInfoViewRevise)
            } else {
                confirmSubmission()
            }
        }

        MemoryCache.getLabelText("s_update")?.let {
            if (!it.isBlank()) {
                btn_update.text = it
            }
        }
    }

    override fun setBankCalendar(entries: List<BankCalendarDate>) {
        if (updateType == UPDATE_TYPE_PAYMENT_INFO) {
            mProvidePaymentInfoView.setBankCalendar(entries)
        } else {
            mProvidePaymentInfoViewRevise.setBankCalendar(entries)
        }
    }

    private fun confirmSubmission() {
        val dataMap = mutableMapOf<String, Any>()
        var extraMap = mutableMapOf<String, String?>()
        getOriginalPaymentInfo(dataMap)
        getOriginalInvoiceData(dataMap)
        when (updateType) {
            UPDATE_TYPE_PAYMENT_INFO -> {
                var tealium = ""
                when (dataMap["paymentMethod"]) {
                    ProvidePaymentInfoView.bank_transfer -> tealium = "bank"
                    ProvidePaymentInfoView.cheque -> tealium = "cheque"
                    ProvidePaymentInfoView.rtgs -> tealium = "rtgs"
                    ProvidePaymentInfoView.ach -> tealium = "ach"
                    ProvidePaymentInfoView.dcms -> tealium = "dcms"
                    ProvidePaymentInfoView.deduction -> tealium = ProvidePaymentInfoView.deduction
                    ProvidePaymentInfoView.va -> tealium = ProvidePaymentInfoView.va
                }
                TealiumUtil.eventTag("onsite", "planned payments - update payment info: $tealium: update")
                val providePaymentInfoData = mProvidePaymentInfoView.getCurrentViewData()
                for (item in providePaymentInfoData) {
                    dataMap[item.key] = item.value
                    if (item.key == "extra") {
                        extraMap = item.value as MutableMap<String, String?>
                    }
                }
            }
            UPDATE_TYPE_INVOICE_INFO -> {
                TealiumUtil.pageTag("dart : buyer portal : invoices : planned payments - update invoice info",
                        "/dart/buyer portal/invoices/planned payments-update invoice info", "transaction", "buyer portal",
                        "invoices")
                TealiumUtil.eventTag("button click", "planned payments - update invoice info: add invoice added: update")
                val invoiceTobePaidData = mInvoiceTobePaidView.getCurrentViewData()
                for (item in invoiceTobePaidData) {
                    dataMap[item.key] = item.value
                }
                if (isChangeMethod) {
                    val providePaymentInfoData = mProvidePaymentInfoViewRevise.getCurrentViewData()
                    for (item in providePaymentInfoData) {
                        dataMap[item.key] = item.value
                    }
                } else {
                    paymentDetail?.itp?.extra?.dcms_va_payment_code?.let {
                        extraMap["dcms_va_payment_code"] = it
                        extraMap["payment_method_provider"] = "DOKU"
                    }
                }
            }
        }
        // check if change to full deduction
        if (dataMap["isFullDeduction"] == true) {
            dataMap["paymentMethod"] = ProvidePaymentInfoView.deduction
        }
        // check all line, if origin is full_deduction and no need to change payment method, that means totalAmountToPay is 0,
        // means use credit note to pay the payment
        if (isFullDeduction) {
            val lines = dataMap["lines"] as List<Line?>?
            if (lines != null) {
                for (line in lines) {
                    if (line?.type == CREDITNOTE && !isChangeMethod) {
                        dataMap["paymentMethod"] = ProvidePaymentInfoView.credit_note
                    }
                }
            }
        }

        if (dataMap["paymenMethod"] == ProvidePaymentInfoView.ach) {
            val banHour = MemoryCache.getACHLimitation(this, currency
                    ?: MemoryCache.defaultCurrency!!)
            val banDays = ceil(banHour / 24.0)
            val currentDate = SimpleDateFormat("yyyy-MM-dd").format(Date())
            if (TimeZoneTransformsUtil.calDaysBetween(currentDate, dataMap["expectedDate"] as String?).toInt() <= banDays) {
                Toast.makeText(this,
                        String.format(MemoryCache.getLabelText("s_ach_ban_tip")
                                ?: getString(R.string.s_ach_ban_tip),
                                banHour.toString()),
                        Toast.LENGTH_SHORT).show()
                return
            }
        }
        val payeeAccount = Account(paymentDetail?.itp?.payeeAccount?.reference, paymentDetail?.itp?.payeeAccount?.currency,
                paymentDetail?.itp?.payeeAccount?.countryCode, paymentDetail?.itp?.payeeAccount?.referenceGroup,
                paymentDetail?.itp?.payeeAccount?.display)
        val payorAccount = Account(paymentDetail?.itp?.payorAccount?.reference, paymentDetail?.itp?.payorAccount?.currency,
                paymentDetail?.itp?.payorAccount?.countryCode, paymentDetail?.itp?.payorAccount?.referenceGroup,
                paymentDetail?.itp?.payorAccount?.display)
        //payee
        dataMap["payeeReference"] = paymentDetail?.itp?.payeeReference ?: ""
        dataMap["payeeAccount"] = payeeAccount
        //payor
        dataMap["payorReference"] = paymentDetail?.itp?.payorReference ?: ""
        dataMap["payorAccount"] = payorAccount
        extraMap["use_generated_token"] = paymentDetail?.itp?.extra?.use_generated_token ?: "true"
        if (isChangeMethod) {
            if (dataMap["paymentMethod"] == ProvidePaymentInfoView.dcms) {
                if (MemoryCache.defaultCountry == "IN") {
                    extraMap["payment_method_provider"] = "PayU"
                } else {
                    extraMap["payment_method_provider"] = "DOKU"
                }
            }
        } else if (paymentDetail?.itp?.paymentMethod == ProvidePaymentInfoView.dcms) {
            if (MemoryCache.defaultCountry == "IN") {
                extraMap["payment_method_provider"] = "PayU"
            } else {
                extraMap["payment_method_provider"] = "DOKU"
            }
        }
        paymentDetail?.itp?.extra?.payment_cheque_amount?.let {
            extraMap["payment_cheque_amount"] = it
        }
        paymentDetail?.itp?.extra?.payment_cheque_currency?.let {
            extraMap["payment_cheque_currency"] = it
        }
        paymentDetail?.itp?.extra?.payment_cheque_date?.let {
            extraMap["payment_cheque_date"] = it
        }
        paymentDetail?.itp?.extra?.payment_cheque_number?.let {
            extraMap["payment_cheque_number"] = it
        }
        paymentDetail?.itp?.extra?.dcms_transaction_ref?.let {
            extraMap["dcms_transaction_ref"] = it
        }
        paymentDetail?.itp?.extra?.dcms_redirect_link?.let {
            extraMap["dcms_redirect_link"] = it
        }
        dataMap["extra"] = extraMap
        mViewModel.requestValidateItp(paymentDetail!!.token, dataMap)
    }

    private fun getOriginalPaymentInfo(dataMap: MutableMap<String, Any>) {
        if (paymentDetail != null && paymentDetail!!.itp != null) {
            //expectedDate
            dataMap["expectedDate"] = paymentDetail?.itp?.expectedDate ?: ""
            //paymentReference
            dataMap["paymentReference"] = paymentDetail?.itp?.paymentReference ?: ""
            //paymentMethod
            dataMap["paymentMethod"] = paymentDetail?.itp?.paymentMethod ?: ""
            //extra
            paymentDetail?.itp?.extra?.also {
                dataMap["extra"] = it
            }
        }
    }

    private fun getOriginalInvoiceData(dataMap: MutableMap<String, Any>) {
        //lines
        paymentDetail?.itp?.lines?.also {
            dataMap["lines"] = it
        }
    }

    override fun setUpdateItpResult(paymentDetailEntityPayload: PaymentDetailEntityPayload) {
        setResult(Activity.RESULT_OK)
        finish()
    }

    override fun showRequestFailedMsg(msg: String?) {
        if (msg.isNullOrEmpty()) {
            return
        }

        var title = ""
        var message = ""
        when {
            msg.contains("achMandateExpired") -> {
                title = MemoryCache.getLabelText("s_ach_invalid_payment_date") ?: getString(R.string.s_ach_invalid_payment_date)
                message = (MemoryCache.getLabelText("s_ach_mandate_tips") ?: getString(R.string.s_ach_mandate_tips))
                        .replace("ACH", MemoryCache.getLabelText("s_payment_method_label_" + "ach") ?: "")
            }
            msg.contains("achPaymentWithin48Hours") -> {
                title = MemoryCache.getLabelText("s_ach_invalid_payment_date") ?: getString(R.string.s_ach_invalid_payment_date)
                message = MemoryCache.getLabelText("s_ach_date_tips") ?: getString(R.string.s_ach_date_tips)
            }
            msg.contains("achMandateAmountTooLarge") -> {
                title = MemoryCache.getLabelText("s_ach_invalid_payment_Amout") ?: getString(R.string.s_ach_invalid_payment_Amout)
                message = (MemoryCache.getLabelText("s_ach_payment_Amout_tips")?.replace("ACH", MemoryCache.getLabelText("s_payment_method_label_" + "ach") ?: "")
                        ?.replace("INR", currency ?: MARKET_CURRENCY)
                        ?: getString(R.string.s_ach_payment_Amout_tips)).replace("ACH",MemoryCache.getLabelText("s_payment_method_label_" + "ach") ?: "")
                try {
                    val map = Gson().fromJson<MutableMap<String, String>>(msg, MutableMap::class.java)
                    if (map.isNotEmpty() && map.containsKey("achMandateAmount")) {
                        message += IndiaNumberUtil.formatNumByDecimal(map["achMandateAmount"].toString(), currency ?: MARKET_CURRENCY)
                        message = message.replace("INR", currency ?: MARKET_CURRENCY)
                    }
                } catch (e: IOException) {

                }
            }
        }
        if (title.isBlank()) {
            showShortToast(msg)
        } else {
            CommonDialog.showAlertDialog(this, title,
                    message,
                    MemoryCache.getLabelText("s_amend") ?: getString(R.string.s_amend), object : CommonDialogExtras.OnButtonListener {
                override fun positiveButtonListener() {
                    finish()
                }

                override fun negativeButtonListener() {

                }
            }, MemoryCache.getLabelText("s_cancel") ?: getString(R.string.s_cancel))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CODE_SELECT_INVOICE, REQUEST_CODE_INVOICE_EDIT_DETAIL -> {
                    mInvoiceTobePaidView.onActivityResult(data)
                }
                REQUEST_CODE_GET_PAYMENT_METHOD -> {
//                    mProvidePaymentInfoView.onActivityResult(REQUEST_CODE_GET_PAYMENT_METHOD, data)
                    mProvidePaymentInfoViewRevise.onActivityResult(REQUEST_CODE_GET_PAYMENT_METHOD, data)
                }
                REQUEST_CODE_CHOOSE_VA_BANK_LIST -> {
                    mProvidePaymentInfoViewRevise.onActivityResult(REQUEST_CODE_CHOOSE_VA_BANK_LIST, data)
                    mProvidePaymentInfoView.onActivityResult(REQUEST_CODE_CHOOSE_VA_BANK_LIST, data)
                }
            }
        }
    }

    override fun showProgressDialog(title: String?) {
        showLoadingDialogExt()
    }

    override fun dismissProgressDialog() {
        hideLoadingDialogExt()
    }

    override fun onResume() {
        super.onResume()
        if (updateType == UPDATE_TYPE_INVOICE_INFO) {
            TealiumUtil.pageTag("dart:buyer portal:planned payments:update invoice info",
                    "/dart/buyer-portal/planned-payments/update-invoice-info", "payment", "buyer portal",
                    "planned payments")
        } else {
            TealiumUtil.pageTag("dart : buyer portal : payments : planned payments - update payment info",
                    "/dart/buyer-portal/payments/planned payments-update payment info", "transaction", "buyer portal",
                    "payments", "mobile","en", "update planned payment", "1", "update planned payment - start")
        }
    }

    companion object {
        const val UPDATE_TYPE_PAYMENT_INFO = 1
        const val UPDATE_TYPE_INVOICE_INFO = 2
        const val INTENT_DATA_CURRENCY = "currency"
        const val INTENT_DATA_UPDATE_TYPE = "update_type"
        const val INTENT_DATA_PAYMENT_DETAIL = "payment_detail"
        const val INTENT_DATA_PAYMENT_METHOD = "payment_method"
        const val INTENT_DATA_PAYMENT_CREDITNOTE = "credit_note"
        const val INTENT_DATA_PAYMENT_CREDITNOTE_VAR = "credit_note_variable"
        const val INTENT_DATA_IS_CREDIT_NOTE_METHOD = "is_credit_note"
        const val INTENT_DATA_IS_FULL_DEDUCTION = "is_deduction"
        fun showActivity1(activity: Activity, paymentDetailEntity: PaymentDetailEntity?, updateType: Int?,
                          creditNotesVariable: List<CreditNoteLocal>?, paymentMethods: PaymentMethod?,
                          currency: String?, requestCode: Int, isCreditnoteMethod: Boolean = false,
                          isFullDeduction: Boolean = false) {
            val intent = Intent(activity, PlannedPaymentUpdateActivity::class.java).apply {
                putExtra(INTENT_DATA_PAYMENT_DETAIL, paymentDetailEntity)
                putExtra(INTENT_DATA_UPDATE_TYPE, updateType)
                putExtra(INTENT_DATA_CURRENCY, currency)
                putExtra(INTENT_DATA_PAYMENT_METHOD, paymentMethods)
                putExtra(INTENT_DATA_IS_CREDIT_NOTE_METHOD, isCreditnoteMethod)
                putExtra(INTENT_DATA_IS_FULL_DEDUCTION, isFullDeduction)
                if (creditNotesVariable != null)
                    putExtra(INTENT_DATA_PAYMENT_CREDITNOTE_VAR, creditNotesVariable as ArrayList<CreditNoteLocal>)
            }
            activity.startActivityForResult(intent, requestCode)
        }

        fun showActivity(activity: Activity, paymentDetailEntity: PaymentDetailEntity?, updateType: Int?, paymentMethods: PaymentMethod?, currency: String?, requestCode: Int) {
            val intent = Intent(activity, PlannedPaymentUpdateActivity::class.java).apply {
                putExtra(INTENT_DATA_PAYMENT_DETAIL, paymentDetailEntity)
                putExtra(INTENT_DATA_UPDATE_TYPE, updateType)
                putExtra(INTENT_DATA_PAYMENT_METHOD, paymentMethods)
                putExtra(INTENT_DATA_CURRENCY, currency)
            }
            activity.startActivityForResult(intent, requestCode)
        }
    }
}