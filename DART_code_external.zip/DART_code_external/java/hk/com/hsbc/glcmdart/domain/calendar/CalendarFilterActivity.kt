package hk.com.hsbc.glcmdart.domain.calendar

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.R.drawable
import hk.com.hsbc.glcmdart.R.string
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import kotlinx.android.synthetic.main.activity_calendar_filter.*

class CalendarFilterActivity : BaseActivity() {

    private var mSelectedCurrency: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar_filter)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(true, this)
        mSelectedCurrency = intent?.getStringExtra(FILTER_CURRENCY)

        mToolbar.title = MemoryCache.getLabelText("s_currency") ?: getString(string.s_currency)
        mToolbar.setNavigationIcon(drawable.ic_close_on_light)
        setSupportActionBar(mToolbar)
        mToolbar.setNavigationOnClickListener {
            finish()
        }

        mContainerLayout.removeAllViews()
        val mCurrencies = MemoryCache.getCurrencyMap()
        mCurrencies.forEach(action = {
            val country = it.key
            it.value.forEach { currency ->
                val mItemView = LayoutInflater.from(this).inflate(R.layout.item_calendar_filter, null)
                val mTopLayout = mItemView.findViewById<RelativeLayout>(R.id.mTopLayout)
                val mContentText = mItemView.findViewById<TextView>(R.id.mContentText)
                val mCheckedImage = mItemView.findViewById<ImageView>(R.id.mCheckedImage)
                mContentText.text = currency
                mCheckedImage.setImageResource(if (mContentText.text == mSelectedCurrency) drawable.ic_done else drawable.transparent)
                mTopLayout.tag = country
                mTopLayout.setOnClickListener {
                    mSelectedCurrency = mContentText.text.toString()
                    mContainerLayout.childCount
                    for (index in 1..mContainerLayout.childCount) {
                        mContainerLayout.getChildAt(index - 1).also { view ->
                            if (view.findViewById<TextView>(R.id.mContentText).text == mSelectedCurrency) {
                                view.findViewById<ImageView>(R.id.mCheckedImage).setImageResource(drawable.ic_done)
                            } else {
                                view.findViewById<ImageView>(R.id.mCheckedImage).setImageResource(drawable.transparent)
                            }
                        }
                    }
                    val intent = Intent().apply {
                        putExtra(FILTER_CURRENCY, mSelectedCurrency)
                        putExtra(FILTER_COUNTRY, it.tag as String)
                    }
                    setResult(Activity.RESULT_OK, intent)
                    finish()
                }
                mContainerLayout.addView(mItemView)
            }
        })
    }

    companion object {
        const val FILTER_CURRENCY = "RESULT_TAG_FILTER_CURRENCY"
        const val FILTER_COUNTRY = "RESULT_TAG_FILTER_COUNTRY"
        const val REQUEST_CODE_CALENDAR_FILTER = 1001
        fun showActivity(fragment: Fragment, selectedCurrency: String?, requestCode: Int) {
            val intent = Intent(fragment.activity, CalendarFilterActivity::class.java).apply {
                if (selectedCurrency != null)
                    putExtra(FILTER_CURRENCY, selectedCurrency)
            }
            fragment.startActivityForResult(intent, requestCode)
        }
    }
}
