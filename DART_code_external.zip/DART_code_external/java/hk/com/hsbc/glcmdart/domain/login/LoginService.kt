/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.login

import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.PayeeEntity
import hk.com.hsbc.glcmdart.domain.dashboard.ProfileDetailEntity
import io.reactivex.Observable
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.*

interface LoginService {

    @Headers("Content-Type: application/json;charset=utf-8",
            "Accept: application/json, text/plain, */*")
    @POST(URL_LOGIN)
    fun requestLogin(@Body requestBody: LoginBean): Observable<Response<LoginEntity>>

    @Headers("Content-Type: application/json;charset=utf-8",
            "Accept: application/json, text/plain, */*")
    @POST(URL_SESSION)
    fun requestSession(): Call<SessionEntity>

    @Headers("Content-Type: application/json;charset=utf-8",
            "Accept: application/json, text/plain, */*")
    @GET(URL_PROFILE)
    fun requestProfile(): Observable<Response<ProfileEntity>>

    @Headers("Content-Type: application/json;charset=utf-8",
            "Accept: application/json, text/plain, */*")
    @GET(URL_PROFILE_DETAIL)
    fun requestProfileDetail(): Observable<Response<ProfileDetailEntity>>

    @Headers("Content-Type: application/json;charset=utf-8",
            "Accept: application/json, text/plain, */*")
    @POST(URL_ORGANISATIONS)
    fun requestOrganisations(): Observable<Response<PayeeEntity>>

    @Headers("Content-Type: application/json;charset=utf-8",
            "Accept: application/json, text/plain, */*")
    @DELETE(URL_SESSION)
    fun requestLogout(): Call<LogoutEntity>

    @Headers("Content-Type: application/json;charset=utf-8",
            "Accept: application/json, text/plain, */*")
    @POST(URL_UPLOAD_URBAN_AIRSHIP)
    fun uploadUrbanAirshipInfo(@Body requestBody: RequestUrbanAirship): Observable<UrbanAirshipEntity>

    @Headers("Content-Type: application/json;charset=utf-8",
            "Accept: application/json, text/plain, */*")
    @DELETE(URL_DETACH_URBAN_AIRSHIP)
    fun detachUrbanAirship(@Path("userId") userId: String): Observable<DetachUrbanAirshipEntity>
}
