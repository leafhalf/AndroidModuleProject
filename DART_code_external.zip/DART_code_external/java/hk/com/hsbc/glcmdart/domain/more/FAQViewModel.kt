package hk.com.hsbc.glcmdart.domain.more

import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.more.entity.HelpEntity
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class FAQViewModel: BaseViewModel() {

    private val faqModel: MoreSimpleListModel by lazy { MoreSimpleListModel() }

    val helpLiveData = MutableLiveData<HelpEntity?>()

    fun requestData() {
        val disposable = faqModel.getHelpInfo()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    helpLiveData.postValue(it)
                }, {
                    requestLoadingLiveData.postValue(false)
                    helpLiveData.postValue(null)
                })
    }
}