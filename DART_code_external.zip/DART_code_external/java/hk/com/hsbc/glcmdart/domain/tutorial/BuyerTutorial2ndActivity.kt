/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.tutorial

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.activity_buyer_tutorial_2nd.*
import kotlin.math.roundToInt

class BuyerTutorial2ndActivity : BaseActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buyer_tutorial_2nd)
        nextButton.setOnClickListener(this)
        skipButton.setOnClickListener(this)

        MemoryCache.getLabelText("button_next")?.let {
            if (!it.isBlank()) {
                nextButton.text = it
            }
        }

        MemoryCache.getLabelText("button_skip")?.let {
            if (!it.isBlank()) {
                skipButton.text = it
            }
        }

        if (MemoryCache.defaultCountry == "ID" && MemoryCache.defaultLanguageFull == "id-id") {
            pfl_buyer_tutorial_2.background = getDrawable(R.mipmap.buyer_tutorial_2nd_id)
        }

//        val nextLp = nextButton.layoutParams as ConstraintLayout.LayoutParams
//        nextLp.bottomMargin = (resources.displayMetrics.heightPixels * 0.22).roundToInt()
//        nextButton.layoutParams = nextLp
//        val skipLp = skipButton.layoutParams as ConstraintLayout.LayoutParams
//        skipLp.bottomMargin = (resources.displayMetrics.heightPixels * 0.22).roundToInt()
//        skipButton.layoutParams = skipLp
    }

    override fun onClick(v: View?) {
        when (v) {
            nextButton -> {
                startActivity(Intent(this, BuyerTutorial3thActivity::class.java))
                finish()
            }
            skipButton -> {
                finish()
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}