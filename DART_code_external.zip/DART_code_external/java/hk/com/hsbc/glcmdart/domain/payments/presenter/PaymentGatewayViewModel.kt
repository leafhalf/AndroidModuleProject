package hk.com.hsbc.glcmdart.domain.payments.presenter

import android.annotation.SuppressLint
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import hk.com.hsbc.glcmdart.domain.dart.ErrorBody
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentTrackInfo
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class PaymentGatewayViewModel: PaymentBaseViewModel() {

    val mGatewayLiveData = MutableLiveData<String>()
    val mPaymentTrackingLiveData = MutableLiveData<PaymentTrackInfo>()
    val mPaymentTrackingErrorLiveData = MutableLiveData<String>()

    @SuppressLint("CheckResult")
    fun getPaymentGateHtml(token: String) {
        paymentsModel.requestPaymentGatewayHtml(token)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    requestLoadingLiveData.postValue(false)
                    if (it.redirectHtml != null) {
                        mGatewayLiveData.postValue(it.redirectHtml)
                    } else {
                        mGatewayLiveData.postValue("")
                    }
                }, {
                    requestLoadingLiveData.postValue(false)
                    if ((it as HttpException).code() != 302) {
                        try {
                            val errorBody = Gson().fromJson(it.response().errorBody()?.string(), ErrorBody::class.java)
                            paymentErrorLiveData.postValue(errorBody.errorText)
                        } catch (e: Exception) {
                            paymentErrorLiveData.postValue(e.toString())
                        }
                    } else {
                        paymentErrorLiveData.postValue("302")
                    }
                })
    }

    @SuppressLint("CheckResult")
    fun trackPayment(token: String) {
        paymentsModel.requestPaymentTracking(token)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    requestLoadingLiveData.postValue(false)
                    if (it.payload != null) {
                        mPaymentTrackingLiveData.postValue(it.payload)
                    } else {
                        mPaymentTrackingErrorLiveData.postValue("Track payment fail!")
                    }
                }, {
                    requestLoadingLiveData.postValue(false)
                    try {
                        val errorBody = Gson().fromJson((it as HttpException).response().errorBody()?.string(), ErrorBody::class.java)
                        if (errorBody.errorText.contains("fail to get transaction information")) {
                            val failTrackInfo = PaymentTrackInfo(null, "non-init",
                                    null, null, null)
                            mPaymentTrackingLiveData.postValue(failTrackInfo)
                        } else {
                            mPaymentTrackingErrorLiveData.postValue(errorBody.errorText)
                        }
                    } catch (e: Exception) {
                        mPaymentTrackingErrorLiveData.postValue(e.toString())
                    }
                })
    }


}