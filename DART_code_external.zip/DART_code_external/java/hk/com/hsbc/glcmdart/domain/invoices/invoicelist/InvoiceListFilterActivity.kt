/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.content.ContextCompat
import com.google.gson.Gson
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog.Companion.TYPE_DUE_DATE_FROM
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog.Companion.TYPE_DUE_DATE_TO
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog.Companion.TYPE_ISSUE_DATE_FROM
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog.Companion.TYPE_ISSUE_DATE_TO
import hk.com.hsbc.glcmdart.domain.payments.SuppliersOrCustomersSelectActivity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.*
import kotlinx.android.synthetic.main.activity_invoice_list_filter.*
import kotlinx.android.synthetic.main.view_invoice_list_filter_amount.*
import kotlinx.android.synthetic.main.view_invoice_list_filter_date.*
import kotlinx.android.synthetic.main.view_invoice_list_filter_date.tv_date_tag
import java.util.*


/**
 * Created by Donut
 *
 * all invoice filter activity
 */
class InvoiceListFilterActivity : BaseActivity(), CompoundButton.OnCheckedChangeListener, View.OnClickListener {

    private lateinit var uploadParameterShadow: InvoiceRequestParameter
    private var lastRadioButton: RadioButton? = null
    private var originUploadParameterStr = ""
    private var selectedCountryCode = ""
    private val mGson by lazy { Gson() }
    private var isTealiumAmountInputFrom = false
    private var isTealiumAmountInputTo = false
    private var isDueFilter = false
    private var payeeOrPayor: Payee? = null
    private var conditionCount = 0
    private var currentAmountFrom = ""
    private var currentAmountTo = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_invoice_list_filter)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(true, this)
        supportActionBar?.hide()
        initEventAndData()
    }

    private fun initEventAndData() {
        MemoryCache.getLabelText("s_talkback_button_back")?.let {
            if (!it.isBlank()) {
                iv_invoice_list_filter_close.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_filters")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_title.text = it
            }
        }
        MemoryCache.getLabelText("s_reset")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_reset.text = it
            }
        }
        MemoryCache.getLabelText("s_supplier")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_supplier_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_currency")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_currency_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_invoice_status")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_status_tag.text = it
            }
        }
        tv_invoice_list_filter_status_fully_tag.text = MemoryCache.getLabelText("s_invoice_status_F")
        tv_invoice_list_filter_status_partially_tag.text = MemoryCache.getLabelText("s_invoice_status_P")
        tv_invoice_list_filter_status_unpaid_tag.text = MemoryCache.getLabelText("s_invoice_status_U")
        tv_invoice_list_filter_status_overpaid_tag.text = MemoryCache.getLabelText("s_invoice_status_O")
        tv_invoice_list_filter_status_closed_tag.text = MemoryCache.getLabelText("s_invoice_status_C")
        MemoryCache.getLabelText("s_fully_paid")?.let {
            if (!it.isBlank()) {
                cb_invoice_list_filter_status_fully_paid.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_partially_paid")?.let {
            if (!it.isBlank()) {
                cb_invoice_list_filter_status_partially_paid.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_unpaid")?.let {
            if (!it.isBlank()) {
                cb_invoice_list_filter_status_unpaid.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_overpaid")?.let {
            if (!it.isBlank()) {
                cb_invoice_list_filter_status_overpaid.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_closed")?.let {
            if (!it.isBlank()) {
                cb_invoice_list_filter_status_closed.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_invoice_amount")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_amount_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_apply_filter")?.let {
            if (!it.isBlank()) {
                btn_invoice_list_filter_set.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_set_filter")?.let {
            if (!it.isBlank()) {
                btn_invoice_list_filter_set.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_from")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_amount_from_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_to")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_amount_to_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_date")?.let {
            if (!it.isBlank()) {
                tv_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_any")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_issue_date_any_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_filter_date_any")?.let {
            if (!it.isBlank()) {
                rb_invoice_list_filter_date_any.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_issue_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_issue_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_last_one_month")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_issue_date_last_month_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_issue_date_last_month")?.let {
            if (!it.isBlank()) {
                rb_invoice_list_filter_issue_date_last_month.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_last_three_months")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_issue_date_last_three_month_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_issue_date_last_three_month")?.let {
            if (!it.isBlank()) {
                rb_invoice_list_filter_issue_date_last_three_month.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_select_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_issue_date_select_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_issue_date_select_date")?.let {
            if (!it.isBlank()) {
                rb_invoice_list_filter_issue_date_select.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_from")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_issue_date_from_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_select_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_issue_date_from.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_to")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_issue_date_to_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_select_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_issue_date_to.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_due_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_next_one_month")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_next_month_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_due_date_next_month")?.let {
            if (!it.isBlank()) {
                rb_invoice_list_filter_due_date_next_month.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_next_three_months")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_next_three_month_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_due_date_next_three_month")?.let {
            if (!it.isBlank()) {
                rb_invoice_list_filter_due_date_next_three_month.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_last_one_month")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_last_month_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_due_date_last_month")?.let {
            if (!it.isBlank()) {
                rb_invoice_list_filter_due_date_last_month.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_last_three_months")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_last_three_month_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_due_date_last_three_month")?.let {
            if (!it.isBlank()) {
                rb_invoice_list_filter_due_date_last_three_month.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_select_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_select_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_due_date_select_date")?.let {
            if (!it.isBlank()) {
                rb_invoice_list_filter_due_date_select.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_from")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_from_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_select_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_from.text = it
            }
        }
        MemoryCache.getLabelText("s_to")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_to_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_select_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_filter_due_date_to.text = it
            }
        }

        // save origin parameters
        try {
            originUploadParameterStr = mGson.toJson(intent?.getSerializableExtra(TAG_INVOICE_FILTER_PARAMETER) as InvoiceRequestParameter?)
            isDueFilter = intent.getBooleanExtra(TAG_INVOICE_FILTER_FLAG, false)
            uploadParameterShadow = mGson.fromJson(originUploadParameterStr, InvoiceRequestParameter::class.java)
        } catch (e: Exception) {
            Toast.makeText(this@InvoiceListFilterActivity, MemoryCache.getLabelText("s_data_error")
                    ?: getString(R.string.s_data_error), Toast.LENGTH_SHORT).show()
            finish()
        }
        ll_invoice_list_filter_title_container.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, ConvertUtil.dp2px(this, 16.0f).toInt())
        if ("S" == MemoryCache.getSessionEntity()?.type) {
            tv_invoice_list_filter_supplier_tag.text = MemoryCache.getLabelText("s_customer")
                    ?: getString(R.string.s_customer)
        }

        tv_invoice_list_filter_supplier.setAccessibilityDelegate(object : View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        })
        setAllRadioButtonListeners()
        setAllCheckBoxListeners()
        cloneParameter()
        tv_invoice_list_filter_supplier.setOnClickListener(this)
        btn_invoice_list_filter_set.setOnClickListener(this)
        rl_invoice_list_filter_issue_date_from.setOnClickListener(this)
        rl_invoice_list_filter_issue_date_to.setOnClickListener(this)
        rl_invoice_list_filter_due_date_from.setOnClickListener(this)
        rl_invoice_list_filter_due_date_to.setOnClickListener(this)
        tv_invoice_list_filter_reset.setOnClickListener(this)
        iv_invoice_list_filter_close.setOnClickListener(this)

        et_invoice_list_filter_amount_from.addTextChangedListener(AmountTextWatcher(true, et_invoice_list_filter_amount_from))

        et_invoice_list_filter_amount_from.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.toggleSoftInput(0, 0)
                et_invoice_list_filter_amount_to.isFocusable = true
                et_invoice_list_filter_amount_to.isFocusableInTouchMode = true
                et_invoice_list_filter_amount_to.requestFocus()
                et_invoice_list_filter_amount_to.findFocus()
                imm.toggleSoftInput(0, 0)
            }
            true
        }

        et_invoice_list_filter_amount_to.addTextChangedListener(AmountTextWatcher(false, et_invoice_list_filter_amount_to))

        et_invoice_list_filter_amount_to.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.toggleSoftInput(0, 0)
            }
            true
        }
    }

    /**
     * show origin parameter
     */
    private fun cloneParameter() {
        val allText = MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
        tv_invoice_list_filter_supplier.text = if ("S" == MemoryCache.getSessionEntity()?.type) {
            uploadParameterShadow.payorName
        } else {
            uploadParameterShadow.payeeName
        } ?: allText
        if (tv_invoice_list_filter_supplier.text.toString() != allText) {
            updateApplyText(true)
        }
        cb_invoice_list_filter_status_fully_paid.isChecked = uploadParameterShadow.status.contains("F")
        cb_invoice_list_filter_status_overpaid.isChecked = uploadParameterShadow.status.contains("O")
        cb_invoice_list_filter_status_partially_paid.isChecked = uploadParameterShadow.status.contains("P")
        cb_invoice_list_filter_status_unpaid.isChecked = uploadParameterShadow.status.contains("U")
        cb_invoice_list_filter_status_closed.isChecked = uploadParameterShadow.status.contains("C")

        when (uploadParameterShadow.dateField) {
            "issueDate" -> {
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_issue_date_select.isChecked = true
                lastRadioButton = rb_invoice_list_filter_issue_date_select
                tv_invoice_list_filter_issue_date_from.text = if (uploadParameterShadow.dateFrom.isNullOrEmpty()) {
                    MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)
                } else {
                    updateApplyText(true)
                    TimeZoneTransformsUtil.formatTime(DateUtil.stringConversionToDate(uploadParameterShadow.dateFrom))
                }
                tv_invoice_list_filter_issue_date_to.text = if (uploadParameterShadow.dateTo.isNullOrEmpty()) {
                    MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)
                } else {
                    updateApplyText(true)
                    TimeZoneTransformsUtil.formatTime(DateUtil.stringConversionToDate(uploadParameterShadow.dateTo))
                }
                ll_invoice_list_filter_issue_date_container.visibility = View.VISIBLE
                tv_invoice_list_filter_due_date_from.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                tv_invoice_list_filter_due_date_to.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
            }
            "dueDate" -> {
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_due_date_select.isChecked = true
                lastRadioButton = rb_invoice_list_filter_due_date_select
                tv_invoice_list_filter_due_date_from.text = if (uploadParameterShadow.dateFrom.isNullOrEmpty()) {
                    MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)
                } else {
                    updateApplyText(true)
                    TimeZoneTransformsUtil.formatTime(DateUtil.stringConversionToDate(uploadParameterShadow.dateFrom))
                }
                tv_invoice_list_filter_due_date_to.text = if (uploadParameterShadow.dateTo.isNullOrEmpty()) {
                    MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)
                } else {
                    updateApplyText(true)
                    TimeZoneTransformsUtil.formatTime(DateUtil.stringConversionToDate(uploadParameterShadow.dateTo))
                }
                ll_invoice_list_filter_due_date_container.visibility = View.VISIBLE
                tv_invoice_list_filter_issue_date_from.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                tv_invoice_list_filter_issue_date_to.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
            }
            else -> {
                rb_invoice_list_filter_date_any.isChecked = true
                lastRadioButton = rb_invoice_list_filter_date_any
                tv_invoice_list_filter_due_date_from.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                tv_invoice_list_filter_due_date_to.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                tv_invoice_list_filter_issue_date_from.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                tv_invoice_list_filter_issue_date_to.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
            }
        }

        et_invoice_list_filter_amount_from.currency = uploadParameterShadow.currency
        et_invoice_list_filter_amount_to.currency = uploadParameterShadow.currency
        if (uploadParameterShadow.amount != null) {
            rl_invoice_list_filter_amount_container.visibility = View.VISIBLE
            if (!uploadParameterShadow.amount?.gte.isNullOrEmpty()) {
                currentAmountFrom = uploadParameterShadow.amount?.gte ?: ""
                updateApplyText(true)
                et_invoice_list_filter_amount_from.setEditText(MemoryCache.globalDecimal.format((uploadParameterShadow.amount?.gte?.toDouble()
                        ?: 0.00) / 100.0),
                        "${uploadParameterShadow.currency} ${IndiaNumberUtil.formatNumByDecimal(uploadParameterShadow.amount?.gte ?: "", uploadParameterShadow.currency ?: "")}")
            }

            if (!uploadParameterShadow.amount?.lte.isNullOrEmpty()) {
                currentAmountTo = uploadParameterShadow.amount?.lte ?: ""
                updateApplyText(true)
                et_invoice_list_filter_amount_to.setEditText(MemoryCache.globalDecimal.format((uploadParameterShadow.amount?.lte?.toDouble()
                        ?: 0.00) / 100.0),
                        "${uploadParameterShadow.currency} ${IndiaNumberUtil.formatNumByDecimal(uploadParameterShadow.amount?.lte ?: "", uploadParameterShadow.currency ?: "")}")
            }

        } else {
            et_invoice_list_filter_amount_from.setEditText("")
            et_invoice_list_filter_amount_to.setEditText("")
        }

        addCurrencySelections()

        if (isDueFilter) {
            v_invoice_list_filter_second_line.visibility = View.GONE
            tv_invoice_list_filter_status_tag.visibility = View.GONE
            tv_invoice_list_filter_status_fully_tag.visibility = View.GONE
            cb_invoice_list_filter_status_fully_paid.visibility = View.GONE
            tv_invoice_list_filter_status_partially_tag.visibility = View.GONE
            cb_invoice_list_filter_status_partially_paid.visibility = View.GONE
            tv_invoice_list_filter_status_unpaid_tag.visibility = View.GONE
            cb_invoice_list_filter_status_unpaid.visibility = View.GONE
            tv_invoice_list_filter_status_overpaid_tag.visibility = View.GONE
            cb_invoice_list_filter_status_overpaid.visibility = View.GONE
            tv_invoice_list_filter_status_closed_tag.visibility = View.GONE
            cb_invoice_list_filter_status_closed.visibility = View.GONE
            v_invoice_list_filter_third_line.visibility = View.GONE
            tv_invoice_list_filter_amount_tag.visibility = View.GONE
            v_invoice_list_amount_range.visibility = View.GONE
            vs_invoice_list_filter_date_tmp.visibility = View.GONE
            v_invoice_list_filter_second_line.visibility = View.GONE
            v_invoice_list_filter_second_line.visibility = View.GONE
            v_invoice_list_filter_second_line.visibility = View.GONE
            tv_invoice_list_filter_title.text = MemoryCache.getLabelText("s_filter")
                    ?: getString(R.string.s_filter)
            v_invoice_list_filter_zero_line.visibility = View.VISIBLE
            conditionCount = 0
            val applyText = MemoryCache.getLabelText("s_apply_filter")
                    ?: getString(R.string.s_apply_filter)
            btn_invoice_list_filter_set.text = applyText
        }
    }

    private fun clearAllSelection() {
        conditionCount = 0
        cb_invoice_list_filter_status_fully_paid.isChecked = false
        cb_invoice_list_filter_status_closed.isChecked = false
        cb_invoice_list_filter_status_overpaid.isChecked = false
        cb_invoice_list_filter_status_partially_paid.isChecked = false
        cb_invoice_list_filter_status_unpaid.isChecked = false
        et_invoice_list_filter_amount_from.setEditText("")
        et_invoice_list_filter_amount_to.setEditText("")
        rb_invoice_list_filter_date_any.isChecked = true
        btn_invoice_list_filter_set.isEnabled = false
        btn_invoice_list_filter_set.setBackgroundColor(ContextCompat.getColor(this, R.color.color56))
    }

    /**
     * check box and radio box check change listener
     */
    override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
        et_invoice_list_filter_amount_from.changeFocus()
        et_invoice_list_filter_amount_to.changeFocus()
        when (buttonView?.id) {
            //fully pay check box
            R.id.cb_invoice_list_filter_status_fully_paid -> {
                TealiumUtil.eventTag("checkbox", "invoices filter popup: invoice status: fully paid " + if (isChecked) "checked" else "unchecked")
                statusCheckBoxChange(isChecked)
            }
            //overpaid check box
            R.id.cb_invoice_list_filter_status_overpaid -> {
                TealiumUtil.eventTag("checkbox", "invoices filter popup: invoice status: overpaid " + if (isChecked) "checked" else "unchecked")
                statusCheckBoxChange(isChecked)
            }
            //partially pay check box
            R.id.cb_invoice_list_filter_status_partially_paid -> {
                TealiumUtil.eventTag("checkbox", "invoices filter popup: invoice status: partially paid " + if (isChecked) "checked" else "unchecked")
                statusCheckBoxChange(isChecked)
            }
            //unpaid check box
            R.id.cb_invoice_list_filter_status_unpaid -> {
                TealiumUtil.eventTag("checkbox", "invoices filter popup: invoice status: unpaid " + if (isChecked) "checked" else "unchecked")
                statusCheckBoxChange(isChecked)
            }
            //closed check box
            R.id.cb_invoice_list_filter_status_closed -> {
                TealiumUtil.eventTag("checkbox", "invoices filter popup: invoice status: closed " + if (isChecked) "checked" else "unchecked")
                statusCheckBoxChange(isChecked)
            }
            //any time radio box
            R.id.rb_invoice_list_filter_date_any -> {
                if (!isChecked) {
                    return
                }

                var localDateSelectCount = 0

                TealiumUtil.eventTag("radio", "any time radio button clicked")
//                resetLastRadioButton()
                ll_invoice_list_filter_issue_date_container.visibility = View.GONE
                ll_invoice_list_filter_due_date_container.visibility = View.GONE
                uploadParameterShadow.dateField = ""
                uploadParameterShadow.dateFrom = ""
                uploadParameterShadow.dateTo = ""
                val selectDateText = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                localDateSelectCount += if (tv_invoice_list_filter_due_date_from.text.toString() != selectDateText) 1 else 0
                localDateSelectCount += if (tv_invoice_list_filter_due_date_to.text.toString() != selectDateText) 1 else 0
                localDateSelectCount += if (tv_invoice_list_filter_issue_date_from.text.toString()  != selectDateText) 1 else 0
                localDateSelectCount += if (tv_invoice_list_filter_issue_date_to.text.toString() != selectDateText) 1 else 0
                conditionCount -= localDateSelectCount
                if (conditionCount == 0) {
                    btn_invoice_list_filter_set.isEnabled = false
                    btn_invoice_list_filter_set.setBackgroundColor(ContextCompat.getColor(this, R.color.color56))
                    btn_invoice_list_filter_set.text = MemoryCache.getLabelText("s_apply_filter")
                            ?: getString(R.string.s_apply_filter)
                } else {
                    btn_invoice_list_filter_set.text = String.format(
                            MemoryCache.getLabelText("s_apply_filter_num")
                                    ?: getString(R.string.s_apply_filter_num),
                            conditionCount)
                }
                rb_invoice_list_filter_issue_date_last_month.isChecked = false
                rb_invoice_list_filter_issue_date_last_three_month.isChecked = false
                rb_invoice_list_filter_issue_date_select.isChecked = false
                rb_invoice_list_filter_due_date_next_month.isChecked = false
                rb_invoice_list_filter_due_date_next_three_month.isChecked = false
                rb_invoice_list_filter_due_date_last_month.isChecked = false
                rb_invoice_list_filter_due_date_last_three_month.isChecked = false
                rb_invoice_list_filter_due_date_select.isChecked = false
                if (lastRadioButton != rb_invoice_list_filter_issue_date_select && lastRadioButton != rb_invoice_list_filter_due_date_select) {
                    updateApplyText(false)
                }
                lastRadioButton = rb_invoice_list_filter_date_any
                tv_invoice_list_filter_issue_date_from.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                tv_invoice_list_filter_issue_date_to.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                tv_invoice_list_filter_due_date_from.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                tv_invoice_list_filter_due_date_to.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                TealiumUtil.eventTag("radio", "invoice filter popup: " + "date any clicked")
            }
            //issue date last month radio box
            R.id.rb_invoice_list_filter_issue_date_last_month -> {
                if (!isChecked) {
                    return
                }

                TealiumUtil.eventTag("radio", "issue date last month radio button clicked")
                ll_invoice_list_filter_issue_date_container.visibility = View.GONE
                ll_invoice_list_filter_due_date_container.visibility = View.GONE
                uploadParameterShadow.dateField = "issueDate"
                val calendar = Calendar.getInstance()
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] - 1)
                uploadParameterShadow.dateFrom = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] + 1)
                uploadParameterShadow.dateTo = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                detectRadioCheckApplyTextChange()
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_issue_date_last_three_month.isChecked = false
                rb_invoice_list_filter_issue_date_select.isChecked = false
                rb_invoice_list_filter_due_date_next_month.isChecked = false
                rb_invoice_list_filter_due_date_next_three_month.isChecked = false
                rb_invoice_list_filter_due_date_last_month.isChecked = false
                rb_invoice_list_filter_due_date_last_three_month.isChecked = false
                rb_invoice_list_filter_due_date_select.isChecked = false
                lastRadioButton = rb_invoice_list_filter_issue_date_last_month
                TealiumUtil.eventTag("radio", "invoice filter popup: " + "issue day lask month clicked")
            }
            //issue date last three month radio box
            R.id.rb_invoice_list_filter_issue_date_last_three_month -> {
                if (!isChecked) {
                    return
                }

                TealiumUtil.eventTag("radio", "issue date last three months radio button clicked")
                ll_invoice_list_filter_issue_date_container.visibility = View.GONE
                ll_invoice_list_filter_due_date_container.visibility = View.GONE
                uploadParameterShadow.dateField = "issueDate"
                val calendar = Calendar.getInstance()
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] - 3)
                uploadParameterShadow.dateFrom = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] + 3)
                uploadParameterShadow.dateTo = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                detectRadioCheckApplyTextChange()
                rb_invoice_list_filter_issue_date_last_month.isChecked = false
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_issue_date_select.isChecked = false
                rb_invoice_list_filter_due_date_next_month.isChecked = false
                rb_invoice_list_filter_due_date_next_three_month.isChecked = false
                rb_invoice_list_filter_due_date_last_month.isChecked = false
                rb_invoice_list_filter_due_date_last_three_month.isChecked = false
                rb_invoice_list_filter_due_date_select.isChecked = false
                lastRadioButton = rb_invoice_list_filter_issue_date_last_three_month
                TealiumUtil.eventTag("radio", "invoice filter popup: " + "issue date last three month clicked")
            }
            //issue date DIY date radio box
            R.id.rb_invoice_list_filter_issue_date_select -> {
                if (!isChecked) {
                    ll_invoice_list_filter_issue_date_container.visibility = View.GONE
                    return
                }

                TealiumUtil.eventTag("radio", "issue date select radio button clicked")
                ll_invoice_list_filter_issue_date_container.visibility = View.VISIBLE
                ll_invoice_list_filter_due_date_container.visibility = View.GONE
                uploadParameterShadow.dateField = "issueDate"
                uploadParameterShadow.dateFrom = ""
                uploadParameterShadow.dateTo = ""
                if (lastRadioButton != rb_invoice_list_filter_date_any && lastRadioButton != rb_invoice_list_filter_due_date_select) {
                    updateApplyText(false)
                }

                rb_invoice_list_filter_issue_date_last_month.isChecked = false
                rb_invoice_list_filter_issue_date_last_three_month.isChecked = false
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_due_date_next_month.isChecked = false
                rb_invoice_list_filter_due_date_next_three_month.isChecked = false
                rb_invoice_list_filter_due_date_last_month.isChecked = false
                rb_invoice_list_filter_due_date_last_three_month.isChecked = false
                rb_invoice_list_filter_due_date_select.isChecked = false
                lastRadioButton = rb_invoice_list_filter_issue_date_select
                TealiumUtil.eventTag("radio", "invoice filter popup: " + "invoice issue date select date clicked")
            }
            //due date last month radio box
            R.id.rb_invoice_list_filter_due_date_last_month -> {
                if (!isChecked) {
                    return
                }

                TealiumUtil.eventTag("radio", "due date last month radio button clicked")
                ll_invoice_list_filter_issue_date_container.visibility = View.GONE
                ll_invoice_list_filter_due_date_container.visibility = View.GONE
                uploadParameterShadow.dateField = "dueDate"
                val calendar = Calendar.getInstance()
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] - 1)
                uploadParameterShadow.dateFrom = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] + 1)
                uploadParameterShadow.dateTo = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                detectRadioCheckApplyTextChange()
                rb_invoice_list_filter_issue_date_last_month.isChecked = false
                rb_invoice_list_filter_issue_date_last_three_month.isChecked = false
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_due_date_next_month.isChecked = false
                rb_invoice_list_filter_due_date_next_three_month.isChecked = false
                rb_invoice_list_filter_issue_date_select.isChecked = false
                rb_invoice_list_filter_due_date_last_three_month.isChecked = false
                rb_invoice_list_filter_due_date_select.isChecked = false
                lastRadioButton = rb_invoice_list_filter_due_date_last_month
                TealiumUtil.eventTag("radio", "invoice filter popup: " + "due date last month clicked")
            }
            //due date next month radio box
            R.id.rb_invoice_list_filter_due_date_next_month -> {
                if (!isChecked) {
                    return
                }

                TealiumUtil.eventTag("radio", "due date next month radio button clicked")
                ll_invoice_list_filter_issue_date_container.visibility = View.GONE
                ll_invoice_list_filter_due_date_container.visibility = View.GONE
                uploadParameterShadow.dateField = "dueDate"
                val calendar = Calendar.getInstance()
                uploadParameterShadow.dateFrom = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] + 1)
                uploadParameterShadow.dateTo = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                detectRadioCheckApplyTextChange()
                rb_invoice_list_filter_issue_date_last_month.isChecked = false
                rb_invoice_list_filter_issue_date_last_three_month.isChecked = false
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_due_date_last_month.isChecked = false
                rb_invoice_list_filter_due_date_next_three_month.isChecked = false
                rb_invoice_list_filter_issue_date_select.isChecked = false
                rb_invoice_list_filter_due_date_last_three_month.isChecked = false
                rb_invoice_list_filter_due_date_select.isChecked = false
                lastRadioButton = rb_invoice_list_filter_due_date_next_month
                TealiumUtil.eventTag("radio", "invoice filter popup: " + "due date next month clicked")
            }
            //due date last three month radio box
            R.id.rb_invoice_list_filter_due_date_next_three_month -> {
                if (!isChecked) {
                    return
                }

                TealiumUtil.eventTag("radio", "due date next three months radio button clicked")
                ll_invoice_list_filter_issue_date_container.visibility = View.GONE
                ll_invoice_list_filter_due_date_container.visibility = View.GONE
                uploadParameterShadow.dateField = "dueDate"
                val calendar = Calendar.getInstance()
                uploadParameterShadow.dateFrom = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] + 3)
                uploadParameterShadow.dateTo = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                detectRadioCheckApplyTextChange()
                rb_invoice_list_filter_issue_date_last_month.isChecked = false
                rb_invoice_list_filter_issue_date_last_three_month.isChecked = false
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_due_date_last_month.isChecked = false
                rb_invoice_list_filter_due_date_next_month.isChecked = false
                rb_invoice_list_filter_issue_date_select.isChecked = false
                rb_invoice_list_filter_due_date_last_three_month.isChecked = false
                rb_invoice_list_filter_due_date_select.isChecked = false
                lastRadioButton = rb_invoice_list_filter_due_date_next_three_month
                TealiumUtil.eventTag("radio", "invoice filter popup: " + "due date next month clicked")
            }
            //due date next three month radio box
            R.id.rb_invoice_list_filter_due_date_last_three_month -> {
                if (!isChecked) {
                    return
                }

                TealiumUtil.eventTag("radio", "due date last three months radio button clicked")
                ll_invoice_list_filter_issue_date_container.visibility = View.GONE
                ll_invoice_list_filter_due_date_container.visibility = View.GONE
                uploadParameterShadow.dateField = "dueDate"
                val calendar = Calendar.getInstance()
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] - 3)
                uploadParameterShadow.dateFrom = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                calendar.set(Calendar.MONTH, calendar[Calendar.MONTH] + 3)
                uploadParameterShadow.dateTo = TimeZoneTransformsUtil.formatParameterTime(calendar.time)
                detectRadioCheckApplyTextChange()
                rb_invoice_list_filter_issue_date_last_month.isChecked = false
                rb_invoice_list_filter_issue_date_last_three_month.isChecked = false
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_due_date_last_month.isChecked = false
                rb_invoice_list_filter_due_date_next_month.isChecked = false
                rb_invoice_list_filter_issue_date_select.isChecked = false
                rb_invoice_list_filter_due_date_next_three_month.isChecked = false
                rb_invoice_list_filter_due_date_select.isChecked = false
                lastRadioButton = rb_invoice_list_filter_due_date_last_three_month
                TealiumUtil.eventTag("radio", "invoice filter popup: " + "due date last three month clicked")
            }
            //due date DIY radio box
            R.id.rb_invoice_list_filter_due_date_select -> {
                if (!isChecked) {
                    ll_invoice_list_filter_due_date_container.visibility = View.GONE
                    return
                }

                TealiumUtil.eventTag("radio", "due date select radio button clicked")
                ll_invoice_list_filter_due_date_container.visibility = View.VISIBLE
                ll_invoice_list_filter_issue_date_container.visibility = View.GONE
                uploadParameterShadow.dateField = "dueDate"
                uploadParameterShadow.dateFrom = ""
                uploadParameterShadow.dateTo = ""
                if (lastRadioButton != rb_invoice_list_filter_date_any && lastRadioButton != rb_invoice_list_filter_issue_date_select) {
                    updateApplyText(false)
                }
                rb_invoice_list_filter_issue_date_last_month.isChecked = false
                rb_invoice_list_filter_issue_date_last_three_month.isChecked = false
                rb_invoice_list_filter_date_any.isChecked = false
                rb_invoice_list_filter_due_date_last_month.isChecked = false
                rb_invoice_list_filter_due_date_next_month.isChecked = false
                rb_invoice_list_filter_issue_date_select.isChecked = false
                rb_invoice_list_filter_due_date_next_three_month.isChecked = false
                rb_invoice_list_filter_due_date_last_three_month.isChecked = false
                lastRadioButton = rb_invoice_list_filter_due_date_select
                TealiumUtil.eventTag("radio", "invoice filter popup: " + "due date select date clicked")
            }
        }
    }

    private fun detectRadioCheckApplyTextChange() {
        val selectDateText = MemoryCache.getLabelText("s_select_date")
                ?: getString(R.string.s_select_date)
        if ((lastRadioButton == rb_invoice_list_filter_date_any) ||
                (lastRadioButton == rb_invoice_list_filter_issue_date_select &&
                        tv_invoice_list_filter_issue_date_from.text.toString() == selectDateText &&
                        tv_invoice_list_filter_issue_date_to.text.toString() == selectDateText) ||
                (lastRadioButton == rb_invoice_list_filter_due_date_select &&
                        tv_invoice_list_filter_due_date_from.text.toString() == selectDateText &&
                        tv_invoice_list_filter_due_date_to.text.toString() == selectDateText)) {
            updateApplyText(true)
        }
        if ((lastRadioButton == rb_invoice_list_filter_issue_date_select &&
                        tv_invoice_list_filter_issue_date_from.text.toString() != selectDateText &&
                        tv_invoice_list_filter_issue_date_to.text.toString() != selectDateText) ||
                (lastRadioButton == rb_invoice_list_filter_due_date_select &&
                        tv_invoice_list_filter_due_date_from.text.toString() != selectDateText &&
                        tv_invoice_list_filter_due_date_to.text.toString() != selectDateText)) {
            updateApplyText(false)
        }
    }

    /**
     * add or remove status to parameter
     */
    private fun statusCheckBoxChange(isChecked: Boolean) {
        if (isChecked) {
            btn_invoice_list_filter_set.isEnabled = true
            btn_invoice_list_filter_set.setBackgroundColor(ContextCompat.getColor(this, R.color.primary_red))
            updateApplyText(true)
        } else {
            conditionCount--
            if (!cb_invoice_list_filter_status_fully_paid.isChecked &&
                            !cb_invoice_list_filter_status_closed.isChecked &&
                            !cb_invoice_list_filter_status_overpaid.isChecked &&
                            !cb_invoice_list_filter_status_partially_paid.isChecked &&
                            !cb_invoice_list_filter_status_unpaid.isChecked) {
                btn_invoice_list_filter_set.isEnabled = false
                btn_invoice_list_filter_set.setBackgroundColor(ContextCompat.getColor(this, R.color.color56))
                btn_invoice_list_filter_set.text = if (conditionCount == 0) {
                    MemoryCache.getLabelText("s_apply_filter") ?: getString(R.string.s_apply_filter)
                } else {
                    String.format(MemoryCache.getLabelText("s_apply_filter_num") ?:
                        getString(R.string.s_apply_filter_num), conditionCount)
                }
            } else if (conditionCount == 0){
                btn_invoice_list_filter_set.text = MemoryCache.getLabelText("s_apply_filter")
                        ?: getString(R.string.s_apply_filter)
            } else {
                btn_invoice_list_filter_set.text = String.format(MemoryCache.getLabelText("s_apply_filter_num") ?:
                getString(R.string.s_apply_filter_num), conditionCount)
            }
        }
    }

    private fun setAllRadioButtonListeners() {
        rb_invoice_list_filter_date_any.setOnCheckedChangeListener(this)
        rb_invoice_list_filter_due_date_select.setOnCheckedChangeListener(this)
        rb_invoice_list_filter_issue_date_select.setOnCheckedChangeListener(this)
        rb_invoice_list_filter_due_date_last_month.setOnCheckedChangeListener(this)
        rb_invoice_list_filter_due_date_next_month.setOnCheckedChangeListener(this)
        rb_invoice_list_filter_due_date_last_three_month.setOnCheckedChangeListener(this)
        rb_invoice_list_filter_due_date_next_three_month.setOnCheckedChangeListener(this)
        rb_invoice_list_filter_issue_date_last_month.setOnCheckedChangeListener(this)
        rb_invoice_list_filter_issue_date_last_three_month.setOnCheckedChangeListener(this)
    }

    private fun removeAllCheckBoxListeners() {
        cb_invoice_list_filter_status_fully_paid.setOnCheckedChangeListener(null)
        cb_invoice_list_filter_status_overpaid.setOnCheckedChangeListener(null)
        cb_invoice_list_filter_status_partially_paid.setOnCheckedChangeListener(null)
        cb_invoice_list_filter_status_unpaid.setOnCheckedChangeListener(null)
        cb_invoice_list_filter_status_closed.setOnCheckedChangeListener(null)
    }

    private fun setAllCheckBoxListeners() {
        cb_invoice_list_filter_status_fully_paid.setOnCheckedChangeListener(this)
        cb_invoice_list_filter_status_overpaid.setOnCheckedChangeListener(this)
        cb_invoice_list_filter_status_partially_paid.setOnCheckedChangeListener(this)
        cb_invoice_list_filter_status_unpaid.setOnCheckedChangeListener(this)
        cb_invoice_list_filter_status_closed.setOnCheckedChangeListener(this)
    }

    /**
     * onClick listener
     */
    override fun onClick(v: View?) {
        val viewId = v?.id
        et_invoice_list_filter_amount_from.changeFocus()
        et_invoice_list_filter_amount_to.changeFocus()
        when (viewId) {
            //supplier
            R.id.tv_invoice_list_filter_supplier -> {
                TealiumUtil.eventTag("button click", "invoices filter popup: supplier")
                SuppliersOrCustomersSelectActivity.showActivity(this, if ("S" == MemoryCache.getSessionEntity()?.type) {
                    uploadParameterShadow.payorReference
                } else {
                    uploadParameterShadow.payeeReference
                }, if ("S" == MemoryCache.getSessionEntity()?.type) {
                    uploadParameterShadow.payorCurrency
                } else {
                    uploadParameterShadow.payeeCurrency
                }, REQUEST_CODE_SUPPLIER, true, "S" == MemoryCache.getSessionEntity()?.type)
            }
            //set current parameter
            R.id.btn_invoice_list_filter_set -> {
                //get amount range
                TealiumUtil.eventTag("button click", "invoices filter popup: apply filter")
                val amountFrom = if (et_invoice_list_filter_amount_from.tag == null) {
                    ""
                } else {
                    et_invoice_list_filter_amount_from.tag.toString()
                }
                val amountTo = if (et_invoice_list_filter_amount_to.tag == null) {
                    ""
                } else {
                    et_invoice_list_filter_amount_to.tag.toString()
                }
                val decimalSymbol = if (uploadParameterShadow.currency == "IDR") {
                    ","
                } else {
                    "."
                }

                var amountFromTxt = ""
                var amountToTxt = ""
                if (amountFrom.isNotEmpty()) {
                    amountFromTxt = (amountFrom.replace(decimalSymbol, ".").toDouble() * 100).toLong().toString()
                }

                if (amountTo.isNotEmpty()) {
                    amountToTxt = (amountTo.replace(decimalSymbol, ".").toDouble() * 100).toLong().toString()
                }
                if (amountFromTxt.isEmpty() && amountToTxt.isEmpty()) {
                    uploadParameterShadow.amount = null
                } else {
                    uploadParameterShadow.amount = InvoiceRequestAmount(amountFromTxt, amountToTxt)
                }
                if (uploadParameterShadow.status.isNullOrEmpty()) {
                    uploadParameterShadow.status = mutableListOf()
                }
                if (cb_invoice_list_filter_status_closed.isChecked) {
                    if (!uploadParameterShadow.status.contains("C"))
                        uploadParameterShadow.status.add("C")
                } else {
                    uploadParameterShadow.status.remove("C")
                }
                if (cb_invoice_list_filter_status_fully_paid.isChecked) {
                    if (!uploadParameterShadow.status.contains("F"))
                        uploadParameterShadow.status.add("F")
                } else {
                    uploadParameterShadow.status.remove("F")
                }
                if (cb_invoice_list_filter_status_overpaid.isChecked) {
                    if (!uploadParameterShadow.status.contains("O"))
                        uploadParameterShadow.status.add("O")
                } else {
                    uploadParameterShadow.status.remove("O")
                }
                if (cb_invoice_list_filter_status_partially_paid.isChecked) {
                    if (!uploadParameterShadow.status.contains("P"))
                        uploadParameterShadow.status.add("P")
                } else {
                    uploadParameterShadow.status.remove("P")
                }
                if (cb_invoice_list_filter_status_unpaid.isChecked) {
                    if (!uploadParameterShadow.status.contains("U"))
                        uploadParameterShadow.status.add("U")
                } else {
                    uploadParameterShadow.status.remove("U")
                }
                val uploadParameterShadowStr = mGson.toJson(uploadParameterShadow)
                if (uploadParameterShadowStr == originUploadParameterStr) {
                    finish()
                } else {
                    if ("B" == MemoryCache.getSessionEntity()?.type) {
                        if ((MemoryCache.getLabelText("s_all")
                                        ?: getString(R.string.s_all)) == uploadParameterShadow.payeeReference) {
                            uploadParameterShadow.payeeReference = null
                        }
                    } else {
                        if ((MemoryCache.getLabelText("s_all")
                                        ?: getString(R.string.s_all)) == uploadParameterShadow.payorReference) {
                            uploadParameterShadow.payorReference = null
                        }
                    }
                    val resultIntent = Intent().apply {
                        putExtra(TAG_INVOICE_FILTER_COUNTRY_CODE_RESULT, selectedCountryCode)
                        putExtra(TAG_INVOICE_FILTER_PARAMETER_RESULT, uploadParameterShadow)
                    }
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                }
            }
            R.id.rl_invoice_list_filter_issue_date_from -> {
                showCalenderDialog(TYPE_ISSUE_DATE_FROM)
            }
            R.id.rl_invoice_list_filter_issue_date_to -> {
                showCalenderDialog(TYPE_ISSUE_DATE_TO)
            }
            R.id.rl_invoice_list_filter_due_date_from -> {
                showCalenderDialog(TYPE_DUE_DATE_FROM)
            }
            R.id.rl_invoice_list_filter_due_date_to -> {
                showCalenderDialog(TYPE_DUE_DATE_TO)
            }
            R.id.tv_invoice_list_filter_reset -> {
                TealiumUtil.eventTag("button click", "invoices filter popup: reset")
                uploadParameterShadow = if (isDueFilter) {
                    InvoiceRequestParameter(null, null, null, mutableListOf("U", "P"), null, null, null, null, InvoiceRequestSort("dueDate", "desc"))
                } else {
                    InvoiceRequestParameter(null, null, null, mutableListOf(), null, null, null, null, uploadParameterShadow.sorting)
                }
                et_invoice_list_filter_amount_from.tag = null
                et_invoice_list_filter_amount_to.tag = null
                selectedCountryCode = ""
                removeAllCheckBoxListeners()
                if (!isDueFilter) {
                    clearAllSelection()
                }
                tv_invoice_list_filter_supplier.text = MemoryCache.getLabelText("s_all")
                        ?: getString(R.string.s_all)
                btn_invoice_list_filter_set.text = MemoryCache.getLabelText("s_apply_filter")
                        ?: getString(R.string.s_apply_filter)
                setAllCheckBoxListeners()
            }
            R.id.iv_invoice_list_filter_close -> {
                TealiumUtil.eventTag("button click", "invoices filter popup: close")
                finish()
            }
        }
    }

    /**
     * show dialog when click DIY date of issue or due
     */
    private fun showCalenderDialog(type: Int) {
        val minDate = if (type == TYPE_ISSUE_DATE_TO && tv_invoice_list_filter_issue_date_from.text.toString() != MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)) {
            tv_invoice_list_filter_issue_date_from.text.toString()
        } else if (type == TYPE_DUE_DATE_TO && tv_invoice_list_filter_due_date_from.text.toString() != MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)) {
            tv_invoice_list_filter_due_date_from.text.toString()
        } else if (type == TYPE_ISSUE_DATE_FROM && tv_invoice_list_filter_issue_date_to.text.toString() != MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)) {
            tv_invoice_list_filter_issue_date_to.text.toString()
        } else if (type == TYPE_DUE_DATE_FROM && tv_invoice_list_filter_due_date_to.text.toString() != MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)) {
            tv_invoice_list_filter_due_date_to.text.toString()
        } else {
            null
        }

        FilterDateDialog.showDialog(this@InvoiceListFilterActivity, type, when (type) {
            TYPE_DUE_DATE_FROM -> if (uploadParameterShadow.dateFrom.isNullOrBlank())
                null
            else
                TimeZoneTransformsUtil.formatTime(DateUtil.stringConversionToDate(uploadParameterShadow.dateFrom))
            TYPE_ISSUE_DATE_FROM -> if (uploadParameterShadow.dateFrom.isNullOrBlank())
                null
            else
                TimeZoneTransformsUtil.formatTime(DateUtil.stringConversionToDate(uploadParameterShadow.dateFrom))
            TYPE_DUE_DATE_TO -> if (uploadParameterShadow.dateTo.isNullOrBlank())
                null
            else
                TimeZoneTransformsUtil.formatTime(DateUtil.stringConversionToDate(uploadParameterShadow.dateTo))
            TYPE_ISSUE_DATE_TO -> if (uploadParameterShadow.dateTo.isNullOrBlank())
                null
            else
                TimeZoneTransformsUtil.formatTime(DateUtil.stringConversionToDate(uploadParameterShadow.dateTo))
            else -> null
        }, minDate, object : FilterDateDialog.DateConfirmCallback {

            override fun getDate(date: String) {
                when (type) {
                    TYPE_ISSUE_DATE_FROM -> {
                        uploadParameterShadow.dateFrom = date
                        tv_invoice_list_filter_issue_date_from.text = TimeZoneTransformsUtil.formatTime(date)
                        updateApplyText(true)
                    }
                    TYPE_DUE_DATE_FROM -> {
                        uploadParameterShadow.dateFrom = date
                        tv_invoice_list_filter_due_date_from.text = TimeZoneTransformsUtil.formatTime(date)
                        updateApplyText(true)
                    }
                    TYPE_ISSUE_DATE_TO -> {
                        uploadParameterShadow.dateTo = date
                        tv_invoice_list_filter_issue_date_to.text = TimeZoneTransformsUtil.formatTime(date)
                        updateApplyText(true)
                    }
                    TYPE_DUE_DATE_TO -> {
                        uploadParameterShadow.dateTo = date
                        tv_invoice_list_filter_due_date_to.text = TimeZoneTransformsUtil.formatTime(date)
                        updateApplyText(true)
                    }
                }
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_SUPPLIER && resultCode == Activity.RESULT_OK) {
            payeeOrPayor = data?.getSerializableExtra(TAG_SELECT_SUPPLIER_RESULT) as Payee?
            val allText = MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
            if ("S" == MemoryCache.getSessionEntity()?.type) {
                if (uploadParameterShadow.payorName.isNullOrBlank() || uploadParameterShadow.payorName == allText) {
                    if (payeeOrPayor?.name != allText) {
                        updateApplyText(true)
                    }
                } else {
                    if (payeeOrPayor?.name == allText) {
                        updateApplyText(false)
                    }
                }
                uploadParameterShadow.payorReference = payeeOrPayor?.reference
                uploadParameterShadow.payorName = payeeOrPayor?.name
                uploadParameterShadow.payorCurrency = payeeOrPayor?.account?.currency
            } else {
                if (uploadParameterShadow.payeeName.isNullOrBlank() || uploadParameterShadow.payeeName == allText) {
                    if (payeeOrPayor?.name != allText) {
                        updateApplyText(true)
                    }
                } else {
                    if (payeeOrPayor?.name == allText) {
                        updateApplyText(false)
                    }
                }
                uploadParameterShadow.payeeReference = payeeOrPayor?.reference
                uploadParameterShadow.payeeName = payeeOrPayor?.name
                uploadParameterShadow.payeeCurrency = payeeOrPayor?.account?.currency
            }
            tv_invoice_list_filter_supplier.text = payeeOrPayor?.name
        }
    }

    private fun addCurrencySelections() {
        val tmpList = mutableListOf<String>()
        ll_currency_filter_tag_container.removeAllViews()
        rg_currency_filter_container.removeAllViews()
        val currencyMap = MemoryCache.getCurrencyMap()
        val currencyMapKeys = currencyMap.keys.toList()
        if (currencyMapKeys.isEmpty() || (currencyMapKeys.size == 1 && (currencyMap[currencyMapKeys[0]]
                        ?: error("")).size <= 1)) {
            tv_invoice_list_filter_currency_tag.visibility = View.GONE
            rl_invoice_list_filter_currency_container.visibility = View.GONE
            v_invoice_list_filter_second_line.visibility = View.GONE
            return
        }

        currencyMap.forEach(action = {
            it.value.forEach { currency ->
                if (!tmpList.contains(currency)) {
                    val currencyFilterTag = TextView(this@InvoiceListFilterActivity)
                    currencyFilterTag.height = ConvertUtil.dp2px(this@InvoiceListFilterActivity, 51.0f * resources.getInteger(R.integer.checker_scale)).toInt()
                    currencyFilterTag.gravity = Gravity.CENTER_VERTICAL
                    currencyFilterTag.textSize = 16.0f * resources.getInteger(R.integer.checker_scale)
                    currencyFilterTag.text = currency
                    ll_currency_filter_tag_container.addView(currencyFilterTag)
                    val currencyFilter = LayoutInflater.from(this).inflate(R.layout.item_green_theme_rb, null) as RadioButton
                    currencyFilter.height = ConvertUtil.dp2px(this@InvoiceListFilterActivity, 51.0f * resources.getInteger(R.integer.checker_scale)).toInt()
                    currencyFilter.tag = it.key
                    rg_currency_filter_container.addView(currencyFilter)
                    currencyFilter.isChecked = currency == uploadParameterShadow.currency
                    tmpList.add(currency)
                }
            }
        })

        rg_currency_filter_container.setOnCheckedChangeListener { group, checkedId ->
            val count = group.childCount
            for (i in 0 until count) {
                val rb = group.getChildAt(i) as RadioButton
                if (rb.isChecked) {
                    selectedCountryCode = rb.tag as String
                    val currency = (ll_currency_filter_tag_container.getChildAt(i) as TextView).text.toString()
                    uploadParameterShadow.currency = currency
                    et_invoice_list_filter_amount_from.currency = currency
                    et_invoice_list_filter_amount_to.currency = currency
                    et_invoice_list_filter_amount_from.updateHintCurrency()
                    et_invoice_list_filter_amount_to.updateHintCurrency()
                    break
                }
            }
        }
    }

    private fun updateApplyText(isIncrease: Boolean) {
        conditionCount += if (isIncrease) 1 else -1
        btn_invoice_list_filter_set.text = String.format(
                MemoryCache.getLabelText("s_apply_filter_num")
                        ?: getString(R.string.s_apply_filter_num),
                conditionCount)
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:invoices:filter popup",
                "/dart/buyer-portal/invoices/filter-popup", "payment", "buyer portal",
                "invoices")
    }

    inner class AmountTextWatcher(private val isAmountFrom: Boolean,
                                  private val etAmount: EditText): TextWatcher {
        var isInputFlag = false
        var isFirstIn = true

        override fun afterTextChanged(s: Editable) {
            if (isAmountFrom) {
                if (!isTealiumAmountInputFrom && !s.isBlank()) {
                    TealiumUtil.eventTag("text entry", "invoices filter popup: invoice amount from")
                    isTealiumAmountInputFrom = true
                }
            } else {
                if (!isTealiumAmountInputTo && !s.isBlank()) {
                    TealiumUtil.eventTag("text entry", "invoices filter popup: invoice amount to")
                    isTealiumAmountInputTo = true
                }
            }

            if (!etAmount.hasFocus()) {
                return
            }

            val decimalSymbol = if (uploadParameterShadow.currency == "IDR") {
                ","
            } else {
                "."
            }

            val banDecimalSymbol = if (uploadParameterShadow.currency == "IDR") {
                "."
            } else {
                ","
            }

            if (s.toString().contains(banDecimalSymbol)) {
                etAmount.setText(s.toString().replace(banDecimalSymbol, ""))
                etAmount.setSelection(etAmount.text.toString().length)
            }

            if (s.toString().contains(decimalSymbol)) {
                if (etAmount.text.toString().indexOf(decimalSymbol) >= 0) {
                    if (etAmount.text.toString().indexOf(decimalSymbol, etAmount.text.toString().indexOf(decimalSymbol) + 1) > 0) {
                        etAmount.setText(etAmount.text.toString().substring(0, etAmount.text.toString().length - 1))
                        etAmount.setSelection(etAmount.text.toString().length)
                    }

                }
            }

            //这部分是处理如果用户输入以.开头，在前面加上0
            if (s.toString().trim().substring(0) == decimalSymbol) {
                etAmount.setText("0$s")
                etAmount.setSelection(2)
            }
            //这里处理用户 多次输入.的处理 比如输入 1..6的形式，是不可以的
            if (s.toString().startsWith("0") && s.toString().trim().length > 1) {
                if (s.toString().substring(1, 2) != decimalSymbol) {
                    etAmount.setText(s.subSequence(0, 1))
                    etAmount.setSelection(1)
                    return
                }
            }
        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if (isFirstIn) {
                isFirstIn = false
                return
            }

            if (s.isNullOrBlank()) {
                if (etAmount.tag != null) {
                    updateApplyText(false)
                }
                isInputFlag = false
            } else {
                if (!isInputFlag) {
                    updateApplyText(true)
                    isInputFlag = true
                }
            }

            if (isAmountFrom) {
                currentAmountFrom = s.toString()
            } else {
                currentAmountTo = s.toString()
            }
        }
    }
}