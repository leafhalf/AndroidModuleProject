/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.app.Activity
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import hk.com.hsbc.glcmdart.framework.IView
import io.reactivex.Observable

/**
 * Created by Donut
 *
 * all invoice contract
 * define all operations for all invoice including view, model and presenter
 */
interface InvoiceListContract {

    interface InvoiceBaseView: IView {
        fun getFragmentActivity(): Activity?
        fun getMainListView(): RecyclerView?
        fun getMainRefresher(): SwipeRefreshLayout?
        fun updateTodayInvoiceInfo(invoiceCount: Int, invoiceAmount: Double, currency: String)
        fun showData(isHasData: Boolean)
        fun reAddScrollListener(isAdd: Boolean)
        fun updateRingData(unpaidAmount: Long, partiallyAmount: Long , paidAmount: Long, overpaidAmount: Long, totalAmount: Long, currency: String, isShowOutstanding: Boolean = false)
    }

    interface View: InvoiceBaseView {
        fun restoreAdapter(adapter: InvoiceListAdapter)
    }

    interface Model {
        fun getInvoiceList(uploadParameter: InvoiceRequestParameter): Observable<InvoiceListEntity>
    }
}