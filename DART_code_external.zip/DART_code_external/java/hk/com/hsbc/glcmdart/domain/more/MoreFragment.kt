/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.more

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.FAQ_BUYER_STATIC_URL
import hk.com.hsbc.glcmdart.client.FAQ_SUPPLIER_STATIC_URL
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.domain.home.HomeActivity
import hk.com.hsbc.glcmdart.domain.login.LoginActivity
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import kotlinx.android.synthetic.main.fragment_more.*

/**
 * More page
 */
class MoreFragment : Fragment(), View.OnClickListener {

    private lateinit var mViewModel: MoreViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_more, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
    }

    private fun initView() {
        tv_more_app_version.text = String.format(MemoryCache.getLabelText("s_app_version") ?: getString(R.string.s_app_version), activity?.packageManager?.getPackageInfo(activity?.packageName, 0)?.versionName)
        val sessionInfo = MemoryCache.getProfile()
        tv_more_user_name.text = if (sessionInfo?.payload?.user?.name?.contains("(") == true) {
            val nameSub = sessionInfo.payload.user.name.split("(")
            nameSub[0]
        } else {
            sessionInfo?.payload?.user?.name
        }
        tv_more_last_login_time.text = String.format(MemoryCache.getLabelText("s_last_login_time") ?: getString(R.string.s_last_login_time) ,TimeZoneTransformsUtil.formatTime(sessionInfo?.payload?.user?.lastLoginDate ?: ""))
        btn_more_my_profile.setOnClickListener(this)
        btn_more_my_notifications.setOnClickListener(this)
        btn_more_my_suppliers_or_buyers.setOnClickListener(this)
        btn_more_faq.setOnClickListener(this)
        btn_more_contact_support.setOnClickListener(this)
        btn_more_legal.setOnClickListener(this)
        btn_more_logout.setOnClickListener(this)
        btn_more_tutorial.setOnClickListener(this)

        mViewModel = ViewModelProviders.of(this).get(MoreViewModel::class.java)
        mViewModel.logoutLiveData.observe(this, Observer {
            doNativeLogout()
//            if (it) {
//                Toast.makeText(DartApplication.instance, "Logout successfully!", Toast.LENGTH_SHORT).show()
//                doNativeLogout()
//            } else {
//                Toast.makeText(DartApplication.instance, "Logout failed!", Toast.LENGTH_SHORT).show()
//            }
        })
        if ("S" == MemoryCache.getSessionEntity()?.type) {
            btn_more_my_suppliers_or_buyers.text = MemoryCache.getLabelText("s_my_buyers") ?: getString(R.string.s_my_buyers)
            btn_more_my_notifications.visibility = View.GONE
            btn_more_my_suppliers_or_buyers.contentDescription = MemoryCache.getLabelText("s_talkback_button_my_buyer") ?: getString(R.string.s_talkback_button_my_buyer)
        } else {
            btn_more_my_suppliers_or_buyers.text = MemoryCache.getLabelText("s_my_suppliers") ?: getString(R.string.s_my_suppliers)
            btn_more_my_suppliers_or_buyers.contentDescription = MemoryCache.getLabelText("s_talkback_button_my_supplier") ?: getString(R.string.s_talkback_button_my_supplier)
        }

        MemoryCache.getLabelText("s_my_profile")?.let {
            if (!it.isBlank()) {
                btn_more_my_profile.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_my_profile")?.let {
            if (!it.isBlank()) {
                btn_more_my_profile.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_my_notifications")?.let {
            if (!it.isBlank()) {
                btn_more_my_notifications.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_my_notification")?.let {
            if (!it.isBlank()) {
                btn_more_my_notifications.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_contact_support")?.let {
            if (!it.isBlank()) {
                btn_more_contact_support.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_contact_support")?.let {
            if (!it.isBlank()) {
                btn_more_contact_support.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_legal")?.let {
            if (!it.isBlank()) {
                btn_more_legal.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_information")?.let {
            if (!it.isBlank()) {
                btn_more_legal.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_logout")?.let {
            if (!it.isBlank()) {
                btn_more_logout.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_logout")?.let {
            if (!it.isBlank()) {
                btn_more_logout.contentDescription = it
            }
        }

        var copyRightText = MemoryCache.getLabelText("s_right_description")
        if (copyRightText != null && copyRightText.contains("year")) {
            copyRightText = copyRightText.replace("year", "2020")
        }

        copyRightText?.let {
            tv_more_copy_right.text = it
        }
    }

    companion object {

        @JvmStatic
        fun newInstance() = MoreFragment()
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_more_my_profile -> {
                TealiumUtil.eventTag("button click", "more landing: ${getString(R.string.s_my_profile)}")
                ProfileActivity.showActivity(activity)
            }
            R.id.btn_more_my_notifications -> {
                TealiumUtil.eventTag("button click", "more landing: ${getString(R.string.s_my_notifications)}")
                NotificationActivity.showActivity(activity)
            }
            R.id.btn_more_my_suppliers_or_buyers -> {
                TealiumUtil.eventTag("button click", "more landing: ${getString(R.string.s_my_suppliers)}")
                SuppliersOrBuyersActivity.showActivity(activity)
            }
            R.id.btn_more_faq -> {
                TealiumUtil.eventTag("button click", "more landing: ${getString(R.string.s_FAQ)}")
                if("S" == MemoryCache.getSessionEntity()?.type){
                    LegalPageActivity.showActivity(activity, getString(R.string.s_FAQ), FAQ_SUPPLIER_STATIC_URL, false)
                }else{
                    LegalPageActivity.showActivity(activity, getString(R.string.s_FAQ), FAQ_BUYER_STATIC_URL, false)
                }
            }
            R.id.btn_more_contact_support -> {
                TealiumUtil.eventTag("button click", "more landing: ${getString(R.string.s_contact_support)}")
                ContactSupportActivity.showActivity(activity)
            }
            R.id.btn_more_legal -> {
                TealiumUtil.eventTag("button click", "more landing: ${getString(R.string.s_legal)}")
                LegalListActivity.showActivity(activity)
            }
            R.id.btn_more_tutorial -> {
                startActivity(Intent(activity, TutorialActivity::class.java))
            }
            R.id.btn_more_logout -> {
                TealiumUtil.eventTag("button click", "more landing: ${getString(R.string.s_logout)}")
                MemoryCache.departmentName = mutableListOf()
                showLoadingDialogExt()
                mViewModel.requestLogout()
            }
        }
    }

    private fun doNativeLogout() {
        hideLoadingDialogExt()
        ApplicationManager.finishActivity(HomeActivity::class.java)
        startActivity(Intent(activity, LoginActivity::class.java))
        activity?.finish()
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:more:landing",
                "/dart/buyer-portal/more/landing",
                "other",
                "buyer portal",
                "more")
    }
}
