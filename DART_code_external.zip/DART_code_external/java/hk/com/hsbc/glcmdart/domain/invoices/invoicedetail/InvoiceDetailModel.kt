/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicedetail

import com.google.gson.Gson
import hk.com.hsbc.glcmdart.client.HOST_URL
import hk.com.hsbc.glcmdart.util.NetworkManager
import io.reactivex.Observable
import okhttp3.MediaType
import okhttp3.RequestBody

/**
 * Created by Donut
 *
 * invoice detail model
 */
class InvoiceDetailModel: InvoiceDetailContract.Model {

    override fun getInvoiceDetail(token: String): Observable<InvoiceDetailEntity> {
        return NetworkManager.getNormalService(InvoiceDetailService::class.java, HOST_URL).getInvoiceDetailInfo(token, token)
    }

    override fun getInvoiceDetailTimeline(token: String): Observable<InvoiceDetailTimeLineEntity> {
        val tokenMap = mapOf(Pair("token", token))
        val tokenStr = Gson().toJson(tokenMap)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), tokenStr)
        return NetworkManager.getNormalService(InvoiceDetailService::class.java, HOST_URL).getInvoiceDetailTimeLine(token, requestBody)
    }

}