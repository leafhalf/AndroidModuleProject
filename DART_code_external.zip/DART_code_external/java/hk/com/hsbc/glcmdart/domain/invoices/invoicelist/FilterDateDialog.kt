/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.app.AlertDialog
import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.calendar.CalendarView
import hk.com.hsbc.glcmdart.domain.calendar.CalendarMonthView
import hk.com.hsbc.glcmdart.domain.calendar.CalendarWeekBar
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import kotlinx.android.synthetic.main.dialog_calender.view.cv_calender_dialog_calender
import kotlinx.android.synthetic.main.dialog_calender.view.tv_calender_dialog_date
import kotlinx.android.synthetic.main.dialog_calender.view.tv_calender_dialog_date_for
import kotlinx.android.synthetic.main.dialog_calender.view.tv_calender_dialog_year
import kotlinx.android.synthetic.main.dialog_calender_with_ban.view.*
import kotlinx.android.synthetic.main.fragment_calendar.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.min


/**
 * Created by Donut
 *
 * a dialog for selecting date.
 * within several type to return date, pls do some spacial logic for different type
 * the style is default, if need to change ,pls define
 */
class FilterDateDialog {

    companion object {
        //type for return
        const val TYPE_ISSUE_DATE_FROM = 1
        const val TYPE_ISSUE_DATE_TO = 2
        const val TYPE_DUE_DATE_FROM = 3
        const val TYPE_DUE_DATE_TO = 4
        const val TYPE_PAYMENT_DATE = 5
        const val TYPE_CHEQUE_DATE = 6

        fun showDialog(context: Context, type: Int, originDate: String?, limitationDate: String?, getDateCallback: DateConfirmCallback?) {
            val contentView = LayoutInflater.from(context).inflate(R.layout.dialog_calender, null)
            val calendar = contentView.cv_calender_dialog_calender
            val tvSelectDateType = contentView.tv_calender_dialog_date_for
            val tvSelectDateYear = contentView.tv_calender_dialog_year
            val tvSelectDateDate = contentView.tv_calender_dialog_date
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale.US)
            val orsdf = SimpleDateFormat("yyyy-MM-dd")
            var selectedDate: String = TimeZoneTransformsUtil.formatParameterTime(Date())
            if ((type == TYPE_DUE_DATE_FROM) or (type == TYPE_ISSUE_DATE_FROM)) {
                tvSelectDateType.text = MemoryCache.getLabelText("s_start_date") ?: context.getString(R.string.s_start_date)
            } else {
                tvSelectDateType.text = MemoryCache.getLabelText("s_end_date") ?: context.getString(R.string.s_end_date)
            }

            //set the min date, so that limit the selection range
            if (!limitationDate.isNullOrEmpty() && limitationDate != MemoryCache.getLabelText("s_select_date") ?: context.getString(R.string.s_select_date)) {
                try {
                    val date = sdf.parse(limitationDate)
                    if ((type == TYPE_DUE_DATE_FROM) or (type == TYPE_ISSUE_DATE_FROM)) {
                        calendar.maxDate = date.time
                    } else {
                        calendar.minDate = date.time

                    }
                } catch (e: Exception) {
                    if ((type == TYPE_DUE_DATE_FROM) or (type == TYPE_ISSUE_DATE_FROM)) {
                        calendar.maxDate = Date().time
                    } else {
                        calendar.minDate = Date().time
                    }
                }
            }

            if (type == TYPE_ISSUE_DATE_FROM) {
                calendar.maxDate = if (!limitationDate.isNullOrEmpty() && limitationDate != MemoryCache.getLabelText("s_select_date") ?: context.getString(R.string.s_select_date)) {
                    val dateTime: Long = try {
                        sdf.parse(limitationDate).time
                    } catch (e: Exception) {
                        Date().time
                    }
                    min(dateTime ,Date().time)
                } else {
                    Date().time
                }
            }


            if (type == TYPE_ISSUE_DATE_TO) {
                calendar.maxDate = Date().time
            }

            //show the last chosen date
            val calendarComponent = Calendar.getInstance()
            val date: Date
            if (!originDate.isNullOrEmpty()) {
                date = if (originDate.contains("-")) {
                    orsdf.parse(originDate)
                } else {
                    sdf.parse(originDate)
                }
                calendar.date = date.time
            } else {
                date = Date()
            }
            calendarComponent.time = date
            tvSelectDateYear.text = calendarComponent[Calendar.YEAR].toString()
            val jsonWeekArray = if (MemoryCache.getLabelText("s_week_array_sun") == null) {
                null
            } else {
                mutableListOf(MemoryCache.getLabelText("s_week_array_sun"), MemoryCache.getLabelText("s_week_array_mon"),
                        MemoryCache.getLabelText("s_week_array_tue"), MemoryCache.getLabelText("s_week_array_wed"), MemoryCache.getLabelText("s_week_array_thu"),
                        MemoryCache.getLabelText("s_week_array_fri"), MemoryCache.getLabelText("s_week_array_sat"))
            }
            val dayStr = if (jsonWeekArray == null) { context.resources.getStringArray(R.array.s_a_weekly_day)[calendarComponent[Calendar.DAY_OF_WEEK] - 1] } else { jsonWeekArray[calendarComponent[Calendar.DAY_OF_WEEK] - 1] }+
                    ", " +
                    SimpleDateFormat("MMM dd", Locale.US).format(date)
            tvSelectDateDate.text = dayStr
            calendar.setOnDateChangeListener { _, year, month, dayOfMonth ->
                TealiumUtil.eventTag("button click", "invoices filter popup: " +
                        if ((type == TYPE_DUE_DATE_FROM) or (type == TYPE_ISSUE_DATE_FROM)) {
                            "from "
                        } else {
                            "to "
                        } +
                        if ((type == TYPE_DUE_DATE_FROM) or (type == TYPE_DUE_DATE_TO)) {
                            "invoice due"
                        } else {
                            "invoice issue"
                        } + " date selected")
                val realMonth = month + 1
                selectedDate = "$year-" + if (realMonth < 10) {
                    "0$realMonth"
                } else {
                    realMonth.toString()
                } + if (dayOfMonth < 10) {
                    "-0$dayOfMonth"
                } else {
                    "-$dayOfMonth"
                }
            }

            val calenderDialog = AlertDialog.Builder(context, android.R.style.Theme_Material_Light_Dialog)
                    .setView(contentView)
                    .setCancelable(true)
                    .setNegativeButton(MemoryCache.getLabelText("s_cancel") ?: context.getString(R.string.s_cancel)) { _, _ -> }
                    .setPositiveButton(MemoryCache.getLabelText("s_ok") ?: context.getString(R.string.s_ok)) { _, _ -> getDateCallback?.getDate(selectedDate) }
                    .create()
            calenderDialog.show()
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                val dm = context.resources.displayMetrics
                val width = dm.widthPixels
                val height = dm.heightPixels
                val params = contentView.layoutParams
                params.height = height / 4 * 3
                params.width = width / 4 * 3
                contentView.layoutParams = params
            }
        }

        fun showDateDialog(context: Context, title: String, minDate: String?, maxDate: String?, banList: List<String>, getDateCallback: DateConfirmCallback?) {
            val contentView = LayoutInflater.from(context).inflate(R.layout.dialog_calender_with_ban, null)
            val realBanList = mutableListOf<String>()
            val calendar = contentView.calendarView
            val tvSelectDateType = contentView.tv_calender_dialog_date_for
            val tvSelectDateYear = contentView.tv_calender_dialog_year
            val tvSelectDateDate = contentView.tv_calender_dialog_date
            val tvSelectedDateText = contentView.calendarText
            val chequeTitle = MemoryCache.getLabelText("s_cheque_date")
                    ?: context.getString(R.string.s_cheque_date)
            if (title != chequeTitle) {
                realBanList.addAll(banList)
            }
            contentView.calendarLeftImage.setOnClickListener { calendar.scrollToPre(true) }
            contentView.calendarRightImage.setOnClickListener { calendar.scrollToNext(true) }
            var selectedDate: String = TimeZoneTransformsUtil.formatParameterTime(Date())
            tvSelectDateType.text = title
            val formatter = SimpleDateFormat("yyyy-MM-dd")
            var today = Date()
            var todayStr = formatter.format(today)
            calendar.setMonthView(CalendarMonthView::class.java)
            calendar.setWeekBar(CalendarWeekBar::class.java)
            val minYear = minDate?.substring(0, 4)?.toInt() ?: 0
            val minMonth = minDate?.substring(5, 7)?.toInt() ?: 0
            val minDay = minDate?.substring(8)?.toInt() ?: 0
            var maxYear = minYear + 15
            var maxMonth = minMonth
            var maxDay = minDay
            if (minDay > 1) {
                for (i in 1 until minDay) {
                    val banDay = "$minYear-${(if (minMonth < 10) "0" else "") +  minMonth}-${(if (i < 10) "0" else "") + i}"
                    realBanList.add(banDay)
                }
            }

            if (maxDate != null) {
                maxYear = maxDate.substring(0, 4).toInt()
                maxMonth = maxDate.substring(5, 7).toInt()
                maxDay = maxDate.substring(8).toInt()
            }

            if (maxDay < 31) {
                for (i in maxDay..31) {
                    val banDay = "$maxYear-${(if (maxMonth < 10) "0" else "") +  maxMonth}-${(if (i < 10) "0" else "") + i}"
                    realBanList.add(banDay)
                }
            }
            calendar.setBanList(realBanList)
            calendar.setRange(minYear, minMonth, minDay,maxYear, maxMonth, maxDay)
            if (title != chequeTitle) {
                while (true) {
                    if (banList.contains(todayStr)) {
                        today = Date(today.time + 86400000)
                        todayStr = formatter.format(today)
                        continue
                    } else {
                        break
                    }
                }
            }
            //show the last chosen date
            val calendarComponent = Calendar.getInstance()
            calendarComponent.time = today
            tvSelectDateYear.text = calendarComponent[Calendar.YEAR].toString()
            val jsonWeekArray = if (MemoryCache.getLabelText("s_week_array_sun") == null) {
                null
            } else {
                mutableListOf(MemoryCache.getLabelText("s_week_array_sun"), MemoryCache.getLabelText("s_week_array_mon"),
                        MemoryCache.getLabelText("s_week_array_tue"), MemoryCache.getLabelText("s_week_array_wed"), MemoryCache.getLabelText("s_week_array_thu"),
                        MemoryCache.getLabelText("s_week_array_fri"), MemoryCache.getLabelText("s_week_array_sat"))
            }
            val dayStr = if (jsonWeekArray == null) { context.resources.getStringArray(R.array.s_a_weekly_day)[calendarComponent[Calendar.DAY_OF_WEEK] - 1] } else { jsonWeekArray[calendarComponent[Calendar.DAY_OF_WEEK] - 1] }+
                    ", " +
                    SimpleDateFormat("MMM dd").format(today)
            tvSelectDateDate.text = dayStr
            calendar.selectedCalendar.year = calendarComponent.get(Calendar.YEAR)
            calendar.selectedCalendar.month = calendarComponent.get(Calendar.MONTH) + 1
            calendar.selectedCalendar.day = calendarComponent.get(Calendar.DAY_OF_MONTH)
            calendar.setOnMonthChangeListener { year, month, itemView ->
                val date = Calendar.getInstance().also { a ->
                    a.set(Calendar.YEAR, year)
                    a.set(Calendar.MONTH, month - 1)
                    a.set(Calendar.DAY_OF_MONTH, 1)
                }.time
                tvSelectedDateText.text = SimpleDateFormat("E, MMMM d, yyyy", Locale.ENGLISH).format(date)
            }
            calendar.setOnCalendarSelectListener(object: CalendarView.OnCalendarSelectListener{
                override fun onCalendarOutOfRange(calendar: hk.com.hsbc.glcmdart.calendar.Calendar?) {
                }

                override fun onCalendarSelect(calendar: hk.com.hsbc.glcmdart.calendar.Calendar?, isClick: Boolean) {
                    if (getDateCallback != null) {
                        val isMonthSingle = calendar?.month ?: 0 < 10
                        val isDaySingle = calendar?.day ?: 0 < 10
                        var month = calendar?.month.toString() + ""
                        if (isMonthSingle) {
                            month = "0$month"
                        }
                        var day = calendar?.day.toString() + ""
                        if (isDaySingle) {
                            day = "0$day"
                        }
                        val currentDate = calendar?.year.toString() + "-" + month + "-" + day
                        val date = SimpleDateFormat("E, MMMM d, yyyy", Locale.ENGLISH).format(SimpleDateFormat("yyyy-MM-dd").parse(currentDate))
                        tvSelectedDateText.text = date
                        selectedDate = currentDate
//                        getDateCallback.getDate(currentDate)
                    }
                }
            })

            val calenderDialog = AlertDialog.Builder(context, android.R.style.Theme_Material_Light_Dialog)
                    .setView(contentView)
                    .setCancelable(true)
                    .setNegativeButton(MemoryCache.getLabelText("s_cancel") ?: context.getString(R.string.s_cancel)) { _, _ -> }
                    .setPositiveButton(MemoryCache.getLabelText("s_ok") ?: context.getString(R.string.s_ok)) { _, _ -> getDateCallback?.getDate(selectedDate) }
                    .create()
            calenderDialog.show()
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                val dm = context.resources.displayMetrics
                val width = dm.widthPixels
                val height = dm.heightPixels
                val params = contentView.layoutParams
                params.height = height / 4 * 3
                params.width = width / 4 * 3
                contentView.layoutParams = params
            }
        }
    }

    interface DateConfirmCallback {
        fun getDate(date: String)
    }
}