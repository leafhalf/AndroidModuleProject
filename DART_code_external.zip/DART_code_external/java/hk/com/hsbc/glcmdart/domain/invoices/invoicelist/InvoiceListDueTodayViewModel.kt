package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.util.SparseArray
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.INVOICE
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import hk.com.hsbc.glcmdart.domain.dart.InvoiceGroup
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.util.*
import kotlin.collections.HashMap

class InvoiceListDueTodayViewModel: BaseViewModel() {

    private var currency: String? = MemoryCache.defaultCurrency
    private var overDueCount: Int = 0
    private var mDataSubDateHashMap = TreeMap<String, HashMap<String, MutableList<InvoiceListNativeEntity>>>()
    val invoiceListLiveData = MutableLiveData<MutableList<InvoiceListNativeEntity>>()
    val invoiceListSummaryLiveData = MutableLiveData<SparseArray<Any>>()
    private val mModel by lazy { InvoiceListDueTodayModel() }
    private var uploadParameter = InvoiceRequestParameter(null, null, null, mutableListOf("U", "P"), null, null, null, null, InvoiceRequestSort("dueDate", "desc"))
    private val mDataList = mutableListOf<InvoiceListNativeEntity>()
    private lateinit var mDueDate: String
    var currentPreference = ""
    var currentSearch = ""
    var isFromHome = true

    fun setDueDate(dueDate: String) {
        mDueDate = dueDate
    }

    fun getOverdueList(isInitRequest: Boolean) {
        if (!isInitRequest) {
            requestLoadingLiveData.postValue(true)
        }
        val overdueRequestParameter = InvoiceOverdueRequestParameter(listOf(INVOICE), null,
                if ("B" == MemoryCache.getSessionEntity()?.type) uploadParameter.payeeReference else MemoryCache.getProfileDetail()?.payload?.organisation,
                if ("B" == MemoryCache.getSessionEntity()?.type) null else uploadParameter.payorReference,
                listOf("U", "P"), mDueDate)
        val disposable = mModel.getOverdueInvoiceList(overdueRequestParameter)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        {
                            if (it.payload == null) {
                                invoiceListLiveData.postValue(mutableListOf())
                                return@subscribe
                            }

                            if (it.payload.invoiceGroups != null) {
                                val rebuildInvoiceGroup = mutableListOf<InvoiceGroup>()
                                if (MemoryCache.departmentName.isNotEmpty() && MemoryCache.getSessionEntity()?.type == "S") {
                                    for (item in it.payload.invoiceGroups) {
                                        if (item.payor.name?.contains("(") == true) {
                                            val belongDepartmentName = item.payor.name.split("(")
                                            if (belongDepartmentName.size <= 1) {
                                                continue
                                            }
                                            val belongDepartNameChecker = belongDepartmentName[1].
                                            replace(")", "").
                                            replace(" ", "")
                                            for (checkItem in MemoryCache.departmentName) {
                                                if (checkItem == belongDepartNameChecker) {
                                                    rebuildInvoiceGroup.add(item)
                                                    break
                                                }
                                            }
                                        }
                                    }
                                }

                                mDataSubDateHashMap = TreeMap()
                                for (item in if (rebuildInvoiceGroup.isNotEmpty()) rebuildInvoiceGroup else it.payload.invoiceGroups) {
                                    mDataSubDateHashMap[item.dueDate] = HashMap()
                                }
                                if (isInitRequest) {
                                    if (MemoryCache.initInvoiceList != null) {
                                        val dealResult = dealAllInvoiceData(MemoryCache.initInvoiceList!!)
                                        dealInvoiceView(dealResult)
                                    } else {
                                        getInvoiceList()
                                    }
                                } else {
                                    getInvoiceList()
                                }
                            } else {
                                invoiceListLiveData.postValue(mutableListOf())
                            }

                        },
                        {
                            invoiceListLiveData.postValue(mutableListOf())
                            exceptionLiveData.postValue(DartApplication.instance?.getString(R.string.s_no_data))
//                            Toast.makeText(DartApplication.instance, DartApplication.instance?.getString(R.string.s_no_data), Toast.LENGTH_SHORT).show()
                        }
                )
    }

    fun getInvoiceList() {
        val uploadParameter = InvoiceRequestParameter(null, if ("B" == MemoryCache.getSessionEntity()?.type) currentPreference else MemoryCache.getProfileDetail()?.payload?.organisation,
                currentSearch, mutableListOf("F", "U", "O", "P", "C"), null, null, null, null,
                InvoiceRequestSort("issueDate", "desc"), null, if ("B" == MemoryCache.getSessionEntity()?.type) null else currentPreference, currency = this.uploadParameter.currency)
        val disposable = mModel.getInvoiceList(uploadParameter)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    //filter special department invoices， when has department name return from logon， then filter matching invoices
                    var rebuildEntity: InvoiceListEntity? = null
                    if (MemoryCache.departmentName.isNotEmpty() && MemoryCache.getSessionEntity()?.type == "S") {
                        if (!it.payload?.invoices.isNullOrEmpty()) {
                            val invoiceList = mutableListOf<Invoice>()
                            val tokens = mutableListOf<String>()
                            for (i in it.payload?.invoices?.indices!!) {
                                if (it.payload.invoices[i].payor?.name?.contains("(") == true) {
                                    val belongDepartmentName = it.payload.invoices[i].payor?.name?.split("(") ?: mutableListOf()
                                    if (belongDepartmentName.size <= 1) {
                                        continue
                                    }
                                    val belongDepartNameChecker = belongDepartmentName[1].
                                    replace(")", "").
                                    replace(" ", "")
                                    for (item in MemoryCache.departmentName) {
                                        if (item == belongDepartNameChecker) {
                                            invoiceList.add(it.payload.invoices[i])
                                            tokens.add(it.payload.tokens?.get(i)!!)
                                            break
                                        }
                                    }
                                }
                            }
                            rebuildEntity = InvoiceListEntity(InvoiceListPayLoad(invoiceList,
                                    it.payload.itps, it.payload.pagination, tokens))
                        }
                    }
                    Observable.just(dealAllInvoiceData(rebuildEntity ?: it))
                            .subscribeOn(Schedulers.newThread())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe { b ->
                                dealInvoiceView(b)
                            }

                }, {
                    requestLoadingLiveData.postValue(false)
                    invoiceListLiveData.postValue(mutableListOf())
                    exceptionLiveData.postValue(it.message)
//                    Toast.makeText(DartApplication.instance, it.message, Toast.LENGTH_SHORT).show()
                })
    }

    private fun dealInvoiceView(isDealDataSuccess: Boolean) {
        if (isDealDataSuccess) {
            if (mDataList.isEmpty()) {
                invoiceListLiveData.postValue(mutableListOf())
                return
            } else {
                invoiceListLiveData.postValue(mDataList)
            }
        } else {
            requestLoadingLiveData.postValue(false)
            invoiceListLiveData.postValue(mutableListOf())
            Toast.makeText(DartApplication.instance, DartApplication.instance?.getString(R.string.s_no_data), Toast.LENGTH_SHORT).show()
        }
    }

    private fun dealAllInvoiceData(entity: InvoiceListEntity): Boolean {
        if (entity.payload != null) {
            if (entity.payload.invoices == null || entity.payload.invoices.isEmpty()) {
                return false
            } else {
                val invoiceNum = entity.payload.invoices.size
                mDataList.clear()
                val nativeInvoiceList = mutableListOf<InvoiceListNativeEntity>()
                var totalAmount = 0.00
                overDueCount = 0
                currency = if (invoiceNum > 0) entity.payload.invoices[0].summation?.outstanding?.currency else { MemoryCache.defaultCurrency }
                for (i in 0 until invoiceNum) {
                    if (entity.payload.invoices[i].status == "U" || entity.payload.invoices[i].status == "P") {
                        if (TimeZoneTransformsUtil.calDaysBetween(TimeZoneTransformsUtil.formatParameterTime(Date()), entity.payload.invoices[i].dueDate).toInt() < 0) {
                            entity.payload.invoices[i].summation?.outstanding?.amount?.let {
                                totalAmount += it.toDouble()
                                overDueCount++
                            }
                        }
                    } else {
                        continue
                    }
                    val nativeEntity = InvoiceListNativeEntity(entity.payload.tokens?.get(i), entity.payload.invoices[i])
                    val nameKey = if ("S" == MemoryCache.getSessionEntity()?.type) { entity.payload.invoices[i].payor?.name } else { entity.payload.invoices[i].payee?.name }
                    if (mDataSubDateHashMap[entity.payload.invoices[i].dueDate] != null && mDataSubDateHashMap[entity.payload.invoices[i].dueDate]?.containsKey(nameKey) == true) {
                        mDataSubDateHashMap[entity.payload.invoices[i].dueDate]?.get(nameKey)?.add(nativeEntity)
                    } else {
                        if (isFromHome && mDataSubDateHashMap[mDueDate] == null) {
                            mDataSubDateHashMap[mDueDate] = HashMap()
                        }

                        if (!isFromHome && mDataSubDateHashMap[entity.payload.invoices[i].dueDate] == null) {
                            mDataSubDateHashMap[entity.payload.invoices[i].dueDate ?: ""] = HashMap()
                        }
                        val subList = mutableListOf(nativeEntity)
                        mDataSubDateHashMap[entity.payload.invoices[i].dueDate]?.put(nameKey ?: "", subList)
                    }
                }

                val summaryArray = SparseArray<Any>()
                summaryArray.put(0, overDueCount)
                summaryArray.put(1, totalAmount)
                summaryArray.put(2, currency ?: MARKET_CURRENCY)
                invoiceListSummaryLiveData.postValue(summaryArray)
                //pick #dueDate data first
                if (mDataSubDateHashMap.keys.contains(mDueDate)) {
                    nativeInvoiceList.addAll(subList(mDueDate))
                }
                //secondly, load other date data, order by date asc
                if (isFromHome) {
                    for (key in mDataSubDateHashMap.keys) {
                        if (key == mDueDate) {
                            continue
                        }
                        nativeInvoiceList.addAll(subList(key))
                    }
                }

                requestLoadingLiveData.postValue(false)
                mDataList.addAll(nativeInvoiceList)
                return true
            }
        } else {
            return false
        }
    }

    fun changeTotalAmount(isOutstanding: Boolean) {
        var totalAmount = 0.00
        if (mDataList.isNullOrEmpty()) {
            return
        }

        mDataList.forEach {
            if (!it.isShowHeader && ("U" == it.invoice?.status  || "P" == it.invoice?.status)) {
                if (TimeZoneTransformsUtil.calDaysBetween(TimeZoneTransformsUtil.formatParameterTime(Date()), it.invoice.dueDate).toInt() < 0) {
                    if (isOutstanding) {
                        it.invoice.summation?.outstanding?.amount?.let { amount ->
                            totalAmount += amount.toDouble()
                        }
                    } else {
                        it.invoice.summation?.total?.amount?.let { amount ->
                            totalAmount += amount.toDouble()
                        }
                    }
                }
            }
        }

        val summaryArray = SparseArray<Any>()
        summaryArray.put(0, overDueCount)
        summaryArray.put(1, totalAmount)
        summaryArray.put(2, currency ?: MARKET_CURRENCY)
        invoiceListSummaryLiveData.postValue(summaryArray)
    }

    fun subList(key: String, defaultMap: TreeMap<String, HashMap<String, MutableList<InvoiceListNativeEntity>>>? = null): List<InvoiceListNativeEntity> {
        val localMap = defaultMap ?: mDataSubDateHashMap
        if (localMap[key] != null) {
            val subKeySet = localMap[key]?.keys ?: return emptyList()
            if (subKeySet.isEmpty()) {
                return emptyList()
            }
            val firstSubKey = subKeySet.first()
            val resultList = mutableListOf<InvoiceListNativeEntity>()
            for (subKey in subKeySet) {
                val tmpList: MutableList<InvoiceListNativeEntity>? = localMap[key]?.get(subKey)
                tmpList?.sortWith(compareBy({it.invoice?.summation?.outstanding?.amount?.length}, {it.invoice?.summation?.outstanding?.amount}))
                tmpList?.reverse()
                if (subKey == firstSubKey) {
                    val firstItem = localMap[key]?.get(subKey)?.get(0)
                    val headerItem = InvoiceListNativeEntity(firstItem?.token, firstItem?.invoice, isShowHeader = true)
                    tmpList?.add(0, headerItem)
                }
                if (tmpList != null) {
                    resultList.addAll(tmpList)
                }
            }
            return resultList
        } else {
            return emptyList()
        }
    }

    fun getUploadParameter(): InvoiceRequestParameter {
        return uploadParameter
    }

    fun setUploadParameter(parameter: InvoiceRequestParameter) {
        uploadParameter = parameter
    }

    fun getDateList(date: String, company: String): ArrayList<InvoiceListItem?> {
        val defaultList = ArrayList<InvoiceListItem?>()
        mDataSubDateHashMap[date]?.get(company)?.forEach {
            if (!it.isShowHeader) {
                val invoiceItem = InvoiceListItem(it.token, it.invoice, active = true)
                defaultList.add(invoiceItem)
            }
        }

        return defaultList
    }
}