package hk.com.hsbc.glcmdart.domain.payments.dialog

import android.app.Dialog
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.dart.PaymentMethod
import hk.com.hsbc.glcmdart.domain.payments.adapter.PaymentMethodAdapter
import hk.com.hsbc.glcmdart.domain.payments.view.ProvidePaymentInfoView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil

object PaymentMethodDialog {

    fun showDialog(c: BaseActivity?, paymentMethods: PaymentMethod?, currency: String?,
                   callback: PaymentMethodSelectCallback?,
                   isUpdate: Boolean = false, preSelectPosition: Int = -1) {
        if (c == null) {
            return
        }

        val paymentMethodList = arrayListOf<String>()
        if (paymentMethods?.cheque != null) {
            paymentMethods.cheque?.active?.let {
                if (it) {
                    paymentMethodList.add(ProvidePaymentInfoView.cheque)
                }
            }
        }
        if (paymentMethods?.rtgs != null) {
            paymentMethods.rtgs?.active?.let {
                if (it) {
                    paymentMethodList.add(ProvidePaymentInfoView.rtgs)
                }
            }
        }
        if (paymentMethods?.ach != null) {
            paymentMethods.ach?.active?.let {
                if (it && paymentMethods.ach?.extra != null) {
                    paymentMethodList.add(ProvidePaymentInfoView.ach)
                }
            }
        }
        if (paymentMethods?.bank_transfer != null) {
            paymentMethods.bank_transfer?.active?.let {
                if (it) {
                    paymentMethodList.add(ProvidePaymentInfoView.bank_transfer)
                }
            }
        }

        if (paymentMethods?.dcms != null && MemoryCache.checkDCMSEnable(c, currency)) {
            paymentMethods.dcms?.active?.let {
                if (it) {
                    paymentMethodList.add(ProvidePaymentInfoView.dcms)
                }
            }
        }

        if (paymentMethods?.virtual_account != null && !paymentMethods.virtual_account?.virtual_accounts.isNullOrEmpty()) {
            paymentMethods.virtual_account?.active?.let {
                if (it) {
                    paymentMethodList.add(ProvidePaymentInfoView.va)
                }
            }
        }
        paymentMethodList.sortBy { it }
        val mDialog = Dialog(c, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(c).inflate(R.layout.dialog_payment_method_select, null)
        val mRecyclerView = mContentView.findViewById<RecyclerView>(R.id.rv_invoice_add_or_edit)
        val mTitle = mContentView.findViewById<TextView>(R.id.tv_dialog_method_select_title)
        val btnOk = mContentView.findViewById<Button>(R.id.btn_dialog_method_select_ok)
        val btnCancel = mContentView.findViewById<Button>(R.id.btn_dialog_method_select_cancel)
        val mAdapter = PaymentMethodAdapter(c, paymentMethodList, mRecyclerView)
        mTitle.text = MemoryCache.getLabelText("s_payment_method_select_dialog_title") ?:
                c.getString(R.string.s_payment_method_select_dialog_title)
        btnCancel.text = MemoryCache.getLabelText("s_cancel") ?: c.getString(R.string.s_cancel)
        mRecyclerView.layoutManager = LinearLayoutManager(c)
        mRecyclerView.adapter = mAdapter
        mRecyclerView.itemAnimator = DefaultItemAnimator()
        if (preSelectPosition >= 0) {
            mAdapter.setSelector(preSelectPosition)
        }
        val onClickListener = View.OnClickListener {
            mDialog.cancel()
            if (it.id == R.id.btn_dialog_method_select_ok) {
                if (mAdapter.getSelector() != null && mAdapter.getSelector()!! >= 0) {
                    callback?.onMethodSelected(mAdapter.getSelector() ?: -1,
                            if (mAdapter.getSelector() == null) null else paymentMethodList[mAdapter.getSelector()!!])
                    if (isUpdate)
                        TealiumUtil.eventTag("button click", "planned payments - update payment info: payment method list: ${paymentMethodList[mAdapter.getSelector()!!]} selected")
                    else
                        TealiumUtil.eventTag("button click", "choose payment method: ${paymentMethodList[mAdapter.getSelector()!!]}")
                }
            }
        }

        btnOk.setOnClickListener(onClickListener)
        btnCancel.setOnClickListener(onClickListener)

        mDialog.setContentView(mContentView)
//        mDialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
//        mDialog.window?.setDimAmount(0.1f)
        mDialog.setCanceledOnTouchOutside(false)
        mDialog.setCancelable(false)
        mDialog.show()
    }
}

interface PaymentMethodSelectCallback {

    fun onMethodSelected(position: Int, methodStr: String?)
}