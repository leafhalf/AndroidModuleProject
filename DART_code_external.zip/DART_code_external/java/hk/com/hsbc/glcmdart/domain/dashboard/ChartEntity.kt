/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.dashboard

import androidx.annotation.Keep
import hk.com.hsbc.glcmdart.domain.dart.Account
import hk.com.hsbc.glcmdart.domain.dart.DeductionEnable

@Keep
data class HomePaymentChannelEntity(
        val payload: HomePaymentChannelPayload?
)

@Keep
data class HomePaymentChannelPayload(
        val items: List<HomePaymentChannelInfo>?
)

@Keep
data class HomePaymentChannelInfo(
        val channel: String?,
        val paidStatus: String?,
        val totalValue: String?,
        val outstandingValue: String?,
        val totalITPCount: String?,
        val totalInvoiceCount: String?,
        val buyerCount: String?,
        val channelProvider: String?
)

@Keep
data class HomeInvoiceStatusEntity(
        val payload: HomeInvoiceStatusPayload?
)

@Keep
data class HomeInvoiceStatusPayload(
        val items: List<HomeInvoiceStatusInfo>?
)

@Keep
data class HomeInvoiceStatusInfo(
        val status: String?,
        val totalCount: String?,
        val diffValue: String?,
        val totalValue: String?,
        val outstandingValue: String?
)

@Keep
data class HomeInvoiceSummaryEntity(
        val payload: HomeInvoiceSummaryPayload?
)

@Keep
data class HomeInvoiceSummaryPayload(
        val invoiceTotalCount: String?,
        val invoiceTotalValue: String?,
        val invoiceOverdueCount: String?,
        val invoiceOverdueValue: String
)

@Keep
data class HomeInvoiceMetricsEntity(
        val payload: HomeInvoiceMetricsPayload?
)

@Keep
data class HomeInvoiceMetricsPayload(
        val itpPaidTodayCount: String?,
        val itpPaidTodayValue: String?,
        val invoiceDueTodayCount: String?,
        val invoiceDueTodayValue: String?
)

@Keep
data class ProfileDetailEntity(
        val payload: ProfileDetailPayload?
)

@Keep
data class ProfileDetailPayload(
        val accounts: List<Account>?,
        val name: String?,
        val organisation: String?,
        val organisationName: String?,
        val deductionEnabled: Boolean?,
        val roles: String?,
        val username: String?,
        val locale: String?
)

@Keep
data class Account(
        val countryCode: String?,
        val currency: String?,
        val reference: String?,
        val display: String?,
        val referenceGroup:String?
)