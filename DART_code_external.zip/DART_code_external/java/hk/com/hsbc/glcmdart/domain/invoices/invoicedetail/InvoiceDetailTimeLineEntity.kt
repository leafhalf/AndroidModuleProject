/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicedetail

import androidx.annotation.Keep


/**
 * Created by Donut
 *
 * invoice detail timeline entity
 */
@Keep
data class InvoiceDetailTimeLineEntity(val payload: TimeLinePayload)

@Keep
data class TimeLinePayload(
        val notifications: List<Notification>?
)

@Keep
data class Notification(
        val id: String?,
        val createdAt: String?,
        val type: String?,
        val status: String?,
        val topic: String?,
        val organisationReference: String?,
        val accountReferenceFull: TimeLineAccount?,
        val userReference: String?,
        val properties: List<NormalMap>?
)

@Keep
data class NormalMap (val key: String?, val value: String?)

@Keep
data class TimeLineAccount(
        val countryCode: String?,
        val reference: String?,
        val referenceGroup: String?
)