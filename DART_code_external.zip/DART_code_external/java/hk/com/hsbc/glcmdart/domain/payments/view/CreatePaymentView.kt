/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.view

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import kotlinx.android.synthetic.main.view_create_payment.view.*
import java.util.*

class CreatePaymentView(context: Context?) : LinearLayout(context) {

    private var invoice: InvoiceListItem? = null
    private var amount: Int = 0
    private var currency: String? = null

    init {
        val mInflater = LayoutInflater.from(context)
        mInflater.inflate(R.layout.view_create_payment, this, true)
        TealiumUtil.pageTag(
                "dart : buyer portal : payments : confirm planned payment - beneficiary info",
                "/dart/buyer portal/payments/confirm planned payment-beneficiary info",
                "transaction",
                "buyer portal",
                "payments",
                "mobile",
                "en",
                "create planned payment",
                "1",
                "create planned payment - start"
        )
    }

    fun setInvoiceEntity(entity: InvoiceListItem?) {
        val dateText = MemoryCache.getLabelText("s_date") ?: context?.getString(R.string.s_date) + ": " + TimeZoneTransformsUtil.formatTime(Date())
        tv_create_date.text = dateText
        invoice = entity
        val organizationsMap = MemoryCache.getOrganisationsMap()

//                invoice?.invoice?.payee?.account?.display
        supplierText.text = if (organizationsMap.containsKey(invoice?.invoice?.payee?.reference))
            (organizationsMap[invoice?.invoice?.payee?.reference] as Payee).name
        else
            invoice?.invoice?.payee?.name
        statusTextMiddle.text = MemoryCache.getLabelText("s_payment_amount") ?: context.getString(R.string.s_payment_amount)
    }

    fun setAmount(a: Int, c: String?) {
        amount = a
        currency = c
        if (amount >= 0 && currency != null) {
            val s = (amount.toDouble() / 100).toString()
            val amountStr = String.format(MemoryCache.getLabelText("s_amount_with_tail") ?: context.getString(R.string.s_amount_with_tail),
                    "$currency\t${IndiaNumberUtil.formatNumByDecimal(s, currency ?: MARKET_CURRENCY)}")
            amountText.text = amountStr
        } else {
            amountText.text = "-"
        }

        amountTextMiddle.text = amountText.text
    }
}