package hk.com.hsbc.glcmdart.domain.payments

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentDetailEntity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.*
import kotlinx.android.synthetic.main.activity_payment_gateway_info.*
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.ArrayList

class PaymentGatewayConfirmActivity : BaseActivity() {

    companion object {
        fun showActivity(context: Activity?, paymentDetail: PaymentDetailEntity? = null, invoiceDetailList: ArrayList<InvoiceAddEntity>? = null) {
            context?.startActivityForResult(Intent(context, PaymentGatewayConfirmActivity::class.java).apply {
                putExtra(TAG_PAYMENT_GATEWAY_DETAIL, paymentDetail)
                putExtra(TAG_PAYMENT_GATEWAY_INVOICE_DETAIL, invoiceDetailList)
            }, REQUEST_CODE_PAYMENT_GATEWAY_CONFIRM)
        }
    }

    private var invoiceDetailList: ArrayList<InvoiceAddEntity>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_gateway_info)
        initViews()
    }

    private fun initViews() {
        MemoryCache.getLabelText("s_confirm_make_payment_title")?.let {
            if (!it.isBlank()) {
                tl_head_title.text = it
            }
        }

        ViewCompat.setAccessibilityDelegate(tl_head_title, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.isHeading = true // false to mark a view as not a heading
            }
        })
        MemoryCache.getLabelText("s_confirm_make_payment_tip")?.let {
            if (!it.isBlank()) {
                tv_make_payment_tip.text = it
            }
        }
        MemoryCache.getLabelText("s_your_track_id")?.let {
            if (!it.isBlank()) {
                tv_make_payment_ref_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_date_and_time")?.let {
            if (!it.isBlank()) {
                tv_make_payment_date_and_time_tag.text = it
            }
        }

        MemoryCache.getLabelText("s_view")?.let {
            if (!it.isBlank()) {
                tv_make_payment_invoice_detail.text = it
            }
        }

        MemoryCache.getLabelText("s_transaction_amount")?.let {
            if (!it.isBlank()) {
                tv_track_amount_tag.text = it
            }
        }

        MemoryCache.getLabelText("s_invoice_details")?.let {
            if (!it.isBlank()) {
                tv_make_payment_invoice_detail_tag.text = it
            }
        }

        MemoryCache.getLabelText("s_confirm")?.let {
            if (!it.isBlank()) {
                btn_confirm.text = it
            }
        }

        MemoryCache.getLabelText("s_cancel")?.let {
            if (!it.isBlank()) {
                btn_cancel.text = it
            }
        }

        MemoryCache.getLabelText("s_confirm_make_payment_floor")?.let {
            if (it.isNotBlank()) {
                tv_make_payment_floor.text = it
            }
        }

        title = ""
        val paymentDetail = intent.getSerializableExtra(TAG_PAYMENT_GATEWAY_DETAIL) as PaymentDetailEntity?
        this.invoiceDetailList = intent.getSerializableExtra(TAG_PAYMENT_GATEWAY_INVOICE_DETAIL) as ArrayList<InvoiceAddEntity>?
        ll_confirm_make_payment_invoice_tip_container.removeAllViews()
        invoiceDetailList?.forEach {
            ll_confirm_make_payment_invoice_tip_container.addView(generateInvoiceItems(it))
            val line = View(this)
            var lineLp = line.layoutParams
            if (lineLp == null) {
                lineLp = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ConvertUtil.dp2px(this, 1.0f).toInt())
            } else {
                lineLp.width = ViewGroup.LayoutParams.MATCH_PARENT
                lineLp.height = ConvertUtil.dp2px(this, 1.0f).toInt()
            }
            line.layoutParams = lineLp
            line.background = ContextCompat.getDrawable(this, R.drawable.line_divider)
            ll_confirm_make_payment_invoice_tip_container.addView(line)
        }
        tv_make_payment_ref.text = paymentDetail?.itp?.paymentReference
        tv_supplier_name.text = MemoryCache.getOrganisationsMap()[paymentDetail?.itp?.payeeReference]?.name
        var amount = 0L
        var crAmount = 0L
        paymentDetail?.itp?.lines?.forEach {
            if (INVOICE == it.type)
                amount += it.amount?.amount?.toLong() ?: 0L
            else if (CREDITNOTE == it.type)
                crAmount += it.amount?.amount?.toLong() ?: 0L
        }

        if (MemoryCache.defaultCountry == "ID") {
            var hasFloor = false
            if (!amount.toString().endsWith("00")) {
                hasFloor = true
                amount = amount / 100 * 100
            }

            if (hasFloor) {
                rl_floor_container.visibility = View.VISIBLE
            } else {
                rl_floor_container.visibility = View.GONE
            }
        }
        val amountText = (paymentDetail?.itp?.payeeAccount?.currency ?: MemoryCache.defaultCurrency) + " " + IndiaNumberUtil.formatNumByDecimal(
                amount.toString(), paymentDetail?.itp?.payeeAccount?.currency ?: MARKET_CURRENCY)
        tv_amount.text = amountText
        if (crAmount > 0) {
            val crText = (MemoryCache.getLabelText("s_cr_note_amount") ?: getString(R.string.s_cr_note_amount)) + " " + IndiaNumberUtil.formatNumByDecimal(
                    crAmount.toString(),
                    paymentDetail?.itp?.payeeAccount?.currency ?: MARKET_CURRENCY)
            tv_cr_amount_total.text = crText
            tv_cr_amount_total.visibility = View.VISIBLE
        } else {
            tv_cr_amount_total.visibility = View.GONE
        }
        tv_track_amount.text = tv_amount.text
        val timeZoneTime = TimeZoneTransformsUtil.formatTimeInSimple(paymentDetail?.createdAt ?: "")
        Log.e("test", timeZoneTime)
        tv_make_payment_date_and_time.text = timeZoneTime
        tv_make_payment_date_and_time.visibility = View.GONE
        tv_make_payment_date_and_time_tag.visibility = View.GONE
        tv_make_payment_invoice_detail.setOnClickListener{
            if (ll_confirm_make_payment_invoice_tip_container.visibility == View.GONE) {
                ll_confirm_make_payment_invoice_tip_container.visibility = View.VISIBLE
                tv_make_payment_invoice_detail.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null,
                        ContextCompat.getDrawable(this, R.drawable.ic_arrow_up_black), null)
                v_tip_separation_line.visibility = View.VISIBLE
                tv_make_payment_invoice_detail.contentDescription = MemoryCache.getLabelText("s_talkback_collapse") ?:
                        getString(R.string.s_talkback_collapse)
                tv_make_payment_invoice_detail.text = MemoryCache.getLabelText("s_hide") ?: getString(R.string.s_hide)
            } else {
                ll_confirm_make_payment_invoice_tip_container.visibility = View.GONE
                tv_make_payment_invoice_detail.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null,
                        ContextCompat.getDrawable(this, R.drawable.ic_arrow_down_black), null)
                v_tip_separation_line.visibility = View.GONE
                tv_make_payment_invoice_detail.contentDescription = MemoryCache.getLabelText("s_talkback_expand") ?:
                        getString(R.string.s_talkback_expand)
                tv_make_payment_invoice_detail.text = MemoryCache.getLabelText("s_view") ?: getString(R.string.s_view)
            }
        }
        tb_header.setNavigationOnClickListener { finish() }
        tb_header.navigationContentDescription = MemoryCache.getLabelText("s_talkback_close_button") ?:
                getString(R.string.s_talkback_close_button)
        btn_cancel.setOnClickListener {
            TealiumUtil.eventTag("button click", "proceed to payment: cancel")
            finish()
        }
        btn_confirm.setOnClickListener {
            TealiumUtil.eventTag("button click", "proceed to payment: proceed to payment")
            setResult(Activity.RESULT_OK)
//            PaymentGatewayActivity.showActivity(this@PaymentGatewayConfirmActivity, paymentDetail?.token
//                    ?: "")
            finish()
        }
    }

    private fun generateInvoiceItems(invoice: InvoiceAddEntity): View {
        val itemView = LayoutInflater.from(this).inflate(R.layout.item_payment_invoice_detail, null)
        val tvTitle: TextView = itemView.findViewById(R.id.tv_title)
        val tvAmount: TextView = itemView.findViewById(R.id.tv_amount)
        val rlCrNote: View = itemView.findViewById(R.id.rl_cr_note)
        val tvCrAmount: TextView = itemView.findViewById(R.id.tv_cr_amount)
        val tvDeductionAmount: TextView = itemView.findViewById(R.id.tv_deduction)
        val tvDeductionAmountTag: TextView = itemView.findViewById(R.id.tv_deduction_tag)
        val llDeduction: View = itemView.findViewById(R.id.ll_deduction)
        val llNote: View = itemView.findViewById(R.id.ll_note)
        val tvNote: TextView = itemView.findViewById(R.id.tv_note)
        val tvAmountTag: TextView = itemView.findViewById(R.id.tv_amount_tag)
        val tvCrNoteAmountTag: TextView = itemView.findViewById(R.id.tv_cr_note_amount_tag)
        val tvNoteTag: TextView = itemView.findViewById(R.id.tv_note_tag)

        MemoryCache.getLabelText("s_amount")?.let {
            if (!it.isBlank()) {
                tvAmountTag.text = it
            }
        }
        MemoryCache.getLabelText("s_cr_note_amount")?.let {
            if (!it.isBlank()) {
                tvCrNoteAmountTag.text = it
            }
        }
        MemoryCache.getLabelText("s_note")?.let {
            if (!it.isBlank()) {
                tvNoteTag.text = it
            }
        }
        MemoryCache.getLabelText("s_deduction_amount")?.let {
            if (!it.isBlank()) {
                tvDeductionAmountTag.text = it
            }
        }
        tvTitle.text = invoice.invoice?.reference
        var amountTmpText = invoice.invoice?.summation?.outstanding?.currency + " " +
                IndiaNumberUtil.formatNumByDecimal(invoice.amount.toString(),
                        invoice.invoice?.summation?.outstanding?.currency ?: MARKET_CURRENCY)
        val decimalSymbol = if (invoice.invoice?.summation?.outstanding?.currency == "IDR") {
            ","
        } else {
            "."
        }
//        val subAmountText = amountTmpText.split(decimalSymbol)
//        if (subAmountText.size == 2) {
//            if (subAmountText[1].length == 1)
//                amountTmpText += "0"
//        }
        tvAmount.text = amountTmpText
        if (!TextUtils.isEmpty(invoice.comment)) {
            llNote.visibility = View.VISIBLE
            tvNote.text = invoice.comment
        } else {
            llNote.visibility = View.GONE
        }

        if (!invoice.creditNotesSelected.isNullOrEmpty()) {
            rlCrNote.visibility = View.VISIBLE
            var totalAmount = 0L
            invoice.creditNotesSelected?.forEach {
                totalAmount += it.outstanding?.toLong() ?: 0L
            }
            amountTmpText = "${invoice.invoice?.summation?.outstanding?.currency} -"+
                    IndiaNumberUtil.formatNumByDecimal(totalAmount.toString(),
                            invoice.invoice?.summation?.outstanding?.currency ?: MARKET_CURRENCY).replace("-","")
            val subCRAmountText = amountTmpText.split(decimalSymbol)
            if (subCRAmountText.size == 2) {
                if (subCRAmountText[1].length == 1)
                    amountTmpText += "0"
            }
            tvCrAmount.text = amountTmpText
        } else {
            rlCrNote.visibility = View.GONE
        }

        if (!invoice.taxDeductionSelected.isNullOrEmpty()) {
            llDeduction.visibility = View.VISIBLE
            var totalAmount = 0.0
            invoice.taxDeductionSelected?.forEach {
                totalAmount += ((BigDecimal.valueOf(invoice.invoice?.summation?.outstanding?.amount?.toLong() ?: 0L) *
                        BigDecimal.valueOf(it.maxRate?.toDouble() ?: 0.0)) / BigDecimal.valueOf(100.0)).toDouble()
            }
            amountTmpText = "${invoice.invoice?.summation?.outstanding?.currency} -"+
                    IndiaNumberUtil.formatNumByDecimal(BigDecimal.valueOf(totalAmount).toString(),
                            invoice.invoice?.summation?.outstanding?.currency ?: MARKET_CURRENCY).replace("-","")
            val subCRAmountText = amountTmpText.split(decimalSymbol)
            if (subCRAmountText.size == 2) {
                if (subCRAmountText[1].length == 1)
                    amountTmpText += "0"
            }
            tvDeductionAmount.text = amountTmpText
        } else {
            llDeduction.visibility = View.GONE
        }

        return itemView
    }
}