/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.login

import android.annotation.SuppressLint
import hk.com.hsbc.glcmdart.client.HOST_URL
import hk.com.hsbc.glcmdart.client.HOST_URL_CONSENT
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.dart.PayeeEntity
import hk.com.hsbc.glcmdart.domain.dart.PayeePayload
import hk.com.hsbc.glcmdart.domain.dart.SchedulerTransformer
import hk.com.hsbc.glcmdart.domain.dashboard.ProfileDetailEntity
import hk.com.hsbc.glcmdart.domain.more.MoreServer
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.NetworkManager
import io.reactivex.Observable
import retrofit2.Response

class LoginModel : LoginContract.Model {

    override fun requestLogin(jsonBody: LoginBean): Observable<Response<LoginEntity>> {
        return NetworkManager.getNormalService(LoginService::class.java, HOST_URL_CONSENT)
                .requestLogin(jsonBody)
    }

    override fun requestSession(): Response<SessionEntity> {
        return NetworkManager.getNormalService(LoginService::class.java, HOST_URL)
                .requestSession()
                .execute()
    }

    override fun requestProfile(): Observable<Response<ProfileEntity>> {
        return NetworkManager.getNormalService(LoginService::class.java, HOST_URL)
                .requestProfile()
    }

    override fun requestProfileDetail(loginType: String?): Observable<Response<ProfileDetailEntity>> {
        return NetworkManager.getNormalService(LoginService::class.java, HOST_URL)
                .requestProfileDetail()
    }

    override fun requestOrganisations(loginType: String?): Observable<Response<PayeeEntity>> {
        return NetworkManager.getNormalService(LoginService::class.java, HOST_URL)
                .requestOrganisations()
    }

    @SuppressLint("CheckResult")
    fun getBuyers() {
        NetworkManager.getNormalService(MoreServer::class.java, HOST_URL).getBuyers()
                .compose(SchedulerTransformer())
                .subscribe({
                    val payeesList = mutableListOf<Payee>()
                    it.payload?.buyerRegSummaries?.apply {
                        if (this.isNotEmpty()) {
                            this.forEach { info ->
                                info.buyers?.forEach { buyerOrSupplierInfo ->
                                    val item = Payee(account = null, reference = buyerOrSupplierInfo.userReference,
                                            name = buyerOrSupplierInfo.userName, settings = null, organizationDetail = null)
                                    payeesList.add(item)
                                }
                            }
                        }
                    }
                    MemoryCache.saveOrganisations(PayeeEntity(PayeePayload(payees = payeesList, payors = null)))
                }, {

                })
    }

    override fun requestLogout(): Response<LogoutEntity> {
        return NetworkManager.getNormalService(LoginService::class.java, HOST_URL_CONSENT)
                .requestLogout()
                .execute().let {
                    // Clear cookies in memory
                    NetworkManager.clearCookies()
                    // Clear memory cache
                    MemoryCache.clear()
//                    when (it.code()) {
//                        204 -> {
//                            // Clear cookies in memory
//                            NetworkManager.clearCookies()
//                            // Clear memory cache
//                            MemoryCache.clear()
//                        }
//                    }
                    it
                }
    }

    override fun uploadUrbanAirshipInfo(jsonBody: RequestUrbanAirship): Observable<UrbanAirshipEntity> {
        return NetworkManager.getNormalService(LoginService::class.java, HOST_URL)
                .uploadUrbanAirshipInfo(jsonBody)
    }

    override fun detachUrbanAirship(userId: String): Observable<DetachUrbanAirshipEntity> {
        return NetworkManager.getNormalService(LoginService::class.java, HOST_URL)
                .detachUrbanAirship(userId)
    }
}