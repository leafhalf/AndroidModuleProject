/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dart

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.ConvertUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.dialog_common.view.*
import kotlinx.android.synthetic.main.dialog_common_alert.view.*

object CommonDialog {

    @JvmOverloads
    fun showDialog(context: Context, title: String?, message: String?, confirmText: String? = null, cancelText: String? = null, confirmCallback: View.OnClickListener? = null, cancelCallback: View.OnClickListener? = null) {
        val mDialog = Dialog(context, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(context).inflate(R.layout.dialog_common, null)
        val tvTitle = mContentView.tv_common_dialog_title
        val tvMessage = mContentView.tv_common_dialog_message
        val tvCancel = mContentView.tv_common_dialog_cancel
        val tvConfirm = mContentView.tv_common_dialog_confirm
        mDialog.setContentView(mContentView)
        val window = mDialog.window?.attributes
        window?.width = ConvertUtil.dp2px(context, 280f).toInt()
        mDialog.window?.attributes = window

        MemoryCache.getLabelText("s_cancel")?.let {
            if (!it.isBlank()) {
                tvCancel.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm")?.let {
            if (!it.isBlank()) {
                tvConfirm.text = it
            }
        }

        if (title.isNullOrBlank()) {
            tvTitle.visibility = View.GONE
        } else {
            tvTitle.text = title
        }

        if (message.isNullOrBlank()) {
            tvMessage.visibility = View.GONE
        } else {
            tvMessage.text = message
        }

        if (!cancelText.isNullOrBlank()) {
            tvCancel.text = cancelText
        }

        if (!confirmText.isNullOrBlank()) {
            tvConfirm.text = confirmText
        }

        tvCancel.setOnClickListener {
            mDialog.cancel()
            cancelCallback?.onClick(tvCancel)
        }

        tvConfirm.setOnClickListener {
            mDialog.cancel()
            confirmCallback?.onClick(tvConfirm)
        }

        mDialog.setCanceledOnTouchOutside(true)
        mDialog.setCancelable(true)
        mDialog.show()
    }

    fun showAlertDialog(context: Context?, title: String?, message: String?, positiveButtonText: String?,
                        buttonListener: CommonDialogExtras.OnButtonListener?, negativeButtonText: String?) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_common_alert, null, false)
        val alertDialog = AlertDialog.Builder(context, android.R.style.Theme_Material_Light_Dialog).create()
        view.tv_title.text = title
        view.tv_message.text = message
        view.btn_cancle.setOnClickListener {
            alertDialog.dismiss()
            buttonListener?.negativeButtonListener()
        }
        if (negativeButtonText == null) {
            view.btn_cancle.visibility = View.GONE
        }
        view.btn_cancle.text = negativeButtonText
        view.btn_select.setOnClickListener {
            alertDialog.dismiss()
            buttonListener?.positiveButtonListener()
        }
        view.btn_select.text = positiveButtonText
        alertDialog.show()
        alertDialog.window?.setContentView(view)
        val dm = context!!.resources.displayMetrics
        val width = dm.widthPixels
        val params = (view.layoutParams as FrameLayout.LayoutParams)
        params.width = width / 9 * 7
        view.layoutParams = params
    }
}

class CommonDialogExtras {
    interface OnButtonListener {
        fun positiveButtonListener()
        fun negativeButtonListener()
    }
}