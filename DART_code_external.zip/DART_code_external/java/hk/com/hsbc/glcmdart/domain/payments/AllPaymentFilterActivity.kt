package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.CompoundButton
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_SUPPLIER
import hk.com.hsbc.glcmdart.client.TAG_SELECT_SUPPLIER_RESULT
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog.Companion.TYPE_ISSUE_DATE_FROM
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog.Companion.TYPE_ISSUE_DATE_TO
import hk.com.hsbc.glcmdart.domain.payments.adapter.PaymentCurrencyAdapter
import hk.com.hsbc.glcmdart.domain.payments.model.bean.Timestap
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import kotlinx.android.synthetic.main.activity_all_payment_filter.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class AllPaymentFilterActivity : BaseActivity(), View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    private val itemCurrencyList = mutableMapOf<String, MutableList<String>>()
    private val mPaymentCurrencyAdapter by lazy { PaymentCurrencyAdapter(this, itemCurrencyList) }
    private var payeeOrPayor: Payee? = null
    private var supplierOrBuyer: Boolean = false
    private var gtCondition: Timestap? = null
    private var ltCondition: Timestap? = null
    private var conditionCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_all_payment_filter)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(true, this)
        initViewAndEvent()
    }

    @SuppressLint("ResourceAsColor")
    private fun initViewAndEvent() {
        MemoryCache.getLabelText("s_reset")?.let {
            if (!it.isBlank()) {
                btn_reset.text = it
            }
        }
        MemoryCache.getLabelText("s_currency")?.let {
            if (!it.isBlank()) {
                tv_currency_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_status")?.let {
            if (!it.isBlank()) {
                tv_payment_status_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_created")?.let {
            if (!it.isBlank()) {
                tv_created_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_revoked")?.let {
            if (!it.isBlank()) {
                tv_revoked_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_closed")?.let {
            if (!it.isBlank()) {
                tv_closed_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_apply_filter")?.let {
            if (!it.isBlank()) {
                btnApply.text = it
            }
        }
        MemoryCache.getLabelText("")?.let {
            if (!it.isBlank()) {
                tv_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_from")?.let {
            if (!it.isBlank()) {
                tv_payment_list_filter_date_from_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_to")?.let {
            if (!it.isBlank()) {
                tv_payment_list_filter_date_to_tag.text = it
            }
        }

        tv_created_tag.text = MemoryCache.getLabelText("s_payment_status_" + "created")
        tv_revoked_tag.text = MemoryCache.getLabelText("s_payment_status_" + "revoked")
        tv_processing_tag.text = if (MemoryCache.defaultCountry == "IN") {
            "Processing"
        } else {
            MemoryCache.getLabelText("s_payment_status_" + "processing")
        }
        tv_closed_tag.text = MemoryCache.getLabelText("s_payment_status_" + "closed")

        tl_head.title = MemoryCache.getLabelText("s_filter") ?: getString(R.string.s_filter)
        tl_head.setNavigationIcon(R.drawable.ic_close_on_light)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            finish()
        }
        supplierOrBuyer = ("S" == MemoryCache.getSessionEntity()?.type)
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        if (supplierOrBuyer) {
            tvRole.text = MemoryCache.getLabelText("s_buyer") ?: getString(R.string.s_buyer)
        } else {
            tvRole.text = MemoryCache.getLabelText("s_supplier") ?: getString(R.string.s_supplier)
        }
        rv_invoice_add_or_edit.adapter = mPaymentCurrencyAdapter
        if (MemoryCache.getCurrencyMap().isNotEmpty())
            itemCurrencyList.putAll(MemoryCache.getCurrencyMap())
        mPaymentCurrencyAdapter.addData(itemCurrencyList)
        mPaymentCurrencyAdapter.setSelectState(intent?.getStringExtra(FILTER_CURRENCY))
        if (intent?.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) != null) {
            payeeOrPayor = intent.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) as Payee?
            tv_supplier.text = payeeOrPayor?.name
            conditionCount++
        } else {
            payeeOrPayor = null
            tv_supplier.text = MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
        }
        if (intent?.getSerializableExtra(FILTER_STATUSES) != null) {
            val statuses = intent?.getSerializableExtra(FILTER_STATUSES) as List<String>
            if (statuses.isEmpty()) {
                cbCreate.isChecked = true
                cbRevoked.isChecked = true
                cbClosed.isChecked = true
                cbProcessing.isChecked = true
                cbPaymentReceived.isChecked = true
                conditionCount += 5
            } else {
                if (statuses.contains("created")) {
                    cbCreate.isChecked = true
                    conditionCount++
                }
                if (statuses.contains("revoked_payor")) {
                    cbRevoked.isChecked = true
                    conditionCount++
                }
                if (statuses.contains("closed")) {
                    cbClosed.isChecked = true
                    conditionCount++
                }
                if (statuses.contains("processing")) {
                        cbProcessing.isChecked = true
                        conditionCount++
                }
                if (statuses.contains("payment_received")) {
                    cbPaymentReceived.isChecked = true
                    conditionCount++
                }
            }
        } else {
            cbCreate.isChecked = true
            cbRevoked.isChecked = true
            cbClosed.isChecked = true
            cbProcessing.isChecked = true
            cbPaymentReceived.isChecked = true
            conditionCount += 5
        }

        if (itemCurrencyList.size <= 1) {
            tv_currency_tag.visibility = View.GONE
            rv_invoice_add_or_edit.visibility = View.GONE
        } else {
            tv_currency_tag.visibility = View.VISIBLE
            rv_invoice_add_or_edit.visibility = View.VISIBLE
        }

        if (intent?.getSerializableExtra(FILTER_DATE_GT) != null) {
            gtCondition = intent?.getSerializableExtra(FILTER_DATE_GT) as Timestap?
            if (gtCondition != null) {
                conditionCount++
                tv_payment_list_filter_date_from.text = TimeZoneTransformsUtil.formatTime(Date((gtCondition?.nano ?: 0) * 1000))
            }
        } else {
            tv_payment_list_filter_date_from.text = MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)
        }
        if (intent?.getSerializableExtra(FILTER_DATE_LT) != null) {
            ltCondition = intent?.getSerializableExtra(FILTER_DATE_LT) as Timestap?
            if (ltCondition != null) {
                conditionCount++
                tv_payment_list_filter_date_to.text = TimeZoneTransformsUtil.formatTime(Date((ltCondition?.nano ?: 0) * 1000))
            }
        } else {
            tv_payment_list_filter_date_to.text = MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)
        }

        btnApply.text = String.format(
                MemoryCache.getLabelText("s_apply_filter_num") ?: getString(R.string.s_apply_filter_num),
                conditionCount)

        rv_supplier.setOnClickListener(this)
        btnApply.setOnClickListener(this)
        btn_reset.setOnClickListener(this)
        iv_payment_list_filter_date_from_icon.setOnClickListener(this)
        iv_payment_list_filter_date_to_icon.setOnClickListener(this)
        cbProcessing.setOnCheckedChangeListener(this)
        cbClosed.setOnCheckedChangeListener(this)
        cbCreate.setOnCheckedChangeListener(this)
        cbRevoked.setOnCheckedChangeListener(this)
        cbPaymentReceived.setOnCheckedChangeListener(this)
    }

    private fun showCalenderDialog(type: Int) {
        val minDate = if (type == TYPE_ISSUE_DATE_TO && tv_payment_list_filter_date_from.text.toString() != MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)) {
            tv_payment_list_filter_date_from.text.toString()
        }  else if (type == TYPE_ISSUE_DATE_FROM && tv_payment_list_filter_date_to.text.toString() != MemoryCache.getLabelText("s_select_date") ?: getString(R.string.s_select_date)){
            tv_payment_list_filter_date_to.text.toString()
        }  else {
            null
        }

        FilterDateDialog.showDialog(this, type, when (type) {
            TYPE_ISSUE_DATE_FROM -> {
                if (gtCondition == null)
                    null
                else
                    TimeZoneTransformsUtil.formatTime(Date(gtCondition!!.nano * 1000)) }
            TYPE_ISSUE_DATE_TO -> {
                if (ltCondition == null)
                    null
                else
                    TimeZoneTransformsUtil.formatTime(Date(ltCondition!!.nano * 1000)) }
            else -> null
        }, minDate, object : FilterDateDialog.DateConfirmCallback {

            override fun getDate(date: String) {
                when (type) {
                    TYPE_ISSUE_DATE_FROM -> {
                        val timestap = SimpleDateFormat("yyyy-MM-dd").parse(date)
                        if (gtCondition == null) {
                            conditionCount++
                            btnApply.text = String.format(
                                    MemoryCache.getLabelText("s_apply_filter_num") ?: getString(R.string.s_apply_filter_num),
                                    conditionCount)
                            gtCondition = Timestap(timestap.time / 1000)
                        } else {
                            gtCondition?.nano = timestap.time / 1000
                        }
//                        uploadParameterShadow.dateFrom = date
                        tv_payment_list_filter_date_from.text = TimeZoneTransformsUtil.formatTime(date)
                    }
                    TYPE_ISSUE_DATE_TO -> {
                        val timestap = SimpleDateFormat("yyyy-MM-dd").parse(date)
                        if (ltCondition == null) {
                            conditionCount++
                            btnApply.text = String.format(
                                    MemoryCache.getLabelText("s_apply_filter_num") ?: getString(R.string.s_apply_filter_num),
                                    conditionCount)
                            ltCondition = Timestap(timestap.time / 1000)
                        } else {
                            ltCondition?.nano = timestap.time / 1000
                        }
//                        uploadParameterShadow.dateTo = date
                        tv_payment_list_filter_date_to.text = TimeZoneTransformsUtil.formatTime(date)
                    }
                }
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE_SUPPLIER) {
            val payee = data?.getSerializableExtra(TAG_SELECT_SUPPLIER_RESULT) as Payee?
            val organizationsMap = MemoryCache.getOrganisationsMap()
            val allText = MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
            if (payeeOrPayor == null || payeeOrPayor?.name == allText) {
                if (payee?.name != allText) {
                    conditionCount++
                    btnApply.text = String.format(
                            MemoryCache.getLabelText("s_apply_filter_num") ?: getString(R.string.s_apply_filter_num),
                            conditionCount)
                }
            } else {
                if (payee?.name == allText) {
                    conditionCount--
                    btnApply.text = String.format(
                            MemoryCache.getLabelText("s_apply_filter_num") ?: getString(R.string.s_apply_filter_num),
                            conditionCount)
                }
            }
            tv_supplier.text = if (organizationsMap.containsKey(payee?.reference))
                (organizationsMap[payee?.reference] as Payee).name
            else
                payee?.name
            payeeOrPayor = payee
        }
    }

    companion object {
        const val FILTER_SUPPLIER_OR_BUYER = "RESULT_TAG_FILTER_SUPPLIER_OR_BUYER"
        const val FILTER_CURRENCY = "RESULT_TAG_FILTER_CURRENCY"
        const val FILTER_STATUSES = "RESULT_TAG_FILTER_STATUSES"
        const val FILTER_DATE_GT = "RESULT_TAG_FILTER_DATE_GT"
        const val FILTER_DATE_LT = "RESULT_TAG_FILTER_DATE_LT"
        const val FILTER_DISPLAY_PROCESSING = "RESULT_TAG_PROCESSING"
        fun showActivity(fragment: Fragment, payeeOrPayor: Payee?, currencySelect: String?,
                         statuses: List<String>?, gtCondition: Timestap? = null,
                         ltCondition: Timestap? = null,
                         requestCode: Int) {
            val intent = Intent(fragment.activity, AllPaymentFilterActivity::class.java).apply {
                if (payeeOrPayor != null)
                    putExtra(FILTER_SUPPLIER_OR_BUYER, payeeOrPayor)
                putExtra(FILTER_CURRENCY, currencySelect)
                if (!statuses.isNullOrEmpty())
                    putExtra(FILTER_STATUSES, statuses as ArrayList<String>)
                if (gtCondition != null) {
                    putExtra(FILTER_DATE_GT, gtCondition)
                }
                if (ltCondition != null) {
                    putExtra(FILTER_DATE_LT, ltCondition)
                }
            }
            fragment.startActivityForResult(intent, requestCode)
        }
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.rv_supplier -> {
                SuppliersOrCustomersSelectActivity.showActivity(this, if (payeeOrPayor != null) {
                    payeeOrPayor?.reference
                } else {
                    MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
                },if (payeeOrPayor != null) {
                    payeeOrPayor?.account?.currency
                } else {
                    null
                }, REQUEST_CODE_SUPPLIER, true, "S" == MemoryCache.getSessionEntity()?.type)
            }
            R.id.btnApply -> {
                val intent = Intent().apply {
                    putExtra(FILTER_SUPPLIER_OR_BUYER, payeeOrPayor)
                    if (!mPaymentCurrencyAdapter.getSelectItem().isNullOrEmpty())
                        putExtra(FILTER_CURRENCY, mPaymentCurrencyAdapter.getSelectItem())
                    val statuses = ArrayList<String>()
                    if (cbCreate.isChecked)
                        statuses.add("created")
                    if (cbRevoked.isChecked)
                        statuses.add("revoked_payor")
                    if (cbClosed.isChecked)
                        statuses.add("closed")
                    if (cbProcessing.isChecked)
                        statuses.add("processing")
                    if (cbPaymentReceived.isChecked)
                        statuses.add("payment_received")
                    if (statuses.isNotEmpty())
                        putExtra(FILTER_STATUSES, statuses)
                    if (gtCondition != null) {
                        putExtra(FILTER_DATE_GT,gtCondition)
                    }
                    if (ltCondition != null) {
                        putExtra(FILTER_DATE_LT, ltCondition)
                    }
                }
                setResult(Activity.RESULT_OK, intent)
                finish()
            }
            R.id.btn_reset -> {
                payeeOrPayor = null
                tv_supplier.text = MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
                mPaymentCurrencyAdapter.setSelectState(intent?.getStringExtra(FILTER_CURRENCY))
                cbCreate.isChecked = false
                cbRevoked.isChecked = false
                cbClosed.isChecked = false
                cbProcessing.isChecked = false
                cbPaymentReceived.isChecked = false
                conditionCount = 0
                btnApply.isEnabled = false
                btnApply.text = MemoryCache.getLabelText("s_apply_filter") ?: getString(R.string.s_apply_filter)
            }
            R.id.iv_payment_list_filter_date_from_icon -> {
                showCalenderDialog(TYPE_ISSUE_DATE_FROM)
            }
            R.id.iv_payment_list_filter_date_to_icon -> {
                showCalenderDialog(TYPE_ISSUE_DATE_TO)
            }
        }
    }

    override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
        if (isChecked) {
            conditionCount++
            btnApply.text = String.format(
                    MemoryCache.getLabelText("s_apply_filter_num") ?: getString(R.string.s_apply_filter_num),
                    conditionCount)
            btnApply.isEnabled = true
            btnApply.setBackgroundColor(ContextCompat.getColor(this, R.color.primary_red))
        } else {
            conditionCount--
            btnApply.text = String.format(
                    MemoryCache.getLabelText("s_apply_filter_num") ?: getString(R.string.s_apply_filter_num),
                    conditionCount)
            if (!cbRevoked.isChecked && !cbProcessing.isChecked && !cbClosed.isChecked && !cbCreate.isChecked) {
                btnApply.text = MemoryCache.getLabelText("s_apply_filter") ?: getString(R.string.s_apply_filter)
                btnApply.isEnabled = false
                btnApply.setBackgroundColor(ContextCompat.getColor(this, R.color.color56))
            }
        }

    }
}
