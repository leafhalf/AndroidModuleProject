package hk.com.hsbc.glcmdart.domain.payments.dialog

import android.app.Dialog
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.TextView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache

object PaymentDetailToolTipDialog {

    fun showDialog(c: BaseActivity?) {

        if (c == null) {
            return
        }

        val mDialog = Dialog(c, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(c).inflate(R.layout.dialog_payment_detail_tool_tip, null)
        val tvTip = mContentView.findViewById<TextView>(R.id.tv_tool_tip_tip)
        val tvTitle = mContentView.findViewById<TextView>(R.id.tv_tool_tip_title)
        val ivClose = mContentView.findViewById<ImageView>(R.id.iv_tool_tip_close)

        tvTitle.text = MemoryCache.getLabelText("s_your_track_id") ?: c.getString(R.string.s_your_track_id)
        tvTip.text = MemoryCache.getLabelText("s_tool_tip_tip") ?: c.getString(R.string.s_tool_tip_tip)
        ivClose.setOnClickListener { mDialog.cancel() }

        mDialog.setContentView(mContentView)
        mDialog.setCanceledOnTouchOutside(true)
        mDialog.setCancelable(true)
        mDialog.show()
    }
}