/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dashboard.HomePaymentChannelInfo
import hk.com.hsbc.glcmdart.domain.payments.view.PaymentSummaryView.Companion.SUMMARY_FILTER_TYPE_METHOD
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.view.RecyclerExtras

class PaymentSummaryAdapter(context: Context, private val mData: ArrayList<HomePaymentChannelInfo>, private val filterType: String) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val inflater: LayoutInflater = LayoutInflater.from(context)

    private var currency: String? = null

    fun setCurrency(currency: String?) {
        this.currency = currency
    }

    fun addData(dataList: ArrayList<HomePaymentChannelInfo>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        notifyDataSetChanged()
    }


    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_payment_summary, parent, false)
        return ItemHolder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        if (SUMMARY_FILTER_TYPE_METHOD == filterType) {
            vh.tvPaymentMethod.text = MemoryCache.getLabelText("s_payment_method_label_" + mData[position].paidStatus)
        } else {
            vh.tvPaymentMethod.text = MemoryCache.getLabelText("s_payment_method_label_" + mData[position].channel)
        }
        vh.tvAmount.text = "$currency " + IndiaNumberUtil.formatNumByDecimal(mData[position].totalValue ?: "0.00", currency ?: MARKET_CURRENCY)
        vh.tvInvoices.text = mData[position].totalInvoiceCount
        vh.tvBuyers.text = mData[position].buyerCount

        MemoryCache.getLabelText("s_amount")?.let {
            if (!it.isBlank()) {
                vh.tvAmountTag.text = it
            }
        }
        MemoryCache.getLabelText("navigation_invoices_title")?.let {
            if (!it.isBlank()) {
                vh.tvInvoicesTag.text = it
            }
        }
        MemoryCache.getLabelText("s_buyers")?.let {
            if (!it.isBlank()) {
                vh.tvBuyersTag.text = it
            }
        }
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvPaymentMethod: TextView = view.findViewById(R.id.tv_payment_method)
        val tvAmount: TextView = view.findViewById(R.id.tv_Amount)
        val tvInvoices: TextView = view.findViewById(R.id.tv_invoices)
        val tvBuyers: TextView = view.findViewById(R.id.tv_buyers)
        val tvAmountTag: TextView = view.findViewById(R.id.tv_amount_tag)
        val tvInvoicesTag: TextView = view.findViewById(R.id.tv_invoices_tag)
        val tvBuyersTag: TextView = view.findViewById(R.id.tv_buyers_tag)
    }

    private var itemClickListener: RecyclerExtras.OnItemClickListener? = null

    fun setOnItemClickListener(listener: RecyclerExtras.OnItemClickListener) {
        this.itemClickListener = listener
    }
}
