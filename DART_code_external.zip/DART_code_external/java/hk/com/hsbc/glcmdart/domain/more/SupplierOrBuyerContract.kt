package hk.com.hsbc.glcmdart.domain.more

import hk.com.hsbc.glcmdart.domain.more.entity.BuyerOrSupplierInfo
import hk.com.hsbc.glcmdart.framework.IView

interface SupplierOrBuyerContract {

    interface View: IView{
        fun updateData(list: List<BuyerOrSupplierInfo>?, hasData: Boolean = true)
    }
}