package hk.com.hsbc.glcmdart.domain.payments

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.payments.adapter.DeductionExtendAdapter
import hk.com.hsbc.glcmdart.domain.payments.adapter.DeductionExtendItemClickListener
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.activity_choose_va_bank.*

class ChooseTaxDeductionExtendActivity(): BaseActivity(), DeductionExtendItemClickListener {

    companion object {
        const val INTENT_TAG_REQUEST_DEDUCTION_EXTEND_LIST = "deductionExtendList"
        const val INTENT_TAG_RESULT_DEDUCTION_EXTEND_LIST = "resultDeductionExtendList"
        const val INTENT_TAG_CURRENT_DEDUCTION_NAME = "deductionName"
        const val INTENT_TAG_INDEX = "index"
        fun showActivityForResult(context: BaseActivity, requestCode: Int, itemIndex: Int,
                                  deductionName: String, deductionExtendList: ArrayList<TaxDeductionInfo>) {
            val intent = Intent(context, ChooseTaxDeductionExtendActivity::class.java)
            intent.putExtra(INTENT_TAG_REQUEST_DEDUCTION_EXTEND_LIST, deductionExtendList)
            intent.putExtra(INTENT_TAG_INDEX, itemIndex)
            intent.putExtra(INTENT_TAG_CURRENT_DEDUCTION_NAME, deductionName)
            context.startActivityForResult(intent, requestCode)
        }
    }

    private var adapter: DeductionExtendAdapter? = null
    private var itemList  = ArrayList<TaxDeductionInfo>()
    private var itemIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_va_bank)
        initViewsAndData()
    }

    private fun initViewsAndData() {
        tb_head.title = intent.getStringExtra(INTENT_TAG_CURRENT_DEDUCTION_NAME)
        tb_head.setTitleTextColor(Color.WHITE)
        tb_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        tb_head.setNavigationOnClickListener { finish() }
        itemList = intent.getSerializableExtra(INTENT_TAG_REQUEST_DEDUCTION_EXTEND_LIST) as ArrayList<TaxDeductionInfo>
        itemIndex = intent.getIntExtra(INTENT_TAG_INDEX, 0)
        adapter = DeductionExtendAdapter(this, itemList as List<TaxDeductionInfo>,
                this)
        rv_choose_va_bank.layoutManager = LinearLayoutManager(this)
        rv_choose_va_bank.addItemDecoration(DividerItemDecoration(this, LinearLayout.VERTICAL))
        rv_choose_va_bank.adapter = adapter

        btn_save.visibility = View.VISIBLE
        btn_save.setOnClickListener {
            setResult(Activity.RESULT_OK, Intent().apply {
                putExtra(INTENT_TAG_RESULT_DEDUCTION_EXTEND_LIST, itemList)
                putExtra(INTENT_TAG_INDEX, itemIndex)
            })

            finish()
        }
    }

    override fun onItemClick(position: Int) {
        for (item in itemList) {
            item.selected = false
        }

        itemList[position].selected = true
        adapter?.notifyDataSetChanged()
    }
}
