/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dart

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import java.io.Serializable

@Keep
data class BasicResponse(
        val code: Int,
        val msg: String?
)

@Keep
data class RequestPagination(
        var currentPage: Int, var limit: Int
) : Serializable

@Keep
data class Account(
        val reference: String?,
        val currency: String?,
        val countryCode: String?,
        val referenceGroup: String?,
        val display: String?
) : Serializable

@Keep
data class Amount(
        val amount: String?,
        val currency: String?
) : Serializable

@Keep
data class Extra(
        val cgst: String?,
        val ewayBillDate: String?,
        val ewayBillNum: String?,
        val ewayStatus: String?,
        val ewayVehicle: String?,
        val gstnAck: String?,
        val gstnUploadStatus: String?,
        val gstrStatus: String?,
        val gstnReconciliation: String?,
        val igst: String?,
        val payeeAddress: String?,
        val payeeGstin: String?,
        val payeeState: String?,
        val payorAddress: String?,
        val payorGstin: String?,
        val payorState: String?,
        val sgst: String?,
        val taxableValue: String?
) : Serializable

@Keep
data class InvoiceGroup(
        val payee: Payee,
        val payor: Payee,
        val dueDate: String,
        val outstanding: String,
        val outstandingCurrency: String,
        val invoiceTokens: List<String>,
        val itpTokens: List<String>,
        val statuses: List<String>,
        var invoiceOutstanding: String?,
        var invoiceOutstandingCurrency: String?,
        var paymentTotal: String?,
        var paymentTotalCurrency: String?
) : Serializable

@Keep
data class Invoice(
        val reference: String?,
        val status: String?,
        val issueDate: String?,
        val dueDate: String?,
        val payee: Payee?,
        val payor: Payee?,
        val summation: Summation?,
        val active: Boolean,
        val extra: Extra?
) : Serializable

@Keep
data class ITP(
        val payeeReference: String?,
//        val payeeAccountReference: String?,
//        val payeeAccountDisplay: String?,
        val payeeAccount: Account?,
        val payorReference: String?,
//        val payorAccountReference: String?,
//        val payorAccountDisplay: String?,
        val payorAccount: Account?,
        val expectedDate: String?,
        val paymentReference: String?,
        val paymentMethod: String?,
        val createdAt: String?,
        val updatedAt: String?,
        val status: String?,
        var vaCodeInfo: ITPVA?,
        var amount: String?,
        val lines: List<Line>?,
        val extra: ITPExtra?
) : Serializable

@Keep
data class ITPExtra(
        val use_generated_token: String?,
        val payment_cheque_amount: String?,
        val payment_cheque_currency: String?,
        val payment_cheque_date: String?,
        val payment_cheque_number: String?,
        val payment_method_provider: String?,
        val dcms_redirect_link: String?,
        val dcms_transaction_ref: String?,
        val dcms_va_payment_code: String?
) : Serializable

@Keep
data class ITPVA(
        var vaCode: String?
): Serializable

@Keep
data class InvoiceListItem(
        val token: String?,
        val invoice: Invoice?,
        val active: Boolean?
) : Serializable

@Keep
data class CalendarListItem(
        val dueOrExpectedDate: String?,
        val invoiceAmount: String?,
        val invoiceCurrency: String?,
        val itpAmount: String?,
        val itpCurrency: String?,
        val dueInvoices: MutableList<InvoiceListItem> = mutableListOf(),
        val expectedPayments: MutableList<ITPListItem> = mutableListOf()
) : Serializable

@Keep
data class ITPListItem(
        val token: String?,
        val itp: ITP?,
        val createdAt: String?,
        val updatedAt: String?,
        val status: String?,
        val amount: String?
) : Serializable

@Keep
data class InvoiceDeductionItem(
        val token: String?,
        val deductionOption: String?,
        val type: String?,
        val currency: String?,
        val amount: String?,
        val date: String?,
        val status: String?,
        val reason: String?
) : Serializable

@Keep
data class Line(
        val type: String?,
        val token: String?,
        val amount: Amount?,
        val comment: String?,
        val status: String?,
        val appliesTo: String?
) : Serializable

@Keep
data class PlannedPaymentDeductionNotification (
        var currency: String?,
        var amount: String?,
        var appliesTo: String?,
        var invoiceRef: String?,
        var payeeName: String?
): Serializable

@Keep
data class Pagination(
        val currentPage: Int,
        val limit: Int,
        val totalPages: Int,
        val totalItems: Int
) : Serializable

@Keep
data class Payee(
        val reference: String?,
        val name: String?,
        val account: Account?,
        @SerializedName("organisation_details")
        val organizationDetail: PayeeDetail?,
        val settings: PayeeSetting?,
        var isChecked: Boolean = false
) : Serializable

@Keep
data class PayeeSetting(val deduction: DeductionEnable?): Serializable

@Keep
data class DeductionEnable(val active: Boolean?): Serializable

@Keep
data class PayeeDetail(
        val address: String?,
        val contact: String?,
        val phone: String?,
        val email: String?,
        val country_code: String
): Serializable

@Keep
data class Summation(
        val subTotal: Amount?,
        val tax: Amount?,
        val total: Amount?,
        val outstanding: Amount?
) : Serializable

@Keep
data class PayeeEntity(val payload: PayeePayload) : Serializable

@Keep
data class PayeePayload(
        val payees: List<Payee>?,
        val payors: List<Payee>?
) : Serializable

@Keep
data class PaymentMethodPayload(val payload: PaymentMethod?)

@Keep
data class PaymentMethod(
        var ach: MethodACH?,
        var bank_transfer: MethodBankTransfer?,
        var cheque: MethodCheque?,
        var credit_note: MethodCreditNote?,
        var rtgs: MethodRTGS?,
        var dcms: MethodDCMS?,
        var virtual_account: MethodVA?
) : Serializable

@Keep
data class MethodCheque(
        var active: Boolean?,
        var issue_date_not_older_than_days: Int?,
        var cheque_number_maximum_length: Int?,
        var cheque_number_minimum_length: Int?
) : Serializable

@Keep
data class MethodRTGS(
        var active: Boolean?,
        var min_payment_amount: Int?
) : Serializable

@Keep
data class MethodACH(
        var active: Boolean?,
        var hours_before_payment_date: Int?,
        var extra: ACHExtra?
) : Serializable

@Keep class MethodVA(
        var active: Boolean?,
        var virtual_accounts: List<String?>?
): Serializable

@Keep
data class ACHExtra(
        var ACH_mandate_amount: String?,
        var ACH_mandate_date: String?,
        var ACH_mandate_urn: String?
) : Serializable

@Keep
data class MethodBankTransfer(
        var active: Boolean?
) : Serializable

@Keep
data class MethodCreditNote(
        var active: Boolean?
) : Serializable

@Keep
data class MethodDCMS(
        var active: Boolean?,
        var enabled_providers: List<String?>?
) : Serializable

@Keep
data class BankCalendarPayload(val payload: BankCalendarEntry) : Serializable

@Keep
data class BankCalendarEntry(
        val entries: List<BankCalendarDate>?
) : Serializable

@Keep
data class BankCalendarDate(
        val date: String?,
        val workingDay: Boolean?
) : Serializable

@Keep
data class ResponseResultPayload(val payload: ResponseResult) : Serializable

@Keep
data class ResponseResult(val Success: Boolean) : Serializable

@Keep
data class VersionUpdateEntity(
        val forceUpdate: ForceUpdate,
        val maintenance: Maintenance
) : Serializable

@Keep
data class ForceUpdate(
        val android: AppVersion
) : Serializable

@Keep
data class Maintenance(
        val android: AppMaintenance
) : Serializable

@Keep
data class AppVersion(
        val forceUpdateLink: String,
        val forceUpdateVersion: String,
        val forceUpdate: Int,
        val forceUpdateMessage: ForceUpdateMessage
) : Serializable

@Keep
data class AppMaintenance(
        val maintenance: Int,
        val maintenanceMessage: ForceUpdateMessage
) : Serializable

@Keep
data class ForceUpdateMessage(
        val en: String
) : Serializable

@Keep
data class ErrorBody(
        val status: String,
        val code: String,
        val errorText: String
) : Serializable

// {"pagination":{"currentPage":1,"limit":10}}
data class CreditnotesBean(var pagination: PaginationBean)

data class PaginationBean(var currentPage: Int, var limit: Int)
@Keep
data class CreditnotesEntity(
        val payload: CreditnotesPayload
)

@Keep
data class CreditNote(
        val payeeReference: String,
        val payeeCreditNoteReference: String,
        val payorReference: String,
        val payorCreditNoteReference: String,
        var amount: String,
        var outstanding: String,
        // save total available outstanding amount
        var originOutstanding: String? = null,
        val state: String,
        val status: String,
        val payeeAccount: PayeeAccount?,
        val payorAccount: PayorAccount?
) : Serializable

@Keep
data class CreditNoteLocal(
        var creditNote: CreditNote?,
        var token: String?,
        var outstanding: String?,
        var active: Boolean? = true,
        var selected: Boolean? = false
) : Serializable

@Keep
data class CreditnotesPayload(
        val creditNotes: List<CreditNote>?,
        val pagination: Pagination,
        val Tokens: List<String>
)

@Keep
data class CreditnotePayloadLocal(
        val creditNote: CreditNote,
        val creditnotePreference: String,
        val supplierOrBuyerName: String,
        val currency: String
) : Serializable

@Keep
data class PayeeAccount(
        val reference: String,
        val currency: String,
        val countryCode: String,
        val referenceGroup: String,
        val display: String
) : Serializable

@Keep
data class PayorAccount(
        val reference: String,
        val currency: String,
        val countryCode: String,
        val referenceGroup: String,
        val display: String
) : Serializable

@Keep
data class CountryISO(
        val name: String,
        val countryCode: String,
        val countryCodeISO3: String,
        val currency: String,
        val language: String
)

@Keep
data class InvoiceExtraLabels(
        val supplierAddress: SupplierAddressLabel,
        val buyerAddress: BuyerAddressLabel,
        val charges: ChargesLabel,
        val eway: EwayLabel,
        val gstn: GSTNLabel
)

@Keep
data class SupplierAddressLabel(
        val title: String,
        val addressPrefix: String,
        val noAddressLabel: String
)

@Keep
data class BuyerAddressLabel(
        val title: String,
        val addressPrefix: String,
        val noAddressLabel: String
)

@Keep
data class ChargesLabel(
        val title: String,
        val itemHeadingLabel: String,
        val amountHeadingLabel: String,
        val taxableValue: String,
        val cgst: String,
        val sgst: String,
        val igst: String,
        val totalHeadingLabel: String
)

@Keep
data class EwayLabel(
        val title: String,
        val heading: EwayHeading
)

@Keep
data class EwayHeading(
        val ewayBillNum: String,
        val ewayBillDate: String,
        val ewayVehicle: String,
        val ewayStatus: String
)

@Keep
data class GSTNLabel(
        val title: String,
        val heading: GSTNHeading
)

@Keep
data class GSTNHeading(
        val gstnUploadStatus: String,
        val gstnAck: String,
        val gstrStatus: String,
        val gstnReconciliation: String
)