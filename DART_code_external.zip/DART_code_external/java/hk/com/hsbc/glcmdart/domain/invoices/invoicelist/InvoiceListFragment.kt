/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.viewpager.widget.ViewPager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.fragment_invoices.view.*

/**
 * Created by Donut
 *
 * invoice page, switch from due invoice to all invoice
 */
class InvoiceListFragment: Fragment(){

    companion object {
        fun newInstance(): InvoiceListFragment {
            return InvoiceListFragment()
        }
    }

    private val todayFragment = InvoiceListDueTodayFragment.newInstance()
    private val totalFragment = InvoiceListTotalFragment.newInstance()
    private lateinit var invoicePager: ViewPager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.fragment_invoices, container, false)
        initViewAndData(rootView)
        return rootView
    }

    private fun initViewAndData(rootView: View) {
        val fragments: ArrayList<Fragment> = arrayListOf(todayFragment, totalFragment)
        val mAdapter = InvoiceListPagerAdapter(childFragmentManager, fragments)
        invoicePager = rootView.vp_invoice_pager.apply {
            adapter = mAdapter
            offscreenPageLimit = 2
            currentItem = 0
            addOnPageChangeListener(object: ViewPager.OnPageChangeListener{

                override fun onPageScrollStateChanged(p0: Int) {
                }

                override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {
                }

                override fun onPageSelected(index: Int) {
                    if (index == 1) {
                        TealiumUtil.eventTag("tab", "landing - invoices: all invoices")
                        todayFragment.endRefreshing()
                    } else {
                        TealiumUtil.eventTag("tab", "landing - invoices: invoices due")
                        totalFragment.endRefreshing()
                    }
                }

            })
        }
        rootView.tl_invoice_tab_container.apply {
            setupWithViewPager(invoicePager)
            removeAllTabs()
            addTab(newTab().apply {
                text = MemoryCache.getLabelText("s_invoices_due_today") ?: getString(R.string.s_invoices_due_today)

            })
            addTab(newTab().apply {
                text = MemoryCache.getLabelText("s_my_invoices") ?: getString(R.string.s_my_invoices)
            })
            getTabAt(0)?.select()
        }

//        val etChannelId = rootView.et_channelid_show.apply {
//            setEditText(UAirship.shared().pushManager.channelId)
//        }
    }

    fun changeSearchText(searchText: String?) {
        if (invoicePager.currentItem == 0) {
            todayFragment.onSearchTextChanged(searchText)
        } else {
            totalFragment.onSearchTextChanged(searchText)
        }
    }
}