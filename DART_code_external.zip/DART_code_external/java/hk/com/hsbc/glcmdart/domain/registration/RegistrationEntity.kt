/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import androidx.annotation.Keep
import java.io.Serializable

/**
 * Created by Donut on 2018/11/14.
 */
@Keep
data class RegistrationInvitationEntity(val payload: InvitationPayload) : Serializable
// for invitation/{invitation code}

@Keep
data class InvitationPayload(
        val error: String,
        val invitationStatus: String,
        val buyer: String?,
        val supplier: String?,
        val items: String?,
        val userType: String?,
        val countryCode: String?
) : Serializable

@Keep
data class ExpiredInvitationEntity(
        val payload: ExpiredInvitationPayload?
): Serializable

@Keep
data class ExpiredInvitationPayload(
        val response: ExpiredInvitationResponse,
        val loginUrl: String?
) : Serializable

@Keep
data class ExpiredInvitationResponse(
        val errorCode: String,
        val invitationCodeStatus: String?,
        val challengeQuestionStatus: String
) : Serializable

@Keep
data class RegistrationChallengeEntity(val payload: ChallengePayload): Serializable
//for invitation/{invitation code}/challenge

@Keep
data class ChallengePayload(
        val errorCode: String,
        val invitationCodeStatus: String,
        val challengeQuestionStatus: String,
        val countryCode: String,
        val customerID: String?,
        val payorID: String?,
        val emailAddress: String?,
        val companyTaxNumber: String?,
        val customerName: String?,
        val buyerUserName: String?,
        val buyerTitle: String?,
        val buyerFirstName: String?,
        val buyerLastName: String?,
        val buyerPaymentMethod: String?,
        val buyerAccountNumber: String?,
        val buyerIfscCode: String?,
        val buyerUrnNumber: String?,
        val maxAmount: String?,
        val amountCurrency: String?,
        val validityDate: String?,
        val buyerVirtualAddress: String?,
        val supplierTelNumber1: String?,
        val supplierTelNumber2: String?,
        val supplierEmailAddress: String?,
        val supplierSalesTitle: String?,
        val supplierSalesFirstName: String?,
        val supplierSalesLastName: String?,
        val supplierSalesEmailAddress: String?,
        val userType: String?,
        val ChallengeToken: String?
): Serializable

@Keep
data class RecoveryQuestionsEntity(val payload: RecoveryPayload) : Serializable
// for invitation/{invitation code}/account/recovery

@Keep
data class RecoveryPayload(val questions: List<Question>) : Serializable

@Keep
data class Question(
        var index: Int? = null,
        val id: String,
        val caption: String?,
        var answer: String? = null
) : Serializable

@Keep
data class UsernameValidationEntity(val payload: CheckAccountPayload) : Serializable
//for invitation/{invitation code}/account/check

@Keep
data class CheckAccountPayload(val available: Boolean?) : Serializable

@Keep
data class ProfileCreationEntity(val payload: CreatePayload) : Serializable
//for invitation/{invitation code}/account/create

@Keep
data class CreatePayload(
        val status: String?,
        val code: Int,
        val errorText: String?,
        val loginUrl: String?,
        val result: Boolean?
) : Serializable

@Keep
data class RequestSecurityQuestionEntity(
        var answer1: String,
        var answer2: String,
        var answer3: String
) : Serializable

@Keep
data class UsernameValidationBean(
        val username: String?,
        val password: String?
) : Serializable

@Keep
data class ProfileCreationBean(
    val invitationCode: String,
    val user: String,
    val password: String,
    val userDisplayName: String,
    val firstName: String,
    val lastName: String,
    val payorReference: String?,
    val payeeReference: String,
    val accounts: List<Any>,
    val mail: String,
    val email: String,
    val answers: List<Answer>
) : Serializable

@Keep
data class Answer(
    val index: Int,
    val id: String,
    val caption: String
) : Serializable