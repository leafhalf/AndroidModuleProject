package hk.com.hsbc.glcmdart.domain.invoices.invoicedetail

import android.annotation.SuppressLint
import android.util.SparseArray
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import io.reactivex.Observable
import io.reactivex.functions.Function3
import io.reactivex.schedulers.Schedulers

class InvoiceDetailViewModel: BaseViewModel() {

    val invoiceDetailLiveData = MutableLiveData<InvoiceDetailEntity>()
    val timelineLiveData = MutableLiveData<InvoiceDetailTimeLineEntity>()
    private val mModel by lazy { InvoiceDetailModel() }

    @SuppressLint("CheckResult")
    fun doRequest(token: String) {
        requestLoadingLiveData.postValue(true)
        Observable.zip(mModel.getInvoiceDetail(token).subscribeOn(Schedulers.io()),
                mModel.getInvoiceDetailTimeline(token).subscribeOn(Schedulers.io()),
                Observable.just(0),
                Function3<InvoiceDetailEntity, InvoiceDetailTimeLineEntity, Int, SparseArray<Any>> { t1, t2, t3 ->
                    val result = SparseArray<Any>()
                    result.put(0, t1)
                    val timelineList = t2.payload.notifications
                    val comparator: Comparator<Notification> = Comparator {o1, o2 ->
                        if (o1.createdAt == o2.createdAt) {
                            if (o1.type == o2.type) {
                                0
                            } else if (o1.type == "deduction.applied") {
                                -2
                            } else if (o1.type == "itp.status.creditnote") {
                                2
                            } else if (o1.type == "creditNote.applied") {
                                -1
                            } else {
                                3
                            }
                        } else {
                            val o1CreateAtSub = o1.createdAt!!.split(".")
                            val o2CreateAtSub = o2.createdAt!!.split(".")
                            if (o1CreateAtSub.size == 2 && o2CreateAtSub.size == 2) {
                                o1CreateAtSub[0].compareTo(o2CreateAtSub[0])
                            } else {
                                o1.createdAt.compareTo(o2.createdAt)
                            }
                        }
                    }
                    val sortedTimelineList = timelineList?.sortedWith(comparator)?.reversed()
                    val sortedTimeLineEntity = InvoiceDetailTimeLineEntity(TimeLinePayload(sortedTimelineList))
                    result.put(1, sortedTimeLineEntity)
                    result.put(2, t3)
                    result
                })
                .subscribe({
                    requestLoadingLiveData.postValue(false)
                    invoiceDetailLiveData.postValue(it[0] as InvoiceDetailEntity)
                    timelineLiveData.postValue(it[1] as InvoiceDetailTimeLineEntity)
                }, {
                    requestLoadingLiveData.postValue(false)
                    exceptionLiveData.postValue(it.message)
//                    Toast.makeText(DartApplication.instance, it.message, Toast.LENGTH_SHORT).show()
                })
    }
}