/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.view

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.*
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSelectableActivity
import hk.com.hsbc.glcmdart.domain.payments.AddNewInvoiceActivity
import hk.com.hsbc.glcmdart.domain.payments.adapter.PlannedPaymentInvoiceAdapter
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentDetailEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.domain.payments.view.ProvidePaymentInfoView.Companion.TYPE_PAYMENT_UPDATE
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import hk.com.hsbc.glcmdart.widget.SpacesItemDecoration
import kotlinx.android.synthetic.main.view_invoice_tobepaid_info.view.*
import java.lang.StringBuilder
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.abs

@SuppressLint("ViewConstructor")
class InvoiceTobePaidView(context: Context?, type: Int? = -1) : LinearLayout(context), RecyclerExtras.OnItemClickListener, RecyclerExtras.OnItemAddClickListener, RecyclerExtras.OnItemDeleteClickListener {

    private val itemList = ArrayList<InvoiceAddEntity>()
    private val mAdapter by lazy { context?.let { PlannedPaymentInvoiceAdapter(it, itemList) } }
    private var llPaymentState: View? = null
    private var llPaymentStateMiddle: View? = null
    private var btnStep: Button? = null
    private var tvAmount: TextView? = null
    private var tvAmountMiddle: TextView? = null
    private var tvCRAmount: TextView? = null
    private var tvDeductionAmount: TextView? = null
    private var tvPaymentDate: TextView? = null
    private val mCreditNotes = ArrayList<CreditNoteLocal>()
    private var isUpdate = false
    private var currency: String? = null
    private var isCreditNoteMethod = false
    private var isFullDeduction = false
    private var hasInvalidInvoice = false

    private var mDeductions: MutableMap<String, ArrayList<TaxDeductionInfo>?>? = null

    init {
        val mInflater = LayoutInflater.from(context)
        val view = mInflater.inflate(R.layout.view_invoice_tobepaid_info, this, false)
        addView(view)
        if (type == TYPE_PAYMENT_UPDATE)
            tv_title.visibility = View.GONE
        else {
            tv_title.visibility = View.VISIBLE
        }
        initEventAndData()
    }

    private fun initEventAndData() {
        rv_invoice_add_or_edit.isFocusableInTouchMode = false
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(context)
        rv_invoice_add_or_edit.addItemDecoration(SpacesItemDecoration(context as Activity, 2))
        mAdapter?.setOnItemClickListener(this)
        mAdapter?.setOnItemAddClickListener(this)
        mAdapter?.setOnItemDeleteClickListener(this)
        rv_invoice_add_or_edit.adapter = mAdapter

        MemoryCache.getLabelText("s_invoice_tobe_paid")?.let {
            if (!it.isBlank()) {
                tv_title.text = it
            }
        }
    }

    fun setMainPageWidget(llPaymentState: View?, llPaymentStateMiddle: View?, tvAmount: TextView?,
                          tvAmountMiddle: TextView?, btnStep: Button?, tvCRAmount: TextView?,
                          tvDeductionAmount: TextView?, tvPaymentDate: TextView?, currency: String?) {
        this.llPaymentState = llPaymentState
        this.llPaymentStateMiddle = llPaymentStateMiddle
        this.btnStep = btnStep
        this.tvAmount = tvAmount
        this.tvAmountMiddle = tvAmountMiddle
        this.tvDeductionAmount = tvDeductionAmount
        this.tvCRAmount = tvCRAmount
        this.tvPaymentDate = tvPaymentDate
        this.currency = currency
        mAdapter?.setCurrency(currency)
    }

    fun updateMainPageWidgetState() {
        this.llPaymentState?.visibility = View.GONE
        this.llPaymentStateMiddle?.visibility = View.VISIBLE
        this.tvPaymentDate?.visibility = View.INVISIBLE
    }

    fun setCreditNoteMethod(isCreditNote: Boolean) {
        isCreditNoteMethod = isCreditNote
    }

    fun setFullDeduction(isDeduction: Boolean) {
        isFullDeduction = isDeduction
    }

    fun setDeductions(deduction: MutableMap<String, ArrayList<TaxDeductionInfo>?>) {
        this.mDeductions = deduction
        MemoryCache.saveDeductionsMap(this.mDeductions as HashMap<String, ArrayList<TaxDeductionInfo>?>?)
    }

    fun setInvoiceListWithCreditNotes(paymentDetail: PaymentDetailEntity, creditNotesLocal: List<CreditNoteLocal>?) {
        isUpdate = true
        val invoices = paymentDetail.invoices
        this.mCreditNotes.clear()
        if (!creditNotesLocal.isNullOrEmpty()) {
            this.mCreditNotes.addAll(creditNotesLocal)
        }
        val linesInvoiceMap = mutableMapOf<String, Line>()
        val invoicesAdded = mutableListOf<InvoiceAddEntity>()
        val removedInvoiceSB = StringBuilder()
        var removedInvoiceCount = 0

        if (invoices != null) {
            for (i in invoices.indices) {
                val token = invoices[i].token

                // calculate credit note original available outstanding
                paymentDetail.itp?.lines?.forEach {
                    if (it.appliesTo == token && it.type == CREDITNOTE) {
                        for (item in mCreditNotes) {
                            if (item.token == it.token) {
                                item.creditNote?.originOutstanding = (-(abs(item.creditNote?.originOutstanding?.toLong()
                                        ?: 0L) +
                                        abs(it.amount?.amount?.toLong() ?: 0L))).toString()
                                item.outstanding = it.amount?.amount
                            }
                        }
                    }

                    // save line info for invoice type
                    if (it.type == INVOICE) {
                        linesInvoiceMap[it.token!!] = it
                    }
                }
            }

            for (invoice in invoices) {
                val creditNotesSelected = mutableListOf<CreditNoteLocal>()
                val creditNotesAvailable = mutableListOf<CreditNoteLocal>()
                val deductionSelected = mutableListOf<TaxDeductionInfo>()
                if (invoice.active != true) {
                    removedInvoiceCount++
                    removedInvoiceSB.append(invoice.invoice?.reference).append(",")
                }
                // no credit note set, then add empty list directly
//                if (creditNotesLocal.isNullOrEmpty()) {
//                    invoicesAdded.add(InvoiceAddEntity(invoice.token, invoice.invoice, linesInvoiceMap[invoice.token]?.amount?.amount
//                            ?: "", linesInvoiceMap[invoice.token]?.comment
//                            ?: "", creditNotesAvailable, creditNotesSelected as ArrayList<CreditNoteLocal>?,
//                            mDeductions?.get(invoice.token), null))
//                    continue
//                }

                mCreditNotes.forEach {
                    creditNotesAvailable.add(CreditNoteLocal(it.creditNote?.copy(), it.token, it.outstanding, it.active, it.selected))
                }

                paymentDetail.itp?.lines?.forEach { selectedCr ->
                    // calculate available credit note, use originOutstanding minus other lines
                    if (selectedCr.type == CREDITNOTE && selectedCr.appliesTo != invoice.token) {
                        // use origin outstanding amount minus selected credit notes
                        for (globalCr in creditNotesAvailable) {
                            if (globalCr.token == selectedCr.token) {
                                val amountText = (-(abs(globalCr.creditNote?.originOutstanding?.toLong()
                                        ?: 0L) - abs(if (selectedCr.amount?.amount.isNullOrBlank()) 0L else selectedCr.amount?.amount?.toLong()!!)
                                        )).toString()
                                globalCr.creditNote?.outstanding = amountText
                            }
                        }
                        //save selected credit note for current invoice
                    } else if (selectedCr.type == CREDITNOTE && selectedCr.appliesTo == invoice.token) {
                        for (globalCr in creditNotesAvailable) {
                            if (globalCr.token == selectedCr.token) {
                                globalCr.creditNote?.outstanding = (-(abs(globalCr.creditNote?.outstanding?.toLong() ?: 0L) +
                                        abs(selectedCr.amount?.amount?.toLong() ?: 0L))).toString()
                                globalCr.outstanding = selectedCr.amount?.amount
                                creditNotesSelected.add(globalCr)
                            }
                        }
                    } else if (selectedCr.type == DEDUCTION && selectedCr.appliesTo == invoice.token) {
                        val deductions =  paymentDetail.deductions?.get(selectedCr.appliesTo)
                        if (!deductions.isNullOrEmpty()) {
                            for (deduction in deductions) {
                                if (deduction.token == selectedCr.token) {
                                    deduction.actualAmount = (BigDecimal.valueOf(invoice.invoice?.summation?.total?.amount?.toDouble()
                                            ?: 0.0) *
                                            BigDecimal.valueOf(deduction.maxRate?.toDouble()
                                                    ?: 0.0) / BigDecimal.valueOf(100.0)).toLong().toString()
                                    deduction.selected = true
                                    deductionSelected.add(deduction)
                                    break
                                }
                            }
                        }
                    }
                }

                invoicesAdded.add(InvoiceAddEntity(invoice.token, invoice.invoice,
                        linesInvoiceMap[invoice.token]?.amount?.amount ?: "",
                        linesInvoiceMap[invoice.token]?.comment ?: "",
                        creditNotesAvailable.filter { it.creditNote?.outstanding?.toLong() ?: 0L < 0 },
                        creditNotesSelected as ArrayList<CreditNoteLocal>?,
                        taxDeductions = mDeductions?.get(invoice.token),
                        taxDeductionSelected = deductionSelected as ArrayList<TaxDeductionInfo>,
                        active=invoice.active)
                )
            }
        }

        if (removedInvoiceCount > 0) {
            ll_removed_invoice_container.visibility = View.VISIBLE
            var removedInvoiceTip = MemoryCache.getLabelText("s_removed_invoice_tip") ?:
                context.getString(R.string.s_removed_invoice_tip)
            if (removedInvoiceCount > 1) {
               removedInvoiceTip = removedInvoiceTip.replace("has", "have")
                       .replace("invoice", "invoices")
            }
            val removedInvoiceRefs = removedInvoiceSB.toString().substring(0, removedInvoiceSB.length - 1)
            val removedTipText = String.format(removedInvoiceTip, removedInvoiceRefs)
            tv_removed_invoice_tip.text = removedTipText
            hasInvalidInvoice = true
        } else {
            ll_removed_invoice_container.visibility = View.GONE
            hasInvalidInvoice = false
        }
        mAdapter?.addData(invoicesAdded as ArrayList<InvoiceAddEntity>)
    }

    fun setInvoicesAndCreditNotes(invoices: List<InvoiceListItem>, creditNotes: List<CreditNoteLocal>?) {
        this.mCreditNotes.clear()
        val removedInvoiceSB = StringBuilder()
        var removedInvoiceCount = 0
        if (!creditNotes.isNullOrEmpty()) {
            TealiumUtil.pageTag(
                    "dart : buyer portal : payments : confirm planned payment - invoice details with credit note",
                    "/dart/buyer portal/payments/confirm planned payment-invoice details with credit note",
                    "transaction",
                    "buyer portal",
                    "payments",
                    "mobile",
                    "en",
                    " create planned payment",
                    "2",
                    " create planned payment - invoice details with credit note"
            )
            for (item in creditNotes) {
                if (item.creditNote?.payeeAccount?.currency == currency) {
                    val creditNoteCopy = CreditNoteLocal(item.creditNote?.copy(), item.token, item.outstanding)
                    mCreditNotes.add(creditNoteCopy)
                }
            }
        } else {
            TealiumUtil.pageTag(
                    "dart : buyer portal : payments : confirm planned payment - invoice details",
                    "/dart/buyer portal/payments/confirm planned payment-invoice details",
                    "transaction",
                    "buyer portal",
                    "payments",
                    "mobile",
                    "en",
                    " create planned payment",
                    "2",
                    " create planned payment - invoice details"
            )
        }
        val invoicesAdd = mutableListOf<InvoiceAddEntity>()
        for (item in invoices) {
            if (item.active != true) {
                removedInvoiceCount++
                removedInvoiceSB.append(item.invoice?.reference).append(",")
            }
            invoicesAdd.add(InvoiceAddEntity(item.token, item.invoice, item.invoice?.summation?.outstanding?.amount,
                    "", mCreditNotes.filter { it.creditNote?.outstanding?.toLong() ?: 0L < 0 },
                    null, mDeductions?.get(item.token), null, active = item.active))
        }
        if (removedInvoiceCount > 0) {
            ll_removed_invoice_container.visibility = View.VISIBLE
            var removedInvoiceTip = MemoryCache.getLabelText("s_removed_invoice_tip") ?:
            context.getString(R.string.s_removed_invoice_tip)
            if (removedInvoiceCount > 1) {
                removedInvoiceTip = removedInvoiceTip.replace("has", "have")
                        .replace("invoice", "invoices")
            }
            val removedInvoiceRefs = removedInvoiceSB.toString().substring(0, removedInvoiceSB.length - 1)
            val removedTipText = String.format(removedInvoiceTip, removedInvoiceRefs)
            tv_removed_invoice_tip.text = removedTipText
            hasInvalidInvoice = true
        } else {
            ll_removed_invoice_container.visibility = View.GONE
            hasInvalidInvoice = false
        }
        mAdapter?.addData(invoicesAdd as ArrayList<InvoiceAddEntity>)
        updatePayAmout()
    }

    override fun onItemClick(view: View, position: Int) {
        // removed invoice can not be revised
        if (itemList[position].active != true) {
            return
        }

        if (isUpdate) {
            TealiumUtil.eventTag("onsite", "planned payments - update invoice info: invoice selected")
        } else {
            if (itemList.size > position && itemList[position].creditNotesSelected != null) {
                TealiumUtil.eventTag("button click", "confirm planned payment - invoice details with credit note: view invoice")
            } else {
                TealiumUtil.eventTag("button click", "confirm planned payment - invoice details: view invoice")
            }
        }
        //init available credit note
        for (globalCr in mCreditNotes) {
            globalCr.creditNote?.outstanding = globalCr.creditNote?.originOutstanding ?: "0"
        }

        if (itemList.size > 0) {
            // scan all invoice items
            for (invoiceItem in itemList) {
                // exclude current item
                if (invoiceItem.token == itemList[position].token) continue
                invoiceItem.creditNotesSelected?.forEach { selectedCr ->
                    // use origin outstanding amount minus selected credit notes
                    for (globalCr in mCreditNotes) {
                        if (globalCr.token == selectedCr.token) {
                            if (globalCr.creditNote?.originOutstanding == globalCr.creditNote?.outstanding) {
                                val amountText = (-(abs(globalCr.creditNote?.originOutstanding?.toLong()
                                        ?: 0L) - abs(if (selectedCr.outstanding.isNullOrBlank()) 0L else selectedCr.outstanding?.toLong()!!)
                                        )).toString()
                                globalCr.creditNote?.outstanding = amountText
                            } else {
                                val amountText = (-(abs(globalCr.creditNote?.outstanding?.toLong()
                                        ?: 0L) - abs(if (selectedCr.outstanding.isNullOrBlank()) 0L else selectedCr.outstanding?.toLong()!!)
                                        )).toString()
                                globalCr.creditNote?.outstanding = amountText
                            }
                        }
                    }
                }
            }
        }

        AddNewInvoiceActivity.showActivity2(context as Activity, itemList,
                // filter available credit note with outstanding amount is negative
                mCreditNotes.filter { (it.creditNote?.outstanding?.toLong() ?: 0) < 0 },
                arrayListOf(itemList[position]),
                currency, REQUEST_CODE_INVOICE_EDIT_DETAIL, isCreditNoteMethod)
    }

    override fun onItemAddClick(view: View, position: Int) {
        if (isUpdate) {
            TealiumUtil.eventTag("button click", "planned payments - update invoice info: add new invoice")
        } else {
            if (itemList.size > position && itemList[position].creditNotesSelected != null) {
                TealiumUtil.eventTag("button click", "confirm planned payment - invoice details with credit note: add new invoice")
            } else {
                TealiumUtil.eventTag("button click", "confirm planned payment - invoice details: add new invoice")
            }
        }
        val intent = Intent(context, InvoiceListSelectableActivity::class.java).apply {
            val availableCreditNotes = mutableListOf<CreditNoteLocal>()
            mCreditNotes.forEach {
                availableCreditNotes.add(CreditNoteLocal(it.creditNote?.copy(), it.token, it.outstanding, it.active, it.selected))
            }

            for (globalCr in availableCreditNotes) {
                globalCr.creditNote?.outstanding = globalCr.creditNote?.originOutstanding ?: "0"
            }

            if (itemList.size > 0) {
                // scan all invoice items
                for (invoiceItem in itemList) {
                    invoiceItem.creditNotesSelected?.forEach { selectedCr ->
                        // use origin outstanding amount minus selected credit notes
                        for (globalCr in availableCreditNotes) {
                            if (globalCr.token == selectedCr.token) {
                                if (globalCr.creditNote?.originOutstanding == globalCr.creditNote?.outstanding) {
                                    val amountText = (-(abs(globalCr.creditNote?.originOutstanding?.toLong()
                                            ?: 0L) - abs(if (selectedCr.outstanding.isNullOrBlank()) 0L else selectedCr.outstanding?.toLong()!!)
                                            )).toString()
                                    globalCr.creditNote?.outstanding = amountText
                                } else {
                                    val amountText = (-(abs(globalCr.creditNote?.outstanding?.toLong()
                                            ?: 0L) - abs(if (selectedCr.outstanding.isNullOrBlank()) 0L else selectedCr.outstanding?.toLong()!!)
                                            )).toString()
                                    globalCr.creditNote?.outstanding = amountText
                                }
                            }
                        }
                    }
                }
            }
            putExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE, availableCreditNotes as ArrayList)
            val invoicesAdded = ArrayList<InvoiceAddEntity>()
            for (item in itemList) {
                val invoiceAdd = InvoiceAddEntity(item.token, item.invoice?.copy(), item.amount, item.comment, item.creditNotes,
                        null, mDeductions?.get(item.token), null)
                invoicesAdded.add(invoiceAdd)
            }
            putExtra(TAG_REQUEST_INTENT_DATA_INVOICE, invoicesAdded)
            putExtra(TAG_REQUEST_INTENT_DATA_INVOICE_CURRENCY, currency)
            putExtra(TAG_REQUEST_INTENT_IS_CREDIT_NOTE_METHOD, isCreditNoteMethod)
        }
        (context as Activity).startActivityForResult(intent, REQUEST_CODE_SELECT_INVOICE)
    }

    override fun onItemDeleteClick(view: View, position: Int) {
        if (isUpdate) {
            TealiumUtil.eventTag("button click", "planned payments - update invoice info: remove invoice")
        } else {
            if (itemList.size > position && itemList[position].creditNotesSelected != null) {
                TealiumUtil.eventTag("button click", "confirm planned payment - invoice details with credit note: remove invoice")
            } else {
                TealiumUtil.eventTag("button click", "confirm planned payment - invoice details: delete invoice")
            }
        }
        CommonDialog.showAlertDialog(context, MemoryCache.getLabelText("s_remove_invoice_title")
                ?: context.getString(R.string.s_remove_invoice_title),
                MemoryCache.getLabelText("s_remove_invoice")
                        ?: context.getString(R.string.s_remove_invoice),
                MemoryCache.getLabelText("s_delete")
                        ?: context.getString(R.string.s_delete), object : CommonDialogExtras.OnButtonListener {
            override fun positiveButtonListener() {
                TealiumUtil.eventTag("button click", "invoice delete confirmation overlay: delete")
                itemList.removeAt(position)
                mAdapter?.notifyDataSetChanged()
                hasInvalidInvoice = false
                for (item in itemList) {
                    if (item.active != true) {
                        hasInvalidInvoice = true
                        break
                    }
                }
                setNextButtonState()
            }

            override fun negativeButtonListener() {
                TealiumUtil.eventTag("button click", "invoice delete confirmation overlay: cancel")
            }
        }, MemoryCache.getLabelText("s_cancel") ?: context.getString(R.string.s_cancel))
        TealiumUtil.pageTag("dart : buyer portal : invoices : invoice delete confirmation",
                "/dart/buyer portal/invoices/invoice delete confirmation",
                "transaction",
                "buyer portal",
                "invoices")
    }

    fun getCurrentViewData(): Map<String, Any> {
        val dataMap = mutableMapOf<String, Any>()
        var fullPaidAmount = 0L
        var hasCreditNote = false
        dataMap["isFullDeduction"] = false
        //lines
        val lines = mutableListOf<Line>()
        for (item in itemList) {
            val amount = Amount(item.amount, currency)
            val line = Line(INVOICE, item.token, amount, item.comment, null, null)
            lines.add(line)
            item.creditNotesSelected?.forEach {
                val creditNoteAmount = Amount((0 - abs(it.outstanding?.toLong()
                        ?: 0L)).toString(), currency)
                val creditNoteLine = Line(CREDITNOTE, it.token, creditNoteAmount, "",  null, item.token)
                lines.add(creditNoteLine)
                hasCreditNote = true
            }
            item.taxDeductionSelected?.forEach {
                val deductionAmount = Amount(it.actualAmount?.split(".")?.get(0), currency)
                val deductionLine = Line(DEDUCTION, it.token, deductionAmount, "", null, item.token)
                lines.add(deductionLine)
            }
            fullPaidAmount += item.amount?.toLong() ?: 0L
        }

        if (fullPaidAmount == 0L && !hasCreditNote) {
            dataMap["isFullDeduction"] = true
        }

        dataMap["lines"] = lines
        return dataMap
    }

    fun getCurrentViewDataDisplay(): Map<String, Any> {
        val dataMap = mutableMapOf<String, Any>()
        dataMap["invoices"] = itemList
        return dataMap
    }

    fun checkInputData(): Boolean {
        if (itemList.size <= 0)
            return false
        for (i in itemList.indices) {
            val itemAmountInput = if (TextUtils.isEmpty(itemList[i].amount)) {
                0L
            } else {
                itemList[i].amount?.toLong() ?: 0L
            }
            if (itemAmountInput == 0L && itemList[i].creditNotesSelected.isNullOrEmpty() &&
                    itemList[i].taxDeductionSelected.isNullOrEmpty())
                return false
        }
        return true
    }

    fun onActivityResult(data: Intent?) {
        ll_amount_validate_container.visibility = View.GONE
        val invoices = data?.getSerializableExtra(TAG_REQUEST_RESULT_INVOICE) as List<InvoiceAddEntity>
        var deductionAmount = 0.0
        val deleteFlag = data.getBooleanExtra(TAG_DELETE_INVOICE, false)
        for (item in invoices) {
            if (!item.taxDeductionSelected.isNullOrEmpty()) {
                for (deduction in item.taxDeductionSelected!!) {
                    deductionAmount += deduction.actualAmount!!.toBigDecimal().setScale(2, RoundingMode.HALF_UP).toDouble()
                }
            }
            for (listItem in itemList) {
                if (item.token == listItem.token) {
                    listItem.creditNotesSelected = item.creditNotesSelected
                    break
                }
            }
        }
        for (invoice in invoices) {
            for (i in itemList.indices) {
                if (itemList[i].token == invoice.token) {
                    itemList.removeAt(i)
                    itemList.add(i, invoice)
                }
            }
        }
        for (invoice in invoices) {
            if (!itemList.contains(invoice)) {
                itemList.add(invoice)
            }
        }
        updatePayAmout()

        if (deleteFlag) {
            itemList.remove(invoices[0])
        }

        hasInvalidInvoice = false
        for (item in itemList) {
            if (item.active != true) {
                hasInvalidInvoice = true
            }

            //init available credit note
            for (globalCr in mCreditNotes) {
                globalCr.creditNote?.outstanding = globalCr.creditNote?.originOutstanding ?: "0"
            }

            if (itemList.size > 0) {
                // scan all invoice items
                for (invoiceItem in itemList) {
                    // exclude current item
                    if (invoiceItem.token == item.token) continue
                    invoiceItem.creditNotesSelected?.forEach { selectedCr ->
                        // use origin outstanding amount minus selected credit notes
                        for (globalCr in mCreditNotes) {
                            if (globalCr.token == selectedCr.token) {
                                val amountText = (-(abs(globalCr.creditNote?.originOutstanding?.toLong()
                                        ?: 0L) - abs(if (selectedCr.outstanding.isNullOrBlank()) 0L else selectedCr.outstanding?.toLong()!!)
                                        )).toString()
                                globalCr.creditNote?.outstanding = amountText
                            }
                        }
                    }
                }
            }

            item.creditNotes = mCreditNotes.filter { it.creditNote?.outstanding?.toLong() ?: 0L < 0 }
        }

        val deductionAmountText = "$currency -${IndiaNumberUtil.formatNumByDecimal(deductionAmount.toString(),
                currency ?: MARKET_CURRENCY)}"
        if (deductionAmount != 0.0) {
            tvDeductionAmount?.text = "${
                MemoryCache.getLabelText("s_deduction_amount") ?: context.getString(R.string.s_deduction_amount)
            }: $deductionAmountText"
            tvDeductionAmount?.visibility = View.VISIBLE
        } else {
            tvDeductionAmount?.visibility = View.GONE
        }
        mAdapter?.notifyDataSetChanged()
        setNextButtonState()
    }

    @SuppressLint("SetTextI18n")
    private fun updatePayAmout() {
        var amountTotal: Long = 0
        var crAmountTotal: Long = 0
        for (item in itemList) {
            if (!TextUtils.isEmpty(item.amount))
                amountTotal += item.amount?.toLong() ?: 0L
            val creditNotesSelected = item.creditNotesSelected
            if (creditNotesSelected != null) {
                for (creditNote in creditNotesSelected) {
                    if (!creditNote.outstanding.isNullOrEmpty())
                        crAmountTotal += creditNote.outstanding?.toLong() ?: 0L
                }
            }
        }

        if (tvAmount != null) {
            val tmpText = "$currency " + IndiaNumberUtil.formatNumByDecimal(amountTotal.toString(), currency
                    ?: MARKET_CURRENCY)
            tvAmount?.text = tmpText
            tvAmountMiddle?.text = tmpText
        }
        if (tvCRAmount != null) {
            val tmpText = IndiaNumberUtil.formatNumByDecimal(crAmountTotal.toString(), currency
                    ?: MARKET_CURRENCY)
            tvCRAmount?.text = "${MemoryCache.getLabelText("s_cr_note_amount") ?: context.getString(R.string.s_cr_note_amount)}: " +
                    "$currency ${if (crAmountTotal == 0L) "" else "-"}$tmpText"
        }
    }

    fun setNextButtonState() {
        if (this.btnStep != null) {
            this.btnStep?.isEnabled = checkInputData()
        }

        if (hasInvalidInvoice) {
            this.btnStep?.isEnabled = false
            val removedInvoiceSB = StringBuilder()
            var removedInvoiceCount = 0
            for (item in itemList) {
                if (item.active != true) {
                    removedInvoiceCount++
                    removedInvoiceSB.append(item.invoice?.reference).append(",")
                }
            }
            if (removedInvoiceCount > 0) {
                ll_removed_invoice_container.visibility = View.VISIBLE
                var removedInvoiceTip = MemoryCache.getLabelText("s_removed_invoice_tip") ?:
                context.getString(R.string.s_removed_invoice_tip)
                if (removedInvoiceCount > 1) {
                    removedInvoiceTip = removedInvoiceTip.replace("has", "have")
                            .replace("invoice", "invoices")
                }
                val removedInvoiceRefs = removedInvoiceSB.toString().substring(0, removedInvoiceSB.length - 1)
                val removedTipText = String.format(removedInvoiceTip, removedInvoiceRefs)
                tv_removed_invoice_tip.text = removedTipText
                hasInvalidInvoice = true
            } else {
                ll_removed_invoice_container.visibility = View.GONE
                hasInvalidInvoice = false
            }
        } else {
            ll_removed_invoice_container.visibility = View.GONE
        }

        var totalAmountToPay = 0L
        for (i in itemList.indices) {
            val itemAmountInput = if (TextUtils.isEmpty(itemList[i].amount)) {
                0L
            } else {
                itemList[i].amount?.toLong() ?: 0L
            }
            totalAmountToPay += itemAmountInput
        }
        // from credit note or deduction to other method
        if (isCreditNoteMethod || isFullDeduction) {
            if (totalAmountToPay != 0L) {
                this.btnStep?.text = MemoryCache.getLabelText("s_next") ?: context.getString(R.string.s_next)
                this.btnStep?.isEnabled = true
            } else {
                this.btnStep?.text = MemoryCache.getLabelText("s_update") ?: context.getString(R.string.s_update)
            }
        } else {
            // prevent other method to credit note or deduction
            if (isUpdate) {
                if (totalAmountToPay == 0L) {
                    this.btnStep?.isEnabled = false
                    tv_amount_validate.text = MemoryCache.getLabelText("s_invalid_amount_tip") ?:
                            context.getString(R.string.s_invalid_amount_tip)
                    ll_amount_validate_container.visibility = View.VISIBLE
                }
            }
        }
    }
}