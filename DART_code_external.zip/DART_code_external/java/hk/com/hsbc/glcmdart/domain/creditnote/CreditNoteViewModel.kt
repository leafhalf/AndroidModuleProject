package hk.com.hsbc.glcmdart.domain.creditnote

import android.annotation.SuppressLint
import android.text.TextUtils
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import hk.com.hsbc.glcmdart.domain.dart.CreditnotePayloadLocal
import hk.com.hsbc.glcmdart.domain.dart.PaginationBean
import hk.com.hsbc.glcmdart.domain.payments.presenter.PaymentBaseViewModel
import hk.com.hsbc.glcmdart.util.MemoryCache
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class CreditNoteViewModel : PaymentBaseViewModel() {

    val creditNoteLiveData = MutableLiveData<MutableList<CreditnotePayloadLocal>>()
    val requestFailLiveData = MutableLiveData<String?>()

    @SuppressLint("CheckResult")
    fun doRequest(payorOrPayee: String?, payeeCreditNoteReference: String?, currencies: List<String>?) {
        val dataMap = mutableMapOf<String, Any>()
        dataMap["pagination"] = PaginationBean(currentPage = 1, limit = Int.MAX_VALUE)
        if (TextUtils.isEmpty(payorOrPayee).not()) {
            if ("S" == MemoryCache.getSessionEntity()?.type) {
                if ((MemoryCache.getLabelText("s_all") ?: "All") == payorOrPayee) {
                    dataMap["payorReference"] = ""
                } else {
                    dataMap["payorReference"] = payorOrPayee ?: ""
                }
            } else {
                if ((MemoryCache.getLabelText("s_all") ?: "All") == payorOrPayee) {
                    dataMap["payeeReference"] = ""
                } else {
                    dataMap["payeeReference"] = payorOrPayee ?: ""
                }
            }
        }
        dataMap["payeeCreditNoteReference"] = payeeCreditNoteReference ?: ""
        if (!currencies.isNullOrEmpty())
            dataMap["currencies"] = currencies
        paymentsModel.requestCreditNotes(Gson().toJson(dataMap))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    val creditnotePayloadLocals = mutableListOf<CreditnotePayloadLocal>()
                    val organizationsMap = MemoryCache.getOrganisationsMap()
                    val supplierOrBuyer = ("S" == MemoryCache.getSessionEntity()?.type)
                    if (!it.payload.creditNotes.isNullOrEmpty() && organizationsMap.isNotEmpty()) {
                        for (item in it.payload.creditNotes) {
                            if (item.outstanding.toLong() > 0) {
                                continue
                            }
                            if (supplierOrBuyer) {
                                if (organizationsMap.contains(item.payorReference)) {
                                    val creditnote = organizationsMap[item.payorReference]?.name?.let { it1 -> item.payorAccount?.currency?.let { it2 -> CreditnotePayloadLocal(item, item.payorCreditNoteReference, it1, it2) } }
                                    creditnote?.let { it1 -> creditnotePayloadLocals.add(it1) }
                                }
                            } else {
                                if (organizationsMap.contains(item.payeeReference)) {
                                    val creditnote = organizationsMap[item.payeeReference]?.name?.let { it1 -> item.payeeAccount?.currency?.let { it2 -> CreditnotePayloadLocal(item, item.payeeCreditNoteReference, it1, it2) } }
                                    creditnote?.let { it1 -> creditnotePayloadLocals.add(it1) }
                                }
                            }
                        }
                    }
                     creditNoteLiveData.postValue(creditnotePayloadLocals)
                }, {
                    requestFailLiveData.postValue(it.message)
                })
    }

}