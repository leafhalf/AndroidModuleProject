/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dart

import android.app.Activity
import android.app.AlarmManager
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.google.gson.Gson
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.login.NetworkDialog
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.*
import hk.com.hsbc.glcmdart.util.ApplicationManager.ACTIVITY_COUNT
import io.reactivex.*
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import no.promon.shield.callbacks.*
import okhttp3.Interceptor
import okhttp3.Response
import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Handle the global network response
 */
class DartInterceptor : Interceptor {

    override fun intercept(chain: Interceptor.Chain?): Response? {
        var request = chain?.request()
        val url = request?.toString()
        val topActivity = ApplicationManager.getTopActivity()
        // -1 No network, show the no network dialog
        url?.also {
            if (!(it.contains(VERSION_UPDATE))) {
                if (!ConnectivityUtil.isConnected()) {
                    topActivity?.runOnUiThread {
                        val dialog = NetworkDialog(topActivity)
                        dialog.setCancelable(false)
                        dialog.setCanceledOnTouchOutside(false)
                        dialog.show()
                    }
                }
            }
        }
        // Add auth
        val token = MemoryCache.getI8Token()
        if (!token.isNullOrEmpty()) {
            request = request?.newBuilder()
                    ?.addHeader("Authorization", "Bearer $token")
                    ?.build()
        }
        // Proceed request
        val response: Response?
        try {
            response = chain?.proceed(request)
        } catch (e: Exception) {
            // Certificate pinning failed
            if (e.message?.contains("Certificate pinning failure!") == true) {
                Handler(Looper.getMainLooper()).post {
                    val context = ApplicationManager.getContext()
                    context.startActivity(IntentUtil.getBrowser(GOOGLE_PLAY_DART))
                }
            }
            // Hostname verifying failed
            throw e
        }
        // 302, start the session expired dialog
        url?.let {
            if (!(it.contains(VERSION_UPDATE))) {
                response?.code()?.also { code ->
                    if (code == 302 || ((!it.contains(URL_LOGIN) && !it.contains(URL_FORGET_PASSWORD_RESET)) && code == 401)) {
                        if (code == 302 && (it.contains(URL_PROFILE) || it.contains(URL_PROFILE_DETAIL) || it.contains(URL_ORGANISATIONS)))
                            return@also
                        topActivity?.also { activity ->
                            if (activity is BaseActivity) {
                                activity.showSessionExpiredDialog()
                            }
                        }
                    }
                }
            }
        }
        return response
    }
}

/**
 * The Certificate
 */
object DartCertificate {

    fun getPublicKeys(context: Context): MutableMap<String, String>? {
        var json: String? = null
        var inputStream: InputStream? = null
        var outputStream: ByteArrayOutputStream? = null
        try {
            inputStream = context.assets.open(("abc.json"))
            outputStream = ByteArrayOutputStream()
            inputStream.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }
            val byteArray = outputStream.toByteArray()
            json = String(byteArray, Charsets.UTF_8)
        } catch (e: Exception) {
            // e.printStackTrace()
        } finally {
            try {
                inputStream?.close()
            } catch (e: Exception) {
                // e.printStackTrace()
            }
            try {
                outputStream?.close()
            } catch (e: Exception) {
                // e.printStackTrace()
            }
        }
        json?.let {
            val map = Gson().fromJson<MutableMap<String, String>>(json, MutableMap::class.java)
            val newMap = mutableMapOf<String, String>()
            map?.forEach {
                newMap[getHostname(it.key)] = it.value
            }
            if (newMap.isNotEmpty()) {
                return newMap
            }
        }
        return null
    }

    fun getHostname(key: String): String {
        return when (key) {
            "s1" -> "dart${BuildConfig.HOSTNAME}.gbm.hsbc.com"
            "s2" -> "www.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com"
            "s3" -> "consent.dart${BuildConfig.HOSTNAME}.gbm.hsbc.com"
            else -> ""
        }
    }
}

class CrashedHandler constructor(val context: Context): Thread.UncaughtExceptionHandler {

    override fun uncaughtException(t: Thread?, e: Throwable?) {
        // e?.printStackTrace()

        val msg = if (e?.message == null) "The application crashed with unknown reason!" else e.message
        val intent = Intent()
        intent.setClass(context, CrashedActivity::class.java)
        intent.putExtra("msg", msg)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
        val activity = PendingIntent.getActivity(context, 192837, intent, PendingIntent.FLAG_ONE_SHOT)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000, activity)

        ApplicationManager.exitApplication()
    }
}

class RequestObservable<Entity> constructor(val action: () -> retrofit2.Response<Entity>): ObservableOnSubscribe<Entity> {

    override fun subscribe(emitter: ObservableEmitter<Entity>) {
        try {
            if (!emitter.isDisposed) {
                val response = action()
                val entity = response.body()
                if (entity != null) {
                    emitter.onNext(entity)
                } else {
                    emitter.onError(Exception("Unknown error!"))
                }
            }
        } catch (e: Exception) {
            emitter.onError(e)
        }
        emitter.onComplete()
    }
}

class SchedulerTransformer<T>: ObservableTransformer<T, T> {

    override fun apply(upstream: Observable<T>): ObservableSource<T> {
        return upstream.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
    }
}

val ACTIVITY_CALLBACK =  object : Application.ActivityLifecycleCallbacks {

    override fun onActivityPaused(activity: Activity?) {
//        activity?.also {
//            Logger.i("${it::class.java.simpleName}: paused")
//        }
    }

    override fun onActivityResumed(activity: Activity?) {
//        activity?.also {
//            Logger.i("${it::class.java.simpleName}resumed")
//        }
    }

    override fun onActivityStarted(activity: Activity?) {
//        activity?.also {
//            Logger.i("${it::class.java.simpleName}started")
//        }
        ACTIVITY_COUNT.incrementAndGet()
        APPLICATION_CALLBACK.run()
    }

    override fun onActivityDestroyed(activity: Activity?) {
//        activity?.also {
//            Logger.i("${it::class.java.simpleName}destroyed")
//        }
        activity?.also {
            ApplicationManager.removeActivity(it)
        }
    }

    override fun onActivitySaveInstanceState(activity: Activity?, outState: Bundle?) {

    }

    override fun onActivityStopped(activity: Activity?) {
//        activity?.also {
//            Logger.i("${it::class.java.simpleName}stopped")
//        }
        ACTIVITY_COUNT.decrementAndGet()
        APPLICATION_CALLBACK.run()
    }

    override fun onActivityCreated(activity: Activity?, savedInstanceState: Bundle?) {
//        activity?.also {
//            Logger.i("${it::class.java.simpleName}created")
//        }
        activity?.also {
            ApplicationManager.addActivity(it)
        }
    }
}

val APPLICATION_CALLBACK = Runnable {
    val flag = ApplicationManager.isApplicationBackground
    val topActivity = ApplicationManager.getTopActivity()
//    Logger.i("DART application is background: $flag")
    topActivity?.also {
        if (it is BaseActivity) {
            // it.handleCachedScreen(flag)
        }
    }
}

val EXTENDED_OBSERVER = ExtendedObserver { callback ->
    ApplicationManager.getAllActivities().forEach { activity ->
        if (activity is ExtendedObserver) {
            activity.handleCallback(callback)
        }
    }
    when (callback.callbackType) {
        CallbackType.FILESYSTEM_SCANNING -> {
            val data = callback as FilesystemScanningData
            val flag = data.isSuspiciousFileDetected
//            Logger.d("FILESYSTEM_SCANNING=$flag")
            MemoryCache.save(MemoryCache.FILESYSTEM_SCANNING, flag)
        }
        CallbackType.FILESYSTEM_WATCHING -> {
            val data = callback as FilesystemWatchingData
            val flag = data.isSuidOrSgidDetected or data.isSuDetected
//            Logger.d("FILESYSTEM_WATCHING=$flag")
            MemoryCache.save(MemoryCache.FILESYSTEM_WATCHING, flag)
        }
        CallbackType.ROOTING -> {
            val data = callback as RootingData
            val flag = data.isDeviceCertainlyRooted
//            Logger.d("ROOTING=$flag")
            MemoryCache.save(MemoryCache.ROOTING, flag)
            RASPUtil.handleRooting()
        }
        CallbackType.REPACKAGING -> {
            val data = callback as RepackagingData
            val flag = data.isRepackaged
//            Logger.d("REPACKAGING=$flag")
            MemoryCache.save(MemoryCache.REPACKAGING, flag)
            RASPUtil.handleRepackaging()
        }
        CallbackType.DEBUGGER -> {
            val data = callback as DebuggerData
            val flag = data.isRunningUnderDebugger
//            Logger.d("DEBUGGER=$flag")
            MemoryCache.save(MemoryCache.DEBUGGER, flag)
            RASPUtil.handleDebugger()
        }
        CallbackType.EMULATOR -> {
            val data = callback as EmulatorData
            val flag = data.isRunningOnEmulator
//            Logger.d("EMULATOR=$flag")
            MemoryCache.save(MemoryCache.EMULATOR, flag)
            RASPUtil.handleEmulator()
        }
        CallbackType.KEYBOARD -> {
            val data = callback as KeyboardData
            val flag = data.isKeyboardUntrusted
//            Logger.d("KEYBOARD=$flag")
            MemoryCache.save(MemoryCache.KEYBOARD, flag)
        }
        CallbackType.SCREENREADER -> {
            val topActivity = ApplicationManager.getTopActivity()
            val data = callback as ScreenreaderData
            val flag = data.isUntrustedScreenreaderPresent
//            Logger.d("SCREENREADER=$flag")
            topActivity?.also {
                if (it is BaseActivity) {
                     if (it.isScreenCaptureAbility()) {
                         if (flag) {
                             MemoryCache.save(MemoryCache.PRE_SCREENREADER, (MemoryCache.get(MemoryCache.SCREENREADER) as Boolean?) ?: false)
                             MemoryCache.save(MemoryCache.SCREENREADER, flag)
                             RASPUtil.handleScreenCapture()
                         }
                     }
                }
            }
        }
        CallbackType.HOOKING_FRAMEWORKS -> {
            val data = callback as HookingFrameworksData
            val flag = data.areHookingFrameworksPresent()
//            Logger.d("HOOKING_FRAMEWORKS=$flag")
            MemoryCache.save(MemoryCache.HOOKING_FRAMEWORKS, flag)
            RASPUtil.handleLibraryInjection()
        }
        CallbackType.NATIVE_CODE_HOOKS -> {
            val data = callback as NativeCodeHooksData
            val flag = data.areNativeCodeHooksPresent()
//            Logger.d("NATIVE_CODE_HOOKS=$flag")
            MemoryCache.save(MemoryCache.NATIVE_CODE_HOOKS, flag)
            RASPUtil.handleLibraryInjection()
        }
        CallbackType.FOREGROUND_OVERRIDE -> {
            val data = callback as ForegroundOverrideData
            val flag = data.overridingApp
//            Logger.d("FOREGROUND_OVERRIDE=$flag")
            MemoryCache.save(MemoryCache.FOREGROUND_OVERRIDE, flag)
        }
        CallbackType.SCREEN_MIRRORING -> {
            val data = callback as ScreenMirroringData
            val flag = data.isScreenMirroringDetected
//            Logger.d("SCREEN_MIRRORING=$flag")
            MemoryCache.save(MemoryCache.SCREEN_MIRRORING, flag)
        }
        else -> {
            //do something
        }
    }
}