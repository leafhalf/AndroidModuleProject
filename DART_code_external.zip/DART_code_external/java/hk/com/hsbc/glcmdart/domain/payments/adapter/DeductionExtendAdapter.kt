package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.content.Context
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil

class DeductionExtendAdapter(private val context: Context, private val dataList: List<TaxDeductionInfo>,
                             private val onClickListener: DeductionExtendItemClickListener?):
        RecyclerView.Adapter<BankNameVH>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BankNameVH {
        val itemView = LayoutInflater.from(context).inflate(R.layout.item_deduction_extend_big_space, null)
        return BankNameVH(itemView)
    }

    override fun onBindViewHolder(holder: BankNameVH, position: Int) {

        if (dataList[position].selected) {
            holder.ivSelected.visibility = View.VISIBLE
        } else {
            holder.ivSelected.visibility = View.INVISIBLE
        }

        val extentText = if (dataList[position].maxRate == null) {
            holder.tvExtendTag.text = "By amount:"
            "${MARKET_CURRENCY} -${IndiaNumberUtil.formatNumByDecimal(dataList[position].maxAmount!!, MARKET_CURRENCY)}"
        } else {
            holder.tvExtendTag.text = "By rate:"
            "${dataList[position].maxRate}%"
        }

        holder.tvExtend.text = extentText
        onClickListener?.let { onItemClick ->
            holder.itemView.setOnClickListener {
                onItemClick.onItemClick(position)
            }
        }

        if (position == dataList.size - 1) {
            holder.vDivider.visibility = View.GONE
        } else {
            holder.vDivider.visibility = View.VISIBLE
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

}

class BankNameVH(itemView: View): RecyclerView.ViewHolder(itemView) {
    val tvExtendTag = itemView.findViewById<TextView>(R.id.tv_item_deduction_extend_tag)
    val tvExtend = itemView.findViewById<TextView>(R.id.tv_item_deduction_extend)
    val ivSelected = itemView.findViewById<ImageView>(R.id.iv_selected)
    val vDivider = itemView.findViewById<View>(R.id.v_divider)
}

interface DeductionExtendItemClickListener {
    fun onItemClick(position: Int)
}