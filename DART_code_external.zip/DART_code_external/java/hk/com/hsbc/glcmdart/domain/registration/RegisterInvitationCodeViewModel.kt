package hk.com.hsbc.glcmdart.domain.registration

import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class RegisterInvitationCodeViewModel: BaseViewModel() {

    private val mModel by lazy { RegistrationModel() }
    val errorLiveData = MutableLiveData<Boolean>()
    val invitationCodeLiveData = MutableLiveData<RegistrationInvitationEntity>()

    fun uploadInvitationCode(invitationCode: String, isRecoveryUsername: Boolean) {
        val disposable = mModel.checkInvitationCode(invitationCode)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    invitationCodeLiveData.postValue(it)
                }, {
                    errorLiveData.postValue(true)
                    exceptionLiveData.postValue(it.message)
//                    Toast.makeText(DartApplication.instance, it.message, Toast.LENGTH_SHORT).show()
                })
    }
}