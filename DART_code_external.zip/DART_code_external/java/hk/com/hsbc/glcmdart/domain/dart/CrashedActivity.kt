/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dart

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import hk.com.hsbc.glcmdart.framework.BaseActivity

class CrashedActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val msg = intent.getStringExtra("msg")
        msg?.let {
            showAlertDialog(it)
        }
    }

    private var dialog: Dialog? = null

    private fun showAlertDialog(msg: String) {
        if (dialog != null && dialog!!.isShowing) {
            dialog?.dismiss()
        }
        dialog = AlertDialog.Builder(this)
                .setTitle("Application crashed!")
                .setMessage(msg)
                .setCancelable(false)
                .setNegativeButton("Cancel") { _, _ ->
                    finish()
                }
                .setPositiveButton("Confirm") { _, _ ->
                    finish()
                }
                .create()
        dialog?.show()
    }

    protected fun hideAlertDialog() {
        if (dialog != null && dialog!!.isShowing) {
            dialog?.dismiss()
        }
    }

    override fun onDestroy() {
        hideAlertDialog()
        super.onDestroy()
    }
}
