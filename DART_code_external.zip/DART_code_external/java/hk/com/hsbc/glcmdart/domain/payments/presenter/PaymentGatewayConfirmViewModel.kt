package hk.com.hsbc.glcmdart.domain.payments.presenter

import android.annotation.SuppressLint
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.invoices.invoicedetail.InvoiceDetailEntity
import hk.com.hsbc.glcmdart.domain.invoices.invoicedetail.InvoiceDetailModel
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import io.reactivex.schedulers.Schedulers

class PaymentGatewayConfirmViewModel:  BaseViewModel() {
    val invoiceDetailLiveData = MutableLiveData<InvoiceDetailEntity>()
    private val mModel by lazy { InvoiceDetailModel() }

    @SuppressLint("CheckResult")
    fun doRequest(token: String) {
        mModel.getInvoiceDetail(token)
                .subscribeOn(Schedulers.io())
                .subscribe({
                    invoiceDetailLiveData.postValue(it)
                }, {
                    requestLoadingLiveData.postValue(false)
                    exceptionLiveData.postValue(it.message)
                })
    }
}