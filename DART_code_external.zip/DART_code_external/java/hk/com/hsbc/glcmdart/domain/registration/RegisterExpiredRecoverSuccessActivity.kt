package hk.com.hsbc.glcmdart.domain.registration

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.welcome.WelcomeActivity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.fragment_register_successfully.*

class RegisterExpiredRecoverSuccessActivity: BaseActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_register_successfully)

        logonButton.setText(R.string.s_invitation_expired_success_ok)
        deleteButton.setOnClickListener(this)
        logonButton.setOnClickListener(this)

        MemoryCache.getLabelText("s_talkback_close_button")?.let {
            if (!it.isBlank()) {
                deleteButton.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_invitation_expired_success_title")?.let {
            if (!it.isBlank()) {
                tv_success_title.text = it
            }
        }
        MemoryCache.getLabelText("s_invitation_expired_success_tip")?.let {
            if (!it.isBlank()) {
                tv_success_tip.text = it
            }
        }
        MemoryCache.getLabelText("button_registerSuccessfully_logon")?.let {
            if (!it.isBlank()) {
                logonButton.text = it
            }
        }
    }

    override fun onClick(v: View?) {
        backForward()
    }

    override fun onBackPressed() {
        backForward()
    }

    private fun backForward() {
        ApplicationManager.finishOtherActivities(RegisterExpiredRecoverSuccessActivity::class.java)
        startActivity(Intent(this, WelcomeActivity::class.java))
        finish()
    }

    companion object {
        fun showActivity(activity: Activity?) {
            activity?.startActivity(Intent(activity, RegisterExpiredRecoverSuccessActivity::class.java))
        }
    }
}