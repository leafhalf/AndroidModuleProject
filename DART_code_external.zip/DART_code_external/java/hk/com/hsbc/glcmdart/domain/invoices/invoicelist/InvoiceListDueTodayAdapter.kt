/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import hk.com.hsbc.glcmdart.view.RecyclerBaseAdapter
import hk.com.hsbc.glcmdart.widget.StickyHeaderItemDecoration
import kotlinx.android.synthetic.main.item_invoice_due_today.view.*
import kotlinx.android.synthetic.main.view_sticky_header.view.*
import java.util.*

/**
 * Created by Donut on 2018/11/1.
 *
 * adapter for due invoice
 */
class InvoiceListDueTodayAdapter(private val mContext: Context, private var mList: MutableList<InvoiceListNativeEntity>) :
        RecyclerBaseAdapter<InvoiceListDueTodayViewHolder>(mContext), StickyHeaderItemDecoration.StickyHeaderInterface {

    //three type to show data: normal is for total amount, outstanding is for outstanding amount, header is for sticky header
    //cause the limitation of sticky header, it's necessary to new a type for header
    private val TYPE_NORMAL = 0
    private val TYPE_OUTSTANDING = 1
    private val TYPE_HEADER = 2

    private val isSupplierUser = "S" == MemoryCache.getSessionEntity()?.type
    var mAdvisePaymentCallback: AdvicePaymentCallback? = null
    var dueDate = ""

    //the same as all invoice
    var isShowDueTodayNormalAmount = true
        set(value) {
            field = value
            notifyItemRangeChanged(0, itemCount)
        }

    fun setData(list: MutableList<InvoiceListNativeEntity>?) {
        mList = mutableListOf()
        if (list != null) {
            mList.addAll(list)
        }
        notifyDataSetChanged()
//        notifyItemRangeChanged(0, mList.size)
    }

    fun getData(): MutableList<InvoiceListNativeEntity> = mList

    override fun getItemViewType(position: Int): Int {
        return when {
            mList[position].isShowHeader -> TYPE_HEADER
            isShowDueTodayNormalAmount -> TYPE_NORMAL
            else -> TYPE_OUTSTANDING
        }
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            val rootView = LayoutInflater.from(mContext).inflate(R.layout.view_sticky_header, null)
            InvoiceListDueTodayHeaderViewHolder(rootView)
        } else {
            val rootView = LayoutInflater.from(mContext).inflate(R.layout.item_invoice_due_today, null)
            InvoiceListDueTodayViewHolder(rootView, viewType)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        //normal item, set due today holder data
        if (holder is InvoiceListDueTodayViewHolder) {
            MemoryCache.getLabelText("s_advise_payment")?.let {
                if (!it.isBlank()) {
                    holder.tvItemAdvisePayment.text = it
                }
            }

            holder.itemView.setAccessibilityDelegate(object: View.AccessibilityDelegate() {
                override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info?.className = Button::class.java.name
                }
            })

            holder.itemView.setOnClickListener {
                if (itemClickListener != null) {
                    itemClickListener?.onItemClick(holder.itemView, position)
                }
            }
            // supplier group, if position equal 0 or last item's supplier name not equal this item supplier name, calculation
            if (position == 0 || mList[position - 1].isShowHeader) {
                holder.rlItemSupplierAndAmountContainer.visibility = View.VISIBLE
                countInvoiceAndTotalAmount(holder, position)
            } else {
                showCompanyHeader(holder, position)
            }

            //if it's the last item or supplier name is different from next item or next item is a header, show the advise payment button
            if ((position == mList.size - 1) || (mList[position].invoice?.payee?.name != mList[position + 1].invoice?.payee?.name) || mList[position + 1].isShowHeader) {
                countTotalAmount(holder, position)
                if ("S" == MemoryCache.getSessionEntity()?.type) {
                    holder.tvItemAdvisePayment.visibility = View.GONE
                    holder.vItemAdvisePaymentLine.visibility = View.GONE
                } else {
                    holder.tvItemAdvisePayment.setAccessibilityDelegate(object: View.AccessibilityDelegate() {

                        override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                            super.onInitializeAccessibilityNodeInfo(host, info)
                            info?.className = Button::class.java.name
                        }
                    })

                    if (mList[position].invoice?.status == "O" || mList[position].invoice?.status == "F") {
                        holder.tvItemAdvisePayment.visibility = View.GONE
                        holder.vItemAdvisePaymentLine.visibility = View.GONE
                    } else {
                        holder.tvItemAdvisePayment.visibility = View.VISIBLE
                        holder.vItemAdvisePaymentLine.visibility = View.VISIBLE
                        holder.tvItemAdvisePayment.setOnClickListener {
                            if (mAdvisePaymentCallback != null) {
                                mAdvisePaymentCallback?.advicePayment(mList[position].invoice?.dueDate!!, mList[position].invoice?.payee?.name!!)
                            }
                        }
                    }
                }
                holder.tvItemTotalAmount.visibility = View.VISIBLE
                holder.itemView.contentDescription = (MemoryCache.getLabelText("s_talkback_clickable_item") ?: context.getString(R.string.s_talkback_clickable_item)) + " " + mList[position].invoice?.reference
            } else {
                holder.tvItemTotalAmount.visibility = View.GONE
                holder.tvItemAdvisePayment.visibility = View.GONE
                holder.vItemAdvisePaymentLine.visibility = View.GONE
            }

            //each item amount
            val amountNum = if (isShowDueTodayNormalAmount) {
                mList[position].invoice?.summation?.outstanding?.amount ?: ""
            } else {
                mList[position].invoice?.summation?.total?.amount ?: ""
            }
            val amountTxt = mList[position].invoice?.summation?.total?.currency + " " +
                    IndiaNumberUtil.formatNumByDecimal(amountNum,mList[position].invoice?.summation?.total?.currency ?: (MemoryCache.defaultCurrency ?: ""))
            holder.tvItemAmount.text = amountTxt
            holder.tvItemInvoiceId.text = mList[position].invoice?.reference
            holder.tvItemStatus.text = MemoryCache.getLabelText("s_invoice_status_" + mList[position].invoice?.status)
            // header item, just show date and overdue days
        } else if (holder is InvoiceListDueTodayHeaderViewHolder) {
            holder.tvItemDueDate.text = TimeZoneTransformsUtil.formatTime(mList[position].invoice?.dueDate)
            if (TimeZoneTransformsUtil.calDaysBetween(dueDate, mList[position + 1].invoice?.dueDate).toInt() >= 0) {
                holder.tvItemOverdueTip.visibility = View.INVISIBLE
                holder.ivItemOverdueIcon.visibility = View.INVISIBLE
            } else {
                holder.tvItemOverdueTip.visibility = View.VISIBLE
                holder.ivItemOverdueIcon.visibility = View.VISIBLE
                holder.tvItemOverdueTip.text = String.format(MemoryCache.getLabelText("s_overdue_days") ?: mContext.getString(R.string.s_overdue_days),
                        TimeZoneTransformsUtil.calDaysBetween(mList[position].invoice?.dueDate, TimeZoneTransformsUtil.formatParameterTime(Date())))
            }
        }
    }

    /**
     * control if the supplier name is showed or not
     */
    private fun showCompanyHeader(holder: InvoiceListDueTodayViewHolder, position: Int) {
        if ((position == 0) || (mList[position].invoice?.payee?.name != mList[position - 1].invoice?.payee?.name)) {
            holder.rlItemSupplierAndAmountContainer.visibility = View.VISIBLE
            countInvoiceAndTotalAmount(holder, position)
        } else {
            holder.rlItemSupplierAndAmountContainer.visibility = View.GONE
        }
    }

    /**
     * count and calculate the number and amount of each supplier
     */
    private fun countInvoiceAndTotalAmount(holder: InvoiceListDueTodayViewHolder, position: Int) {
        var count = 1
        for (i in position + 1 until mList.size) {
            if (mList[position].invoice?.payee?.name == mList[i].invoice?.payee?.name && mList[position].invoice?.dueDate == mList[i].invoice?.dueDate) {
                count++
            } else {
                break
            }
        }
        val organizationsMap = MemoryCache.getOrganisationsMap()
        val payeeReferenceName = if (isSupplierUser) {
            if (organizationsMap.containsKey(mList[position].invoice?.payor?.reference))
                (organizationsMap[mList[position].invoice?.payor?.reference] as Payee).name
            else
                mList[position].invoice?.payor?.name
        } else {
            if (organizationsMap.containsKey(mList[position].invoice?.payee?.reference))
                (organizationsMap[mList[position].invoice?.payee?.reference] as Payee).name
            else
                mList[position].invoice?.payor?.name
        }
        val supplierStr = "$payeeReferenceName($count)"
        holder.tvItemSupplier.text = supplierStr
    }

    private fun countTotalAmount(holder: InvoiceListDueTodayViewHolder, position: Int) {
        var totalAmount = 0.0
        for (i in position downTo 0) {
            if (mList[i].isShowHeader) {
                break
            }

            if (mList[position].invoice?.payee?.name == mList[i].invoice?.payee?.name && mList[position].invoice?.dueDate == mList[i].invoice?.dueDate) {
                totalAmount += if (holder.type == TYPE_NORMAL) {
                    if (mList[position].invoice?.summation?.outstanding?.amount != null) {
                        (mList[i].invoice?.summation?.outstanding?.amount?.toDouble() ?: 0.00) / 100.0
                    } else {
                        0.0
                    }
                } else {
                    if (mList[position].invoice?.summation?.total?.amount != null) {
                        (mList[i].invoice?.summation?.total?.amount?.toDouble() ?: 0.00) / 100.0
                    } else {
                        0.0
                    }
                }
            } else {
                break
            }
        }

        val totalAmountStr = "Total: " +
                mList[position].invoice?.summation?.total?.currency + " "+
                IndiaNumberUtil.formatNum(MemoryCache.globalDecimal.format(totalAmount),
                        mList[position].invoice?.summation?.total?.currency ?: (MemoryCache.defaultCurrency ?: ""))
        holder.tvItemTotalAmount.text = totalAmountStr
    }

    override fun getHeaderPositionForItem(itemPosition: Int): Int {
        var headerPosition = 0
        var position = itemPosition
        do {
            if (this.isHeader(position)) {
                headerPosition = position
                break
            }
            position -= 1
        } while (position >= 0)
        return headerPosition
    }

    override fun getHeaderLayout(headerPosition: Int): Int {
        return R.layout.view_sticky_header
    }

    override fun bindHeaderData(header: View, headerPosition: Int) {
        header.tv_sticky_header_date.text = TimeZoneTransformsUtil.formatTime(mList[headerPosition].invoice?.dueDate ?: "")
        if (TimeZoneTransformsUtil.calDaysBetween(dueDate, mList[headerPosition + 1].invoice?.dueDate).toInt() >= 0) {
            header.tv_sticky_header_overdue_tip.visibility = View.GONE
            header.iv_alert_ic.visibility = View.GONE
        } else {
            header.tv_sticky_header_overdue_tip.visibility = View.VISIBLE
            header.iv_alert_ic.visibility = View.VISIBLE
            header.tv_sticky_header_overdue_tip.text = String.format(MemoryCache.getLabelText("s_overdue_days") ?: mContext.getString(R.string.s_overdue_days),
                    TimeZoneTransformsUtil.calDaysBetween(mList[headerPosition].invoice?.dueDate!!, TimeZoneTransformsUtil.formatParameterTime(Date())))

        }
    }

    override fun isHeader(itemPosition: Int): Boolean {
        return mList[itemPosition].isShowHeader
    }
}

/**
 * normal item holder
 */
class InvoiceListDueTodayViewHolder(view: View, val type: Int) : RecyclerView.ViewHolder(view) {
    val rlItemSupplierAndAmountContainer: RelativeLayout = view.rl_invoice_list_item_supplier_and_total_container
    val tvItemSupplier: TextView = view.tv_invoice_list_item_total_supplier_name
    val tvItemTotalAmount: TextView = view.tv_invoice_list_item_total_amount
    val tvItemAmount: TextView = view.tv_invoice_list_item_amount
    val tvItemStatus: TextView = view.tv_invoice_list_item_state
    val tvItemInvoiceId: TextView = view.tv_invoice_list_item_item_id
    val tvItemAdvisePayment: TextView = view.tv_invoice_list_item_advise_payment
    val vItemAdvisePaymentLine: View = view.v_invoice_list_item_advise_payment_line
}

/**
 * header holder
 */
class InvoiceListDueTodayHeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val tvItemDueDate: TextView = view.tv_sticky_header_date
    val tvItemOverdueTip: TextView = view.tv_sticky_header_overdue_tip
    val ivItemOverdueIcon: ImageView = view.iv_alert_ic
}

/**
 * click advice payment callback
 */
interface AdvicePaymentCallback {
    fun advicePayment(date: String, company: String)
}