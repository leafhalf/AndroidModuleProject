/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.calendar

import android.content.Context
import android.widget.LinearLayout
import android.widget.TextView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.calendar.Calendar
import hk.com.hsbc.glcmdart.calendar.WeekBar

class CalendarWeekBar(context: Context) : WeekBar(context) {

    private var mPreSelectedIndex: Int = 0
    private val mLayout: LinearLayout

    init {
        inflate(context, R.layout.view_week_bar, this)
        mLayout = findViewById(R.id.layout)
    }

    override fun onDateSelected(calendar: Calendar, weekStart: Int, isClick: Boolean) {
        // mLayout.getChildAt(mPreSelectedIndex).isSelected = false
        val viewIndex = getViewIndexByCalendar(calendar, weekStart)
        // mLayout.getChildAt(viewIndex).isSelected = true
        mPreSelectedIndex = viewIndex
    }

    override fun onWeekStartChange(weekStart: Int) {
        for (i in 0 until childCount) {
            (mLayout.getChildAt(i) as TextView).text = getWeekString(i, weekStart)
        }
    }

    private fun getWeekString(index: Int, weekStart: Int): String {
        val weeks = context.resources.getStringArray(R.array.array_week_bar)

        if (weekStart == 1) {
            return weeks[index]
        }
        return if (weekStart == 2) {
            weeks[if (index == 6) 0 else index + 1]
        } else weeks[if (index == 0) 6 else index - 1]
    }
}
