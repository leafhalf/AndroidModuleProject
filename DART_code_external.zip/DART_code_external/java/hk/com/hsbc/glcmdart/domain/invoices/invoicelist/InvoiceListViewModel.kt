package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.annotation.SuppressLint
import android.util.SparseArray
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.PAGINATION_PER_PAGE
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import hk.com.hsbc.glcmdart.domain.dart.RequestPagination
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import hk.com.hsbc.glcmdart.util.MemoryCache
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class InvoiceListViewModel: BaseViewModel() {

    val invoiceListLiveData = MutableLiveData<MutableList<InvoiceListNativeEntity>>()
    val invoiceListSummaryLiveData = MutableLiveData<SparseArray<Any>>()
    private var mPreList = ArrayList<InvoiceAddEntity>()
    private val mModel by lazy { InvoiceListModel() }
    private var isListLoading = false
    private val pagination = RequestPagination(currentPage = 0, limit = PAGINATION_PER_PAGE)
    private var uploadParameter = InvoiceRequestParameter(null, null, null, mutableListOf("F", "U", "O", "P", "C"), null, null, null, null, InvoiceRequestSort("issueDate", "desc"))

    fun setPreList(preList: ArrayList<InvoiceAddEntity>?) {
        preList?.also {
            mPreList = preList
        }
    }

    fun getUploadParameter(): InvoiceRequestParameter = uploadParameter
    fun setUploadParameter(parameter: InvoiceRequestParameter) {
        uploadParameter = parameter
    }

    @SuppressLint("CheckResult")
    fun doRequest(isLoadMore: Boolean, isSelectable: Boolean, isInitRequest: Boolean = false) {
        if (isInitRequest) {
            if (MemoryCache.initInvoiceList != null) {
                dealDatas(MemoryCache.initInvoiceList!!, isSelectable)
                return
            }
        }

        if (isListLoading) {
            return
        }

        if (isLoadMore) {
            pagination.currentPage += 1
        } else {
            pagination.currentPage = 1
        }

        isListLoading = true
        uploadParameter.pagination = null
        mModel.getInvoiceList(uploadParameter)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        {
                            isListLoading = false
                            //filter special department invoices， when has department name return from logon， then filter matching invoices
                            var rebuildEntity: InvoiceListEntity? = null
                            if (MemoryCache.departmentName.isNotEmpty() && MemoryCache.getSessionEntity()?.type == "S") {
                                if (!it.payload?.invoices.isNullOrEmpty()) {
                                    val invoiceList = mutableListOf<Invoice>()
                                    val tokens = mutableListOf<String>()
                                    for (i in it.payload?.invoices?.indices!!) {
                                        if (it.payload.invoices[i].payor?.name?.contains("(") == true) {
                                            val belongDepartmentName = it.payload.invoices[i].payor?.name?.split("(") ?: mutableListOf()
                                            if (belongDepartmentName.size <= 1) {
                                                continue
                                            }
                                            val belongDepartNameChecker = belongDepartmentName[1].
                                            replace(")", "").
                                            replace(" ", "")
                                            for (item in MemoryCache.departmentName) {
                                                if (item == belongDepartNameChecker) {
                                                    invoiceList.add(it.payload.invoices[i])
                                                    tokens.add(it.payload.tokens?.get(i)!!)
                                                    break
                                                }
                                            }
                                        }
                                    }
                                    rebuildEntity = InvoiceListEntity(InvoiceListPayLoad(invoiceList,
                                            it.payload.itps, it.payload.pagination, tokens))
                                }
                            }
                            if (rebuildEntity != null) {
                                dealDatas(rebuildEntity, isLoadMore)
                            } else {
                                dealDatas(it, isLoadMore)
                            }
                        }, {
                    isListLoading = false
                    exceptionLiveData.postValue(it.message)
//                    Toast.makeText(DartApplication.instance, it.message, Toast.LENGTH_LONG).show()
                    if (!isLoadMore) {
                        requestLoadingLiveData.postValue(false)
                        invoiceListLiveData.postValue(mutableListOf())
                    }
                })
    }

    private fun dealDatas(entity: InvoiceListEntity, isSelectable: Boolean, isLoadMore: Boolean = false) {
        if (entity.payload != null) {
            if (entity.payload.invoices == null || entity.payload.invoices.isEmpty()) {
                if (isLoadMore) {
                    Toast.makeText(DartApplication.instance, DartApplication.instance?.getString(R.string.s_no_more_data), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(DartApplication.instance, DartApplication.instance?.getString(R.string.s_no_data), Toast.LENGTH_SHORT).show()
                    requestLoadingLiveData.postValue(false)
                    invoiceListLiveData.postValue(mutableListOf())
                }
            } else {
                val invoiceNum = entity.payload.invoices.size
                val nativeInvoiceList = ArrayList<InvoiceListNativeEntity>()
                var unpaidAmount = 0L
                var partiallyAmount = 0L
                var paidedAmount = 0L
                var overpaidAmount = 0L
                var totalAmount = 0L
                val currency = entity.payload.invoices[0].summation?.total?.currency ?: ""
                for (i in 0 until invoiceNum) {
                    var isAtPreList = false
                    for (item in mPreList) {
                        if (entity.payload.tokens?.get(i) == item.token) {
                            isAtPreList = true
                        }
                    }

                    if (!isAtPreList) {
                        val nativeEntity = InvoiceListNativeEntity(entity.payload.tokens?.get(i), entity.payload.invoices[i])
                        if (isSelectable) {
                            if (entity.payload.invoices[i].status == "U" || entity.payload.invoices[i].status == "P") {
                                nativeInvoiceList.add(nativeEntity)
                            }
                        } else {
                            nativeInvoiceList.add(nativeEntity)
                        }
                    }

                    if (entity.payload.invoices[i].status != "C") {
                        entity.payload.invoices[i].summation?.total?.amount?.let { amount ->
                            totalAmount += amount.toLong()
                        }
                    }

                    when(entity.payload.invoices[i].status) {
                        "U" -> {
                            entity.payload.invoices[i].summation?.total?.amount?.let { amount ->
                                unpaidAmount += amount.toLong()
                            }
                        }
                        "P" -> {
                            entity.payload.invoices[i].summation?.total?.amount?.let { amount ->
                                partiallyAmount += amount.toLong()
                            }
                        }
                        "F" -> {
                            entity.payload.invoices[i].summation?.total?.amount?.let { amount ->
                                paidedAmount += amount.toLong()
                            }
                        }
                        "O" -> {
                            entity.payload.invoices[i].summation?.total?.amount?.let { amount ->
                                overpaidAmount += amount.toLong()
                            }
                        }
                    }
                }

                val summaryArray = SparseArray<Any>()
                summaryArray.put(0, unpaidAmount)
                summaryArray.put(1, partiallyAmount)
                summaryArray.put(2, paidedAmount)
                summaryArray.put(3, overpaidAmount)
                summaryArray.put(4, totalAmount)
                summaryArray.put(5, currency)
                invoiceListSummaryLiveData.postValue(summaryArray)

                //load next page, directly add data to total data list
                if (isLoadMore) {
                    invoiceListLiveData.value?.addAll(nativeInvoiceList)
                    invoiceListLiveData.postValue(invoiceListLiveData.value)
                    //refresh or init
                } else {
                    requestLoadingLiveData.postValue(false)
                    invoiceListLiveData.postValue(nativeInvoiceList)
                }
            }
        } else {
            invoiceListLiveData.postValue(mutableListOf())
            Toast.makeText(DartApplication.instance, DartApplication.instance?.getString(R.string.s_no_data), Toast.LENGTH_SHORT).show()
        }
    }
}