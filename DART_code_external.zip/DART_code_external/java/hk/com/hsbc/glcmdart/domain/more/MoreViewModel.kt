package hk.com.hsbc.glcmdart.domain.more

import android.annotation.SuppressLint
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.dart.SchedulerTransformer
import hk.com.hsbc.glcmdart.domain.login.LoginModel
import hk.com.hsbc.glcmdart.domain.login.LogoutEntity
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import io.reactivex.Observable
import retrofit2.Response

class MoreViewModel: BaseViewModel() {
    private val mModel by lazy { LoginModel() }

    val logoutLiveData = MutableLiveData<Boolean>()

    @SuppressLint("CheckResult")
    fun requestLogout() {
        Observable.just(0)
                .map {
                    val entity = mModel.requestLogout()
                    entity
                }
                .compose(SchedulerTransformer())
                .subscribe({
                    updateLogout(it, null)
                }, {
                    updateLogout(null, it)
                })
    }

    private fun updateLogout(response: Response<LogoutEntity>?, throwable: Throwable?) {
        when (response?.code()) {
            204 -> {

                logoutLiveData.postValue(true)
            }
            else -> {
                logoutLiveData.postValue(false)
            }
        }
    }
}