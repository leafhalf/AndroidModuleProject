package hk.com.hsbc.glcmdart.domain.creditnote

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_SUPPLIER
import hk.com.hsbc.glcmdart.client.TAG_SELECT_SUPPLIER_RESULT
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.payments.SuppliersOrCustomersSelectActivity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import kotlinx.android.synthetic.main.activity_credit_note_filter.*

class CreditNoteFilterActivity : BaseActivity() {

    private val itemCurrencyList = mutableMapOf<String, MutableList<String>>()
    private val mCreditNoteCurrencyAdapter by lazy { CreditNoteCurrencyAdapter(this, itemCurrencyList) }
    private var payeeOrPayor: Payee? = null
    private var supplierOrBuyer: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credit_note_filter)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(true, this)
        initViewAndEvent()
    }

    @SuppressLint("ResourceAsColor")
    private fun initViewAndEvent() {
        MemoryCache.getLabelText("s_reset")?.let {
            if (!it.isBlank()) {
                btn_reset.text = it
            }
        }
        MemoryCache.getLabelText("s_currency")?.let {
            if (!it.isBlank()) {
                tv_currency.text = it
            }
        }
        MemoryCache.getLabelText("s_apply_filter")?.let {
            if (!it.isBlank()) {
                btnApply.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_set_filter")?.let {
            if (!it.isBlank()) {
                btnApply.contentDescription = it
            }
        }
        tl_head.title = MemoryCache.getLabelText("s_filters") ?: getString(R.string.s_filters)
        tl_head.setNavigationIcon(R.drawable.ic_close_on_light)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            finish()
        }
        supplierOrBuyer = ("S" == MemoryCache.getSessionEntity()?.type)
        rv_supplier.setOnClickListener {
            SuppliersOrCustomersSelectActivity.showActivity(this, if (payeeOrPayor != null) {
                payeeOrPayor?.reference
            } else {
                MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
            }, if (payeeOrPayor != null) {
                payeeOrPayor?.account?.currency
            } else {
                null
            }, REQUEST_CODE_SUPPLIER, true, "S" == MemoryCache.getSessionEntity()?.type)
        }
        btnApply.setOnClickListener {
            val intent = Intent().apply {
                putExtra(FILTER_SUPPLIER_OR_BUYER, payeeOrPayor)
                if (mCreditNoteCurrencyAdapter.getSelectItem().isNotEmpty())
                    putExtra(FILTER_CURRENCY, mCreditNoteCurrencyAdapter.getSelectItem() as ArrayList<String>)
            }
            setResult(Activity.RESULT_OK, intent)
            finish()
        }
        btn_reset.setOnClickListener {
            payeeOrPayor = null
            tv_supplier.text = MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
            mCreditNoteCurrencyAdapter.resetSelectState()
        }
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        if (supplierOrBuyer) {
            tvRole.text = MemoryCache.getLabelText("s_buyer") ?: getString(R.string.s_buyer)
        } else {
            tvRole.text = MemoryCache.getLabelText("s_supplier") ?: getString(R.string.s_supplier)
        }
        rv_invoice_add_or_edit.adapter = mCreditNoteCurrencyAdapter
        if (MemoryCache.getCurrencyMap().isNotEmpty())
            itemCurrencyList.putAll(MemoryCache.getCurrencyMap())
        mCreditNoteCurrencyAdapter.addData(itemCurrencyList)
        if (intent?.getSerializableExtra(FILTER_CURRENCY) != null) {
            mCreditNoteCurrencyAdapter.setSelectState(intent?.getSerializableExtra(FILTER_CURRENCY) as List<String>)
        }
        if (intent?.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) != null) {
            payeeOrPayor = intent.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) as Payee?
            tv_supplier.text = payeeOrPayor?.name
        } else {
            payeeOrPayor = null
            tv_supplier.text = MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE_SUPPLIER) {
            val payee = data?.getSerializableExtra(TAG_SELECT_SUPPLIER_RESULT) as Payee?
            val organizationsMap = MemoryCache.getOrganisationsMap()
            tv_supplier.text = if (organizationsMap.containsKey(payee?.reference))
                (organizationsMap[payee?.reference] as Payee).name
            else
                payee?.name
            payeeOrPayor = payee
        }
    }

    companion object {
        const val FILTER_SUPPLIER_OR_BUYER = "RESULT_TAG_FILTER_SUPPLIER_OR_BUYER"
        const val FILTER_CURRENCY = "RESULT_TAG_FILTER_CURRENCY"
        fun showActivity(fragment: Fragment, payeeOrPayor: Payee?, currencySelect: List<String>?, requestCode: Int) {
            val intent = Intent(fragment.activity, CreditNoteFilterActivity::class.java).apply {
                if (payeeOrPayor != null)
                    putExtra(FILTER_SUPPLIER_OR_BUYER, payeeOrPayor)
                if (!currencySelect.isNullOrEmpty())
                    putExtra(FILTER_CURRENCY, currencySelect as ArrayList<String>)
            }
            fragment.startActivityForResult(intent, requestCode)
        }
    }
}
