/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.app.Activity
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.CommonDialog
import hk.com.hsbc.glcmdart.domain.welcome.WelcomeActivity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.widget.LoadingButton
import hk.com.hsbc.glcmdart.widget.LoadingCompletedCallback
import kotlinx.android.synthetic.main.activity_enter_invitation_code.*

/**
 * Created by Donut on 2018/11/14.
 */
class RegisterEnterInvitationCodeActivity : BaseActivity(), RegisterEnterInvitationCodeContract.View, View.OnClickListener {

    private lateinit var mViewModel: RegisterInvitationCodeViewModel
    //    private val mPresenter = RegisterEnterInvitationCodePresenter()
    private var isRecoverUserName = false
    private var isTealiumTextRegisterEnter = false
    private var isTealiumTextRecoverEnter = false

    companion object {
        fun showActivity(activity: Activity, isRecoverUserNameFlag: Boolean) {
            val intent = Intent(activity, RegisterEnterInvitationCodeActivity::class.java).apply {
                putExtra(TAG_FORGET_TYPE_FLAG, isRecoverUserNameFlag)
            }
            activity.startActivityForResult(intent, REQUEST_CODE_REGISTER_ENTER_INVITATION_CODE)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enter_invitation_code)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        ll_enter_invitation_code_title_container.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)

//        mPresenter.attachView(this)
        mViewModel = ViewModelProviders.of(this).get(RegisterInvitationCodeViewModel::class.java)
        mViewModel.invitationCodeLiveData.observe(this, Observer {
            showInvalidMessage(it.payload.invitationStatus, it)
        })

        mViewModel.errorLiveData.observe(this, Observer {
            if (it) {
                lb_submit.enableButton(false)
                lb_submit.setButtonText(MemoryCache.getLabelText("s_next") ?: getString(R.string.s_next))
            }
        })
        mViewModel.exceptionLiveData.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })
        isRecoverUserName = intent.getBooleanExtra(TAG_FORGET_TYPE_FLAG, false)
        iv_back.setOnClickListener(this)
        et_enter_invitation_code.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(editable: Editable?) {
                if (isRecoverUserName) {
                    if (!isTealiumTextRecoverEnter) {
                        TealiumUtil.eventTag("text entry", "recover username: invitation code: invitation code entered")
                        isTealiumTextRecoverEnter = true
                    }
                } else {
                    if (!isTealiumTextRegisterEnter) {
                        TealiumUtil.eventTag("text entry", "registration: invitation code: invitation code entered")
                        isTealiumTextRegisterEnter = true
                    }
                }
                lb_submit.enableButton(editable.toString().isNotEmpty())
                if (tv_enter_invitation_code_invalid_tip.visibility == View.VISIBLE) {
                    tv_enter_invitation_code_invalid_tip.visibility = View.GONE
                    lb_submit.setButtonText(MemoryCache.getLabelText("s_next") ?: getString(R.string.s_next))
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

        })
        lb_submit.enableButton(false)
        lb_submit.setOnButtonClickListener(this)

        addLayoutListener(lb_submit)

        MemoryCache.getLabelText("s_talkback_back_button")?.let {
            if (!it.isBlank()) {
                iv_back.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_invitation_code_title")?.let {
            if (!it.isBlank()) {
                tv_enter_invitation_code_title.text = it
            }
        }
        MemoryCache.getLabelText("s_invitation_code_tip")?.let {
            if (!it.isBlank()) {
                tv_enter_invitation_code_tip.text = it
            }
        }
        MemoryCache.getLabelText("s_invitation_code_title")?.let {
            if (!it.isBlank()) {
                tv_enter_invitation_code_title.text = it
            }
        }
        MemoryCache.getLabelText("s_invitation_code_title")?.let {
            if (!it.isBlank()) {
                tv_enter_invitation_code_input_tip.text = it
            }
        }
        MemoryCache.getLabelText("s_invalid_invitation_code_tip")?.let {
            if (!it.isBlank()) {
                tv_enter_invitation_code_invalid_tip.text = it
            }
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.iv_back -> {
                if (isRecoverUserName) {
                    TealiumUtil.eventTag("button click", "recover username: invitation code: back")
                } else {
                    TealiumUtil.eventTag("button click", "registration: invitation code: back")
                }
                finish()
            }
            R.id.tv_submit -> {
                if (isRecoverUserName) {
                    TealiumUtil.eventTag("button click", "recover username: invitation code: next")
                } else {
                    TealiumUtil.eventTag("button click", "registration: invitation code: next")
                }
                tv_enter_invitation_code_invalid_tip.visibility = View.GONE
                lb_submit.startLoadingAnimation()
                mViewModel.uploadInvitationCode(et_enter_invitation_code.text.toString(), isRecoverUserName)
            }
        }
    }


    override fun getActivity(): Activity {
        return this
    }

    override fun obtainSubmitButton(): LoadingButton {
        return lb_submit
    }

    override fun showInvalidMessage(validStatus: String, entity: RegistrationInvitationEntity?) {
        val isExpired = validStatus == "X"
        if (validStatus != "A" && validStatus != "R" && validStatus != "X") {
            if (isRecoverUserName) {
                TealiumUtil.eventTag("error", "recover username: invitation code: your invitation code doesn't exist")
            } else {
                TealiumUtil.eventTag("error", "registration: invitation code: your invitation code doesn't exist")
            }
            tv_enter_invitation_code_invalid_tip.visibility = View.VISIBLE
            lb_submit.endLoadingAnimation(false)
            lb_submit.setButtonText(MemoryCache.getLabelText("s_next") ?: getString(R.string.s_next))
        } else {
            lb_submit.animationEndCallback = object : LoadingCompletedCallback {
                override fun onAnimationCompleted() {
                    if (isExpired) {
                        CommonDialog.showDialog(this@RegisterEnterInvitationCodeActivity,
                                getString(R.string.s_invitation_expired_dialog_title),
                                getString(R.string.s_invitation_expired_dialog_message),
                                getString(R.string.button_userInformation_continue),
                                getString(R.string.s_cancel), View.OnClickListener {
                            enterInvitationCodeGoAhead(entity, isExpired)
                        }, View.OnClickListener{
                            ApplicationManager.finishOtherActivities(RegisterEnterInvitationCodeActivity::class.java)
                            startActivity(Intent(this@RegisterEnterInvitationCodeActivity, WelcomeActivity::class.java))
                            finish()
                        })
                    } else {
                        enterInvitationCodeGoAhead(entity, isExpired)
                    }
                }
            }
            lb_submit.endLoadingAnimation(true)
        }
    }

    private fun enterInvitationCodeGoAhead(entity: RegistrationInvitationEntity?, isExpired: Boolean) {
        val completedIntent = Intent().apply {
            putExtra(TAG_INVITATION_CODE_RESULT, et_enter_invitation_code.text.toString())
            putExtra(TAG_INVITATION_CODE_EXPIRED, isExpired)
            putExtra(TAG_INVITATION_CODE_TYPE, entity?.payload?.userType)
            putExtra(TAG_INVITATION_CODE_COMPANY_NAME, if ("S" == entity?.payload?.userType) {
                entity.payload.supplier
            } else {
                entity?.payload?.buyer
            })
            putExtra(TAG_INVITATION_CODE_COUNTRY, entity?.payload?.countryCode)
        }
        setResult(Activity.RESULT_OK, completedIntent)
        finish()
    }

    private var rootVisionHeight = 0
    private fun addLayoutListener(bottomView: View) {
        window.decorView.viewTreeObserver.addOnGlobalLayoutListener {
            val rect = Rect()
            window.decorView.getWindowVisibleDisplayFrame(rect)
            val visionHeight = rect.height()
            if (rootVisionHeight == 0) {
                rootVisionHeight = visionHeight
                return@addOnGlobalLayoutListener
            }

            if (rootVisionHeight == visionHeight) {
                return@addOnGlobalLayoutListener
            }

            val invisibleHeight = rootVisionHeight - visionHeight
            if (invisibleHeight > 150) {
                bottomView.animate().translationY(-invisibleHeight.toFloat()).setDuration(0).start()
            } else {
                bottomView.animate().translationY(0F).start()
            }
            rootVisionHeight = visionHeight
        }
    }

    override fun onResume() {
        super.onResume()
        if (isRecoverUserName) {
            TealiumUtil.pageTag("dart : buyer portal : recover username : invitation code",
                    "/dart/buyer portal/recover username/invitation code", "verification", "buyer portal",
                    "recover username", "mobile","en", "recover username", "2", "recover username - invitation code")
        } else {
            TealiumUtil.pageTag("dart : buyer portal : registration : invitation code",
                    "/dart/buyer portal/registration/invitation code", "verification", "buyer portal",
                    "registration", "mobile","en", "registration", "2", "registration - invitation code")
        }
    }
}