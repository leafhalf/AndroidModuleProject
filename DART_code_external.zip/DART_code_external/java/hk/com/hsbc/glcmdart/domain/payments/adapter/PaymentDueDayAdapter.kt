/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentDueDayLocalEntity
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import hk.com.hsbc.glcmdart.widget.StickyHeaderItemDecoration

const val TYPE_HEADER = 0
const val TYPE_SECOND_HEADER = 1
const val TYPE_ITEM = 2

class PaymentDueDayAdapter(private val context: Context, private val mData: ArrayList<PlannedPaymentDueDayLocalEntity>) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), RecyclerExtras.OnItemClickListener, StickyHeaderItemDecoration.StickyHeaderInterface {
    val inflater: LayoutInflater = LayoutInflater.from(context)

    fun addData(dataList: ArrayList<PlannedPaymentDueDayLocalEntity>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        notifyDataSetChanged()
    }


    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            TYPE_HEADER -> {
                val view: View = inflater.inflate(R.layout.view_row_header, parent, false)
                ViewHolderHeader(view)
            }
            TYPE_SECOND_HEADER -> {
                val view: View = inflater.inflate(R.layout.view_row_second_header, parent, false)
                ViewHolderSecondHeader(view)
            }
            else -> {
                val view: View = inflater.inflate(R.layout.item_payment_due_day, parent, false)
                ItemHolder(view)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is ItemHolder) {
            val vh: ItemHolder = holder
            var amount = 0L
            mData[position].itp?.lines?.forEach {
                if (it.type == "invoice") amount += (it.amount?.amount?.toLong() ?: 0L)
            }
            val descTmpText = "${mData[position].itp?.payorAccount?.currency} "+ IndiaNumberUtil.formatNumByDecimal(amount.toString(), mData[position].itp?.payorAccount?.currency ?: "")
            vh.tvDesc.text = descTmpText
            vh.tvNumber.text = mData[position].itp?.paymentReference
            var statusText = MemoryCache.getLabelText("s_payment_status_" + mData[position].statuse)
            if (statusText == "Processed") {
                if (MemoryCache.defaultCountry == "IN") {
                    statusText = "Processing"
                }
            }
            vh.tvStatus.text = statusText
            vh.tvPaymentMethod.text = MemoryCache.getLabelText("s_payment_method_label_" + mData[position].itp?.paymentMethod)

            vh.rlItem.setAccessibilityDelegate(object: View.AccessibilityDelegate() {

                override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info?.className = Button::class.java.name
                }
            })
            vh.rlItem.setOnClickListener { v ->
                itemClickListener?.onItemClick(v, position)
            }
            MemoryCache.getLabelText("s_talkback_clickable_item")?.let {
                if (!it.isBlank()) {
                    vh.itemView.contentDescription = it + " " + mData[position].itp?.paymentReference
                }
            }
        } else if (holder is ViewHolderHeader) {
            val vh: ViewHolderHeader = holder
            vh.tvDate.text = TimeZoneTransformsUtil.formatTime(mData[position].expectedDate!!)
            if (mData[position].dueDayTotal!! > 0) {
                vh.tvDate.text = TimeZoneTransformsUtil.formatTime(mData[position].expectedDate!!)
                vh.ivAlertIc.visibility = View.VISIBLE
                MemoryCache.getLabelText("s_overdue_days")?.let {
                    if (!it.isBlank()) {
                        vh.tvDueDate.text = String.format(it, mData[position].dueDayTotal.toString())
                    }
                }
            } else {
                vh.ivAlertIc.visibility = View.GONE
                vh.tvDueDate.text = ""
            }
        } else if (holder is ViewHolderSecondHeader) {
            val vh: ViewHolderSecondHeader = holder
            vh.tvPayee.text = mData[position].payeeReference
            if (mData[position].dueDayAmount != null) {
                val totalTmpText = "${if (MemoryCache.getLabelText("s_total").isNullOrEmpty()) {
                    context.getString(R.string.s_total)
                } else {
                    MemoryCache.getLabelText("s_total")
                }
                } ${mData[position].currency} ${IndiaNumberUtil.formatNumByDecimal(mData[position].dueDayAmount.toString(), mData[position].currency
                        ?: MARKET_CURRENCY)}"

                vh.tvDueTotal.text = totalTmpText
            } else {
                vh.tvDueTotal.text = ""
            }
        }
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val rlItem: View = view.findViewById(R.id.rl_item)
        val tvDesc: TextView = view.findViewById(R.id.tv_desc)
        val tvNumber: TextView = view.findViewById(R.id.tv_number)
        val tvStatus: TextView = view.findViewById(R.id.tv_status)
        val tvPaymentMethod: TextView = view.findViewById(R.id.tv_payment_method)
    }

    private var itemClickListener: RecyclerExtras.OnItemClickListener? = null

    fun setOnItemClickListener(listener: RecyclerExtras.OnItemClickListener) {
        this.itemClickListener = listener
    }

    override fun onItemClick(view: View, position: Int) {

    }

    override fun getHeaderPositionForItem(itemPosition: Int): Int {
        var headerPosition = 0
        var position = itemPosition
        do {
            if (this.isHeader(position)) {
                headerPosition = position
                break
            }
            position -= 1
        } while (position >= 0)
        return headerPosition
    }

    override fun getHeaderLayout(headerPosition: Int): Int {
        return R.layout.view_row_header
    }

    override fun bindHeaderData(header: View, headerPosition: Int) {
        ((header as RelativeLayout).getChildAt(0) as TextView).text = TimeZoneTransformsUtil.formatTime(mData[headerPosition].expectedDate!!)
        val overdue: String = if ((mData[headerPosition].dueDayTotal ?: 0) > 0) {
            header.getChildAt(2).visibility = View.VISIBLE
            val overDueLabel = MemoryCache.getLabelText("s_overdue_days")
            if(overDueLabel == null) {
                "Overdue: " + (mData[headerPosition].dueDayTotal ?: "0") + " days"
            } else {
                if (!overDueLabel.isBlank()) {
                    String.format(overDueLabel, mData[headerPosition].dueDayTotal?.toString() ?: "0")
                } else {
                    "Overdue: " + (mData[headerPosition].dueDayTotal ?: "0") + " days"
                }
            }
        } else {
            header.getChildAt(2).visibility = View.GONE
            ""
        }
        (header.getChildAt(1) as TextView).text = overdue
    }

    override fun isHeader(itemPosition: Int): Boolean {
        return mData[itemPosition].header!!
    }

    class ViewHolderHeader(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tv_date)
        val tvDueDate: TextView = view.findViewById(R.id.tv_due_date)
        val ivAlertIc: ImageView = view.findViewById(R.id.iv_alert_ic)
    }

    class ViewHolderSecondHeader(view: View) : RecyclerView.ViewHolder(view) {
        val tvPayee: TextView = view.findViewById(R.id.tv_payee)
        val tvDueTotal: TextView = view.findViewById(R.id.tv_due_total)
    }

    override fun getItemViewType(position: Int): Int {
        return if (mData[position].header == true) {
            TYPE_HEADER
        } else {
            if (mData[position].secondHeader == true)
                TYPE_SECOND_HEADER
            else
                TYPE_ITEM
        }
    }
}
