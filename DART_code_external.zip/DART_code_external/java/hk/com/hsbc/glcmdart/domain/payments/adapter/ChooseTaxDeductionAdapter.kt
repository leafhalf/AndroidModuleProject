/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.app.Activity
import android.content.Context
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_CHOOSE_TAX_DEDUCTION_EXTEND
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import hk.com.hsbc.glcmdart.domain.payments.ChooseTaxDeductionExtendActivity
import hk.com.hsbc.glcmdart.domain.payments.dialog.DeductionExtendDialog
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfoGrouped
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ConvertUtil
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import java.math.BigDecimal
import java.util.regex.Pattern

class ChooseTaxDeductionAdapter(private val context: Context,
                                private val mData: ArrayList<TaxDeductionInfoGrouped>,
                                private val mInvoice: Invoice) :
        RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val inflater: LayoutInflater = LayoutInflater.from(context)
    val inputMap = mutableMapOf<String, String>()
//    var selectPosition = mutableMapOf<Int, Boolean>()
//    private var btnUpdate: Button? = null
    private var currency: String? = null
    var didOperation = false

//    fun setBtnUpdateWidget(btn_update: Button?) {
//        this.btnUpdate = btn_update
//    }

    fun setCurrency(currency: String?) {
        this.currency = currency
    }

    fun getSelectItems(): List<TaxDeductionInfo> {
        val taxDeductionSelects = mutableListOf<TaxDeductionInfo>()
        for (item in mData)
            if (item.selectedDeduction != null && item.selected) {
                taxDeductionSelects.add(item.selectedDeduction!!)
            }
        return taxDeductionSelects
    }

    fun addData(dataList: ArrayList<TaxDeductionInfoGrouped>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_choose_tax_deduction, parent, false)
        return ItemHolder(view, InputTextWatcher(), FocusChangeListener())
    }

//    private val sb = StringBuilder()
    private val deductionApproachListName = listOf("Percentage", "Allocation")

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        vh.etAmountAllocate.hint = "$currency ${if (currency == "IDR") "0,00" else "0.00"}"
//        val token = mData[position].token ?: ""

//        if (mData[position].type == "1") {
//        vh.tvDescription.text = if (mData[position].type == "1") { "Official tax deduction" } else { "Commercial deduction" }
        if (mData[position].taxDeductionOptions.size > 1) {
//            vh.tvDeductionApproachOnly.visibility = View.GONE
//            vh.spDeductionApproach.visibility = View.VISIBLE
//            var selectedDeductionOptionIndex = 0
            if (mData[position].selectedDeduction != null) {
                for (optionIndex in 0 until mData[position].taxDeductionOptions.size) {
                    if (mData[position].taxDeductionOptions[optionIndex].token == mData[position].selectedDeduction?.token) {
//                        selectedDeductionOptionIndex = optionIndex
                        mData[position].taxDeductionOptions[optionIndex].selected = true
                        break
                    }
                }
            } else {
                var hasSelectedFlag = false
                mData[position].taxDeductionOptions.forEach {
                    if (it.selected) {
                        hasSelectedFlag = true
                    }
                }
                if (!hasSelectedFlag) {
                    mData[position].taxDeductionOptions[0].selected = true
                }
            }
//            val itemSelectedListener = object: AdapterView.OnItemSelectedListener{
//
//                private var isInitSelected = true
//                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
//                    if (isInitSelected) {
//                        isInitSelected = false
//                        return
//                    }
//
//                    val item = mData[(parent?.tag as Int?)!!].taxDeductionOptions[position]
//                    val deductionAmount = if (item.maxRate == null) {
//                        item.maxAmount
//                    } else {
//                        ((mInvoice.summation?.total?.amount?.toBigDecimal() ?: 0.toBigDecimal()) *
//                                item.maxRate!!.toBigDecimal() / 100.toBigDecimal())
//                                .setScale(2, BigDecimal.ROUND_HALF_UP).toString()
//                    }
//                    item.actualAmount = deductionAmount
//                    mData[(parent?.tag as Int?)!!].selectedDeduction = item
//                    notifyItemChanged(parent?.tag as Int)
//                }
//
//                override fun onNothingSelected(parent: AdapterView<*>?) {
//                }
//
//            }
//            val displayList = mutableListOf<String>()
//            mData[position].taxDeductionOptions.forEach {
//                val displayText = if (it.maxRate == null) {
//                    "$currency -${IndiaNumberUtil.formatNumByDecimal(it.maxAmount!!, currency!!)}"
//                } else {
//                    "${it.maxRate}%"
//                }
//                displayList.add(displayText)
//            }
//            val deductionSPAdapter = ArrayAdapter<String>(context, R.layout.item_spinner_display, R.id.tv_spinner_display, displayList)
////                    DeductionOptionsAdapter(context, mData[position].taxDeductionOptions, currency, position)
//            deductionSPAdapter.setDropDownViewResource(R.layout.item_spinner)
//            vh.spDeductionApproach.adapter = deductionSPAdapter
//            vh.spDeductionApproach.onItemSelectedListener = itemSelectedListener
//            vh.spDeductionApproach.dropDownVerticalOffset = context.resources.getDimensionPixelOffset(R.dimen.d_common_padding_margin_30)
//            vh.spDeductionApproach.setSelection(selectedDeductionOptionIndex)
//            vh.spDeductionApproach.tag = position
            val deductionRateText = if (mData[position].selectedDeduction != null) {
                if (mData[position].selectedDeduction?.maxRate == null) {
                    "$currency -${IndiaNumberUtil.formatNumByDecimal(mData[position].selectedDeduction?.maxAmount!!, currency!!)}"
                } else {
                    "${mData[position].selectedDeduction?.maxRate}%"
                }
            } else {
                if (mData[position].taxDeductionOptions[0].maxRate == null) {
                    "$currency -${IndiaNumberUtil.formatNumByDecimal(mData[position].taxDeductionOptions[0].maxAmount!!, currency!!)}"
                } else {
                    "${mData[position].taxDeductionOptions[0].maxRate}%"
                }
            }
            vh.tvDeductionApproachOnly.text = deductionRateText
            vh.tvDeductionApproachOnly.setCompoundDrawablesRelativeWithIntrinsicBounds(null,
                    null, context.getDrawable(R.drawable.ic_arrow_for_more_details), null)
            vh.tvDeductionApproachOnly.setOnClickListener {
                // 2 options here
                // option 1: to new Activity
                ChooseTaxDeductionExtendActivity.showActivityForResult(context as BaseActivity,
                        REQUEST_CODE_CHOOSE_TAX_DEDUCTION_EXTEND, position, mData[position].taxDeductionOptions[0].name ?: "",
                        mData[position].taxDeductionOptions as ArrayList<TaxDeductionInfo>)

                // option 2: show dialog
//                DeductionExtendDialog.showDialog(context as BaseActivity, mData[position].taxDeductionOptions,
//                        mData[position].taxDeductionOptions[0].name ?: "", position,
//                object: DeductionExtendDialog.DeductionApplyCallback {
//                    override fun onDeductionSelected(deductions: List<TaxDeductionInfo>, callerPosition: Int,
//                                                     subItemPosition: Int) {
//                        mData[callerPosition].taxDeductionOptions = deductions as MutableList<TaxDeductionInfo>
//                        mData[callerPosition].selectedDeduction = deductions[subItemPosition]
//                val deductionAmount = if (mData[callerPosition].selectedDeduction?.maxRate == null) {
//                    mData[callerPosition].selectedDeduction?.maxAmount
//                } else {
//                    ((mInvoice.summation?.total?.amount?.toBigDecimal() ?: 0.toBigDecimal()) *
//                            mData[callerPosition].selectedDeduction?.maxRate!!.toBigDecimal() / 100.toBigDecimal())
//                            .setScale(2, BigDecimal.ROUND_HALF_UP).toString()
//                }
//                mData[callerPosition].selectedDeduction?.actualAmount = deductionAmount
//                        notifyDataSetChanged()
//                    }
//                })
            }
        } else {
            val deductionRateText = if (mData[position].taxDeductionOptions[0].maxRate == null) {
                "$currency -${IndiaNumberUtil.formatNumByDecimal(mData[position].taxDeductionOptions[0].maxAmount!!, currency!!)}"
            } else {
                "${mData[position].taxDeductionOptions[0].maxRate}%"
            }
            vh.tvDeductionApproachOnly.text = deductionRateText
            vh.tvDeductionApproachOnly.setCompoundDrawablesRelativeWithIntrinsicBounds(null,
                    null, null, null)
            vh.tvDeductionApproachOnly.setOnClickListener {  }
        }


        vh.sbTaxAllocation.visibility = View.GONE
        vh.llPercentAllocation.visibility = View.GONE
        if (mData[position].selectedDeduction != null) {
            val amountText = if (mData[position].selectedDeduction?.maxRate == null) {
                "$currency -${IndiaNumberUtil.formatNumByDecimal(mData[position].selectedDeduction?.maxAmount!!, currency!!)}"
            } else {
                val tmp1 = BigDecimal.valueOf(mInvoice.summation?.total?.amount?.toDouble() ?: 0.00)
                val tmp2 = BigDecimal.valueOf(mData[position].selectedDeduction?.maxRate!!.toDouble())
                val amountTextTmp = tmp1 * tmp2.divide(BigDecimal.valueOf(100.0))
                val amountText = IndiaNumberUtil.formatNumByDecimal(amountTextTmp.setScale(2, BigDecimal.ROUND_HALF_UP).toDouble().toString(), currency
                        ?: MARKET_CURRENCY)
                "$currency -$amountText"
            }
            vh.tvDeductionAmountDisplay.text = amountText
        } else {
            val amountText = if (mData[position].taxDeductionOptions[0].maxRate == null) {
                "$currency -${IndiaNumberUtil.formatNumByDecimal(mData[position].taxDeductionOptions[0].maxAmount!!, currency!!)}"
            } else {
                val tmp1 = BigDecimal.valueOf(mInvoice.summation?.total?.amount?.toDouble() ?: 0.00)
                val tmp2 = BigDecimal.valueOf(mData[position].taxDeductionOptions[0].maxRate!!.toDouble())
                val amountTextTmp = tmp1 * tmp2.divide(BigDecimal.valueOf(100.0))
                val amountText = IndiaNumberUtil.formatNumByDecimal(amountTextTmp.setScale(2, BigDecimal.ROUND_HALF_UP).toDouble().toString(), currency
                        ?: MARKET_CURRENCY)
                "$currency -$amountText"
            }
            vh.tvDeductionAmountDisplay.text = amountText
        }
        vh.cbTaxDeduction.setOnCheckedChangeListener(null)
        vh.cbTaxDeduction.isChecked = mData[position].selectedDeduction != null && mData[position].selected
//        if (!mData[position].actualAmount.isNullOrEmpty()) {
//            inputMap[token] = MemoryCache.globalDecimal.format((mData[position].actualAmount?.toDouble()
//                    ?: 0.00))
//            Log.e("test", "1")
//            selectPosition[position] = true
//            updateSelectViewState(vh.llAllocate, position)
//        } else {
//            selectPosition[position] = mData[position].selected == true
//            Log.e("test", "2: " + vh.cbTaxDeduction.isChecked.toString())
//        }
        vh.tvName.text = mData[position].taxDeductionOptions[0].name
        vh.tvAmountToAllocateTag.text = MemoryCache.getLabelText("s_deduction_rate") ?: context.getString(R.string.s_deduction_rate)
        vh.tvDeductionAmountTag.text = MemoryCache.getLabelText("s_deduction_amount") ?: context.getString(R.string.s_deduction_amount)
        vh.cbTaxDeduction.setOnCheckedChangeListener { _, isChecked ->
            TealiumUtil.eventTag("checkbox", "choose credit note: credit note ${if (isChecked) "checked" else "unchecked"}")
            if (position > -1) {
                mData[position].selected = isChecked
                var selectPosition = 0
                for (i in 0 until mData[position].taxDeductionOptions.size) {
                    if (mData[position].taxDeductionOptions[i].selected) {
                        selectPosition = i
                        break
                    }
                }
                if (mData[position].taxDeductionOptions.size > 1) {
                    mData[position].selectedDeduction = mData[position].taxDeductionOptions[selectPosition]
                } else {
                    mData[position].selectedDeduction = mData[position].taxDeductionOptions[0]
                }
//                mData[position].actualRate = if (isChecked) mData[position].maxRate else null
                val deductionAmount = if (mData[position].selectedDeduction?.maxRate == null) {
                    mData[position].selectedDeduction?.maxAmount
                } else {
                    ((mInvoice.summation?.total?.amount?.toBigDecimal() ?: 0.toBigDecimal()) *
                            mData[position].selectedDeduction?.maxRate!!.toBigDecimal() / 100.toBigDecimal())
                            .setScale(2, BigDecimal.ROUND_HALF_UP).toString()
                }
                mData[position].selectedDeduction?.actualAmount = if (isChecked) deductionAmount else null
//                refreshButtonState()
            }
            didOperation = true
            notifyItemChanged(position)
//            selectPosition[position] = isChecked
//            updateSelectViewState(vh.llAllocate, position)
        }
//        vh.etAmountAllocate.tag = token
//        vh.inputTextWatcher.token = token
//        vh.inputTextWatcher.mTaxDeduction = mData[position]
//        vh.inputTextWatcher.position = position
//        vh.inputTextWatcher.tvAmountValidate = vh.tvAmountValidate
//        setEditTextInput(token, vh.etAmountAllocate)
        vh.etAmountAllocate.setOnEditorActionListener { _, _, _ ->
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.toggleSoftInput(0, 0)
            true
        }
        vh.inputTextWatcher.etAmountAllocate = vh.etAmountAllocate
//        vh.sbTaxAllocation.max = if (!mData[position].maxRate.isNullOrBlank()) {
//             mData[position].maxRate?.toInt() ?: 0
//        } else {
//            0
//        }
//        vh.tvSeekEnd.text = if (!mData[position].maxRate.isNullOrBlank()) {
//            mData[position].maxRate
//        } else {
//            ""
//        }
//        vh.sbTaxAllocation.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
//            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
//                vh.tvSeekIndicator.text = "$progress%"
//                if (progress > 0) {
//                    mData[position].actualRate = progress.toString()
//                } else {
//                    mData[position].actualRate = null
//                }
//
//                val amountText = (mInvoice.summation?.total?.amount?.toDouble() ?: 0.00) / 100.0 * progress / 100.0
//                vh.tvDeductionAmountDisplay.text = "-$amountText"
//                updateSelectViewState(vh.llAllocate, position)
//            }
//
//            override fun onStartTrackingTouch(seekBar: SeekBar?) {
//            }
//
//            override fun onStopTrackingTouch(seekBar: SeekBar?) {
//            }
//        })
    }

    private fun updateSelectViewState(ll_allocate: View?, position: Int) {
//        if (mData[position].selected) {
//            ll_allocate?.visibility = View.VISIBLE
//        } else {
//            ll_allocate?.visibility = View.GONE
//        }

        //no amendment for amount or percentage, so no need to check counting of chosen and value
//        val selectedCount = selectPosition.count { value -> value.value}
//        val inputCount = mData.count { !it.actualAmount.isNullOrBlank() || !it.actualRate.isNullOrBlank()}
//        btnUpdate?.isEnabled = selectedCount == inputCount
    }

    override fun getItemViewType(position: Int): Int {
        return PlannedPaymentInvoiceAdapter.ITEM_INVOICE_DETAIL
    }

    inner class ItemHolder(view: View, internal var inputTextWatcher: InputTextWatcher, private var focusChangeListener: FocusChangeListener) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tv_tax_deduction_title)
        val llAllocate: View = view.findViewById(R.id.ll_allocate)
        val llPercentAllocation: View = view.findViewById(R.id.ll_percentage_container)
        val tvDescription: TextView = view.findViewById(R.id.tv_tax_deduction_description)
        val tvSeekIndicator: TextView = view.findViewById(R.id.tv_tax_percent_current)
        val tvSeekEnd: TextView = view.findViewById(R.id.tv_tax_percent_end)
        val sbTaxAllocation: SeekBar = view.findViewById(R.id.sb_present)
        val etAmountAllocate: EditText = view.findViewById(R.id.et_amount_allocate)
        val cbTaxDeduction: CheckBox = view.findViewById(R.id.cb_tax_deduction)
        val tvAmountValidate: TextView = view.findViewById(R.id.tv_amount_validate)
        val tvAmountToAllocateTag: TextView = view.findViewById(R.id.tv_amount_to_allocate_tag)
        val llDeductionAmountDisplay: LinearLayout = view.findViewById(R.id.ll_deduction_amount_container)
        val tvDeductionAmountDisplay: TextView = view.findViewById(R.id.tv_deduction_amount)
        val tvDeductionApproachOnly: TextView = view.findViewById(R.id.tv_deduction_approach_only)
        val spDeductionApproach: Spinner = view.findViewById(R.id.sp_deduction_approach)
        val tvDeductionAmountTag: TextView = view.findViewById(R.id.tv_deduction_amount_tag)

        init {
            etAmountAllocate.addTextChangedListener(inputTextWatcher)
            etAmountAllocate.onFocusChangeListener = this.focusChangeListener
        }
    }

    private fun setEditTextInput(reference: String, et: EditText?) {
        if (TextUtils.isEmpty(reference))
            return
        if (inputMap.containsKey(reference)) {
            val tmpText = if (inputMap[reference].isNullOrBlank()) "0.00" else inputMap[reference]
            val decimalNumber = MemoryCache.globalDecimal.format(tmpText?.toDouble())
            val etText = "$currency " + IndiaNumberUtil.formatNum(decimalNumber, currency ?: "")
            et?.setText(etText)
        } else {
            et?.setText("")
        }
    }

    inner class InputTextWatcher : TextWatcher {

        var token: String = ""
        var mTaxDeduction: TaxDeductionInfo? = null
        var position: Int? = -1
        var tvAmountValidate: TextView? = null
        var etAmountAllocate: EditText? = null

        override fun afterTextChanged(s: Editable) {
            if (etAmountAllocate?.hasFocus() == true) {
                val input = s.toString()
                inputMap[etAmountAllocate?.tag.toString() + "origin"] = input
                val decimalSymbol = if (currency == "IDR") {
                    ","
                } else {
                    "."
                }

                val banDecimalSymbol = if (currency == "IDR") {
                    "."
                } else {
                    ","
                }

                if (s.toString().contains(banDecimalSymbol)) {
                    etAmountAllocate?.setText(s.toString().replace(banDecimalSymbol, ""))
                    etAmountAllocate?.setSelection(etAmountAllocate?.text.toString().length)
                    //在textchangewatcher中settext会调用第二次watcher，用return来结束第一次的调用，因为第一次会保留原字符
                    return
                }

                if (s.toString().contains(decimalSymbol)) {
                    if (etAmountAllocate?.text.toString().indexOf(decimalSymbol) >= 0) {
                        if (etAmountAllocate?.text.toString().indexOf(decimalSymbol, etAmountAllocate?.text.toString().indexOf(decimalSymbol) + 1) > 0) {
                            etAmountAllocate?.setText(etAmountAllocate?.text.toString().substring(0, etAmountAllocate?.text.toString().length - 1))
                            etAmountAllocate?.setSelection(etAmountAllocate?.text.toString().length)
                        }

                    }
                }

                //这部分是处理如果用户输入以.开头，在前面加上0
                if (s.toString().trim().substring(0) == decimalSymbol) {
                    val tmpZeroText = "0$s"
                    etAmountAllocate?.setText(tmpZeroText)
                    etAmountAllocate?.setSelection(2)
                    //在textchangewatcher中settext会调用第二次watcher，用return来结束第一次的调用，因为第一次会保留原字符
                    return
                }
                //这里处理用户 多次输入.的处理 比如输入 1..6的形式，是不可以的
                if (s.toString().startsWith("0")
                        && s.toString().trim().length > 1) {
                    if (s.toString().substring(1, 2) != decimalSymbol) {
                        etAmountAllocate?.setText(s.subSequence(0, 1))
                        etAmountAllocate?.setSelection(1)
                        return
                    }
                }
                if (((context as Activity).currentFocus != null) && !TextUtils.isEmpty(token)) {
                    var inputAmount = ""
                    if (input.isNotEmpty()) {
                        inputAmount = if (input.endsWith(decimalSymbol)) {
                            (input + "00").replace("$currency", "")
                        } else {
                            input.replace("$currency", "")
                        }
                        inputAmount = inputAmount.replace(decimalSymbol, ".")
                        inputAmount = inputAmount.replace(banDecimalSymbol, ".")
                    }
                    if (inputAmount.contains(".")) {
                        val pattern = Pattern.compile("(.)\\1+")
                        val matcher = pattern.matcher(inputAmount)
                        val sb = StringBuffer()
                        while (matcher.find()) {
                            val single = matcher.group(1)
                            if (single == ".") {
                                matcher.appendReplacement(sb, single)
                            }
                        }
                        matcher.appendTail(sb)
                        inputAmount = sb.toString()
                    }
                    if (inputAmount.contains(".")) {
                        val subStr = inputAmount.split(".")
                        if (subStr.size > 2) {
                            inputAmount = subStr[0] + "." + subStr[1]
                        }
                    }
                    inputMap[token] = inputAmount
                    if (inputAmount.isNotEmpty()) {
                        mTaxDeduction?.actualAmount = inputAmount
                    } else {
                        mTaxDeduction?.actualAmount = ""
                    }
//                    if (position ?: -1 > -1) {
//                        if (selectPosition.containsKey(position) && (selectPosition[position] == true)) {
//                            val currentActualAmount = if (mData[position?: 0].actualAmount.isNullOrEmpty()) "0" else mData[position
//                                    ?: 0].actualAmount
//                            val creditNoteOutstanding = (currentActualAmount?.replace("-", "")?.toLong()
//                                    ?: 0L) / 100
//                            var creditNoteAmountInput = 0L
//                            if (inputAmount.isNotEmpty())
//                                creditNoteAmountInput = (inputAmount.toDouble()).toLong()
//                            if (creditNoteAmountInput == 0L || (creditNoteAmountInput > creditNoteOutstanding)) {
//                                setUpdateButtonState(false, tvAmountValidate, creditNoteAmountInput)
//                            } else {
//                                setUpdateButtonState(true, tvAmountValidate, creditNoteAmountInput)
//                            }
//                        }
//                    }
                }
            }
        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

        }

        //limit 2 decimal
        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
        }
    }

//    private fun setUpdateButtonState(b: Boolean, tv_amount_validate: TextView?, creditNoteAmountInput: Long) {
//        if (b)
//            tv_amount_validate?.visibility = View.GONE
//        else {
//            if (creditNoteAmountInput == 0L) {
//                tv_amount_validate?.visibility = View.GONE
//            } else {
//                tv_amount_validate?.visibility = View.VISIBLE
//                MemoryCache.getLabelText("s_amount_greater_tips2")?.let {
//                    if (!it.isBlank()) {
//                        tv_amount_validate?.text = it
//                    }
//                }
//            }
//        }
//        refreshButtonState()
//    }

//    private fun refreshButtonState() {
//        var validateFlag = true
//        if (selectPosition.containsValue(true)) {
//            for (item in selectPosition) {
//                val position = item.key
//                if (item.value) {
//                    validateFlag = validateFlag && (!mData[position].actualAmount.isNullOrBlank() ||
//                            !mData[position].actualRate.isNullOrBlank())
//                }
//            }
//        } else {
//            validateFlag = originalSelectFlag
//        }
//        btnUpdate?.isEnabled = validateFlag
//    }

    inner class FocusChangeListener : View.OnFocusChangeListener {
        override fun onFocusChange(v: View?, hasFocus: Boolean) {
            val inputEditText = v as EditText
            val reference = v.getTag().toString()
            val input: String?
            var inputShow: String? = ""
            val decimalSymbol = if (currency == "IDR") "," else "."
            if (inputMap.containsKey(reference)) {
                input = if (inputMap[reference].isNullOrBlank()) {
                    ""
                } else {
                    var tmpInput = inputMap[reference] ?: "0"
                    tmpInput = if (tmpInput.contains(decimalSymbol)) {
                        val tmpInputSubStr = tmpInput.split(decimalSymbol)
                        if (tmpInputSubStr[1].length == 1) {
                            tmpInput += "0"
                        }
                        if (tmpInputSubStr[1].length > 2) {
                            tmpInput = tmpInputSubStr[0] + decimalSymbol + tmpInputSubStr[1].subSequence(0, 2)
                        }

                        tmpInput
                    } else {
                        (tmpInput.toDouble()).toString()
                    }
                    tmpInput
                }
                if (!TextUtils.isEmpty(input)) {
                    val exchange = (if (input.isNullOrBlank())
                        ""
                    else
                        MemoryCache.globalDecimal.format(input.toDouble())).replace(".", if (currency == "IDR") "," else ".")
                    inputShow = "$currency $exchange"
                }
            }
            if (!hasFocus) {
                inputEditText.setText(inputShow)
            } else {
                val tmpInput = if (inputMap[reference + "origin"].isNullOrBlank()) v.text.toString().replace(currency
                        ?: "", "").trim()
                else inputMap[reference + "origin"]
                inputEditText.setText(tmpInput)
            }
        }
    }
}
