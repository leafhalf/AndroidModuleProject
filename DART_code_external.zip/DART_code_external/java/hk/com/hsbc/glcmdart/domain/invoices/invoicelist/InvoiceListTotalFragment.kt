/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.util.Pair
import androidx.core.view.ViewCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.AppBarLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dashboard.RingData
import hk.com.hsbc.glcmdart.domain.dashboard.RingView
import hk.com.hsbc.glcmdart.domain.home.HomeActivity
import hk.com.hsbc.glcmdart.domain.invoices.invoicedetail.InvoiceDetailActivity
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_DEFAULT
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_HIGH_TO_LOW
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_LOW_TO_HIGH
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_NEW_TO_OLD
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_OLD_TO_NEW
import hk.com.hsbc.glcmdart.util.FastClickUtil
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.fragment_sub_invoice.view.*
import kotlinx.android.synthetic.main.view_total_invoice_header.view.*

/**
 * Created by Donut
 *
 * all invoice page
 */
class InvoiceListTotalFragment : Fragment(), InvoiceListContract.View, SwipeRefreshLayout.OnRefreshListener,
        SearchTextChangeCallback, OnRecyclerViewItemClickListener<InvoiceListNativeEntity> {

//    private val mPresenter = InvoiceListPresenter()
    private var mAdapter: InvoiceListAdapter? = null
    private var rvContentList: RecyclerView? = null
    private var srlContentRefresher: SwipeRefreshLayout? = null
    private var tvTodayInvoiceCount: TextView? = null
    private var tvTodayInvoiceAmount: TextView? = null
    private var tvNoData: TextView? = null
    private var screenPageItemSize = 0
    private var lastSortType = SORT_TYPE_DEFAULT
    private lateinit var llInvoiceSummaryChartContainer: LinearLayout
    private lateinit var llInvoiceSummaryPointContainer: LinearLayout
    private lateinit var llInvoiceSummaryContainer: LinearLayout
    private lateinit var rvInvoiceSummaryChart: RingView
    private lateinit var loadingView: ProgressBar
    private var isRefreshing = false
    private var currentCountryCode = MemoryCache.defaultCountry

    private lateinit var mViewModel: InvoiceListViewModel

    override fun getFragmentActivity(): Activity? {
        return activity
    }

    companion object {
        fun newInstance(): InvoiceListTotalFragment {
            return InvoiceListTotalFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        mPresenter.attachView(this)
        val rootView = inflater.inflate(R.layout.fragment_sub_invoice, container, false)

        mViewModel = ViewModelProviders.of(this).get(InvoiceListViewModel::class.java)
        mViewModel.requestLoadingLiveData.observe(this, Observer {
            srlContentRefresher?.isRefreshing = it
        })
        mViewModel.invoiceListSummaryLiveData.observe(this, Observer {
            updateRingData(it[0] as Long, it[1] as Long, it[2] as Long, it[3] as Long, it[4] as Long, it[5] as String)
        })
        mViewModel.invoiceListLiveData.observe(this, Observer {
            if (it.isEmpty()) {
                showData(false)
            } else {
                showData(true)
                mAdapter?.setData(it)
            }
        })
        mViewModel.exceptionLiveData.observe(this, Observer {
            Toast.makeText(activity, it, Toast.LENGTH_SHORT).show()
        })
        llInvoiceSummaryChartContainer = rootView.ll_invoice_summary_chart_container
        llInvoiceSummaryPointContainer = rootView.ll_invoice_summary_point_container
        llInvoiceSummaryContainer = rootView.ll_invoice_summary_chart_container
        rvInvoiceSummaryChart = rootView.rv_invoice_summary_chart_container
        tvNoData = rootView.tv_invoice_list_no_data

        MemoryCache.getLabelText("s_all_invoices")?.let {
            if (!it.isBlank()) {
                rootView.tv_all_invoices_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_no_record")?.let {
            if (!it.isBlank()) {
                tvNoData?.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_invoice_sorting")?.let {
            if (!it.isBlank()) {
                rootView.iv_sort_condition.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_talkback_invoice_filter")?.let {
            if (!it.isBlank()) {
                rootView.iv_filter_condition_entrance.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_show_outstanding_amount")?.let {
            if (!it.isBlank()) {
                rootView.sw_outstanding.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_show_outstanding_amount")?.let {
            if (!it.isBlank()) {
                rootView.tv_outstanding_tag.text = it
            }
        }

        rootView.iv_filter_condition_entrance.setOnClickListener {
            TealiumUtil.eventTag("button click", "landing - invoices: filter")
            if (!FastClickUtil.isFastClick) {
                val filterIntent = Intent(activity, InvoiceListFilterActivity::class.java).apply {
//                    putExtra(TAG_INVOICE_FILTER_PARAMETER, mPresenter.getUploadParameter())
                    putExtra(TAG_INVOICE_FILTER_PARAMETER, mViewModel.getUploadParameter())
                }
                startActivityForResult(filterIntent, REQUEST_CODE_INVOICE_FILTER)
            }
        }
        rootView.iv_sort_condition.setOnClickListener {
            TealiumUtil.eventTag("dropdown", "landing - invoices: sort by expanded")
            ContextCompat.getSystemService(activity!!, InputMethodManager::class.java)?.hideSoftInputFromWindow(rootView.windowToken, 0)
            it.setBackgroundResource(R.drawable.ic_sorting_red)
            if (activity != null) {
                //do sorting when choose sort item
                val timeConditionWindow = InvoiceListSortPopupWindow(activity!!, object : InvoiceSortPopupChoose {
                    override fun onChoose(item: String) {
                        it.setBackgroundResource(R.drawable.ic_sorting)
                        when (item) {
                            (MemoryCache.getLabelText("tv_invoice_list_sort_default") ?: getString(R.string.s_default)) -> {
                                TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Default")
                                lastSortType = SORT_TYPE_DEFAULT
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("issueDate", "desc")
                                mViewModel.getUploadParameter().sorting = InvoiceRequestSort("issueDate", "desc")
                            }
                            (MemoryCache.getLabelText("s_new_to_old") ?: getString(R.string.s_new_to_old)) -> {
                                TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Due date: Newest to Oldest")
                                lastSortType = SORT_TYPE_NEW_TO_OLD
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("dueDate", "desc")
                                mViewModel.getUploadParameter().sorting = InvoiceRequestSort("dueDate", "desc")
                            }
                            (MemoryCache.getLabelText("s_old_to_new") ?: getString(R.string.s_old_to_new)) -> {
                                TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Due date: Oldest to Newest")
                                lastSortType = SORT_TYPE_OLD_TO_NEW
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("dueDate", "asc")
                                mViewModel.getUploadParameter().sorting = InvoiceRequestSort("dueDate", "asc")
                            }
                            (MemoryCache.getLabelText("s_high_to_low") ?: getString(R.string.s_high_to_low)) -> {
                                TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Amount: Highest to Lowest")
                                lastSortType = SORT_TYPE_HIGH_TO_LOW
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("amount", "desc")
                                mViewModel.getUploadParameter().sorting = InvoiceRequestSort("amount", "desc")
                            }
                            (MemoryCache.getLabelText("s_low_to_high") ?: getString(R.string.s_low_to_high)) -> {
                                TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Amount: Lowest to Highest")
                                lastSortType = SORT_TYPE_LOW_TO_HIGH
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("amount", "asc")
                                mViewModel.getUploadParameter().sorting = InvoiceRequestSort("amount", "asc")
                            }

                        }
                        mViewModel.doRequest(isLoadMore = false, isSelectable = false)
//                        mPresenter.getInvoiceList(isLoadMore = false, isSelectable = false)
                    }
                }).showUpPopupWindow(lastSortType)

                //recover the icon of sorting button
                timeConditionWindow.setOnDismissListener {
                    TealiumUtil.eventTag("dropdown", "landing - invoices: sort by collapsed")
                    it.setBackgroundResource(R.drawable.ic_sorting)
                }

                //adjust the popup window size
                if (Build.VERSION.SDK_INT >= 24) {
                    val location = intArrayOf(0, 0)
                    it.getLocationOnScreen(location)
                    val h = it.resources.displayMetrics.heightPixels - location[1]
                    timeConditionWindow.height = h - it.measuredHeight
                }

                if (Build.VERSION.SDK_INT == Build.VERSION_CODES.N) {
                    val location = intArrayOf(0, 0)
                    it.getLocationOnScreen(location)
                    timeConditionWindow.showAtLocation(it, Gravity.NO_GRAVITY, 0, location[1])
                } else {
                    timeConditionWindow.showAsDropDown(it)
                }
            }
        }

        //change amount show
        rootView.sw_outstanding.setOnCheckedChangeListener { _, isChecked ->
            TealiumUtil.eventTag("button click","more invoices due: outstanding amount: ${if(isChecked) "selected" else "unselected"}")
            mAdapter?.isShowOutstandingAmount = isChecked
            rvContentList?.requestLayout()
            calculateRingChartAmount(!isChecked)
        }

        rootView.abl_title.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { _, verticalOffset ->
            rootView.srl_invoice_list_refresher.isEnabled = verticalOffset >= 0
        })

        mAdapter = InvoiceListAdapter(mutableListOf(), false)
//        mPresenter.setAdapter(mAdapter as InvoiceListAdapter)
        mAdapter?.onItemClickListener = this
        rvContentList = rootView.rv_invoice_list.apply {
            layoutManager = LinearLayoutManager(activity, RecyclerView.VERTICAL, false)
            adapter = mAdapter
        }
        srlContentRefresher = rootView.srl_invoice_list_refresher.apply {
            setOnRefreshListener(this@InvoiceListTotalFragment)
        }

//        setRefreshing(true)
//        if (isInit) {
        loadingView = rootView.pb_loading
        loadingView.visibility = View.VISIBLE
        loadingView.announceForAccessibility(MemoryCache.getLabelText("s_loading") ?: getString(R.string.s_loading))
//            isInit = false
//        }
        mViewModel.doRequest(isLoadMore = false, isSelectable = false)
//        mPresenter.getInvoiceList(isLoadMore = false, isSelectable = false)
        return rootView
    }

    override fun onItemClick(view: View, viewType: Int, data: InvoiceListNativeEntity?, position: Int) {
//        val tvSupplierName = view.findViewById<TextView>(R.id.tv_invoice_list_item_supplier_name)
//        val tvInvoiceId = view.findViewById<TextView>(R.id.tv_invoice_list_item_item_id)
//        val tvInvoiceStatus = view.findViewById<TextView>(R.id.tv_invoice_list_item_state)
//        val invoiceIdName = "invoice_id:" + data?.invoice?.reference
//        val supplierName = "supplier_name:" + data?.invoice?.payee?.name
//        val statusName = "pay_state:" + data?.invoice?.reference + data?.invoice?.status
//        ViewCompat.setTransitionName(tvInvoiceId, invoiceIdName)
//        ViewCompat.setTransitionName(tvSupplierName, supplierName)
//        ViewCompat.setTransitionName(tvInvoiceStatus, statusName)
//        val part1 = Pair(tvSupplierName as View, ViewCompat.getTransitionName(tvSupplierName))
//        val part2 = Pair(tvInvoiceId as View, ViewCompat.getTransitionName(tvInvoiceId))
//        val part3 = Pair(tvInvoiceStatus as View, ViewCompat.getTransitionName(tvInvoiceStatus))
//        val activityOptionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(getFragmentActivity()!!, part1, part2, part3)
        TealiumUtil.eventTag("button click", "landing - invoices: invoice selected")
        val intent = Intent(activity, InvoiceDetailActivity::class.java).apply {
            putExtra(TAG_INVOICE_TOKEN, data)
            putExtra(TAG_INVOICE_FROM_PLANNED_PAYMENT_CREATION, false)
        }
//        startActivity(intent, activityOptionsCompat.toBundle())
        startActivity(intent)
    }

    override fun onRefresh() {
        if (!isRefreshing) {
//            mPresenter.getUploadParameter().search = (activity as HomeActivity).getCurrentSearchingContent()
            mViewModel.getUploadParameter().search = (activity as HomeActivity).getCurrentSearchingContent()
            setRefreshing(true)
            mViewModel.doRequest(isLoadMore = false, isSelectable = false)
//            mPresenter.getInvoiceList(isLoadMore = false, isSelectable = false)
        }
    }

    override fun getMainListView(): RecyclerView? {
        return rvContentList
    }

    override fun getMainRefresher(): SwipeRefreshLayout? {
        return srlContentRefresher
    }

    override fun updateRingData(unpaidAmount: Long, partiallyAmount: Long, paidAmount: Long, overpaidAmount: Long, totalAmount: Long, currency: String,isShowOutstanding: Boolean) {
        if ("S" == MemoryCache.getSessionEntity()?.type) {
            llInvoiceSummaryChartContainer.visibility = View.GONE
            return
        }

        if (totalAmount == 0L) {
            llInvoiceSummaryChartContainer.visibility = View.GONE
        } else {
            activity?.let {
                llInvoiceSummaryChartContainer.visibility = View.VISIBLE
                val map = mutableListOf<String>()
//                val uploadParameter = mPresenter.supplyUploadParameter()
                val uploadParameter = mViewModel.getUploadParameter()
                if (uploadParameter.status.contains("U")) {
                    map.add("U")
                }
                if (uploadParameter.status.contains("P")) {
                    map.add("P")
                }
                if (uploadParameter.status.contains("O")) {
                    map.add("O")
                }
                if (uploadParameter.status.contains("F")) {
                    map.add("F")
                }

                if (isShowOutstanding) {
                    map.remove("F")
                    map.remove("O")
                }

                val invoiceSummaryList = mutableListOf(RingData(unpaidAmount.toDouble() / totalAmount.toDouble(), getInvoiceColor("U"), null),
                        RingData(partiallyAmount.toDouble() / totalAmount.toDouble(), getInvoiceColor("P"), null),
                        RingData(paidAmount.toDouble() / totalAmount.toDouble(), getInvoiceColor("F"), null),
                        RingData(overpaidAmount.toDouble() / totalAmount.toDouble(), getInvoiceColor("O"), null))
                rvInvoiceSummaryChart.setData(invoiceSummaryList.filter {
                    it.gravity > 0
                })

                llInvoiceSummaryPointContainer.removeAllViews()
                for (key in map) {
                    val totalValue = when (key) {
                        "U" -> unpaidAmount
                        "P" -> partiallyAmount
                        "F" -> paidAmount
                        "O" -> overpaidAmount
                        else -> 0
                    }
                    val view = LayoutInflater.from(it).inflate(R.layout.item_chart_invoice, null, false)
                    val pointView = view.findViewById<ImageView>(R.id.pointView)
                    val countText = view.findViewById<TextView>(R.id.countText)
                    val currencyText = view.findViewById<TextView>(R.id.currencyText)
                    pointView.setBackgroundColor(getInvoiceColor(key))
                    countText.text = MemoryCache.getLabelText("s_invoice_status_$key")
                    val currencyStr = currency + " " +
                            IndiaNumberUtil.formatNumByDecimal(totalValue.toString(), currency)
                    currencyText.text = currencyStr
                    llInvoiceSummaryPointContainer.addView(view)
                }
            }
        }
    }

    private fun getInvoiceColor(s: String): Int {
        return context?.let {
            when (s) {
                "U" -> ContextCompat.getColor(it, R.color.c_ring_invoice_unpaid)
                "P" -> ContextCompat.getColor(it, R.color.c_ring_invoice_partially)
                "F" -> ContextCompat.getColor(it, R.color.c_ring_invoice_paid)
                "O" -> ContextCompat.getColor(it, R.color.c_ring_invoice_over_paid)
                else -> 0xFFFFFF
            }
        } ?: 0xFFFFFF
    }

    /**
     * restore adapter from presenter
     */
    override fun restoreAdapter(adapter: InvoiceListAdapter) {
        mAdapter = adapter
        screenPageItemSize = (rvContentList?.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()
    }

    /**
     * show invoice list
     */
    override fun updateTodayInvoiceInfo(invoiceCount: Int, invoiceAmount: Double, currency: String) {
        val invoiceNumStr = "$invoiceCount Invoices"
        tvTodayInvoiceCount?.text = invoiceNumStr
        val invoiceAmountStr = "$currency $invoiceAmount"
        tvTodayInvoiceAmount?.text = invoiceAmountStr
    }

    /**
     * search function
     */
    override fun onSearchTextChanged(searchText: String?) {
        setRefreshing(true)
//        mPresenter.getUploadParameter().search = searchText
        mViewModel.getUploadParameter().search = searchText
        mViewModel.doRequest(isLoadMore = false, isSelectable = false)
//        mPresenter.getInvoiceList(false, isSelectable = false)
    }

    override fun reAddScrollListener(isAdd: Boolean) {
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            if (!isRefreshing) {
                setRefreshing(true)
                if (requestCode == REQUEST_CODE_INVOICE_FILTER) {
                    currentCountryCode = data?.getStringExtra(TAG_INVOICE_FILTER_COUNTRY_CODE_RESULT)
                    if (currentCountryCode.isNullOrBlank()) {
                        currentCountryCode = MemoryCache.defaultCountry
                    }
                }
//                mPresenter.obtainActivityResult(requestCode, resultCode, data)
                mViewModel.setUploadParameter(data?.getSerializableExtra(TAG_INVOICE_FILTER_PARAMETER_RESULT) as InvoiceRequestParameter)
                mViewModel.doRequest(isLoadMore = false, isSelectable = false)
            }
        }
    }

    /**
     * show has data or not
     */
    override fun showData(isHasData: Boolean) {
        if (loadingView.visibility == View.VISIBLE) {
            loadingView.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete") ?: getString(R.string.talkBack_loading_complete))
            loadingView.visibility = View.GONE
        }
        setRefreshing(false)
        if (isHasData) {
            tvNoData?.visibility = View.GONE
            rvContentList?.visibility = View.VISIBLE
            if ("B" == MemoryCache.getSessionEntity()?.type) {
                llInvoiceSummaryContainer.visibility = View.VISIBLE
            } else {
                llInvoiceSummaryContainer.visibility = View.GONE
            }
        } else {
            tvNoData?.visibility = View.VISIBLE
            rvContentList?.visibility = View.GONE
            rvInvoiceSummaryChart.setData(mutableListOf())
            llInvoiceSummaryContainer.visibility = View.GONE
        }
    }

    fun endRefreshing() {
        srlContentRefresher?.isRefreshing = false
    }

    private fun setRefreshing(refreshingState: Boolean) {
//        if (!isInit) {
        if (refreshingState) {
            srlContentRefresher?.announceForAccessibility(MemoryCache.getLabelText("s_loading") ?: getString(R.string.s_loading))
        } else {
            srlContentRefresher?.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete") ?: getString(R.string.talkBack_loading_complete))
        }
        isRefreshing = refreshingState
        srlContentRefresher?.isRefreshing = refreshingState
//        }
    }

    private fun calculateRingChartAmount(isNormal: Boolean) {
        var unpaidAmount = 0L
        var partiallyAmount = 0L
        var paidedAmount = 0L
        var overpaidAmount = 0L
        var totalAmount = 0L
        val currentList = mAdapter?.getData()
        var currency  = ""
        currentList?.let {
            currency = it[0].invoice?.summation?.total?.currency ?: ""
            for (item in it) {
                if (item.invoice?.status != "C") {
                    if (isNormal) {
                        item.invoice?.summation?.total?.amount?.let { amount ->
                            totalAmount += amount.toLong()
                        }
                    } else {
                        if ("U" == item.invoice?.status || "P" == item.invoice?.status) {
                            item.invoice.summation?.outstanding?.amount?.let { amount ->
                                totalAmount += amount.toLong()
                            }
                        }
                    }
                }

                when (item.invoice?.status) {
                    "U" -> {
                        if (isNormal) {
                            item.invoice.summation?.total?.amount?.let { amount ->
                                unpaidAmount += amount.toLong()
                            }
                        } else {
                            item.invoice.summation?.outstanding?.amount?.let { amount ->
                                unpaidAmount += amount.toLong()
                            }
                        }
                    }
                    "P" -> {
                        if (isNormal) {
                            item.invoice.summation?.total?.amount?.let { amount ->
                                partiallyAmount += amount.toLong()
                            }
                        } else {
                            item.invoice.summation?.outstanding?.amount?.let { amount ->
                                partiallyAmount += amount.toLong()
                            }
                        }
                    }
                    "F" -> {
                        if (isNormal) {
                            item.invoice.summation?.total?.amount?.let { amount ->
                                paidedAmount += amount.toLong()
                            }
                        } else {
                            item.invoice.summation?.outstanding?.amount?.let { amount ->
                                paidedAmount += amount.toLong()
                            }
                        }
                    }
                    "O" -> {
                        if (isNormal) {
                            item.invoice.summation?.total?.amount?.let { amount ->
                                overpaidAmount += amount.toLong()
                            }
                        } else {
                            item.invoice.summation?.outstanding?.amount?.let { amount ->
                                overpaidAmount += amount.toLong()
                            }
                        }
                    }

                }
            }

            updateRingData(unpaidAmount, partiallyAmount, if (isNormal) paidedAmount else 0L, if (isNormal) overpaidAmount else 0L, totalAmount, currency, !isNormal)
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:invoices:all invoices",
                "/dart/buyer-portal/invoices/all-invoices", "payment", "buyer portal",
                "invoices")
    }
}