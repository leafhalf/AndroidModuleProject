/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.home

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.preference.PreferenceManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_NOTIFICATION_POSITIVE
import hk.com.hsbc.glcmdart.domain.calendar.CalendarFragment
import hk.com.hsbc.glcmdart.domain.creditnote.CreditNoteFragment
import hk.com.hsbc.glcmdart.domain.dart.CommonDialog
import hk.com.hsbc.glcmdart.domain.dashboard.ChartFragment
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListFragment
import hk.com.hsbc.glcmdart.domain.login.LoginActivity
import hk.com.hsbc.glcmdart.domain.more.MoreFragment
import hk.com.hsbc.glcmdart.domain.payments.PaymentsFragment
import hk.com.hsbc.glcmdart.domain.tutorial.BUYER_TUTORIAL_PAGE
import hk.com.hsbc.glcmdart.domain.tutorial.BuyerTutorial1stActivity
import hk.com.hsbc.glcmdart.domain.tutorial.SUPPLIER_TUTORIAL_PAGE
import hk.com.hsbc.glcmdart.domain.tutorial.SupplierTutorial1stActivity
import hk.com.hsbc.glcmdart.extension.addStatusViewWithColor
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.extension.showLongToast
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.view_custom_title_bar.*

class HomeActivity : BaseActivity(), HomeContract.View, View.OnClickListener {

    //    private var chartFragment: ChartFragment? = null onSearchTextChanged
    private lateinit var invoicesFragment: InvoiceListFragment
    private lateinit var paymentsFragment: PaymentsFragment
    //    private var calendarFragment: CalendarFragment? = null
    private lateinit var creditNoteFragment: CreditNoteFragment
    private lateinit var moreFragment: MoreFragment
//    internal val mPresenter by lazy { HomePresenter() }
    private lateinit var fragments: Array<Fragment>
    private var lastShowFragment = 0
    private var isPaddingStatusBar = true
    private val loginType = MemoryCache.getSessionEntity()?.type
    private lateinit var mainFragment: Fragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        addStatusViewWithColor(this, Color.BLACK)
        initFragment()
        initBottomNavigationView()
//        createPresenter()

        bottomNavigationView.menu.getItem(0).icon = if ("S" == MemoryCache.getSessionEntity()?.type) {
            ContextCompat.getDrawable(this, R.drawable.icon_home)
        } else {
            ContextCompat.getDrawable(this, R.drawable.icon_calendar)
        }

        bottomNavigationView.menu.getItem(0).title = if ("S" == MemoryCache.getSessionEntity()?.type) {
            MemoryCache.getLabelText("navigation_home_title") ?: getString(R.string.navigation_home_title)
        } else {
            MemoryCache.getLabelText("navigation_calendar_title") ?: getString(R.string.navigation_calendar_title)
        }

        bottomNavigationView.selectedItemId = R.id.navigation_calendar

        if (getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).getBoolean("notificationTipShow", true) &&
                "B" == MemoryCache.getSessionEntity()?.type) {
            CommonDialog.showDialog(this, MemoryCache.getLabelText("s_notification_tip_dialog_title") ?: getString(R.string.s_notification_tip_dialog_title),
                    MemoryCache.getLabelText("s_notification_tip_dialog_message") ?: getString(R.string.s_notification_tip_dialog_message),
                    MemoryCache.getLabelText("s_notification_dialog_confirm") ?: getString(R.string.s_notification_dialog_confirm),
                    MemoryCache.getLabelText("s_notification_tip_dialog_negative") ?: getString(R.string.s_notification_tip_dialog_negative), View.OnClickListener {
                TealiumUtil.eventTag("button click", "notification overlay: go to setting")
                openSetting()
            }, View.OnClickListener {
                TealiumUtil.eventTag("button click", "notification overlay: no thanks")
            })
            TealiumUtil.pageTag("dart:buyer portal:home:notification overlay",
                    "/dart/buyer-portal/home/notification-overlap",
                    "other", "buyer portal", "home")
            getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).edit().putBoolean("notificationTipShow", false).apply()
        }
        openTutorialActivity()

//        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1520, NotificationHelper(this).getNotification1("Test", "TestContent").build())
    }

    private fun openSetting() {
        val pkg = applicationContext.packageName
        val uid = applicationInfo.uid
        try {
            val intent = Intent().apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    action = Settings.ACTION_APP_NOTIFICATION_SETTINGS
                    putExtra(Settings.EXTRA_APP_PACKAGE, pkg)
                    putExtra(Settings.EXTRA_CHANNEL_ID, uid)
                }

                putExtra("app_package", pkg)
                putExtra("app_uid", uid)
            }

            startActivityForResult(intent, REQUEST_CODE_NOTIFICATION_POSITIVE)
        } catch (e: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS)
            startActivityForResult(intent, REQUEST_CODE_NOTIFICATION_POSITIVE)
        }
    }

//    private fun createPresenter() {
//        registerPresenter(mPresenter as IPresenter<*>)
//    }

    private fun initFragment() {
        mainFragment = if (loginType == "S") {
            removeStatusView(this)
            ChartFragment.newInstance()
        } else {
            CalendarFragment.newInstance("", "")
        }
        invoicesFragment = InvoiceListFragment.newInstance()
        paymentsFragment = PaymentsFragment.newInstance("", "")
        creditNoteFragment = CreditNoteFragment.newInstance()
        moreFragment = MoreFragment.newInstance()
        fragments = arrayOf(mainFragment, invoicesFragment, paymentsFragment, creditNoteFragment, moreFragment)
        supportFragmentManager
                .beginTransaction()
                .add(R.id.fl_container, mainFragment)
                .show(mainFragment)
                .commit()

        tv_title.text = MemoryCache.getLabelText("actionbar_calendar_title") ?: getString(R.string.actionbar_calendar_title)
        v_customer_title.visibility = if ("S" == MemoryCache.getSessionEntity()?.type) {
            isPaddingStatusBar = false
            View.GONE
        } else {
            View.VISIBLE
        }
        iv_search_close_or_search.setOnClickListener {
            if (et_search.text.toString().isBlank()) {
                et_search.text = null
                tv_back.visibility = View.VISIBLE
                et_search.visibility = View.VISIBLE
                tv_title.visibility = View.GONE
                iv_search_close_or_search.visibility = View.GONE
                val imm = it.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.toggleSoftInput(0, 0)
                et_search.requestFocus()
            } else {
                et_search.text = null
                when(lastShowFragment) {
                    0 -> {}
                    1 -> { TealiumUtil.eventTag("button click", "landing - invoices: clear search") }
                    2 -> {
                        paymentsFragment.clearSearchEditText()
                        TealiumUtil.eventTag("button click", "landing - planned payments: clear search")
                    }
                    3 -> {
                        creditNoteFragment.changeSearchText("")
                    }
                }
                iv_search_close_or_search.visibility = View.GONE
            }
        }

        et_search.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                if (et_search.text.toString().length < 3 && et_search.text.toString().isNotBlank()) {
                    Toast.makeText(this,
                            MemoryCache.getLabelText("s_search_input_tip") ?: getString(R.string.s_search_input_tip),
                            Toast.LENGTH_SHORT).show()
                    return@setOnEditorActionListener false
                }

                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.toggleSoftInput(0, 0)
                when (lastShowFragment) {
                    1 -> {
                        TealiumUtil.eventTag("text entry", "landing - invoices: search bar entered")
                        invoicesFragment.changeSearchText(v?.text.toString())
                    }

                    2 -> {
                        TealiumUtil.eventTag("text entry", "landing - planned payments: search bar entered")
                        paymentsFragment.changeSearchText(v?.text.toString())
                    }

                    3 -> {
                        TealiumUtil.eventTag("text entry", "landing - credit notes: search bar entered")
                        creditNoteFragment.changeSearchText(v?.text.toString())
                    }
                }
            }
            false
        }

        et_search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s.isNullOrEmpty()) {
                    iv_search_close_or_search.visibility = View.GONE
                } else {
                    iv_search_close_or_search.visibility = View.VISIBLE
                    iv_search_close_or_search.setBackgroundResource(R.drawable.ic_close_white)
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

        })

        tv_back.setOnClickListener {
            if (et_search.text.toString().isEmpty()) {
                et_search.visibility = View.GONE
                tv_back.visibility = View.GONE
                tv_title.visibility = View.VISIBLE
                iv_search_close_or_search.visibility = View.VISIBLE
                iv_search_close_or_search.setBackgroundResource(R.drawable.ic_search)
                val imm = it.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(it.windowToken, 0)
                when (lastShowFragment) {
                    1 -> {
                        TealiumUtil.eventTag("text entry", "landing - invoices: search bar entered")
                        invoicesFragment.changeSearchText("")
                    }

                    2 -> {
                        TealiumUtil.eventTag("text entry", "landing - planned payments: search bar entered")
                        paymentsFragment.changeSearchText("")
                    }
                }
            } else {
                et_search.text = null
                if (lastShowFragment == 1) {
                    TealiumUtil.eventTag("button click", "landing - invoices: clear search")
                } else {
                    TealiumUtil.eventTag("button click", "landing - planned payments: clear search")
                }
                iv_search_close_or_search.visibility = View.GONE
            }
        }
//        title = getString(R.string.actionbar_invoices_title)
    }

    private fun initBottomNavigationView() {
        MemoryCache.getLabelText("navigation_calendar_title")?.let {
            if (!it.isBlank()) {
                bottomNavigationView.menu.getItem(0).title = it
            }
        }
        MemoryCache.getLabelText("navigation_invoices_title")?.let {
            if (!it.isBlank()) {
                bottomNavigationView.menu.getItem(1).title = it
            }
        }
        MemoryCache.getLabelText("navigation_payments_title")?.let {
            if (!it.isBlank()) {
                bottomNavigationView.menu.getItem(2).title = it
            }
        }
        MemoryCache.getLabelText("navigation_creditnotes_title")?.let {
            if (!it.isBlank()) {
                bottomNavigationView.menu.getItem(3).title = it
            }
        }
        MemoryCache.getLabelText("navigation_more_title")?.let {
            if (!it.isBlank()) {
                bottomNavigationView.menu.getItem(4).title = it
            }
        }
        MemoryCache.getLabelText("s_search")?.let {
            if (!it.isBlank()) {
                et_search.hint = it
            }
        }
        bottomNavigationView.setOnNavigationItemSelectedListener {
            et_search.text = null
            iv_search_close_or_search.setBackgroundResource(R.drawable.ic_search)
            when (it.itemId) {
                R.id.navigation_calendar -> {
                    TealiumUtil.eventTag("button click", "calendar: bottom nav: calendar")
                    if (lastShowFragment != 0) {
                        switchFragment(lastShowFragment, 0)
                        v_customer_title.visibility = if ("S" == MemoryCache.getSessionEntity()?.type) {
                            removeStatusView(this)
                            isPaddingStatusBar = false
                            View.GONE
                        } else {
                            if (!isPaddingStatusBar) {
                                addStatusViewWithColor(this, Color.BLACK)
                                isPaddingStatusBar = true
                            }
                            View.VISIBLE
                        }
                        lastShowFragment = 0

                        tv_title.text = MemoryCache.getLabelText("actionbar_calendar_title") ?: getString(R.string.actionbar_calendar_title)
                        iv_search_close_or_search.visibility = View.GONE
                        et_search.visibility = View.GONE
                    }
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.navigation_invoices -> {
                    TealiumUtil.eventTag("button click", "invoices: bottom nav: invoices")
                    if (lastShowFragment != 1) {
                        switchFragment(lastShowFragment, 1)
                        lastShowFragment = 1
                        v_customer_title.visibility = View.VISIBLE
                        tv_title.text = MemoryCache.getLabelText("actionbar_invoices_title") ?: getString(R.string.actionbar_invoices_title)
                        iv_search_close_or_search.contentDescription = MemoryCache.getLabelText("s_talkback_search_invoice") ?: getString(R.string.s_talkback_search_invoice)
                        et_search.visibility = View.GONE
                        tv_back.visibility = View.GONE
                        tv_title.visibility = View.VISIBLE
                        iv_search_close_or_search.visibility = View.VISIBLE
                        if (!isPaddingStatusBar) {
                            addStatusViewWithColor(this, Color.BLACK)
                            isPaddingStatusBar = true
                        }
                    }
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.navigation_payments -> {
                    TealiumUtil.eventTag("button click", "payments: bottom nav: payments")
                    if (lastShowFragment != 2) {
                        switchFragment(lastShowFragment, 2)
                        lastShowFragment = 2
                        v_customer_title.visibility = View.VISIBLE
                        tv_title.text = MemoryCache.getLabelText("actionbar_payments_title") ?: getString(R.string.actionbar_payments_title)
                        iv_search_close_or_search.contentDescription = MemoryCache.getLabelText("s_talkback_search_payment") ?: getString(R.string.s_talkback_search_payment)
                        et_search.visibility = View.GONE
                        tv_back.visibility = View.GONE
                        tv_title.visibility = View.VISIBLE
                        iv_search_close_or_search.visibility = View.VISIBLE
                        if (!isPaddingStatusBar) {
                            addStatusViewWithColor(this, Color.BLACK)
                            isPaddingStatusBar = true
                        }
                    }

                    return@setOnNavigationItemSelectedListener true
                }
                R.id.navigation_creditnotes -> {
                    TealiumUtil.eventTag("button click", "creditnotes: bottom nav: creditnotes")
                    if (lastShowFragment != 3) {
                        switchFragment(lastShowFragment, 3)
                        lastShowFragment = 3
                        v_customer_title.visibility = View.VISIBLE
                        tv_title.text = MemoryCache.getLabelText("actionbar_creditnotes_title") ?: getString(R.string.actionbar_creditnotes_title)
                        iv_search_close_or_search.contentDescription = MemoryCache.getLabelText("s_talkback_search_credit_note") ?: getString(R.string.s_talkback_search_credit_note)
                        et_search.visibility = View.GONE
                        tv_back.visibility = View.GONE
                        tv_title.visibility = View.VISIBLE
                        iv_search_close_or_search.visibility = View.VISIBLE
                        if (!isPaddingStatusBar) {
                            addStatusViewWithColor(this, Color.BLACK)
                            isPaddingStatusBar = true
                        }
                    }
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.navigation_more -> {
                    TealiumUtil.eventTag("button click", "more: bottom nav: more")
                    if (lastShowFragment != 4) {
                        switchFragment(lastShowFragment, 4)
                        lastShowFragment = 4
                        v_customer_title.visibility = View.GONE
                        tv_title.text = MemoryCache.getLabelText("actionbar_more_title") ?: getString(R.string.actionbar_more_title)
                        iv_search_close_or_search.visibility = View.VISIBLE
                        et_search.visibility = View.GONE
                        removeStatusView(this)
                        isPaddingStatusBar = false
                    }
                    return@setOnNavigationItemSelectedListener true
                }
            }
            false
        }
    }

    override fun onClick(v: View?) {}

    private fun switchFragment(lastIndex: Int, i: Int) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.hide(fragments[lastIndex])
        if (!fragments[i].isAdded) {
            transaction.add(R.id.fl_container, fragments[i])
        }
        transaction.show(fragments[i]).commitAllowingStateLoss()
    }

    fun getCurrentSearchingContent(): String {
        return et_search.text.toString()
    }

    override fun showLogoutView(msg: String) {
        showLongToast(msg)
        startActivity(Intent(this, LoginActivity::class.java).let {
            finish()
            it
        })
    }

    override fun hideLogoutView(msg: String) {
        showLongToast(msg)
    }

    private fun openTutorialActivity() {
        when (MemoryCache.getLoginEntity()?.payload?.SessionInfo?.type) {
            "B" -> {
                if (!PreferenceManager.getDefaultSharedPreferences(applicationContext).getBoolean(BUYER_TUTORIAL_PAGE, false)) {
                    startActivity(Intent(this, BuyerTutorial1stActivity::class.java))
                }
            }
            "S" -> {
                if (!PreferenceManager.getDefaultSharedPreferences(applicationContext).getBoolean(SUPPLIER_TUTORIAL_PAGE, false)) {
                    startActivity(Intent(this, SupplierTutorial1stActivity::class.java))
                }
            }
        }
    }
}
