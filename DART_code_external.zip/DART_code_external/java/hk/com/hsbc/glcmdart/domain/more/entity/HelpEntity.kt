/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more.entity

import androidx.annotation.Keep
import java.io.Serializable

/**
 * Created by Donut on 2018/11/12.
 */
@Keep
data class HelpEntity(val sections: List<Section>)

@Keep
data class Section(
        val title: String?,
        val order:Int,
        val faqs: List<FAQ>?,
        val roles: List<String>?
):Serializable

@Keep
data class FAQ(
        val question: Question,
        val answer: List<Answer>,
        val order: Int,
        val roles: List<String>?
): Serializable

@Keep
data class Question(val text: String?): Serializable

@Keep
data class Answer(
        val type: String?,
        val order: Int,
        val text: String?
): Serializable

@Keep
data class BuyerListEntity(
        val payload: BuyerListPayload?
): Serializable

@Keep
data class BuyerListPayload(
        val buyerRegSummaries: List<BuyerListInfo>?,
        val supplierRegSummaries: List<BuyerListInfo>?
): Serializable

@Keep
data class BuyerListInfo(
        val buyers: List<BuyerOrSupplierInfo>?,
        val orgReference: String?,
        val orgName: String?
): Serializable

@Keep
data class BuyerOrSupplierInfo(
        val userReference: String?,
        val userName: String?,
        val email: String?,
        val inviteSentDate: String?,
        val registrationStatus: String?,
        val activityStatus: String?,
        val country_code: String?,
        val external_reference: String?
): Serializable