/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dart

import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import kotlinx.android.synthetic.main.activity_keyboard.*

class LibraryInjectionActivity : BaseActivity(),
        View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_libraryinjection)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        removeStatusView(this)

        MemoryCache.getLabelText("description_libraryinjection")?.let {
            if (!it.isBlank()) {
                tv_success_title.text = it
            }
        }
        MemoryCache.getLabelText("button_quit")?.let {
            if (!it.isBlank()) {
                quitButton.text = it
            }
        }
        MemoryCache.getLabelText("button_continue")?.let {
            if (!it.isBlank()) {
                continueButton.text = it
            }
        }
        quitButton.setOnClickListener(this)
        continueButton.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v) {
            quitButton -> {
                finish()
                ApplicationManager.exitApplication()
            }
            continueButton -> {
                finish()
            }
        }
    }
}
