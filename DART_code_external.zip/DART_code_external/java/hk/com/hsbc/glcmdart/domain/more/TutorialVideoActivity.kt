package hk.com.hsbc.glcmdart.domain.more

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TUTORIAL_LINK_PREFIX
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.activity_tutorial_video.*

class TutorialVideoActivity: BaseActivity() {

    companion object {

        val TYPE_FIRST_IN = 0
        val TYPE_ONLINE_PAYMENT = 1
        val TYPE_MAKE_PAYMENT = 2

        fun showActivity(c: Context?, tutorialType: Int) {
            val intent = Intent(c, TutorialVideoActivity::class.java)
            intent.putExtra("videoType", tutorialType)
            c?.startActivity(intent)
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tutorial_video)
        title = ""
        initViews()
    }

    private fun initViews() {
        val tutorialType = intent.getIntExtra("videoType", TYPE_FIRST_IN)
        tb_header.setNavigationOnClickListener { finish() }
        val videoId = when(tutorialType) {
            TYPE_FIRST_IN -> {
                tb_header_title.text = MemoryCache.getLabelText("s_tutorial_first") ?: getString(R.string.s_tutorial_first)
                ibtn_play.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_play_circle_outline_black))
                when(MemoryCache.getSessionEntity()?.type) {
                    "B" -> {
                        when(MemoryCache.defaultLanguageFull) {
                            "en-in" -> R.raw.buyer_en
                            "en-id" -> R.raw.buyer_en_id
                            "id-id" -> R.raw.buyer_id
                            else -> 0
                        }
                    }
                    "S" -> {
                        when(MemoryCache.defaultLanguageFull) {
                            "en-in" -> R.raw.supplier_en
                            "en-id" -> R.raw.supplier_en
                            "id-id" -> R.raw.supplier_id
                            else -> 0
                        }
                    }
                    else -> 0
                }
            }
            TYPE_ONLINE_PAYMENT -> {
                tb_header_title.text = MemoryCache.getLabelText("s_tutorial_online_payment") ?: getString(R.string.s_tutorial_online_payment)
                ibtn_play.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_play_circle_outline_white))
                R.raw.online_payment
            }
            TYPE_MAKE_PAYMENT -> {
                tb_header_title.text = MemoryCache.getLabelText("s_tutorial_make_payment") ?: getString(R.string.s_tutorial_make_payment)
                ibtn_play.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_play_circle_outline_white))
                R.raw.make_payment
            }
            else -> 0
        }

        val uri = "android.resource://$packageName/$videoId"
        vv_tutorial.setVideoPath(uri)
        vv_tutorial.setVideoURI(Uri.parse(uri))
        vv_tutorial.start()
        ibtn_play.setOnClickListener {
            vv_tutorial.start()
            ibtn_play.visibility = View.GONE
        }
        vv_tutorial.setOnCompletionListener {
            ibtn_play.visibility = View.VISIBLE
        }
    }

//    private fun initViews() {
//        val tutorialType = intent.getIntExtra("videoType", TYPE_FIRST_IN)
//        tb_header.setNavigationOnClickListener { finish() }
//        val videoId = when(tutorialType) {
//            TYPE_FIRST_IN -> {
//                tb_header_title.text = MemoryCache.getLabelText("s_tutorial_first") ?: getString(R.string.s_tutorial_first)
//                ibtn_play.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_play_circle_outline_black))
//                when(MemoryCache.getSessionEntity()?.type) {
//                    "B" -> {
//                        when(MemoryCache.defaultLanguageFull) {
//                            "en-in" -> "buyer_en"
//                            "en-id" -> "buyer_en_id"
//                            "id-id" -> "buyer_id"
//                            else -> "buyer_en"
//                        }
//                    }
//                    "S" -> {
//                        when(MemoryCache.defaultLanguageFull) {
//                            "en-in" -> "supplier_en"
//                            "en-id" -> "supplier_en"
//                            "id-id" -> "supplier_id"
//                            else -> "supplier_en"
//                        }
//                    }
//                    else -> "buyer_en"
//                }
//            }
//            TYPE_ONLINE_PAYMENT -> {
//                tb_header_title.text = MemoryCache.getLabelText("s_tutorial_online_payment") ?: getString(R.string.s_tutorial_online_payment)
//                ibtn_play.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_play_circle_outline_white))
//                "online_payment"
//            }
//            TYPE_MAKE_PAYMENT -> {
//                tb_header_title.text = MemoryCache.getLabelText("s_tutorial_make_payment") ?: getString(R.string.s_tutorial_make_payment)
//                ibtn_play.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_play_circle_outline_white))
//                "make_payment"
//            }
//            else -> "buyer_en"
//        }
//
//        val countryFolder = when(MemoryCache.defaultCountry) {
//            "IN" -> "IN_tutorial"
//            "ID" -> "ID_tutorial"
//            else -> "IN_tutorial"
//        }
//
//        val uri = "$TUTORIAL_LINK_PREFIX$countryFolder/$videoId.mp4"
////        vv_tutorial.setVideoPath(uri)
//        vv_tutorial.setVideoURI(Uri.parse(uri))
//        vv_tutorial.start()
//        ibtn_play.setOnClickListener {
//            vv_tutorial.start()
//            ibtn_play.visibility = View.GONE
//        }
//        vv_tutorial.setOnCompletionListener {
//            ibtn_play.visibility = View.VISIBLE
//        }
//    }
}