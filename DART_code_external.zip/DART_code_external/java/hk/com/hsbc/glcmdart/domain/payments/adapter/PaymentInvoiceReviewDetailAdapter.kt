/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.content.Context
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import kotlinx.android.synthetic.main.item_warming.view.*
import java.math.BigDecimal

class PaymentInvoiceReviewDetailAdapter(private val context: Context, private val mData: ArrayList<InvoiceAddEntity>) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), RecyclerExtras.OnItemClickListener {
    val inflater: LayoutInflater = LayoutInflater.from(context)

    fun addData(dataList: ArrayList<InvoiceAddEntity>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        notifyDataSetChanged()
    }


    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_payment_invoice_detail, parent, false)
        return ItemHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        MemoryCache.getLabelText("s_amount")?.let {
            if (!it.isBlank()) {
                vh.tvAmountTag.text = it
            }
        }
        MemoryCache.getLabelText("s_cr_note_amount")?.let {
            if (!it.isBlank()) {
                vh.tvCrNoteAmountTag.text = it
            }
        }
        MemoryCache.getLabelText("s_note")?.let {
            if (!it.isBlank()) {
                vh.tvNoteTag.text = it
            }
        }
        MemoryCache.getLabelText("s_view_detail")?.let {
            if (!it.isBlank()) {
                vh.btnViewDetail.text = it
            }
        }

        if (mData[position].active == true) {
            vh.tvRemovedTag.visibility = View.GONE
        } else {
            vh.tvRemovedTag.visibility = View.VISIBLE
        }
        vh.tvTitle.text = mData[position].invoice?.reference
        var amountTmpText = mData[position].invoice?.summation?.outstanding?.currency + " " +
                IndiaNumberUtil.formatNumByDecimal(mData[position].amount.toString(),
                        mData[position].invoice?.summation?.outstanding?.currency
                                ?: MARKET_CURRENCY)
        val decimalSymbol = if (mData[position].invoice?.summation?.outstanding?.currency == "IDR") {
            ","
        } else {
            "."
        }
        val subAmountText = amountTmpText.split(decimalSymbol)
        if (subAmountText.size == 2) {
            if (subAmountText[1].length == 1)
                amountTmpText += "0"
        }
        vh.tvAmount.text = amountTmpText
        if (!TextUtils.isEmpty(mData[position].comment)) {
            vh.rlNote.visibility = View.VISIBLE
            vh.tvNote.text = mData[position].comment
        } else {
            vh.rlNote.visibility = View.GONE
        }

        vh.btnViewDetail.visibility = View.VISIBLE
        vh.btnViewDetail.setOnClickListener { v ->
            MemoryCache.getLabelText("s_talkback_clickable_item")?.let {
                if (!it.isBlank()) {
                    vh.llItem.contentDescription = it + "invoice reference " + mData[position].invoice?.reference
                } else {
                    vh.llItem.contentDescription = context.getString(R.string.s_talkback_clickable_item) + "invoice reference " + mData[position].invoice?.reference
                }
            }
            itemClickListener?.onItemClick(v, position)
        }

        if (!mData[position].creditNotesSelected.isNullOrEmpty()) {
            vh.rlCrNote.visibility = View.VISIBLE
            var totalAmount = 0L
            mData[position].creditNotesSelected?.forEach {
                totalAmount += it.outstanding?.toLong() ?: 0L
            }
            amountTmpText = "${mData[position].invoice?.summation?.outstanding?.currency} -" +
                    IndiaNumberUtil.formatNumByDecimal(totalAmount.toString(),
                            mData[position].invoice?.summation?.outstanding?.currency
                                    ?: MARKET_CURRENCY).replace("-", "")
            val subCRAmountText = amountTmpText.split(decimalSymbol)
            if (subCRAmountText.size == 2) {
                if (subCRAmountText[1].length == 1)
                    amountTmpText += "0"
            }
            vh.tvCrAmount.text = amountTmpText
        } else {
            vh.rlCrNote.visibility = View.GONE
        }


        if (!mData[position].taxDeductionSelected.isNullOrEmpty()) {
            vh.llDeduction.visibility = View.VISIBLE
            var totalAmount = 0.0
            vh.llDeductionRejectedContainer.removeAllViews()
            mData[position].taxDeductionSelected?.forEach {
                totalAmount += (BigDecimal.valueOf(it.maxRate?.toDouble() ?: 0.0) *
                        BigDecimal.valueOf(mData[position].invoice?.summation?.total?.amount?.toDouble() ?: 0.0) /
                        BigDecimal.valueOf(100.0)).toDouble()
                if (it.status == "rejected") {
                    vh.llDeductionRejectedContainer.addView(provideRejectedDeductionsWarming(mData[position].invoice!!, it))
                }
            }
            amountTmpText = "${mData[position].invoice?.summation?.outstanding?.currency} -" +
                    IndiaNumberUtil.formatNumByDecimal(BigDecimal.valueOf(totalAmount).toString(),
                            mData[position].invoice?.summation?.outstanding?.currency
                                    ?: MARKET_CURRENCY).replace("-", "")
            val subCRAmountText = amountTmpText.split(decimalSymbol)
            if (subCRAmountText.size == 2) {
                if (subCRAmountText[1].length == 1)
                    amountTmpText += "0"
            }
            vh.tvDeductionAmount.text = amountTmpText

        } else {
            vh.llDeduction.visibility = View.GONE
        }
    }

    private fun provideRejectedDeductionsWarming(invoice: Invoice, item: TaxDeductionInfo): View {
        return LayoutInflater.from(context).inflate(R.layout.item_warming, null).apply {
            this.tv_warming_content.text = String.format(MemoryCache.getLabelText("s_deduction_rejected_warming") ?:
                    context.getString(R.string.s_deduction_rejected_warming), invoice.summation?.total?.currency,
                    IndiaNumberUtil.formatNumByDecimal(item.actualAmount!!,
                            invoice.summation?.total?.currency ?: MARKET_CURRENCY),
                    invoice.reference, invoice.payee?.name)
        }
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val llItem: LinearLayout = view.findViewById(R.id.ll_item)
        val tvTitle: TextView = view.findViewById(R.id.tv_title)
        val tvAmount: TextView = view.findViewById(R.id.tv_amount)
        val rlCrNote: View = view.findViewById(R.id.rl_cr_note)
        val tvCrAmount: TextView = view.findViewById(R.id.tv_cr_amount)
        val tvDeductionAmount: TextView = view.findViewById(R.id.tv_deduction)
        val llDeduction: View = view.findViewById(R.id.ll_deduction)
        val rlNote: View = view.findViewById(R.id.ll_note)
        val tvNote: TextView = view.findViewById(R.id.tv_note)
        val tvAmountTag: TextView = view.findViewById(R.id.tv_amount_tag)
        val tvCrNoteAmountTag: TextView = view.findViewById(R.id.tv_cr_note_amount_tag)
        val tvNoteTag: TextView = view.findViewById(R.id.tv_note_tag)
        val tvRemovedTag: TextView = view.findViewById(R.id.tv_removed_label)
        val btnViewDetail: Button = view.findViewById(R.id.btn_view_detail)
        val llDeductionRejectedContainer: LinearLayout = view.findViewById(R.id.ll_rejected_deductions_container)
    }

    private var itemClickListener: RecyclerExtras.OnItemClickListener? = null

    fun setOnItemClickListener(listener: RecyclerExtras.OnItemClickListener) {
        this.itemClickListener = listener
    }

    override fun onItemClick(view: View, position: Int) {

    }
}
