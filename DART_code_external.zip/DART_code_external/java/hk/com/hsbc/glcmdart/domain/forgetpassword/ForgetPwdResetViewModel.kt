package hk.com.hsbc.glcmdart.domain.forgetpassword

import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class ForgetPwdResetViewModel: BaseViewModel() {

    private val mModel by lazy { ForgetPwdModel() }

    val resetResultLiveData = MutableLiveData<Boolean>()

    fun resetPassword(passwordResetEntity: RequestResetPasswordEntity, resetToken: String) {
        val disposable = mModel.resetPassword(passwordResetEntity, resetToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    if (it.payload == null) {
                        resetResultLiveData.postValue(false)
                    } else {
                        resetResultLiveData.postValue(it.payload == true)
                    }
                },{
                    resetResultLiveData.postValue(false)
                })
    }
}