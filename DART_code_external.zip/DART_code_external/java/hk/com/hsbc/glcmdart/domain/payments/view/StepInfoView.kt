/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.view

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentCreationActivity.Companion.STEP_FOUR
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentCreationActivity.Companion.STEP_ONE
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentCreationActivity.Companion.STEP_THREE
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentCreationActivity.Companion.STEP_TWO
import kotlinx.android.synthetic.main.view_step_info.view.*

class StepInfoView(context: Context?) : LinearLayout(context) {

    init {
        val mInflater = LayoutInflater.from(context)
        mInflater.inflate(R.layout.view_step_info, this, true)
    }

    @SuppressLint("ResourceAsColor")
    fun setCurrentStep(step: Int) {
        when (step) {
            STEP_ONE -> {
                view_step1.visibility = View.VISIBLE
                view_step2.visibility = View.INVISIBLE
                view_step3.visibility = View.INVISIBLE
                view_step4.visibility = View.INVISIBLE
            }

            STEP_TWO -> {
                view_step1.visibility = View.VISIBLE
                view_step2.visibility = View.VISIBLE
                view_step3.visibility = View.INVISIBLE
                view_step4.visibility = View.INVISIBLE
            }

            STEP_THREE -> {
                view_step1.visibility = View.VISIBLE
                view_step2.visibility = View.VISIBLE
                view_step3.visibility = View.VISIBLE
                view_step4.visibility = View.INVISIBLE
            }

            STEP_FOUR -> {
                view_step1.visibility = View.VISIBLE
                view_step2.visibility = View.VISIBLE
                view_step3.visibility = View.VISIBLE
                view_step4.visibility = View.VISIBLE
            }
        }
    }
}