/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.more.entity.BuyerOrSupplierInfo
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.view.BaseHolder
import kotlinx.android.synthetic.main.activity_suppliers_or_buyers.*
import kotlinx.android.synthetic.main.item_suppliers_or_buyers.view.*

class SuppliersOrBuyersActivity: BaseActivity(), SupplierOrBuyerContract.View {

    companion object {
        fun showActivity(activity: Activity?) {
            val intent = Intent(activity, SuppliersOrBuyersActivity::class.java)
            activity?.startActivity(intent)
        }
    }

    private var isShowSupplier = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_suppliers_or_buyers)
        isShowSupplier = "B" == MemoryCache.getSessionEntity()?.type
        if (isShowSupplier) {
            tb_head.title = MemoryCache.getLabelText("s_my_suppliers")
                    ?: getString(R.string.s_my_suppliers)
        } else {
            tb_head.title = MemoryCache.getLabelText("s_my_buyers")
                    ?: getString(R.string.s_my_buyers)
        }
        tb_head.setTitleTextColor(Color.WHITE)
        tb_head.setNavigationIcon(R.drawable.ic_arrow_back_white)

        tb_head.setNavigationOnClickListener {
            TealiumUtil.eventTag(
                    "button click",
                    "Supplier: back")
            finish()
        }

            val mAdapter = SuppliersOrBuyersAdapter(if (isShowSupplier) {
                MemoryCache.getOrganisations()?.payload?.payees
            } else {
                MemoryCache.getOrganisations()?.payload?.payors
            }            ?: mutableListOf())
            rv_suppliers_or_buyers.also {
                it.layoutManager = LinearLayoutManager(this@SuppliersOrBuyersActivity, RecyclerView.VERTICAL, false)
                it.adapter = mAdapter
            }
    }

    /**
     * only for data get from api
     */
    override fun updateData(list: List<BuyerOrSupplierInfo>?, hasData: Boolean) {

    }

    override fun onResume() {
        super.onResume()
        if (isShowSupplier) {
            TealiumUtil.pageTag(
                    "dart:buyer portal:more:my suppliers - landing",
                    "/dart/buyer-portal/more/my-suppliers/landing",
                    "landing",
                    "buyer portal",
                    "more")
        }
    }
}

class SuppliersOrBuyersAdapter(private val mList: List<Payee>): RecyclerView.Adapter<SuppliersOrBuyersViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): SuppliersOrBuyersViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_suppliers_or_buyers,viewGroup, false)
        return SuppliersOrBuyersViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    override fun onBindViewHolder(viewHolder: SuppliersOrBuyersViewHolder, position: Int) {
        viewHolder.setData(mList[position], position)
    }
}

class SuppliersOrBuyersViewHolder(itemView: View): BaseHolder<Payee>(itemView) {
    private val tvName = itemView.tv_suppliers_or_buyers_name
    override fun setData(data: Payee, position: Int) {
        val nameText = if (data.account == null) {
            data.name
        } else {
            "${data.name} (${data.account.currency})"
        }
        tvName.text = nameText
        itemView.setOnClickListener {
            SuppliersOrBuyersDetailActivity.showActivity(itemView.context as Activity?, data)
        }
    }
}