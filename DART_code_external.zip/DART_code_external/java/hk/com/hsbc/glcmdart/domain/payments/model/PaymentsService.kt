/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.model

import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.BankCalendarPayload
import hk.com.hsbc.glcmdart.domain.dart.CreditnotesEntity
import hk.com.hsbc.glcmdart.domain.dart.PaymentMethodPayload
import hk.com.hsbc.glcmdart.domain.dart.ResponseResultPayload
import hk.com.hsbc.glcmdart.domain.payments.model.bean.*
import io.reactivex.Observable
import okhttp3.RequestBody
import retrofit2.http.*

interface PaymentsService {

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST(URL_PLANNED_PAYMENT_LIST)
    fun getPlannedPaymentList(@Body body: RequestBody): Observable<PlannedPaymentListPayload>

    /**
     * this method support Supplier/Tracking Id filter
     */
    @POST("$URL_PLANNED_PAYMENT_LIST/{filter}")
    fun getPlannedPaymentListByFilter(@Path("filter") filter: String): Observable<PaymentDetailEntityPayload>

    @POST(URL_PLANNED_PAYMENT_LIST)
    fun createPlannedPayment(@Body body: Map<String, String?>): Observable<PlannedPaymentListPayload>


    @GET("$URL_PAYMENT_METHODS/{payee}/{country}/{defaultCurrency}")
    fun getPaymentMethods(@Path("payee") payee: String?, @Path("country") country: String?, @Path("defaultCurrency") currency: String?): Observable<PaymentMethodPayload>

    @GET("$URL_BANK_CALENDAR/{countryCode}")
    fun getBankCalendar(@Path("countryCode") countryCode: String?): Observable<BankCalendarPayload>

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST(URL_ITP_VALIDATE)
    fun validateItp(@Body body: RequestBody): Observable<ResponseResultPayload>

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST(URL_CREATE_ITP)
    fun createItp(@Body body: RequestBody): Observable<PlannedPaymentPayload>

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST(URL_CREDIT_NOTES)
    fun creditnotes(@Body body: RequestBody): Observable<CreditnotesEntity>

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST("$URL_ITP_REVOKE/{token}")
    fun itpRevoke(@Path("token") token: String, @Body body: RequestBody): Observable<RevokePayload>

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST("$URL_UPDATE_ITP/{token}")
    fun updateItp(@Path("token") token: String, @Body body: RequestBody): Observable<PaymentDetailEntityPayload>

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST(URL_PAYMENT_GATEWAY_REDIRECT)
    fun getGatewayHtml(@Path("token")token: String): Observable<PaymentPayInfo>

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST(URL_PAYMENT_GATEWAY_TRACK)
    fun trackPayment(@Path("token")token: String): Observable<PaymentTrackPayload>

    @Headers("Content-Type: application/json", "Accept: */*")
    @GET(URL_GET_DEDUCTION_LIST)
    fun getDeductions(@Path("payeeReference") payeeRef: String, @Path("countryCode") countryCode: String,
        @Path("payeeAccountRef") payeeAccountRef: String): Observable<TaxDeductionPayload>
}