/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.login

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.fragment_locked.*

class LockedFragment constructor(context: Context): Dialog(context), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.fragment_locked)

        deleteButton.setOnClickListener(this)
        returnButton.setOnClickListener(this)

        TealiumUtil.pageTag(
                "dart:buyer portal:logon:account locked",
                "/dart/buyer-portal/logon/account-locked",
                "en",
                "authentication",
                "buyer portal",
                "logon"
        )
    }

    override fun onClick(v: View?) {
        when (v) {
            deleteButton -> {
                TealiumUtil.eventTag(
                        "content",
                        "button click",
                        "dart - account locked: close"
                )
                dismiss()
            }
            returnButton -> {
                TealiumUtil.eventTag(
                        "content",
                        "button click",
                        "dart - account locked: return"
                )
                dismiss()
            }
        }
    }
}

