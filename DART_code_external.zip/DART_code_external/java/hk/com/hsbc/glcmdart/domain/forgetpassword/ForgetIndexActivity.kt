/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.forgetpassword

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_FORGET_TYPE_FLAG
import hk.com.hsbc.glcmdart.domain.registration.RegisterMainActivity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_forget_index.*

class ForgetIndexActivity: BaseActivity(), View.OnClickListener {

    companion object {
        fun showActivity(activity: Activity, isForgetUserName: Boolean = false) {
            activity.startActivity(Intent(activity, ForgetIndexActivity::class.java).apply {
                putExtra(TAG_FORGET_TYPE_FLAG, isForgetUserName)
            })
        }
    }

    private var isForgetUserNameFlag = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_index)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(true, this)
        isForgetUserNameFlag = intent?.getBooleanExtra(TAG_FORGET_TYPE_FLAG, false)!!
        initViewAndData()
    }

    private fun initViewAndData() {
        if (isForgetUserNameFlag) {
            MemoryCache.getLabelText("s_about_username")?.let {
                if (!it.isBlank()) {
                    tv_forget_index_title.text = it
                } else {
                    tv_forget_index_title.text = getString(R.string.s_about_username)
                }
            }
            MemoryCache.getLabelText("s_forget_username_tip")?.let {
                if (!it.isBlank()) {
                    tv_forget_index_tip.text = it
                } else {
                    tv_forget_index_tip.text = getString(R.string.s_forget_username_tip)
                }
            }
            MemoryCache.getLabelText("s_forget_username_operation_tip")?.let {
                if (!it.isBlank()) {
                    tv_forget_index_operation_tip.text = it
                } else {
                    tv_forget_index_operation_tip.text = getString(R.string.s_forget_username_operation_tip)
                }
            }
            MemoryCache.getLabelText("s_forget_username_operation")?.let {
                if (!it.isBlank()) {
                    tv_forget_index_operation.text = it
                } else {
                    tv_forget_index_operation.text = getString(R.string.s_forget_username_operation)
                }
            }
            tv_forget_index_cancel.visibility = View.GONE
        } else {
            MemoryCache.getLabelText("s_about_password")?.let {
                if (!it.isBlank()) {
                    tv_forget_index_title.text = it
                }
            }
            MemoryCache.getLabelText("s_forget_password_tip")?.let {
                if (!it.isBlank()) {
                    tv_forget_index_tip.text = it
                }
            }
            MemoryCache.getLabelText("s_forget_password_operation_tip")?.let {
                if (!it.isBlank()) {
                    tv_forget_index_operation_tip.text = it
                }
            }
            MemoryCache.getLabelText("s_forget_password_operation")?.let {
                if (!it.isBlank()) {
                    tv_forget_index_operation.text = it
                }
            }
        }
        MemoryCache.getLabelText("s_talkback_close_button")?.let {
            if (!it.isBlank()) {
                iv_forget_index_close.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_reset_password")?.let {
            if (!it.isBlank()) {
                tv_forget_index_operation.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_cancel")?.let {
            if (!it.isBlank()) {
                tv_forget_index_cancel.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_cancel")?.let {
            if (!it.isBlank()) {
                tv_forget_index_cancel.contentDescription = it
            }
        }
        ll_top.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)
        tv_forget_index_operation.setOnClickListener(this)
        iv_forget_index_close.setOnClickListener(this)
        tv_forget_index_cancel.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.iv_forget_index_close -> {
                TealiumUtil.eventTag(
                        "button click",
                        "${if (isForgetUserNameFlag) { "recover username: landing" } else { "recover password landing" }}: close"
                )
                finish()
            }
            R.id.tv_forget_index_operation -> {
                if (isForgetUserNameFlag) {
                    TealiumUtil.eventTag(
                            "button click",
                            "about username: got it"
                    )
                    RegisterMainActivity.showActivity(this, true)
                } else {
                    TealiumUtil.eventTag(
                            "button click",
                            "about password: reset password"
                    )
                    ForgetPwdMainActivity.showActivity(this)
                }
            }
            R.id.tv_forget_index_cancel -> {
                TealiumUtil.eventTag(
                        "button click",
                        "recover password landing: cancel"
                )
                finish()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (isForgetUserNameFlag) {
            TealiumUtil.pageTag("dart : buyer portal : recover username : landing",
                    "/dart/buyer portal/recover username/landing", "verification", "buyer portal",
                    "recover username")
        } else {
            TealiumUtil.pageTag("dart : buyer portal : recover password : landing",
                    "/dart/buyer portal/recover password/landing", "verification", "buyer portal",
                    "recover password")
        }
    }
}

