/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.dashboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_HOME_ACCOUNTS
import hk.com.hsbc.glcmdart.client.TAG_HOME_FILTER_RESULT
import hk.com.hsbc.glcmdart.client.TAG_HOME_PARAMETER
import hk.com.hsbc.glcmdart.domain.dart.Account
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ConvertUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import kotlinx.android.synthetic.main.activity_chart_filter.*
import kotlinx.android.synthetic.main.item_home_filter_account.view.*

class ChartFilterActivity : BaseActivity(), CompoundButton.OnCheckedChangeListener, View.OnClickListener {

    companion object {
        fun showActivity(fragment: Fragment, accounts: MutableList<Account>?, originParameter: HashMap<String, Any>?, requestCode: Int) {
            val intent = Intent(fragment.activity, ChartFilterActivity::class.java).apply {
                putExtra(TAG_HOME_ACCOUNTS, accounts as ArrayList<String>)
                putExtra(TAG_HOME_PARAMETER, originParameter)
            }
            fragment.startActivityForResult(intent, requestCode)
        }
    }

    private var uploadParameterShadow = HashMap<String, Any>()
    private lateinit var originBuyerFilter: MutableList<String>
    private var originAccounts = mutableListOf<Account>()
    private var accountsList = mutableListOf<String>()
    private var totalAccountList = mutableListOf<Account>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chart_filter)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(true, this)
        ll_chart_filter_title_container.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)
        supportActionBar?.hide()
        initEventAndData()
    }

    private var lastRadioButton: RadioButton? = null

    private fun initEventAndData() {
        MemoryCache.getLabelText("s_talkback_close_button")?.let {
            if (!it.isBlank()) {
                iv_chart_filter_close.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_filters")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_title.text = it
            }
        }
        MemoryCache.getLabelText("s_reset")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_reset.text = it
            }
        }
        MemoryCache.getLabelText("s_currency")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_currency_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_account")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_account_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_any")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_issue_date_any_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_any_date")?.let {
            if (!it.isBlank()) {
                rb_chart_filter_date_any.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_talkback_select_issue_date")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_issue_date_select_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_select_date")?.let {
            if (!it.isBlank()) {
                rb_chart_filter_date_issue_select.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_from")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_date_issue_from_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_choose_date_from")?.let {
            if (!it.isBlank()) {
                iv_chart_filter_date_issue_from_icon.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_to")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_date_issue_to_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_choose_date_to")?.let {
            if (!it.isBlank()) {
                iv_chart_filter_date_issue_to_icon.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_apply_filter")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_set.text = it
            }
        }
        MemoryCache.getLabelText("s_issue_date")?.let {
            if (!it.isBlank()) {
                tv_chart_filter_issue_date_tag.text = it
            }
        }

        tv_chart_filter_date_issue_from.background = null
        tv_chart_filter_date_issue_to.background = null
        (intent?.getSerializableExtra(TAG_HOME_PARAMETER) as HashMap<String, Any>?)?.let {
            uploadParameterShadow = it
            accountsList.addAll(it["accounts"] as ArrayList<String>)
            val localBuyers = it["buyers"]
            originBuyerFilter = if (localBuyers == null) {
                mutableListOf()
            } else {
                localBuyers as MutableList<String>
            }
        }
        (intent?.getSerializableExtra(TAG_HOME_ACCOUNTS) as ArrayList<Account>?)?.let {
            totalAccountList.addAll(it)
        }

        uploadParameterShadow.also {
                rb_chart_filter_date_any.isChecked = false
                rb_chart_filter_date_issue_select.isChecked = true
                lastRadioButton = rb_chart_filter_date_issue_select
                tv_chart_filter_date_issue_from.text = if ((it["minDate"] as String?).isNullOrEmpty()) {
                    MemoryCache.getLabelText("s_select_date")
                            ?: getString(R.string.s_select_date)
                } else {
                    TimeZoneTransformsUtil.formatTime(it["minDate"] as String)
                }
                tv_chart_filter_date_issue_to.text = if ((it["maxDate"] as String?).isNullOrEmpty()) {
                    MemoryCache.getLabelText("s_select_date")
                            ?: getString(R.string.s_select_date)
                } else {
                    TimeZoneTransformsUtil.formatTime(it["maxDate"] as String)
                }
                rl_chart_filter_issue_date_container.visibility = View.VISIBLE
//            when (it["dateField"]) {
//                "issueDate" -> {
//                    rb_chart_filter_date_any.isChecked = false
//                    rb_chart_filter_date_issue_select.isChecked = true
//                    lastRadioButton = rb_chart_filter_date_issue_select
//                    tv_chart_filter_date_issue_from.text = if ((it["minDate"] as String?).isNullOrEmpty()) {
//                        MemoryCache.getLabelText("s_select_date")
//                                ?: getString(R.string.s_select_date)
//                    } else {
//                        TimeZoneTransformsUtil.formatTime(it["dateFrom"] as String)
//                    }
//                    tv_chart_filter_date_issue_to.text = if ((it["dateTo"] as String?).isNullOrEmpty()) {
//                        MemoryCache.getLabelText("s_select_date")
//                                ?: getString(R.string.s_select_date)
//                    } else {
//                        TimeZoneTransformsUtil.formatTime(it["dateTo"] as String)
//                    }
//                    rl_chart_filter_issue_date_container.visibility = View.VISIBLE
//                }
//                else -> {
//                    rb_chart_filter_date_any.isChecked = true
//                    lastRadioButton = rb_chart_filter_date_any
//                    tv_chart_filter_date_issue_from.text = MemoryCache.getLabelText("s_select_date")
//                            ?: getString(R.string.s_select_date)
//                    tv_chart_filter_date_issue_to.text = MemoryCache.getLabelText("s_select_date")
//                            ?: getString(R.string.s_select_date)
//                }
//            }
        }

        rb_chart_filter_date_any.setOnCheckedChangeListener(this)
        rb_chart_filter_date_issue_select.setOnCheckedChangeListener(this)
        tv_chart_filter_set.setOnClickListener(this)
        tv_chart_filter_date_issue_from.setOnClickListener(this)
        tv_chart_filter_date_issue_to.setOnClickListener(this)
        iv_chart_filter_date_issue_from_icon.setOnClickListener(this)
        iv_chart_filter_date_issue_to_icon.setOnClickListener(this)
        iv_chart_filter_close.setOnClickListener(this)
        tv_chart_filter_reset.setOnClickListener(this)

        val ifInitAccountEmpty = accountsList.isEmpty()
        for (item in totalAccountList) {
            val checked = if (ifInitAccountEmpty && item.currency == uploadParameterShadow["currency"]) {
                true
            } else {
                var hasItem = false
                for (accountItem in accountsList) {
                    if (accountItem == item.display) {
                        hasItem = true
                        break
                    }
                }
                hasItem
            }
            if (ifInitAccountEmpty && item.currency == uploadParameterShadow["currency"]) {
                accountsList.add(item.display ?: "no name")
            }
            ll_chart_filter_account_container.addView(provideAccountCheckView(item.display
                    ?: "no name", item.currency ?: "no currency",
                    checked,
                    item.currency == uploadParameterShadow["currency"]))
        }

//        if (accountsList.isEmpty()) {
//            uploadParameterShadow["accounts"] = defaultAccounts
//        }
        addCurrencySelections()
    }

    override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
        when (buttonView?.id) {
            //any time radio box
            R.id.rb_chart_filter_date_any -> {
                if (isChecked) {
                    resetLastRadioButton()
                    rl_chart_filter_issue_date_container.visibility = View.GONE
                    uploadParameterShadow["dateField"] = ""
                    uploadParameterShadow["dateFrom"] = ""
                    uploadParameterShadow["dateTo"] = ""
                    lastRadioButton = rb_chart_filter_date_any
                }
            }
            //issue date DIY date radio box
            R.id.rb_chart_filter_date_issue_select -> {
                if (isChecked) {
                    resetLastRadioButton()
                    rl_chart_filter_issue_date_container.visibility = View.VISIBLE
                    uploadParameterShadow["dateField"] = "issueDate"
                    lastRadioButton = rb_chart_filter_date_issue_select
                } else {
                    rl_chart_filter_issue_date_container.visibility = View.GONE
                    tv_chart_filter_date_issue_from.text = MemoryCache.getLabelText("s_select_date")
                            ?: getString(R.string.s_select_date)
                    tv_chart_filter_date_issue_to.text = MemoryCache.getLabelText("s_select_date")
                            ?: getString(R.string.s_select_date)
                }
            }
            else -> {
                if (isChecked) {
                    accountsList.add(buttonView?.tag as String)
                    tv_chart_filter_set.isEnabled = true
                    tv_chart_filter_set.setBackgroundColor(ContextCompat.getColor(this@ChartFilterActivity, R.color.primary_red))
                } else {
                    accountsList.remove(buttonView?.tag as String)
                    if (accountsList.isNullOrEmpty()) {
                        tv_chart_filter_set.isEnabled = false
                        tv_chart_filter_set.setBackgroundColor(ContextCompat.getColor(this@ChartFilterActivity, R.color.light_gray))
                    }
                }
            }
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tv_chart_filter_set -> {
                uploadParameterShadow["accounts"] = accountsList
                val resultIntent = Intent().apply {
                    putExtra(TAG_HOME_FILTER_RESULT, uploadParameterShadow)
                }
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            }
            R.id.tv_chart_filter_date_issue_from -> {
                showCalenderDialog(FilterDateDialog.TYPE_ISSUE_DATE_FROM)
            }
            R.id.tv_chart_filter_date_issue_to -> {
                showCalenderDialog(FilterDateDialog.TYPE_ISSUE_DATE_TO)
            }
            R.id.iv_chart_filter_date_issue_from_icon -> {
                showCalenderDialog(FilterDateDialog.TYPE_ISSUE_DATE_FROM)
            }
            R.id.iv_chart_filter_date_issue_to_icon -> {
                showCalenderDialog(FilterDateDialog.TYPE_ISSUE_DATE_TO)
            }
            R.id.iv_chart_filter_close -> {
                finish()
            }
            R.id.tv_chart_filter_reset -> {
                val payeeInfo = uploadParameterShadow["payee_accounts"]
                uploadParameterShadow = HashMap()
                uploadParameterShadow["currency"] = MemoryCache.defaultCurrency ?: "IDR"
                uploadParameterShadow["buyers"] = originBuyerFilter
                payeeInfo?.let {
                    uploadParameterShadow["payee_accounts"] = it
                }
                tv_chart_filter_date_issue_from.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)
                tv_chart_filter_date_issue_to.text = MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date)

//                Log.e("test", "totalList size: ${totalAccountList.size}")
                val defaultAccounts = mutableListOf<Account>()
                addCurrencySelections()
                ll_chart_filter_account_container.removeAllViews()
                accountsList = mutableListOf()
                for (item in totalAccountList) {
                    ll_chart_filter_account_container.addView(provideAccountCheckView(item.display
                            ?: "no name",
                            item.currency ?: "no currency",
                            false,
                            item.currency == uploadParameterShadow["currency"]))
                }
//                rb_chart_filter_date_any.isChecked = true
//                rb_chart_filter_date_issue_select.isChecked = false
//                rl_chart_filter_issue_date_container.visibility = View.GONE
//                tv_chart_filter_date_issue_from.text = MemoryCache.getLabelText("s_select_date")
//                        ?: getString(R.string.s_select_date)
//                tv_chart_filter_date_issue_to.text = MemoryCache.getLabelText("s_select_date")
//                        ?: getString(R.string.s_select_date)
                tv_chart_filter_set.isEnabled = false
                tv_chart_filter_set.setBackgroundColor(ContextCompat.getColor(this@ChartFilterActivity, R.color.light_gray))
            }
        }
    }

    /**
     * do unique chosen
     */
    private fun resetLastRadioButton() {
        if (lastRadioButton != null) {
            lastRadioButton?.setOnCheckedChangeListener(null)
            lastRadioButton?.isChecked = false
            lastRadioButton?.setOnCheckedChangeListener(this)
        }
    }

    /**
     * show dialog when click DIY date of issue or due
     */
    private fun showCalenderDialog(type: Int) {
        val minDate = if (type == FilterDateDialog.TYPE_ISSUE_DATE_TO && tv_chart_filter_date_issue_from.text.toString() != (MemoryCache.getLabelText("s_select_date")
                        ?: getString(R.string.s_select_date))) {
            tv_chart_filter_date_issue_from.text.toString()
        } else {
            tv_chart_filter_date_issue_to.text.toString()
        }

        FilterDateDialog.showDialog(this, type, when (type) {
            FilterDateDialog.TYPE_ISSUE_DATE_FROM -> uploadParameterShadow["minDate"] as String?
            FilterDateDialog.TYPE_ISSUE_DATE_TO -> uploadParameterShadow["maxDate"] as String?
            else -> null
        }, minDate, object : FilterDateDialog.DateConfirmCallback {

            override fun getDate(date: String) {
                when (type) {
                    FilterDateDialog.TYPE_ISSUE_DATE_FROM -> {
                        uploadParameterShadow["minDate"] = date
                        tv_chart_filter_date_issue_from.text = TimeZoneTransformsUtil.formatTime(date)
                    }
                    FilterDateDialog.TYPE_ISSUE_DATE_TO -> {
                        uploadParameterShadow["maxDate"] = date
                        tv_chart_filter_date_issue_to.text = TimeZoneTransformsUtil.formatTime(date)
                    }
                }
            }
        })
    }

    private fun provideAccountCheckView(title: String, currency: String, checked: Boolean, isEnable: Boolean = true): View {
        val view = LayoutInflater.from(this).inflate(R.layout.item_home_filter_account, null)
        val tmpDisplay = "$title $currency"
        view.tv_home_filter_item_title.text = tmpDisplay
        view.cb_home_filter_item_check.isChecked = checked
        view.cb_home_filter_item_check.isEnabled = isEnable
        view.cb_home_filter_item_check.tag = title
        view.cb_home_filter_item_check.setOnCheckedChangeListener(this)
        return view
    }

    private fun addCurrencySelections() {
        ll_currency_filter_tag_container.removeAllViews()
        rg_currency_filter_container.removeAllViews()
        val currencyMap = MemoryCache.getCurrencyMap()
        val currencyMapKeys = currencyMap.keys.toList()
        if (currencyMapKeys.isEmpty() || (currencyMapKeys.size == 1 && (currencyMap[currencyMapKeys[0]]
                        ?: error("")).size <= 1)) {
            tv_chart_filter_currency_tag.visibility = View.GONE
            rl_currency_container.visibility = View.GONE
            v_currency_line.visibility = View.GONE
            return
        }

        currencyMap.forEach(action = {
            it.value.forEach { tagString ->
                val currencyFilterTag = TextView(this@ChartFilterActivity)
                currencyFilterTag.height = ConvertUtil.dp2px(this@ChartFilterActivity, 51.0f * resources.getInteger(R.integer.checker_scale)).toInt()
                currencyFilterTag.gravity = Gravity.CENTER_VERTICAL
                currencyFilterTag.text = tagString
                currencyFilterTag.textSize = 16.0f * resources.getInteger(R.integer.checker_scale)
                ll_currency_filter_tag_container.addView(currencyFilterTag)
                val currencyFilter = LayoutInflater.from(this).inflate(R.layout.item_green_theme_rb, null) as RadioButton
                currencyFilter.height = ConvertUtil.dp2px(this@ChartFilterActivity, 51.0f * resources.getInteger(R.integer.checker_scale)).toInt()
                rg_currency_filter_container.addView(currencyFilter)
                currencyFilter.isChecked = tagString == uploadParameterShadow["currency"]
            }
        })

        rg_currency_filter_container.setOnCheckedChangeListener { group, checkedId ->
            val count = group.childCount
            for (i in 0 until count) {
                val rb = group.getChildAt(i) as RadioButton
                if (rb.isChecked) {
                    accountsList = mutableListOf()
                    tv_chart_filter_set.isEnabled = false
                    tv_chart_filter_set.setBackgroundColor(ContextCompat.getColor(this@ChartFilterActivity, R.color.light_gray))
                    val selectedCurrency = (ll_currency_filter_tag_container.getChildAt(i) as TextView).text
                    uploadParameterShadow["currency"] = selectedCurrency
                    for (j in 0 until ll_chart_filter_account_container.childCount) {
                        if (((ll_chart_filter_account_container.getChildAt(j) as RelativeLayout).getChildAt(0) as TextView).text.endsWith(selectedCurrency)) {
                            ((ll_chart_filter_account_container.getChildAt(j) as RelativeLayout).getChildAt(1) as CheckBox).isEnabled = true
                        } else {
                            ((ll_chart_filter_account_container.getChildAt(j) as RelativeLayout).getChildAt(1) as CheckBox).isChecked = false
                            ((ll_chart_filter_account_container.getChildAt(j) as RelativeLayout).getChildAt(1) as CheckBox).isEnabled = false
                        }
                    }
                    break
                }
            }
        }
    }
}