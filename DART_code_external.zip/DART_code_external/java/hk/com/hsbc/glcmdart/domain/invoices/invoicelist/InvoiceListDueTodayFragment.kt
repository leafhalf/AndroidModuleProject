/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.AppBarLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.domain.home.HomeActivity
import hk.com.hsbc.glcmdart.domain.invoices.invoicedetail.InvoiceDetailActivity
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentCreationActivity
import hk.com.hsbc.glcmdart.util.*
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import hk.com.hsbc.glcmdart.widget.StickyHeaderItemDecoration
import kotlinx.android.synthetic.main.fragment_deal_invoice.view.*
import kotlinx.android.synthetic.main.view_today_invoice_header.view.*
import kotlinx.android.synthetic.main.view_total_invoice_header.view.*
import java.util.*

/**
 * Created by Donut on 2018/11/1.
 *
 * a fragment for showing due invoice, home page or sub-page of calendar
 */
class InvoiceListDueTodayFragment : Fragment(), InvoiceListDueTodayContract.View,
        SwipeRefreshLayout.OnRefreshListener, SearchTextChangeCallback,
        RecyclerExtras.OnItemClickListener, AdvicePaymentCallback {

    //    private val mPresenter = InvoiceListDueTodayPresenter()
    private var mAdapter: InvoiceListDueTodayAdapter? = null
    private var rvContentList: RecyclerView? = null
    private var srlContentRefresher: SwipeRefreshLayout? = null
    private var tvTodayInvoiceCount: TextView? = null
    private var tvTodayInvoiceAmount: TextView? = null
    private var tvNoData: RelativeLayout? = null
    private lateinit var loadingView: ProgressBar
    private var isRefreshing = false
    private lateinit var rootView: View
    private var isFromHome = false
    private var isLocalData = false
    private var currentCountryCode = MemoryCache.defaultCountry
    private lateinit var mViewModel: InvoiceListDueTodayViewModel

    override fun getFragmentActivity(): Activity? {
        return activity
    }

    companion object {
        fun newInstance(isHomePage: Boolean = true, date: String = TimeZoneTransformsUtil.formatParameterTime(Date()), defaultList: ArrayList<InvoiceListItem>? = null): InvoiceListDueTodayFragment = InvoiceListDueTodayFragment().apply {
            arguments = Bundle().apply {
                putString(TAG_INVOICE_DUE_DATE, date)
                putBoolean(TAG_INVOICE_DUE_DATE_HOME_PAGE_FLAG, isHomePage)
                putSerializable(TAG_INVOICE_DUE_DATE_DEFAULT_LIST, defaultList)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        mPresenter.attachView(this)
        isFromHome = arguments?.get(TAG_INVOICE_DUE_DATE_HOME_PAGE_FLAG) as Boolean
        val dueDateStr = arguments?.get(TAG_INVOICE_DUE_DATE) as String
//        mPresenter.setDueDate(dueDateStr)
//        mPresenter.isFromHome = isFromHome
        mViewModel = ViewModelProviders.of(this).get(InvoiceListDueTodayViewModel::class.java)
        mViewModel.setDueDate(dueDateStr)
        mViewModel.isFromHome = isFromHome

        mViewModel.invoiceListLiveData.observe(this, androidx.lifecycle.Observer {
            if (it.isEmpty()) {
                showData(false)
            } else {
                showData(true)
            }
            mAdapter?.setData(it)
        })

        mViewModel.invoiceListSummaryLiveData.observe(this, androidx.lifecycle.Observer {
            updateTodayInvoiceInfo(it[0] as Int, it[1] as Double, it[2] as String)
        })
        mViewModel.requestLoadingLiveData.observe(this, androidx.lifecycle.Observer {
            setRefreshing(it)
        })
        mViewModel.exceptionLiveData.observe(this, androidx.lifecycle.Observer {
            Toast.makeText(activity, it, Toast.LENGTH_SHORT).show()
        })
        //inflate root view
        rootView = inflater.inflate(R.layout.fragment_deal_invoice, container, false)
        //if it's home page, show the summary info for due invoice and supplier filter button, if not, hide them
        if (isFromHome) {
            rootView.v_invoice_sorting_and_filter.iv_filter_condition_entrance.visibility = View.VISIBLE
            rootView.v_invoice_today_list_header.visibility = View.VISIBLE
        } else {
            rootView.v_invoice_sorting_and_filter.iv_filter_condition_entrance.visibility = View.GONE
            rootView.v_invoice_today_list_header.visibility = View.GONE
        }
        rootView.tv_today_invoice_header_date.text = TimeZoneTransformsUtil.formatTime(dueDateStr)
        rootView.v_invoice_sorting_and_filter.iv_sort_condition.visibility = View.GONE
        rootView.v_invoice_sorting_and_filter.v_sort_condition_line.visibility = View.GONE
        tvNoData = rootView.tv_invoice_list_no_data
        rootView.v_invoice_sorting_and_filter.iv_filter_condition_entrance.contentDescription =
                if ("B" == MemoryCache.getSessionEntity()?.type)
                    MemoryCache.getLabelText("s_talkback_invoice_due_filter_buyer")
                            ?: getString(R.string.s_talkback_invoice_due_filter_buyer)
                else
                    MemoryCache.getLabelText("s_talkback_invoice_due_filter_supplier")
                            ?: getString(R.string.s_talkback_invoice_due_filter_supplier)
        rootView.v_invoice_sorting_and_filter.iv_filter_condition_entrance.setOnClickListener {
            if (!FastClickUtil.isFastClick) {
                if (activity != null && !activity?.isFinishing!!) {
                    TealiumUtil.eventTag("button click", "landing - invoices: filter")
                    val filterIntent = Intent(activity, InvoiceListFilterActivity::class.java).apply {
//                        putExtra(TAG_INVOICE_FILTER_PARAMETER, mPresenter.supplyUploadParameter())
                        putExtra(TAG_INVOICE_FILTER_PARAMETER, mViewModel.getUploadParameter())
                        putExtra(TAG_INVOICE_FILTER_FLAG, true)
                    }
                    startActivityForResult(filterIntent, REQUEST_CODE_DUE_INVOICE_FILTER)
                }
            }
        }

        //resolve nest scroll between recycler view and coordination layout
        rootView.abl_title.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { _, verticalOffset ->
            if (!isLocalData) {
                rootView.srf_refresher.isEnabled = verticalOffset >= 0
            }
        })

        //default, outstanding amount is showing
        rootView.v_invoice_sorting_and_filter.sw_outstanding.isChecked = true
        rootView.v_invoice_sorting_and_filter.sw_outstanding.setOnCheckedChangeListener { _, isChecked ->
            TealiumUtil.eventTag("button click", "more invoices due: outstanding amount: ${if (isChecked) "selected" else "unselected"}")
            mAdapter?.isShowDueTodayNormalAmount = isChecked
            rvContentList?.requestLayout()
            mViewModel.changeTotalAmount(isChecked)
//            mPresenter.changeTotalAmount(isChecked)
        }

        tvTodayInvoiceCount = rootView.v_invoice_today_list_header.tv_today_invoice_header_overdue_invoices_num
        tvTodayInvoiceAmount = rootView.v_invoice_today_list_header.tv_today_invoice_header_amount
        mAdapter = InvoiceListDueTodayAdapter(activity!!, mutableListOf())
        mAdapter?.itemClickListener = this
        mAdapter?.mAdvisePaymentCallback = this
        rvContentList = rootView.rv_invoice_list.apply {
            layoutManager = LinearLayoutManager(activity, RecyclerView.VERTICAL, false)
            adapter = mAdapter
        }


        val defaultList = arguments?.getSerializable(TAG_INVOICE_DUE_DATE_DEFAULT_LIST) as ArrayList<InvoiceListItem>?
        if (defaultList == null) {
            //support date selected data, consider if can change to local mode
            srlContentRefresher = rootView.srf_refresher.apply {
                setOnRefreshListener(this@InvoiceListDueTodayFragment)
            }
            loadingView = rootView.pb_loading
            loadingView.visibility = View.VISIBLE
            loadingView.announceForAccessibility(MemoryCache.getLabelText("s_loading")
                    ?: getString(R.string.s_loading))
            mViewModel.getOverdueList(true)
//            mPresenter.getOverdueList(true)
        } else {
            //support local data from calendar
            isLocalData = true
            rootView.srf_refresher.isEnabled = false
            if (defaultList.isNullOrEmpty()) {
                rvContentList?.visibility = View.GONE
                tvNoData?.visibility = View.VISIBLE
            } else {
                val defaultTreeMap = TreeMap<String, HashMap<String, MutableList<InvoiceListNativeEntity>>>()
                val defaultNativeList = mutableListOf<InvoiceListNativeEntity>()
                val defaultTreeMapKeys = defaultTreeMap.keys
                var defaultTreeMapNameKeys: Set<String>
                defaultList.forEach {
                    if (!defaultTreeMapKeys.contains(it.invoice?.dueDate)) {
                        it.invoice?.dueDate?.let { date ->
                            defaultTreeMap[date] = HashMap()
                        }
                    }
                    val nativeItem = InvoiceListNativeEntity(it.token, it.invoice)
                    defaultTreeMapNameKeys = defaultTreeMap[it.invoice?.dueDate]?.keys ?: emptySet()
                    if (!defaultTreeMapNameKeys.contains(it.invoice?.payee?.name)) {
                        defaultTreeMap[it.invoice?.dueDate]?.put(it.invoice?.payee?.name
                                ?: "", mutableListOf())

                    }
                    defaultTreeMap[it.invoice?.dueDate]?.get(it.invoice?.payee?.name)?.add(nativeItem)
                }

                for (key in defaultTreeMap.keys) {
//                    defaultNativeList.addAll(mPresenter.subList(key, defaultTreeMap))
                    defaultNativeList.addAll(mViewModel.subList(key, defaultTreeMap))
                }

                mAdapter?.setData(defaultNativeList)
                mAdapter?.setOnItemClickListener(object : RecyclerExtras.OnItemClickListener {
                    override fun onItemClick(view: View, position: Int) {
                        if (!defaultNativeList[position].isShowHeader) {
                            TealiumUtil.eventTag("button click", "landing - invoices: invoice selected")
                            InvoiceDetailActivity.showActivity(activity, defaultNativeList[position])
                        }
                    }
                })
                mAdapter?.mAdvisePaymentCallback = object : AdvicePaymentCallback {
                    override fun advicePayment(date: String, company: String) {
                        val groupList = ArrayList<InvoiceListItem?>()
                        defaultTreeMap[date]?.get(company)?.also {
                            for (item in it) {
                                if (item.isShowHeader) {
                                    continue
                                }
                                val invoiceItem = InvoiceListItem(item.token, item.invoice, active = true)
                                groupList.add(invoiceItem)
                            }
                        }
                        PlannedPaymentCreationActivity.showActivity(activity, groupList, 404)
                    }

                }
                rvContentList?.addItemDecoration(StickyHeaderItemDecoration(rootView.rv_invoice_list, mAdapter!!))
            }
        }

        MemoryCache.getLabelText("s_as_of_today")?.let {
            if (!it.isBlank()) {
                rootView.tv_today_invoice_header_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_overdue_invoices")?.let {
            if (!it.isBlank()) {
                rootView.tv_today_invoice_header_overdue_invoices_num_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_amount_to_pay")?.let {
            if (!it.isBlank()) {
                rootView.tv_today_invoice_header_amount_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_no_amount_due")?.let {
            if (!it.isBlank()) {
                tvTodayInvoiceAmount?.text = it
            }
        }

        MemoryCache.getLabelText("s_show_outstanding_amount")?.let {
            if (!it.isBlank()) {
                rootView.v_invoice_sorting_and_filter.tv_outstanding_tag.text = it
            }
        }
        return rootView
    }

    override fun onRefresh() {
        if (!isRefreshing) {
            if (activity is HomeActivity) {
//                mPresenter.currentSearch = (activity as HomeActivity).getCurrentSearchingContent()
                mViewModel.currentSearch = (activity as HomeActivity).getCurrentSearchingContent()
            }
            setRefreshing(true)
            mViewModel.getOverdueList(false)
//            mPresenter.getOverdueList(false)
        }
    }

    override fun advicePayment(date: String, company: String) {
        PlannedPaymentCreationActivity.showActivity(activity, mViewModel.getDateList(date, company))
    }

    override fun getMainListView(): RecyclerView? {
        return rvContentList
    }

    override fun getMainRefresher(): SwipeRefreshLayout? {
        return srlContentRefresher
    }

    override fun restoreAdapter(adapter: InvoiceListDueTodayAdapter?) {
        mAdapter = adapter
    }

    override fun updateRingData(unpaidAmount: Long, partiallyAmount: Long, paidAmount: Long, overpaidAmount: Long, totalAmount: Long, currency: String, isShowOutstanding: Boolean) {
    }

    /**
     * show the summary info
     */
    override fun updateTodayInvoiceInfo(invoiceCount: Int, invoiceAmount: Double, currency: String) {
        tvTodayInvoiceCount?.text = invoiceCount.toString()
        val amountStr = IndiaNumberUtil.formatNum(MemoryCache.globalDecimal.format(invoiceAmount / 100.0), currency)
        val invoiceAmountStr = "$currency $amountStr"
        tvTodayInvoiceAmount?.text = invoiceAmountStr
    }

    /**
     * from search box, put search txt to parameter to do a filtering
     */
    override fun onSearchTextChanged(searchText: String?) {
        setRefreshing(true)
        rootView.v_invoice_today_list_header.visibility = View.GONE
//        mPresenter.currentSearch = searchText ?: ""
//        mPresenter.getOverdueList(false)
        mViewModel.currentSearch = searchText ?: ""
        mViewModel.getOverdueList(false)
    }

    override fun reAddScrollListener(isAdd: Boolean) {
    }

    /**
     * when select supplier, return it and change data
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            if (!isRefreshing) {
                setRefreshing(true)
                if (requestCode == REQUEST_CODE_DUE_INVOICE_FILTER) {
                    currentCountryCode = data?.getStringExtra(TAG_INVOICE_FILTER_COUNTRY_CODE_RESULT)
                    if (currentCountryCode.isNullOrBlank()) {
                        currentCountryCode = MemoryCache.defaultCountry
                    }
                }
//                mPresenter.obtainActivityResult(requestCode, resultCode, data)
                data?.also {
                    mViewModel.setUploadParameter(it.getSerializableExtra(TAG_INVOICE_FILTER_PARAMETER_RESULT) as InvoiceRequestParameter)
                    mViewModel.getOverdueList(false)
                }
            }
        }
    }

    /**
     * if has data or not
     */
    override fun showData(isHasData: Boolean) {
        if (loadingView.visibility == View.VISIBLE) {
            loadingView.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete")
                    ?: getString(R.string.talkBack_loading_complete))
            loadingView.visibility = View.GONE
        }
        setRefreshing(false)

        if (isHasData) {
            rvContentList?.visibility = View.VISIBLE
            tvNoData?.visibility = View.GONE
            if (isFromHome) {
                rootView.v_invoice_today_list_header.visibility = View.VISIBLE
            }
        } else {
            rvContentList?.visibility = View.GONE
            tvNoData?.visibility = View.VISIBLE
            updateTodayInvoiceInfo(0, 0.00, MemoryCache.defaultCurrency ?: "")
            tvTodayInvoiceAmount?.text = MemoryCache.getLabelText("s_no_amount_due")
                    ?: getString(R.string.s_no_amount_due)
        }
    }

    override fun onItemClick(view: View, position: Int) {
        if (mAdapter?.getData()?.get(position)?.isShowHeader != true) {
            TealiumUtil.eventTag("button click", "landing - invoices: invoice selected")
            InvoiceDetailActivity.showActivity(activity, mAdapter?.getData()?.get(position))
        }
    }
//    override fun onItemClick(view: View, viewType: Int, data: InvoiceListNativeEntity?, position: Int) {
//        val tvSupplierName = view.findViewById<TextView>(R.id.tv_invoice_list_item_supplier_name)
//        val tvInvoiceId = view.findViewById<TextView>(R.id.tv_invoice_list_item_item_id)
//        val tvInvoiceStatus = view.findViewById<TextView>(R.id.tv_invoice_list_item_state)
//        val invoiceIdName = "invoice_id:" + data?.invoice?.reference
//        val supplierName = "supplier_name:" + data?.invoice?.payee?.name
//        val statusName = "pay_state:" + data?.invoice?.reference + data?.invoice?.status
//        ViewCompat.setTransitionName(tvInvoiceId, invoiceIdName)
//        ViewCompat.setTransitionName(tvSupplierName, supplierName)
//        ViewCompat.setTransitionName(tvInvoiceStatus, statusName)
//        val part1 = Pair(tvSupplierName as View, ViewCompat.getTransitionName(tvSupplierName))
//        val part2 = Pair(tvInvoiceId as View, ViewCompat.getTransitionName(tvInvoiceId))
//        val part3 = Pair(tvInvoiceStatus as View, ViewCompat.getTransitionName(tvInvoiceStatus))
//        val activityOptionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(getFragmentActivity()!!, part1, part2, part3)
//        TealiumUtil.eventTag("button click", "landing - invoices: invoice selected")
//        val intent = Intent(activity, InvoiceDetailActivity::class.java).apply {
//            putExtra(TAG_INVOICE_TOKEN, data)
//            putExtra(TAG_INVOICE_FROM_PLANNED_PAYMENT_CREATION, false)
//        }
//        startActivity(intent, activityOptionsCompat.toBundle())
//    }

    fun endRefreshing() {
        srlContentRefresher?.isRefreshing = false
    }

    private fun setRefreshing(refreshingState: Boolean) {
        if (refreshingState) {
            srlContentRefresher?.announceForAccessibility(MemoryCache.getLabelText("s_loading")
                    ?: getString(R.string.s_loading))
        } else {
            srlContentRefresher?.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete")
                    ?: getString(R.string.talkBack_loading_complete))
        }
        isRefreshing = refreshingState
        srlContentRefresher?.isRefreshing = refreshingState
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:invoices:invoices due",
                "/dart/buyer-portal/invoices/invoices-due", "payment", "buyer portal",
                "invoices")
    }

}