/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.http.SslError
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.transition.Slide
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.webkit.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.snackbar.Snackbar
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.*
import hk.com.hsbc.glcmdart.domain.invoices.invoicedetail.InvoiceDetailActivity
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListNativeEntity
import hk.com.hsbc.glcmdart.domain.payments.adapter.PaymentInvoiceReviewDetailAdapter
import hk.com.hsbc.glcmdart.domain.payments.contract.PaymentDetailContract
import hk.com.hsbc.glcmdart.domain.payments.dialog.PaymentDetailToolTipDialog
import hk.com.hsbc.glcmdart.domain.payments.model.bean.*
import hk.com.hsbc.glcmdart.domain.payments.presenter.PaymentDetailViewModel
import hk.com.hsbc.glcmdart.domain.payments.presenter.PaymentGatewayViewModel
import hk.com.hsbc.glcmdart.domain.payments.view.ProvidePaymentInfoView
import hk.com.hsbc.glcmdart.domain.tutorial.BuyerTutorial6thActivity
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.*
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import hk.com.hsbc.glcmdart.widget.ProgressWebView
import hk.com.hsbc.glcmdart.widget.SpacesItemDecoration
import kotlinx.android.synthetic.main.activity_planned_payment_detail.*
import kotlinx.android.synthetic.main.view_ach_mandate.*
import kotlinx.android.synthetic.main.view_cheque_detail_review.*
import kotlinx.android.synthetic.main.view_common_beneficiary_info.*
import kotlinx.android.synthetic.main.view_common_beneficiary_info.view.*
import kotlinx.android.synthetic.main.view_payment_detail_header.*
import kotlinx.android.synthetic.main.view_payment_detail_info.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.abs
import kotlin.math.ceil

class PlannedPaymentDetailActivity : BaseActivity(), PaymentDetailContract.View,
        RecyclerExtras.OnItemClickListener, WebViewNotify {

    private lateinit var mViewModel: PaymentDetailViewModel
    private lateinit var mPGViewModel: PaymentGatewayViewModel

    //    private val mPresenter by lazy { PaymentDetailPresenter() }
    private val itemList = ArrayList<InvoiceAddEntity>()
    private val mAdapter by lazy { PaymentInvoiceReviewDetailAdapter(this, itemList) }
    private var payorOrPayeeReference: String? = null
    private var organization: String? = null
    private var token: String? = null
    private var paymentDetailEntity: PaymentDetailEntity? = null
    private var paymentGatewayTrackEntity: PaymentTrackInfo? = null
    private var paymentReference: String? = null
    private var paymentMethods: PaymentMethod? = null
    private var creditNotes: List<CreditNoteLocal>? = null
    private var currency: String? = null
    private var countryCode: String? = null
    private var behavior: BottomSheetBehavior<View>? = null
    private var invoiceDetailList = ArrayList<InvoiceAddEntity>()
    private var allPaymentInProgress: PlannedPaymentListPayload? = null
    private var bottomWebView: ProgressWebView? = null
    private var isFinishPaid = false
    private var isCancelling = false
    private var isCreditNoteMethod = false
    private var isFullDeduction = false
    private var isUploadingPaymentCode = false
    private var isCreatePaymentCode = false
    private var currentPaymentCode = ""
    private var currentPaymentRef = ""
    private var redirectUrl = ""
    private var hasCaughtPaymentCode = false

    private val webviewHandler = Handler {
        when (it.what) {
            1 -> {
                cl_bottom_sheet.visibility = View.GONE
                v_slide_indicator.visibility = View.GONE
                showLoadingDialogExt()
                if (bottomWebView != null) {
                    bottomWebView?.post {
                        bottomWebView?.loadDataWithBaseURL(null, "", "text/html", "utf-8", null)
                        bottomWebView?.stopLoading()
                        bottomWebView?.clearHistory()
                    }
                }
                mPGViewModel.trackPayment(paymentReference ?: "")
                mViewModel.requestDetailAndCreditnote(paymentReference ?: "", countryCode, currency)
//                mViewModel.requestPaymentDetailData(paymentReference ?: "")
//                mViewModel.requestCreditNotes(countryCode, currency)
                btn_make_pg.isEnabled = true
                tv_copy.isEnabled = true
                iv_reference_tool_tip.isEnabled = true
                btn_revoke.isEnabled = true
            }
            2 -> {
                cl_bottom_sheet.visibility = View.GONE
                v_slide_indicator.visibility = View.GONE
                showOngoingError(false)
            }
            3 -> {
                cl_bottom_sheet.visibility = View.GONE
                v_slide_indicator.visibility = View.GONE
                showOngoingError(true)
            }
            4 -> {
                cl_bottom_sheet.visibility = View.GONE
                v_slide_indicator.visibility = View.GONE
                showLoadingDialogExt()
//                behavior?.state = BottomSheetBehavior.STATE_HIDDEN
                cl_bottom_sheet.visibility = View.GONE
                v_slide_indicator.visibility = View.GONE
                if (bottomWebView != null) {
                    bottomWebView?.post {
                        bottomWebView?.loadDataWithBaseURL(null, "", "text/html", "utf-8", null)
                        bottomWebView?.stopLoading()
                        bottomWebView?.clearHistory()
                    }
                }
                if (!isCreatePaymentCode) {
                    mViewModel.requestDetailAndCreditnote(paymentReference
                            ?: "", countryCode, currency)
                }
                btn_make_pg.isEnabled = true
                tv_copy.isEnabled = true
                iv_reference_tool_tip.isEnabled = true
                btn_revoke.isEnabled = true
            }
            5 -> {
                if (!hasCaughtPaymentCode) {
                    ll_va_info_container.visibility = View.VISIBLE
                    val paymentCode = currentPaymentCode
                    tv_channel.text = MemoryCache.getVABankNameMap(this, paymentCode.substring(0, 5))
                    tv_code.text = paymentCode
                    showLoadingDialogExt()
                    hasCaughtPaymentCode = true
                    uploadPaymentCode()
                }
            }
            else -> {
                behavior?.state = BottomSheetBehavior.STATE_HIDDEN
            }
        }
        true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
        val slideDown = Slide()
        slideDown.slideEdge = Gravity.BOTTOM
        window.exitTransition = slideDown
        setContentView(R.layout.activity_planned_payment_detail)
        initEventAndData()
    }

    @SuppressLint("ResourceAsColor")
    fun initEventAndData() {
        val buttonAccessibilityDelegate = object : View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        }

        iv_reference_tool_tip.visibility = View.VISIBLE
        tv_payment_ref_tag.text = MemoryCache.getLabelText("s_your_tracking_id") ?: getString(R.string.s_your_tracking_id)
        tv_payment_ref_tag.contentDescription = MemoryCache.getLabelText("s_your_tracking_id") ?: getString(R.string.s_your_tracking_id)
        MemoryCache.getLabelText("s_revoke_Advice")?.let {
            if (!it.isBlank()) {
                btn_revoke.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_infomation")?.let {
            if (!it.isBlank()) {
                tv_payment_details_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_update")?.let {
            if (!it.isBlank()) {
                tv_payment_update.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_method")?.let {
            if (!it.isBlank()) {
                tv_payment_method_title.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_date")?.let {
            if (!it.isBlank()) {
                tv_payment_date_title.text = it
            }
        }
        MemoryCache.getLabelText("s_invoice_infomation")?.let {
            if (!it.isBlank()) {
                tv_invoice_summary_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_update")?.let {
            if (!it.isBlank()) {
                tv_invoice_update.text = it
            }
        }
        MemoryCache.getLabelText("s_update_outdate_warnming")?.let {
            if (!it.isBlank()) {
                tv_revoke_warming_tip.text = it
            }
        }
        MemoryCache.getLabelText("s_cheque_date")?.let {
            if (!it.isBlank()) {
                tv_cheque_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_cheque_number")?.let {
            if (!it.isBlank()) {
                tv_cheque_number_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_cheque_amount")?.let {
            if (!it.isBlank()) {
                et_cheque_amount_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_urn_number")?.let {
            if (!it.isBlank()) {
                tv_URN_number_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_expiration_date")?.let {
            if (!it.isBlank()) {
                tv_expiration_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_maximum_amount")?.let {
            if (!it.isBlank()) {
                tv_maximum_amount_tag.text = it
            }
        }
        tv_bankname.text = MemoryCache.getLabelText("s_bank_name_value")
                ?: getString(R.string.s_bank_name_value)
        MemoryCache.getLabelText("s_beneficiary_info")?.let {
            if (!it.isBlank()) {
                tv_baneficiary_info_tag.text = it
            }
        }

        MemoryCache.getLabelText("head_payment_bank_name")?.let {
            if (!it.isBlank()) {
                tv_bankname_title.text = it
            }
        }
        MemoryCache.getLabelText("head_payment_account_number")?.let {
            if (!it.isBlank()) {
                tv_account_number_title.text = it
            }
        }

        MemoryCache.getLabelText("s_make_payment")?.let {
            if (!it.isBlank()) {
                btn_make_pg.text = it
            }
        }

        MemoryCache.getLabelText("s_track_payment")?.let {
            if (!it.isBlank()) {
                btn_track.text = it
            }
        }

        MemoryCache.getLabelText("s_talkback_copy_reference")?.let {
            if (!it.isBlank()) {
                tv_copy.text = it
            }
        }

        MemoryCache.getLabelText("s_account_name")?.let {
            if (!it.isBlank()) {
                tv_account_name_title.text = it
            }
        }

        MemoryCache.getLabelText("s_va_bank_convenience_store")?.let {
            if (!it.isBlank()) {
                tv_channel_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_code_tag")?.let {
            if (!it.isBlank()) {
                tv_code_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_va_cap_warming")?.let {
            if (!it.isBlank()) {
                tv_va_tip.text = it
            }
        }

        ViewCompat.setAccessibilityDelegate(tl_head_title, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.isHeading = true // false to mark a view as not a heading
            }
        })
        ViewCompat.setAccessibilityDelegate(tv_payment_details_tag, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.isHeading = true // false to mark a view as not a heading
            }
        })
        ViewCompat.setAccessibilityDelegate(tv_invoice_summary_tag, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.isHeading = true // false to mark a view as not a heading
            }
        })
        ViewCompat.setAccessibilityDelegate(tv_baneficiary_info_tag, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.isHeading = true // false to mark a view as not a heading
            }
        })
        tl_head_title.text = MemoryCache.getLabelText("planned_payment_detail_title")
                ?: getString(R.string.planned_payment_detail_title)
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        tl_head.navigationContentDescription = MemoryCache.getLabelText("s_talkback_back_button")
                ?: getString(R.string.s_talkback_back_button)
        tl_head.title = null
        title = ""
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            if (cl_bottom_sheet.visibility == View.VISIBLE) {
                return@setNavigationOnClickListener
            }

            TealiumUtil.eventTag("button click", "payment - detail: back")
            ActivityCompat.finishAfterTransition(this)
        }

        mViewModel = ViewModelProviders.of(this).get(PaymentDetailViewModel::class.java)
        mPGViewModel = ViewModelProviders.of(this).get(PaymentGatewayViewModel::class.java)
        mViewModel.revokeLiveData.observe(this, Observer {
            if (it) {
                setItpRevokeResult()
            }
        })

        mViewModel.paymentMethodLiveData.observe(this, Observer {
            setPaymentMethods(it)
        })

        mViewModel.paymentDetailUpdateLiveData.observe(this, Observer {
            if (it == null) {
                uploadPaymentCode()
            } else {
                hideLoadingDialogExt()
                isCreatePaymentCode = false
                isUploadingPaymentCode = false
                hasCaughtPaymentCode = false
            }
        })

        mViewModel.paymentDetailLiveData.observe(this, Observer {
            // clear deduction cache, progress of creation or update has been finished, so deduction cache can be cleared
            MemoryCache.saveDeductionsMap(null)
            if (it.payload?.status != "processing" && (it.payload?.status == "created" && it.payload.itp?.paymentMethod == "dcms")) {
                mViewModel.requestPaymentList(currency ?: MemoryCache.defaultCurrency)
            }

            if (it.payload?.itp?.paymentMethod == "dcms" || it.payload?.itp?.paymentMethod == "virtual_account") {
                mPGViewModel.trackPayment(paymentReference ?: "")
            } else {

                hideLoadingDialogExt()
                tv_payment_ref_tip.visibility = View.VISIBLE
                v_payment_ref_tip_ic.visibility = View.VISIBLE
                v_payment_ref_tip_ic.background = ContextCompat.getDrawable(this, R.drawable.ic_info_blue)
            }
            setPlannedPaymentDetail(it)
        })

        mViewModel.creditNoteAvailableLiveData.observe(this, Observer {
            setCreditNotes(it)
        })

        mViewModel.allPaymentList.observe(this, Observer {
            hideLoadingDialogExt()
            if ("S" == MemoryCache.getSessionEntity()?.type ||
                    paymentDetailEntity?.status == "processing" ||
                    (paymentDetailEntity?.status != "created" && paymentDetailEntity?.itp?.paymentMethod != "dcms")) {
                return@Observer
            }

            allPaymentInProgress = it
            val itpList = mutableListOf<ITP>()
            val itpSize = allPaymentInProgress?.payload?.itps?.size ?: 0
            for (i in 0 until itpSize) {
                if (allPaymentInProgress?.payload?.statuses!![i] == "processing") {
                    itpList.add(allPaymentInProgress?.payload?.itps!![i])
                }
            }
            val processingInvoiceRefList = mutableSetOf<String?>()
            itpList.forEach { itp ->
                itp.lines?.forEach { line ->
                    paymentDetailEntity?.invoices?.forEach { invoiceItem ->
                        if (invoiceItem.token != null && line.token != null && invoiceItem.token == line.token) {
                            processingInvoiceRefList.add(invoiceItem.invoice?.reference)
                        }
                    }
                }
            }

            if (processingInvoiceRefList.size >= 1) {
                val sb = StringBuilder()
                processingInvoiceRefList.forEach { invoiceRef ->
                    sb.append("-  ").append(invoiceRef).append("\n")
                }
                val invoiceRefs = sb.toString()
                if (tv_payment_ref_tip.visibility != View.VISIBLE) {
                    v_payment_ref_tip_ic.visibility = View.VISIBLE
                    tv_payment_ref_tip.visibility = View.VISIBLE
                }
                val tipStr = String.format((MemoryCache.getLabelText("s_has_processing_payment_tip_in_multi")
                        ?: getString(R.string.s_has_processing_payment_tip_in_multi)), invoiceRefs)
                tv_payment_ref_tip.text = tipStr
                tv_payment_ref_tip.contentDescription = tipStr
                v_payment_ref_tip_ic.visibility = View.VISIBLE

//            } else if (processingInvoiceRefList.size == 1) {
//                if (tv_payment_ref_tip.visibility != View.VISIBLE) {
//                    v_payment_ref_tip_ic.visibility = View.VISIBLE
//                    tv_payment_ref_tip.visibility = View.VISIBLE
//                }
//                val tipStr = MemoryCache.getLabelText("s_has_processing_payment_tip") ?:
//                                getString(R.string.s_has_processing_payment_tip)
//                tv_payment_ref_tip.text = tipStr
            } else {
                v_payment_ref_tip_ic.visibility = View.GONE
                tv_payment_ref_tip.visibility = View.GONE
            }
        })

        mPGViewModel.requestLoadingLiveData.observe(this, Observer {
            if (it) {
                showLoadingDialogExt()
            } else {
                hideLoadingDialogExt()
            }
        })
        mPGViewModel.mPaymentTrackingLiveData.observe(this, Observer {
            hideLoadingDialogExt()
            paymentGatewayTrackEntity = it
            if (paymentDetailEntity?.status == "created" && paymentDetailEntity?.itp?.paymentMethod == "dcms") {
                if (it.txnStatus == "non-init") {
                    if ("B" == MemoryCache.getSessionEntity()?.type) {
                        btn_make_pg.visibility = View.VISIBLE
                        btn_make_pg.isEnabled = true
                        btn_make_pg.setBackgroundColor(ContextCompat.getColor(this, R.color.primary_red))
                        tv_payment_ref_tip.visibility = View.GONE
                    }
                } else if (it.txnStatus == "initiated" || it.txnStatus == "inprogress") {
                    if ("B" == MemoryCache.getSessionEntity()?.type) {
                        ll_invoice_update.isEnabled = false
                        tv_invoice_update.setTextColor(ContextCompat.getColor(this, R.color.disable_grey))
                        val drawableRight = ContextCompat.getDrawable(this, R.drawable.ic_edit_gray)
                        tv_invoice_update.setCompoundDrawablesWithIntrinsicBounds(null, null, drawableRight, null)
                        tv_invoice_update.compoundDrawablePadding = 5
                        ll_payment_update.isEnabled = false
                        tv_payment_update.setTextColor(ContextCompat.getColor(this, R.color.disable_grey))
                        tv_payment_update.setCompoundDrawablesWithIntrinsicBounds(null, null, drawableRight, null)
                        tv_payment_update.compoundDrawablePadding = 5
                        showOngoingError(false)
                    }
                } else if (it.txnStatus != "captured" || it.txnStatus == "pending") {
                    //Do nothing
                    if ("B" == MemoryCache.getSessionEntity()?.type) {
                        val sharedPreferences = getSharedPreferences(DartApplication.instance?.applicationInfo?.packageName, Context.MODE_PRIVATE)
                        val firstMakePayment = sharedPreferences.getBoolean("firstMakePayment", true)
                        if (firstMakePayment) {
                            getSharedPreferences(DartApplication.instance?.applicationInfo?.packageName, Context.MODE_PRIVATE).edit().putBoolean("firstMakePayment", false).apply()
                            startActivity(Intent(this, BuyerTutorial6thActivity::class.java))
                        }
                        btn_make_pg.visibility = View.VISIBLE
                        btn_make_pg.isEnabled = true
                        btn_make_pg.setBackgroundColor(ContextCompat.getColor(this, R.color.primary_red))
                        tv_payment_pg_status_tip.visibility = View.VISIBLE
                        v_payment_pg_status_ic.visibility = View.VISIBLE
                        tv_payment_pg_status_tip.contentDescription = MemoryCache.getLabelText("s_payment_ongoing_incomplete_tip")
                                ?: getString(R.string.s_payment_ongoing_incomplete_tip)
                    }
                } else if (it.txnStatus == "captured") {
                    btn_track.visibility = View.VISIBLE
                    if ("S" == MemoryCache.getSessionEntity()?.type) {
                        tv_payment_ref_tip.visibility = View.GONE
                        v_payment_ref_tip_ic.visibility = View.GONE
                        v_payment_pg_status_ic.visibility = View.GONE
                        tv_payment_pg_status_tip.visibility = View.GONE
                        v_payment_overpaid_tip_ic.visibility = View.GONE
                        tv_payment_overpaid_tip.visibility = View.GONE
                    }
                }
            } else if (paymentDetailEntity?.status == "processing") {
                tv_payment_pg_status_tip.visibility = View.VISIBLE
                v_payment_pg_status_ic.visibility = View.VISIBLE
                v_payment_pg_status_ic.background = ContextCompat.getDrawable(this, R.drawable.ic_info_blue)
                btn_track.visibility = View.VISIBLE
                if ("S" == MemoryCache.getSessionEntity()?.type) {
                    tv_payment_ref_tip.visibility = View.GONE
                    v_payment_ref_tip_ic.visibility = View.GONE
                    v_payment_pg_status_ic.visibility = View.GONE
                    tv_payment_pg_status_tip.visibility = View.GONE
                    v_payment_overpaid_tip_ic.visibility = View.GONE
                    tv_payment_overpaid_tip.visibility = View.GONE
                }
            }
        })

        mPGViewModel.mGatewayLiveData.observe(this, Observer {
            hideLoadingDialogExt()
            if (!it.isNullOrBlank()) {
                isCancelling = false
                redirectUrl = it
                val dcmsForm = "<html><head><body>$it</body></html>"
                showBottomSheet()
                bottomWebView?.loadData(dcmsForm, "text/html", "utf-8")

//                WebViewTest.showActivity(this, dcmsForm)
            }
        })

        mPGViewModel.paymentErrorLiveData.observe(this, Observer {
            if (it == "302") {
                showSessionExpiredDialog()
            } else {
                PaymentGatewaySentTipActivity.showActivity(this, true)
            }
        })

        btn_make_pg.setOnClickListener {
            if (cl_bottom_sheet.visibility == View.VISIBLE) {
                return@setOnClickListener
            }

            isFinishPaid = false
            hasCaughtPaymentCode = false
            PaymentGatewayConfirmActivity.showActivity(this@PlannedPaymentDetailActivity,
                    paymentDetailEntity, this.invoiceDetailList)

//            if (!paymentDetailEntity?.itp?.extra?.dcms_va_payment_code.isNullOrBlank()) {
//                hasCaughtPaymentCode = false
//                PaymentGatewayConfirmActivity.showActivity(this@PlannedPaymentDetailActivity,
//                        paymentDetailEntity, this.invoiceDetailList)
//            } else {
//                if (!isFinishPaid) {
//                    TealiumUtil.eventTag("button click", "payment detail: pay invoice")
//                    if ("captured" != paymentGatewayTrackEntity?.txnStatus) {
//                        hasCaughtPaymentCode = false
//                        PaymentGatewayConfirmActivity.showActivity(this@PlannedPaymentDetailActivity,
//                                paymentDetailEntity, this.invoiceDetailList)
//                    } else {
//                        PaymentGatewaySentTipActivity.showActivity(this)
//                    }
//                } else {
//                    if (!paymentDetailEntity?.itp?.extra?.dcms_va_payment_code.isNullOrBlank() &&
//                            "captured" != paymentGatewayTrackEntity?.txnStatus) {
//                        isFinishPaid = false
//                        hasCaughtPaymentCode = false
//                        PaymentGatewayConfirmActivity.showActivity(this@PlannedPaymentDetailActivity,
//                                paymentDetailEntity, this.invoiceDetailList)
//                    } else {
//                        PaymentGatewaySentTipActivity.showActivity(this)
//                    }
//                }
//            }
        }

        iv_reference_tool_tip.setOnClickListener {
            if (cl_bottom_sheet.visibility == View.VISIBLE) {
                return@setOnClickListener
            }
            PaymentDetailToolTipDialog.showDialog(this)
        }

        btn_track.setOnClickListener {
            if (cl_bottom_sheet.visibility == View.VISIBLE) {
                return@setOnClickListener
            }

            if (paymentDetailEntity?.status == "processing") {
                TealiumUtil.eventTag("button click", "payment detail - processing: track payment")
            } else {
                TealiumUtil.eventTag("button click", "payment detail - closed: track payment")
            }
            startActivity(Intent(this@PlannedPaymentDetailActivity, PaymentTrackActivity::class.java).apply {
                putExtra(TAG_PAYMENT_GATEWAY_DETAIL, paymentDetailEntity)
                putExtra(TAG_PAYMENT_GATEWAY_INVOICE_DETAIL, invoiceDetailList)
                putExtra(TAG_PAYMENT_GATEWAY_TRACK, paymentGatewayTrackEntity)
            })
//            PaymentTrackActivity.showActivity(this@PlannedPaymentDetailActivity,
//                    paymentDetailEntity, this.invoiceDetailList)
        }

        btn_revoke.setOnClickListener {
            if (cl_bottom_sheet.visibility == View.VISIBLE) {
                return@setOnClickListener
            }

            if (paymentDetailEntity?.itp?.paymentMethod == "ach") {
                val banHour = MemoryCache.getACHLimitation(this, currency
                        ?: MemoryCache.defaultCurrency!!)
                val banDays = ceil(banHour / 24.0)
                val currentDate = SimpleDateFormat("yyyy-MM-dd").format(Date())
                if (TimeZoneTransformsUtil.calDaysBetween(currentDate, paymentDetailEntity?.itp?.expectedDate).toInt() <= banDays) {
                    Toast.makeText(this,
                            String.format(MemoryCache.getLabelText("s_ach_ban_tip")
                                    ?: getString(R.string.s_ach_ban_tip),
                                    banHour.toString()),
                            Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }

            TealiumUtil.eventTag("button click", "payment - detail: revoke")
            CommonDialog.showAlertDialog(this, MemoryCache.getLabelText("s_revoke_payment")
                    ?: getString(R.string.s_revoke_payment),
                    MemoryCache.getLabelText("s_revoke_payment_warming")
                            ?: getString(R.string.s_revoke_payment_warming),
                    MemoryCache.getLabelText("s_revoke")
                            ?: getString(R.string.s_revoke), object : CommonDialogExtras.OnButtonListener {
                override fun positiveButtonListener() {
                    TealiumUtil.eventTag("button click", "payment revoke confirmation overlay: revoke")
                    if (!TextUtils.isEmpty(payorOrPayeeReference) && !TextUtils.isEmpty(token))
                        mViewModel.requestItpRevoke(token, payorOrPayeeReference)
                }

                override fun negativeButtonListener() {
                    TealiumUtil.eventTag("button click", "payment revoke confirmation overlay: cancel")
                }
            }, MemoryCache.getLabelText("s_cancel") ?: getString(R.string.s_cancel))
            TealiumUtil.pageTag("dart : buyer portal : payments : payment revoke confirmation",
                    "/dart/buyer portal/payments/payment revoke confirmation",
                    "transaction",
                    "buyer portal",
                    "payments")
        }
        tv_copy.setOnClickListener {
            if (cl_bottom_sheet.visibility == View.VISIBLE) {
                return@setOnClickListener
            }

            val copy = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            copy.text = tv_reference.text
            val snackbar = Snackbar.make(it, MemoryCache.getLabelText("s_reference_copy")
                    ?: getString(R.string.s_reference_copy), Snackbar.LENGTH_SHORT)
            snackbar.view.setBackgroundColor(Color.parseColor("#FFFFFF"))
            val drawable = ContextCompat.getDrawable(this, R.drawable.ic_success)//image chose by self
            drawable?.setBounds(0, 0, drawable.minimumWidth, drawable.minimumHeight)
            val toast = snackbar.view.findViewById<TextView>(R.id.snackbar_text)
            toast.compoundDrawablePadding = 13
            toast.setCompoundDrawables(drawable, null, null, null)
            snackbar.show()
        }
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        rv_invoice_add_or_edit.addItemDecoration(SpacesItemDecoration(this, 1))
        mAdapter.setOnItemClickListener(this)
        rv_invoice_add_or_edit.adapter = mAdapter

        paymentReference = intent.getStringExtra("paymentReference")
        tv_payment_ref_tip.contentDescription = String.format(MemoryCache.getLabelText("s_own_payment_reference")
                ?: getString(R.string.s_own_payment_reference), paymentReference)
        tv_payment_pg_status_tip.contentDescription = String.format(MemoryCache.getLabelText("s_own_payment_reference")
                ?: getString(R.string.s_own_payment_reference), paymentReference)
        tv_payment_overpaid_tip.contentDescription = String.format(MemoryCache.getLabelText("s_own_payment_reference")
                ?: getString(R.string.s_own_payment_reference), paymentReference)
        tv_payment_ref_tip.text = String.format(MemoryCache.getLabelText("s_own_payment_reference")
                ?: getString(R.string.s_own_payment_reference), paymentReference)
        tv_payment_pg_status_tip.text = String.format(MemoryCache.getLabelText("s_own_payment_reference")
                ?: getString(R.string.s_own_payment_reference), paymentReference)
        tv_payment_overpaid_tip.text = String.format(MemoryCache.getLabelText("s_own_payment_reference")
                ?: getString(R.string.s_own_payment_reference), paymentReference)
        mViewModel.requestDetailAndCreditnote(paymentReference ?: "", countryCode, currency)
//        mViewModel.requestPaymentDetailData(paymentReference ?: "")
//        mViewModel.requestCreditNotes(countryCode, currency ?: MemoryCache.defaultCurrency)
        showLoadingDialogExt()
        ll_payment_update.setOnClickListener {
            if (cl_bottom_sheet.visibility == View.VISIBLE) {
                return@setOnClickListener
            }

            if (paymentDetailEntity?.itp?.paymentMethod == "ach") {
                val banHour = MemoryCache.getACHLimitation(this, currency
                        ?: MemoryCache.defaultCurrency!!)
                val banDays = ceil(banHour / 24.0)
                val currentDate = SimpleDateFormat("yyyy-MM-dd").format(Date())
                if (TimeZoneTransformsUtil.calDaysBetween(currentDate, paymentDetailEntity?.itp?.expectedDate).toInt() <= banDays) {
                    Toast.makeText(this,
                            String.format(MemoryCache.getLabelText("s_ach_ban_tip")
                                    ?: getString(R.string.s_ach_ban_tip),
                                    banHour.toString()),
                            Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }

            TealiumUtil.eventTag("button click", "payment - detail: update payment information")
            if (paymentDetailEntity != null && "created" == paymentDetailEntity?.status) {
                PlannedPaymentUpdateActivity.showActivity(this, paymentDetailEntity,
                        PlannedPaymentUpdateActivity.UPDATE_TYPE_PAYMENT_INFO, paymentMethods, currency,
                        REQUEST_CODE_UPDATE_PAYMENT_INFO)
            }
        }
        ll_invoice_update.setOnClickListener {
            if (cl_bottom_sheet.visibility == View.VISIBLE) {
                return@setOnClickListener
            }

            if (paymentDetailEntity?.itp?.paymentMethod == "ach") {
                val banHour = MemoryCache.getACHLimitation(this, currency
                        ?: MemoryCache.defaultCurrency!!)
                val banDays = ceil(banHour / 24.0)
                val currentDate = SimpleDateFormat("yyyy-MM-dd").format(Date())
                if (TimeZoneTransformsUtil.calDaysBetween(currentDate, paymentDetailEntity?.itp?.expectedDate).toInt() <= banDays) {
                    Toast.makeText(this,
                            String.format(MemoryCache.getLabelText("s_ach_ban_tip")
                                    ?: getString(R.string.s_ach_ban_tip),
                                    banHour.toString()),
                            Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }

            TealiumUtil.eventTag("button click", "planned payments payment detail: update invoice information")
            if (paymentDetailEntity != null && "created" == paymentDetailEntity?.status) {
                PlannedPaymentUpdateActivity.showActivity1(this, paymentDetailEntity,
                        PlannedPaymentUpdateActivity.UPDATE_TYPE_INVOICE_INFO, creditNotes,
                        paymentMethods, currency, REQUEST_CODE_UPDATE_PAYMENT_INFO,
                        isCreditNoteMethod, isFullDeduction)
            }
        }

        rl_copy.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_payment_update.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_invoice_update.setAccessibilityDelegate(buttonAccessibilityDelegate)

        MemoryCache.getLabelText("s_bank_code_label")?.let {
            if (!it.isBlank()) {
                tv_IFSC_code_title.text = it
            }
        }
        tv_IFSC_code.text = MemoryCache.bankCode

        val collapseLp = nested_scroll_view.layoutParams
        collapseLp.height = getWebViewHeight()
        nested_scroll_view.layoutParams = collapseLp
        bottomWebView = wv_bottom_sheet
        behavior = BottomSheetBehavior.from(nested_scroll_view)
        behavior?.peekHeight = getWebViewHeight() / 3
        behavior?.setBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {

            override fun onSlide(bottomSheet: View, slideOffset: Float) {
                val vIndicatorLp = v_slide_indicator.layoutParams as RelativeLayout.LayoutParams
                vIndicatorLp.setMargins(0,
                        nested_scroll_view.top + (ConvertUtil.dp2px(this@PlannedPaymentDetailActivity, 10f).toInt()),
                        0,
                        0)
                v_slide_indicator.layoutParams = vIndicatorLp
            }

            override fun onStateChanged(bottomSheet: View, newState: Int) {
                when (newState) {
                    BottomSheetBehavior.STATE_COLLAPSED -> {
//                        cl_bottom_sheet.background = null
                    }
                    BottomSheetBehavior.STATE_HIDDEN -> {
//                        cl_bottom_sheet.background = null
//                        bottomWebView?.goBack()
                        cl_bottom_sheet.visibility = View.GONE
                        v_slide_indicator.visibility = View.GONE
                        if (!isFinishPaid) {
//                            CommonDialog.showDialog(this@PlannedPaymentDetailActivity,
//                                    MemoryCache.getLabelText("s_payment_incomplete_title")
//                                            ?: getString(R.string.s_payment_incomplete_title),
////                                    MemoryCache.getLabelText("s_payment_incomplete_tip")
////                                            ?:
//                                            getString(R.string.s_payment_incomplete_tip),
//                                    MemoryCache.getLabelText("s_ok") ?: getString(R.string.s_ok),
//                                    MemoryCache.getLabelText("s_cancel")
//                                            ?: getString(R.string.s_cancel),
//                                    View.OnClickListener {
//                                        showBottomSheet()
//                                    },
//                                    View.OnClickListener {
//                                        showLoadingDialogExt()
//                                        if (bottomWebView != null) {
//                                            bottomWebView?.post {
//                                                bottomWebView?.loadDataWithBaseURL(null, "", "text/html", "utf-8", null)
//                                                bottomWebView?.stopLoading()
//                                                bottomWebView?.clearHistory()
//                                            }
//                                        }
//                                        mPGViewModel.trackPayment(paymentReference ?: "")
//                                        mViewModel.requestPaymentDetailData(paymentReference ?: "")
//                                        mViewModel.requestCreditNotes(countryCode, currency)
//                                        btn_make_pg.isEnabled = true
//                                        tv_copy.isEnabled = true
//                                        iv_reference_tool_tip.isEnabled = true
//                                        btn_revoke.isEnabled = true
//                                    }
//                            )
                        } else {
                            showLoadingDialogExt()
//                            mPGViewModel.trackPayment(paymentReference ?: "")
//                            mViewModel.requestPaymentDetailData(paymentReference ?: "")
//                            mViewModel.requestCreditNotes(countryCode, currency)
                            btn_make_pg.isEnabled = true
                            tv_copy.isEnabled = true
                            iv_reference_tool_tip.isEnabled = true
                            btn_revoke.isEnabled = true
                        }
                    }
                    else -> {
                        cl_bottom_sheet.setBackgroundColor(Color.parseColor("#50000000"))
                        btn_make_pg.isEnabled = false
                        tv_copy.isEnabled = false
                        iv_reference_tool_tip.isEnabled = false
                        btn_revoke.isEnabled = false
                    }
                }
            }
        })
        val webViewLp = bottomWebView?.layoutParams
        webViewLp?.height = getWebViewHeight()
        bottomWebView?.layoutParams = webViewLp
        bottomWebView?.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                bottomWebView?.mProgressBar?.progress = newProgress
                if (!isFinishPaid) {
                    view?.loadUrl("javascript:window.payu_obj.checkContent(document.getElementsByTagName('html')[0].innerHTML)")
                }
                super.onProgressChanged(view, newProgress)
            }
        }
        bottomWebView?.webViewClient = object : WebViewClient() {
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                if (DeviceUtil.isEmulator() && (BuildConfig.FLAVOR_env == "dev" || BuildConfig.FLAVOR_env == "uat")) {
                    if (handler != null) {
                        handler.proceed()
                    }
                } else {
                    super.onReceivedSslError(view, handler, error)
                }
            }

            override fun onReceivedHttpAuthRequest(view: WebView?, handler: HttpAuthHandler?, host: String?, realm: String?) {
                if (DeviceUtil.isEmulator() && (BuildConfig.FLAVOR_env == "dev" || BuildConfig.FLAVOR_env == "uat")) {
                    var username: String? = null
                    var password: String? = null

                    val reuseHttpAuthUsernamePassword = handler?.useHttpAuthUsernamePassword()

                    if (reuseHttpAuthUsernamePassword!! && view != null) {
                        val credentials = view.getHttpAuthUsernamePassword(host, realm)
                        if (credentials != null && credentials.size == 2) {
                            username = credentials[0]
                            password = credentials[1]
                        }
                    }
                    if (username != null && password != null) {
                        handler.proceed(username, password)
                    } else {
                        httpAuthAlertDialog(handler)
                    }
                } else {
                    super.onReceivedHttpAuthRequest(view, handler, host, realm)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                Log.e("test", "current url = $url")
//                view?.loadUrl("javascript:window.payu_obj.checkContent(document.getElementsByTagName('html')[0].innerHTML)")
                bottomWebView?.mProgressBar?.visibility = View.GONE
                nested_scroll_view?.scrollTo(0,0)
                super.onPageFinished(view, url)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url?.startsWith("https://www.dart") == true || url?.startsWith("https://consent.dart") == true) {
                    isFinishPaid = true
                    webviewHandler.sendEmptyMessage(4)
                    return
                }
                bottomWebView?.mProgressBar?.visibility = View.VISIBLE
                bottomWebView?.mProgressBar?.progress = 30
                bottomWebView?.showLogo()
                super.onPageStarted(view, url, favicon)
            }
        }

        bottomWebView?.settings?.javaScriptEnabled = true
        bottomWebView?.settings?.layoutAlgorithm = WebSettings.LayoutAlgorithm.NARROW_COLUMNS
        bottomWebView?.settings?.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
//        bottomWebView?.settings?.useWideViewPort = true
//        bottomWebView?.settings?.loadWithOverviewMode = true
        bottomWebView?.addJavascriptInterface(WebViewInterface(this), "payu_obj")
        bottomWebView?.setOnTouchListener { v, event ->
            bottomWebView?.requestDisallowInterceptTouchEvent(false)
            false
        }
    }

    private fun uploadPaymentCode() {
        val dataMap = mutableMapOf<String, Any>()
        val payeeAccount = Account(paymentDetailEntity?.itp?.payeeAccount?.reference, paymentDetailEntity?.itp?.payeeAccount?.currency,
                paymentDetailEntity?.itp?.payeeAccount?.countryCode, paymentDetailEntity?.itp?.payeeAccount?.referenceGroup,
                paymentDetailEntity?.itp?.payeeAccount?.display)
        val payorAccount = Account(paymentDetailEntity?.itp?.payorAccount?.reference, paymentDetailEntity?.itp?.payorAccount?.currency,
                paymentDetailEntity?.itp?.payorAccount?.countryCode, paymentDetailEntity?.itp?.payorAccount?.referenceGroup,
                paymentDetailEntity?.itp?.payorAccount?.display)
        //payee
        dataMap["payeeReference"] = paymentDetailEntity?.itp?.payeeReference ?: ""
        dataMap["payeeAccount"] = payeeAccount
        //payor
        dataMap["payorReference"] = paymentDetailEntity?.itp?.payorReference ?: ""
        dataMap["payorAccount"] = payorAccount
        dataMap["paymentMethod"] = ProvidePaymentInfoView.dcms
        dataMap["expectedDate"] = paymentDetailEntity?.itp?.expectedDate!!
        val extraMap = mutableMapOf<String, String>()
        extraMap["use_generated_token"] = paymentDetailEntity?.itp?.extra?.use_generated_token ?: "true"
        if (MemoryCache.defaultCountry == "IN") {
            extraMap["payment_method_provider"] = "PayU"
        } else {
            extraMap["payment_method_provider"] = "DOKU"
            if (currentPaymentRef.isNotBlank()) {
                extraMap["dcms_transaction_ref"] = currentPaymentRef
            }
            if (redirectUrl.isNotBlank()) {
                extraMap["dcms_redirect_link"] = redirectUrl
            }
            if (currentPaymentCode.isNotBlank()) {
                extraMap["dcms_va_payment_code"] = currentPaymentCode
            }
        }
        dataMap["lines"] = paymentDetailEntity?.itp?.lines ?: mutableListOf<Line>()
        dataMap["extra"] = extraMap
        isUploadingPaymentCode = true
        isCreatePaymentCode = true
        mViewModel.updatePaymentDetail(paymentDetailEntity?.token, dataMap)
    }

    private var authUserName: String? = null
    private var authPassword: String? = null
    private fun httpAuthAlertDialog(httpAuthHandler: HttpAuthHandler) {
        val dialogBuilder = AlertDialog.Builder(this@PlannedPaymentDetailActivity)
        val inflater = this@PlannedPaymentDetailActivity.getLayoutInflater()
        val dialogView = inflater.inflate(R.layout.http_authentication, null)

        val txtUsername = dialogView.findViewById(R.id.dauth_userinput) as EditText
        txtUsername.setText(authUserName)
        val txtPassword = dialogView.findViewById(R.id.dauth_passinput) as EditText
        txtPassword.setText(authPassword)

        dialogBuilder.setView(dialogView)

        dialogBuilder.setPositiveButton(android.R.string.ok
        ) { dialog, whichButton ->
            val username = txtUsername.text.toString()
            authUserName = username
            val password = txtPassword.text.toString()
            authPassword = password
            httpAuthHandler.proceed(username, password)
        }
        dialogBuilder.setNegativeButton(android.R.string.cancel,
                object : DialogInterface.OnClickListener {
                    override fun onClick(dialog: DialogInterface, whichButton: Int) {
                        httpAuthHandler.cancel()
                    }
                }
        )

        dialogBuilder.setCancelable(false)

        val alertDialog = dialogBuilder.create()
        alertDialog.show()
    }


    private fun showOngoingError(ifTransactionError: Boolean) {
        btn_make_pg.visibility = View.VISIBLE
        btn_track.visibility = View.GONE

        cl_bottom_sheet.visibility = View.GONE
        v_slide_indicator.visibility = View.GONE
        tv_payment_pg_status_tip.visibility = View.VISIBLE
        v_payment_pg_status_ic.visibility = View.VISIBLE
        if (!ifTransactionError) {
            v_payment_pg_status_ic.background = ContextCompat.getDrawable(this, R.drawable.ic_alert_yellow)
            tv_payment_pg_status_tip.contentDescription = MemoryCache.getLabelText("s_payment_ongoing_tip")
                    ?: getString(R.string.s_payment_ongoing_tip)
            tv_payment_pg_status_tip.text = MemoryCache.getLabelText("s_payment_ongoing_tip")
                    ?: getString(R.string.s_payment_ongoing_tip)
            btn_make_pg.isEnabled = false
            btn_make_pg.setBackgroundColor(ContextCompat.getColor(this, R.color.color56))
            btn_revoke.visibility = View.GONE
        } else {
            v_payment_pg_status_ic.background = ContextCompat.getDrawable(this, R.drawable.ic_alert_yellow)
            tv_payment_pg_status_tip.contentDescription = String.format(MemoryCache.getLabelText("s_payu_error_tip")
                    ?: getString(R.string.s_payu_error_tip), paymentDetailEntity?.itp?.paymentReference)
            tv_payment_pg_status_tip.text = String.format(MemoryCache.getLabelText("s_payu_error_tip")
                    ?: getString(R.string.s_payu_error_tip), paymentDetailEntity?.itp?.paymentReference)
            btn_make_pg.isEnabled = true
            btn_make_pg.setBackgroundColor(ContextCompat.getColor(this, R.color.primary_red))
            btn_revoke.visibility = View.VISIBLE
        }
        tv_payment_overpaid_tip.visibility = View.GONE
        v_payment_overpaid_tip_ic.visibility = View.GONE
    }

    private fun showBottomSheet() {
        cl_bottom_sheet.visibility = View.VISIBLE
        v_slide_indicator.visibility = View.VISIBLE
        val vTestLp = v_slide_indicator.layoutParams as RelativeLayout.LayoutParams
        vTestLp.setMargins(0, (ConvertUtil.dp2px(this@PlannedPaymentDetailActivity, 58f).toInt()), 0, 0)
        v_slide_indicator.layoutParams = vTestLp
        behavior?.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun getWebViewHeight(): Int {
        val screenHeight = resources.displayMetrics.heightPixels
        return screenHeight - ConvertUtil.dp2px(this, 80.0f).toInt()
    }

    @SuppressLint("SetTextI18n")
    override fun setPlannedPaymentDetail(paymentDetail: PaymentDetailEntityPayload) {
        payorOrPayeeReference = if ("S" == MemoryCache.getSessionEntity()?.type) {
            paymentDetail.payload?.itp?.payeeReference
        } else {
            paymentDetail.payload?.itp?.payorReference
        }
        organization = if ("S" == MemoryCache.getSessionEntity()?.type) {
            if (MemoryCache.getOrganisationsMap().containsKey(paymentDetail.payload?.itp?.payorReference))
                MemoryCache.getOrganisationsMap()[paymentDetail.payload?.itp?.payorReference]?.name
            else paymentDetail.payload?.invoices?.get(0)?.invoice?.payor?.name
        } else {
            if (MemoryCache.getOrganisationsMap().containsKey(paymentDetail.payload?.itp?.payeeReference))
                MemoryCache.getOrganisationsMap()[paymentDetail.payload?.itp?.payeeReference]?.name
            else paymentDetail.payload?.invoices?.get(0)?.invoice?.payee?.name
        }
        token = paymentDetail.payload?.token
        paymentDetailEntity = paymentDetail.payload
        //检查是否有overpaid的invoice:
        val overpaidInvoiceRefList = mutableSetOf<String?>()
        paymentDetailEntity?.invoices?.forEach { invoiceItem ->
            if (invoiceItem.invoice?.status == "O" || invoiceItem.invoice?.status == "F") {
                overpaidInvoiceRefList.add(invoiceItem.invoice.reference)
            }
//            var invoiceItemAmount = 0.0
//            if (invoiceItem.invoice?.summation?.outstanding?.amount != null) {
//                invoiceItemAmount = invoiceItem.invoice.summation.outstanding.amount.toDouble()
//            }
//            paymentDetailEntity?.itp?.lines?.forEach { line ->
//                var lineAmount = 0.0
//                if (line.amount?.amount != null) {
//                    lineAmount = line.amount.amount.toDouble()
//                }
//                if (lineAmount > invoiceItemAmount) {
//                    overpaidInvoiceRefList.add(invoiceItem.invoice?.reference)
//                }
//            }
        }
        currency = paymentDetailEntity?.itp?.payeeAccount?.currency
        countryCode = paymentDetailEntity?.itp?.payeeAccount?.countryCode
        mViewModel.requestPaymentMethods(paymentDetailEntity?.itp?.payeeReference
                ?: "", countryCode, currency)

        if ("created" == paymentDetail.payload?.status) {
            if ("S" != MemoryCache.getSessionEntity()?.type) {
                if ("credit_note" == paymentDetail.payload.itp?.paymentMethod) {
                    ll_invoice_update.visibility = View.VISIBLE
                    ll_payment_update.visibility = View.GONE
                    isCreditNoteMethod = true
                    isFullDeduction = false
                } else if ("full_deduction" == paymentDetail.payload.itp?.paymentMethod){
                    ll_invoice_update.visibility = View.VISIBLE
                    ll_payment_update.visibility = View.GONE
                    isCreditNoteMethod = false
                    isFullDeduction = true
                } else {
                    ll_invoice_update.visibility = View.VISIBLE
                    ll_payment_update.visibility = View.VISIBLE
                    isCreditNoteMethod = false
                    isFullDeduction = false
                }
                btn_revoke.visibility = View.VISIBLE
                if ("dcms" == paymentDetail.payload.itp?.paymentMethod) {
                    if (overpaidInvoiceRefList.isNotEmpty()) {
                        val sbOverpaid = StringBuilder()
                        overpaidInvoiceRefList.forEach { ref ->
                            sbOverpaid.append("-  ").append(ref).append("\n")
                        }

                        val refTip = String.format(MemoryCache.getLabelText("s_payment_invoice_overpaid_tip")
                                ?: getString(R.string.s_payment_invoice_overpaid_tip), sbOverpaid.toString())
                        tv_payment_overpaid_tip.text = refTip
                        v_payment_overpaid_tip_ic.visibility = View.VISIBLE
                        tv_payment_overpaid_tip.visibility = View.VISIBLE
                    } else {
                        v_payment_overpaid_tip_ic.visibility = View.GONE
                        tv_payment_overpaid_tip.visibility = View.GONE
                    }
                    val sharedPreferences = getSharedPreferences(DartApplication.instance?.applicationInfo?.packageName, Context.MODE_PRIVATE)
                    val firstMakePayment = sharedPreferences.getBoolean("firstMakePayment", true)
                    if (firstMakePayment) {
                        getSharedPreferences(DartApplication.instance?.applicationInfo?.packageName, Context.MODE_PRIVATE).edit().putBoolean("firstMakePayment", false).apply()
                        startActivity(Intent(this, BuyerTutorial6thActivity::class.java))
                    }
                    btn_make_pg.visibility = View.VISIBLE
                    TealiumUtil.pageTag("dart : buyer portal : payments : payment - make payment",
                            "/dart/buyer_portal/payments/payment-make_payment", "transaction",
                            "buyer portal", "payments", "Mobile App", "en",
                            "payment - make payment", "1",
                            "proceed to make payment")
                } else {
                    btn_make_pg.visibility = View.GONE
                }
                if (DateUtil.isBeforeCurrentDate(paymentDetail.payload.itp?.expectedDate)) {
                    if ("credit_note" == paymentDetail.payload.itp?.paymentMethod || "full_deduction" == paymentDetail.payload.itp?.paymentMethod)
                        rl_revoke_warnming.visibility = View.GONE
                    else
                        rl_revoke_warnming.visibility = View.VISIBLE
                    ll_invoice_update.isEnabled = false
                    tv_invoice_update.setTextColor(ContextCompat.getColor(this, R.color.disable_grey))
                    val drawableRight = ContextCompat.getDrawable(this, R.drawable.ic_edit_gray)
                    tv_invoice_update.setCompoundDrawablesWithIntrinsicBounds(null, null, drawableRight, null)
                    tv_invoice_update.compoundDrawablePadding = 5
                    TealiumUtil.pageTag("dart : buyer portal : payments : planned payments - payments due",
                            "/dart/buyer portal/payments/planned payments-payments due", "transaction", "buyer portal",
                            "payments")
                } else {
                    ll_invoice_update.isEnabled = true
                    tv_invoice_update.setTextColor(ContextCompat.getColor(this, R.color.primary_red))
                    rl_revoke_warnming.visibility = View.GONE
                    val drawableRight = ContextCompat.getDrawable(this, R.drawable.ic_edit)
                    tv_invoice_update.setCompoundDrawablesWithIntrinsicBounds(null, null, drawableRight, null)
                    tv_invoice_update.compoundDrawablePadding = 5
                }
            } else {
                ll_invoice_update.visibility = View.GONE
                ll_payment_update.visibility = View.GONE
                btn_revoke.visibility = View.GONE
                btn_make_pg.visibility = View.GONE
            }
        } else {
            ll_invoice_update.visibility = View.GONE
            btn_revoke.visibility = View.GONE
            ll_payment_update.visibility = View.GONE
            btn_make_pg.visibility = View.GONE
            btn_track.visibility = View.GONE

            if ("processing" == paymentDetail.payload?.status &&
                    "dcms" == paymentDetail.payload.itp?.paymentMethod) {
                btn_track.visibility = View.VISIBLE
                if ("B" == MemoryCache.getSessionEntity()?.type) {
                    val refTip = MemoryCache.getLabelText("s_own_payment_reference_dcms_processing")
                            ?: getString(R.string.s_own_payment_reference_dcms_processing)
                    tv_payment_ref_tip.text = refTip
                    tv_payment_ref_tip.contentDescription = refTip
                    tv_payment_ref_tip.visibility = View.VISIBLE
                    v_payment_ref_tip_ic.visibility = View.VISIBLE
                    TealiumUtil.pageTag("dart : buyer portal : payments : payment - track payment",
                            "/dart/buyer_portal/payments/payment-track_payment", "transaction",
                            "buyer portal", "payments", "Mobile App", "en",
                            "payment - track payment", "2",
                            "payment information")
                }
            }
        }

        //header
        tv_payment_ref.text = String.format(MemoryCache.getLabelText("s_payment_ref")
                ?: getString(R.string.s_payment_ref), paymentDetail.payload?.itp?.paymentReference)
        tv_reference.text = paymentDetail.payload?.itp?.paymentReference
        tv_reference.contentDescription = paymentDetail.payload?.itp?.paymentReference
        tv_due_date.text = "${MemoryCache.getLabelText("s_date")
                ?: getString(R.string.s_date)}: ${TimeZoneTransformsUtil.formatTime(paymentDetail.payload?.itp?.expectedDate)}"
        tv_supplier_name.text = organization
        var statusText = MemoryCache.getLabelText("s_payment_status_" + paymentDetail.payload?.status)
        if (statusText == "Processed") {
            if (MemoryCache.defaultCountry == "IN") {
                statusText = "Processing"
            }
        }
        tv_pay_status.text = statusText
        var amount = 0L
        var crAmount = 0L
        var deduction = 0L
        var onlyPending = true
        val confirmedDeductionList = mutableListOf<PlannedPaymentDeductionNotification>()
        val rejectedDeductionList = mutableListOf<PlannedPaymentDeductionNotification>()
        paymentDetail.payload?.itp?.lines?.forEach {
            if (INVOICE == it.type)
                amount += abs(it.amount?.amount?.toLong() ?: 0L)
            else if (CREDITNOTE == it.type)
                crAmount += abs(it.amount?.amount?.toLong() ?: 0L)
            else
                deduction += abs(it.amount?.amount?.toLong() ?: 0L)
        }
        tv_amount.text = "$currency ${IndiaNumberUtil.formatNumByDecimal(amount.toString(), currency
                ?: MARKET_CURRENCY)}"
        if (crAmount != 0L) {
            tv_cr_amount_total.visibility = View.VISIBLE
            tv_cr_amount_total.text = "${
                MemoryCache.getLabelText("s_cr_note_amount")
                        ?: getString(R.string.s_cr_note_amount)
            }: $currency -" +
                    IndiaNumberUtil.formatNumByDecimal(crAmount.toString().replace("-", ""), currency
                            ?: MARKET_CURRENCY)
        } else {
            tv_cr_amount_total.text = ""
            tv_cr_amount_total.visibility = View.GONE
        }

        if (deduction != 0L) {
            tv_deduction_amount_total.visibility = View.VISIBLE
            tv_deduction_amount_total.text = "${MemoryCache.getLabelText("s_deduction_amount")
                    ?: getString(R.string.s_deduction_amount)}: $currency -" +
                    IndiaNumberUtil.formatNumByDecimal(deduction.toString().replace("-", ""), currency
                            ?: MARKET_CURRENCY)
        } else {
            tv_deduction_amount_total.visibility = View.GONE
        }
        //Beneficiary info
        tv_bankname.text = MemoryCache.getLabelText("s_bank_name_value")
                ?: getString(R.string.s_bank_name_value)
        tv_account_number.text = paymentDetail.payload?.itp?.payeeAccount?.display
                ?: (paymentDetail.payload?.itp?.payeeAccount?.reference ?: "-")
        tv_account_name.text = paymentDetail.payload?.invoices?.get(0)?.invoice?.payee?.name ?: "-"
        //Payment info
        tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_" + paymentDetail.payload?.itp?.paymentMethod)
        tv_payment_date.text = TimeZoneTransformsUtil.formatTime(paymentDetail.payload?.itp?.expectedDate)
        rl_payment_date_container.visibility = View.VISIBLE
        rl_payment_detail_tag_container.visibility = View.VISIBLE
        rl_payment_method_container.visibility = View.VISIBLE
        when (paymentDetail.payload?.itp?.paymentMethod) {
            "ach" -> {
                view_ach.visibility = View.VISIBLE
            }

            "cheque" -> {
                views_cheque.visibility = View.VISIBLE
                tv_cheque_date.text = TimeZoneTransformsUtil.formatTime(paymentDetail.payload.itp.extra?.payment_cheque_date)
                tv_cheque_number.text = paymentDetail.payload.itp.extra?.payment_cheque_number
                et_cheque_amount.text = paymentDetail.payload.itp.extra?.payment_cheque_currency + " " +
                        IndiaNumberUtil.formatNumByDecimal(paymentDetail.payload.itp.extra?.payment_cheque_amount
                                ?: "0.00", currency ?: MARKET_CURRENCY)

            }

            "full_deduction" -> {
                rl_payment_date_container.visibility = View.GONE
                rl_payment_detail_tag_container.visibility = View.GONE
                rl_payment_method_container.visibility = View.GONE
            }
        }
        if (paymentDetail.payload?.itp != null) {
            val invoiceNotesMap = mutableMapOf<String, String>()
            //creditNotes
            val invoiceAmount = mutableMapOf<String, String>()
            val creditNotesSelectedMap = mutableMapOf<String, ArrayList<CreditNoteLocal>>()
            val deductionSelectedMap = mutableMapOf<String, ArrayList<TaxDeductionInfo>>()
            if (paymentDetail.payload.itp.lines != null) {
                for (item in paymentDetail.payload.itp.lines) {
                    if (CREDITNOTE == item.type) {
                        //figure out selected credit note
                        item.appliesTo?.let {
                            if (creditNotesSelectedMap[it].isNullOrEmpty()) {
                                creditNotesSelectedMap[it] = ArrayList()
                            }

                            var creditnote: CreditNoteLocal? = null
                            creditNotes?.forEach { cr ->
                                if (cr.token == item.token) {
                                    creditnote = CreditNoteLocal(cr.creditNote, cr.token, item.amount?.amount?.replace("-", ""), selected = true)
                                }
                            }
                            creditnote?.let { selectedCr ->
                                creditNotesSelectedMap[it]?.add(selectedCr)
                            }
                        }
                    } else if (INVOICE == item.type) {
                        invoiceAmount[item.token!!] = item.amount?.amount ?: "0.00"
                        if (item.comment != null)
                            invoiceNotesMap[item.token] = item.comment
                    } else {
                        if (item.status == "Confirmed") {
                            onlyPending = false
                            val confirmItem = PlannedPaymentDeductionNotification(item.amount?.currency,
                                    item.amount?.amount, item.appliesTo, null, null)
                            confirmedDeductionList.add(confirmItem)
                        } else if (item.status == "Rejected") {
                            onlyPending = false
                            val rejectItem = PlannedPaymentDeductionNotification(item.amount?.currency,
                                    item.amount?.amount, item.appliesTo, null, null)
                            rejectedDeductionList.add(rejectItem)
                        }
                        paymentDetail.payload.deductions?.get(item.appliesTo)?.forEach {
                            if (it.token == item.token) {
                                item.appliesTo?.let { applyto ->
                                    if (deductionSelectedMap[applyto].isNullOrEmpty()) {
                                        deductionSelectedMap[applyto] = ArrayList()
                                    }

                                    deductionSelectedMap[applyto]?.add(it)
                                }
                            }
                        }
                    }
                }
            }
            val invoicesAdd = mutableListOf<InvoiceAddEntity>()
            // check if any other vertical invoice is in this payment
            if (paymentDetail.payload.invoices != null) {
                var hasDisplayDialog = false
                for (i in paymentDetail.payload.invoices.indices) {
                    confirmedDeductionList.forEach {
                        if (paymentDetail.payload.invoices[i].token == it.appliesTo) {
                            it.invoiceRef = paymentDetail.payload.invoices[i].invoice?.reference
                            it.payeeName = paymentDetail.payload.invoices[i].invoice?.payee?.name
                        }
                    }
                    rejectedDeductionList.forEach {
                        if (paymentDetail.payload.invoices[i].token == it.appliesTo) {
                            it.invoiceRef = paymentDetail.payload.invoices[i].invoice?.reference
                            it.payeeName = paymentDetail.payload.invoices[i].invoice?.payee?.name
                        }
                    }
                    // 1.check if vertical name has been set and if user is supplier
                    if (MemoryCache.departmentName.isNotEmpty() &&
                            MemoryCache.getSessionEntity()?.type == "S" &&
                            !hasDisplayDialog) {
                        // 2.check if all invoices in this payment are in filtered invoice list from home page one by one
                        var inInvoiceList = false
                        for (item in MemoryCache.initInvoiceList?.payload?.invoices!!) {
                            if (paymentDetail.payload.invoices[i].invoice?.reference == item.reference) {
                                inInvoiceList = true
                            }
                        }
                        // 3.if any invoice is not in the initiated list, display warming dialog and set displayed flag to true
                        //      to avoid duplicating prompt
                        if (!inInvoiceList) {
                            CommonDialog.showDialog(this, getString(R.string.s_other_dep_invoice_dialog_title),
                                    getString(R.string.s_other_dep_invoice_dialog_msg), getString(R.string.s_other_dep_invoice_dialog_confirm),
                                    getString(R.string.s_cancel), cancelCallback = View.OnClickListener {
                                finish()
                            })
                            hasDisplayDialog = true
                        }
                    }
                    val invoiceToken = paymentDetail.payload.invoices[i].token
                    var invoiceActivation = false
                    if (paymentDetail.payload.invoices[i].active == true) {
                        invoiceActivation = true
                    } else {
                        ll_payment_update.visibility = View.GONE
                    }
                    invoicesAdd.add(InvoiceAddEntity(invoiceToken, paymentDetail.payload.invoices[i].invoice, invoiceAmount[invoiceToken]
                            ?: "", if (invoiceNotesMap.containsKey(invoiceToken)) invoiceNotesMap[invoiceToken] else "", null,
                            creditNotesSelectedMap[paymentDetail.payload.invoices[i].token],
                            null, deductionSelectedMap[invoiceToken], active = invoiceActivation))
                }
            }
            invoiceDetailList = invoicesAdd as ArrayList<InvoiceAddEntity>
            mAdapter.addData(invoicesAdd)
        }

        tv_copy.isEnabled = true
        if (paymentDetail.payload?.itp?.paymentMethod == "virtual_account" ||
                !paymentDetail.payload?.itp?.extra?.dcms_va_payment_code.isNullOrBlank()) {
            ll_va_info_container.visibility = View.VISIBLE
            val paymentCode = paymentDetail.payload?.itp?.extra?.dcms_va_payment_code!!
            tv_channel.text = MemoryCache.getVABankNameMap(this, paymentCode.substring(0, 5))
            tv_code.text = paymentCode
            if (paymentDetail.payload.itp.paymentMethod == "virtual_account") {
                btn_make_pg.visibility = View.GONE
            }
        }

        if (paymentDetail.payload?.itp?.extra?.dcms_va_payment_code.isNullOrBlank()) {
            ll_va_info_container.visibility = View.GONE
        }

        if ("B" == MemoryCache.getSessionEntity()?.type) {
            if (deduction != 0L) {
                v_payment_deduction_tip_ic.visibility = View.VISIBLE
                tv_payment_deduction_tip.visibility = View.VISIBLE
                if (onlyPending) {
                    v_payment_deduction_tip_ic.background = ContextCompat.getDrawable(this, R.drawable.ic_info_blue)
                    tv_payment_deduction_tip.text = "Deductions applied in the planned payment is being reviewed by supplier"
                } else {
                    if (rejectedDeductionList.isEmpty()) {
                        v_payment_deduction_tip_ic.visibility = View.GONE
                        tv_payment_deduction_tip.visibility = View.GONE
                    } else {
                        v_payment_deduction_tip_ic.background = ContextCompat.getDrawable(this, R.drawable.ic_alert_yellow)
                        val rejectInfoSB = StringBuilder()
                        rejectedDeductionList.forEach {
                            rejectInfoSB.append(String.format(MemoryCache.getLabelText("s_deduction_rejected_warming") ?:
                            getString(R.string.s_deduction_rejected_warming), it.currency + " -",
                                    IndiaNumberUtil.formatNumByDecimal(it.amount!!, it.currency!!).replace("-", ""),
                                    it.invoiceRef, it.payeeName)).append("\n")
                        }
                        tv_payment_deduction_tip.text = rejectInfoSB.toString().substring(0, rejectInfoSB.toString().length - 1)
                    }
                }
            } else {
                v_payment_deduction_tip_ic.visibility = View.GONE
                tv_payment_deduction_tip.visibility = View.GONE
            }
        }
    }

    override fun setCreditNotes(creditNotes: List<CreditNoteLocal>?) {
        this.creditNotes = creditNotes?.filter {
            try {
                (it.creditNote!!.amount.toLong() <= 0) && (it.creditNote!!.outstanding.toLong() <= 0)
            } catch (e: Exception) {
                false
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun setPaymentMethods(paymentMethods: PaymentMethod?) {
        if (paymentMethods == null) {
            return
        }
        this.paymentMethods = paymentMethods
        //just update ach payment method data
        if (paymentMethods.ach != null) {
            tv_URN_number.text = paymentMethods.ach?.extra?.ACH_mandate_urn ?: ""
            tv_expiration_date.text = TimeZoneTransformsUtil.formatTime(paymentMethods.ach?.extra?.ACH_mandate_date
                    ?: "")
            tv_maximum_amount.text = "$currency " + IndiaNumberUtil.formatNumByDecimal(paymentMethods.ach?.extra?.ACH_mandate_amount
                    ?: "", currency ?: MARKET_CURRENCY)
        }
    }

    override fun setItpRevokeResult() {
        setResult(Activity.RESULT_OK)
        finish()
    }

    override fun onItemClick(view: View, position: Int) {
        val invoice = InvoiceListNativeEntity(itemList[position].token, itemList[position].invoice, false, isShowHeader = false)
        InvoiceDetailActivity.showActivity(this, invoice, true)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_UPDATE_PAYMENT_INFO) {
                showLoadingDialogExt()
//                mPGViewModel.trackPayment(paymentReference ?: "")
                mViewModel.requestDetailAndCreditnote(paymentReference ?: "", countryCode, currency)
//                mViewModel.requestPaymentDetailData(paymentReference ?: "")
//                mViewModel.requestCreditNotes(countryCode, currency)
            } else if (requestCode == REQUEST_CODE_PAYMENT_GATEWAY_CONFIRM) {
                if ("pending" == paymentGatewayTrackEntity?.txnStatus) {
                    val dcmsForm = "<html><head><body>${paymentDetailEntity?.itp?.extra?.dcms_redirect_link}</body></html>"
                    showBottomSheet()
                    bottomWebView?.loadData(dcmsForm, "text/html", "utf-8")
                } else {
                    showLoadingDialogExt()
                    mPGViewModel.getPaymentGateHtml(token ?: "")
                }
//                showBottomSheet()
//                hideLoadingDialogExt()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:planned payments:payment detail",
                "/dart/buyer-portal/planned-payments/payment-detail", "payment", "buyer portal",
                "planned payments")
    }

    companion object {
        fun showActivity(fragment: Fragment, paymentReference: String, requestCode: Int) {
            val intent = Intent(fragment.activity, PlannedPaymentDetailActivity::class.java).apply {
                putExtra("paymentReference", paymentReference)
            }
            fragment.startActivityForResult(intent, requestCode)
        }

        fun showActivity(activity: Activity, paymentReference: String, requestCode: Int, isFinish: Boolean) {
            val intent = Intent(activity, PlannedPaymentDetailActivity::class.java).apply {
                putExtra("paymentReference", paymentReference)
            }
            activity.startActivityForResult(intent, requestCode)
            if (isFinish) {
                activity.setResult(Activity.RESULT_OK)
                activity.finish()
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (cl_bottom_sheet.visibility == View.VISIBLE) {
                if (bottomWebView?.canGoBack() == true) {
                    bottomWebView?.goBack()
                } else {
                    cl_bottom_sheet.visibility = View.GONE
                    v_slide_indicator.visibility = View.GONE
                    btn_make_pg.isEnabled = true
                }
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun notifySuccess() {
        if (isFinishPaid) {
            return
        }
        isFinishPaid = true
        startActivityForResult(Intent(this, PaymentSentSuccessActivity::class.java), REQUEST_CODE_UPDATE_PAYMENT_INFO)
        behavior?.state = BottomSheetBehavior.STATE_HIDDEN
        if (bottomWebView != null) {
            bottomWebView?.post {
                bottomWebView?.loadDataWithBaseURL(null, "", "text/html", "utf-8", null)
                bottomWebView?.stopLoading()
//                val parent = bottomWebView?.parent as ViewGroup
//                parent.removeView(bottomWebView)
                bottomWebView?.clearHistory()
                bottomWebView?.destroy()
                bottomWebView = null
            }
        }
    }

    override fun notifyUserCancel() {
        webviewHandler.sendEmptyMessage(0)
    }

    override fun notifyUserCancelFromWebview() {
        if (!isCancelling) {
            webviewHandler.sendEmptyMessage(1)
            isCancelling = true
        }
    }

    override fun notifyPayUError() {
        webviewHandler.sendEmptyMessage(2)
    }

    override fun notifyError() {
        webviewHandler.sendEmptyMessage(3)
    }

    override fun notifyPaymentCodeCreated(paymentCode: String, paymentRef: String) {
        currentPaymentCode = paymentCode
        currentPaymentRef = paymentRef
        webviewHandler.sendEmptyMessage(5)
    }
}


class WebViewInterface(notifyCallback: WebViewNotify?) {

    private var webviewNotifyCallback: WebViewNotify? = notifyCallback

    @JavascriptInterface
    fun checkContent(htmlStr: String?) {
        if (htmlStr?.contains("numva") == true) {
            val subPaymentCodeHtml = htmlStr.split("numva")
            val subPaymentRefHtml = htmlStr.split("<div class=\"fright\">")
            var paymentCode = ""
            var paymentRef = ""
            if (subPaymentCodeHtml.size == 2) {
                val leftArrowIndex = subPaymentCodeHtml[1].indexOf("<")
                if (leftArrowIndex > -1) {
                    val paymentCodeWhole = subPaymentCodeHtml[1].substring(0, leftArrowIndex)
                    val paymentCodeSub = paymentCodeWhole.split(">")
                    paymentCode = if (paymentCodeSub.size == 2) {
                        paymentCodeSub[1].trim()
                    } else {
                        ""
                    }
                }
            }

            if (subPaymentRefHtml.size == 2) {
                val leftArrowIndex = subPaymentRefHtml[1].indexOf("<")
                if (leftArrowIndex > -1) {
                    paymentRef = subPaymentRefHtml[1].substring(0, leftArrowIndex)
                    webviewNotifyCallback?.notifyPaymentCodeCreated(paymentCode, paymentRef)
                    return
                }
            }
        }

//        if (htmlStr?.contains("Payment Successful") == true) {
//            webviewNotifyCallback?.notifySuccess()
//            return
//        }
//
//        if (htmlStr?.contains("transaction failed") == true && htmlStr.contains("Cancelled by user")) {
//            webviewNotifyCallback?.notifyUserCancelFromWebview()
//            return
//        }
//
//        if (htmlStr?.contains("Transaction Failed") == true) {
//            webviewNotifyCallback?.notifyError()
//            return
//        }
//
//        if (htmlStr?.contains("Cancelled by user") == true) {
//            webviewNotifyCallback?.notifyUserCancel()
//            return
//        }
//
//        if (htmlStr?.contains("SORRY") == true || htmlStr?.contains("Sorry") == true) {
//            Log.e("test", "sorry there")
//            webviewNotifyCallback?.notifyPayUError()
//            return
//        }
    }
}

interface WebViewNotify {
    fun notifySuccess()
    fun notifyUserCancel()
    fun notifyUserCancelFromWebview()
    fun notifyPayUError()
    fun notifyError()
    fun notifyPaymentCodeCreated(paymentCode: String, paymentRef: String)
}