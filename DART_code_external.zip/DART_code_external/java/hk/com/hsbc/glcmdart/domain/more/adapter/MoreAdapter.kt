/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.more.entity.MoreEntity
import hk.com.hsbc.glcmdart.view.RecyclerExtras

class MoreAdapter(context: Context, private val infos: Array<MoreEntity>) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), RecyclerExtras.OnItemClickListener, RecyclerExtras.OnItemLongClickListener {
    val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getItemCount(): Int = infos.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_more_list, parent, false)
        return ItemHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        vh.ivIcon.setImageResource(infos[position].resId ?: 0)
        vh.tvTitle.text = infos[position].title
        vh.llItem.setOnClickListener { v ->
            itemClickListener?.onItemClick(v, position)
        }
        vh.llItem.setOnLongClickListener { v ->
            itemLongClickListener?.onItemLongClick(v, position)
            true
        }
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        var llItem: LinearLayout = view.findViewById(R.id.ll_item)
        var ivIcon: ImageView = view.findViewById(R.id.iv_icon)
        var tvTitle: TextView = view.findViewById(R.id.tv_title)
    }

    private var itemClickListener: RecyclerExtras.OnItemClickListener? = null
    fun setOnItemClickListener(listener: RecyclerExtras.OnItemClickListener) {
        this.itemClickListener = listener
    }

    private var itemLongClickListener: RecyclerExtras.OnItemLongClickListener? = null
    fun setOnItemLongClickListener(listener: RecyclerExtras.OnItemLongClickListener) {
        this.itemLongClickListener = listener
    }

    override fun onItemClick(view: View, position: Int) {

    }

    override fun onItemLongClick(view: View, position: Int) {

    }

}
