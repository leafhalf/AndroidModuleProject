/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_legal_list.*

class LegalListActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_legal_list)
        initView()
    }

    @SuppressLint("ResourceAsColor")
    private fun initView() {
        tl_head.title = MemoryCache.getLabelText("s_legal") ?: getString(R.string.s_legal)
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            finish()
        }
        tv_acknowledgement.setOnClickListener {
            TealiumUtil.eventTag(
                    "button click",
                    "more legal: acknowledgement")
            LegalPageActivity.showActivity(this, MemoryCache.getLabelText("s_acknowledge_of_3rd") ?: getString(R.string.s_acknowledge_of_3rd), ACKNOWLEDGEMENT_STATIC_URL)
        }
        tv_privacy.setOnClickListener {
            TealiumUtil.eventTag(
                    "button click",
                    "more legal: privacy and data")
            LegalPageActivity.showActivity(this, MemoryCache.getLabelText("s_privacy_and_data") ?: getString(R.string.s_privacy_and_data), PRIVACY_AND_DATA_STATIC_URL)
            TealiumUtil.pageTag(
                    "dart:buyer portal:more:privacy and data",
                    "/dart/buyer-portal/more/privacy-and-data",
                    "other",
                    "buyer portal",
                    "more")
        }
        tv_licence.setOnClickListener {
            TealiumUtil.eventTag(
                    "button click",
                    "more legal: user licence")
            var url = EULA_STATIC_URL
            url = url.replace("{country}", MemoryCache.defaultCountry ?: MARKET_COUNTRY)
            url = url.replace("{language}", MemoryCache.defaultLanguageFull ?: "en-in")
            url = url.replace("EULA.html", "EULA-${MemoryCache.defaultLanguageFull}.html")
            LegalPageActivity.showActivity(this, MemoryCache.getLabelText("s_about_EULA")
                    ?: getString(R.string.s_about_EULA), url, true)
//            LegalPageActivity.showActivity(this, MemoryCache.getLabelText("s_end_user_licence") ?: getString(R.string.s_end_user_licence), EULA_STATIC_URL)
            TealiumUtil.pageTag(
                    "dart:buyer portal:more:end user licence",
                    "/dart/buyer-portal/more/end-user-licence",
                    "other",
                    "buyer portal",
                    "more")
        }
        tv_cookie_policy.setOnClickListener {
            TealiumUtil.eventTag(
                    "button click",
                    "more legal: cookie policy")
            LegalPageActivity.showActivity(this, MemoryCache.getLabelText("s_cookie_policy") ?: getString(R.string.s_cookie_policy), COOKIE_POLICY_STATIC_URL)
            TealiumUtil.pageTag(
                    "dart:buyer portal:more:cookie policy",
                    "/dart/buyer-portal/more/cookie policy",
                    "other",
                    "buyer portal",
                    "more")
        }
        tv_terms_conditions.setOnClickListener {
            TealiumUtil.eventTag(
                    "button click",
                    "more legal: terms and conditions")
            LegalPageActivity.showActivity(this, MemoryCache.getLabelText("s_terms_conditions") ?: getString(R.string.s_terms_conditions),
                    if("B" == MemoryCache.getSessionEntity()?.type) TERMS_AND_CONDITIONS_STATIC_URL else TERMS_AND_CONDITIONS_SUPPLIER_STATIC_URL)
            TealiumUtil.pageTag(
                    "dart:buyer portal:more:terms and conditions",
                    "/dart/buyer-portal/more/terms-and-conditions",
                    "other",
                    "buyer portal",
                    "more")
        }

        MemoryCache.getLabelText("s_end_user_licence")?.let {
            if (!it.isBlank()) {
                tv_licence.text = it
            }
        }
        MemoryCache.getLabelText("s_privacy_and_data")?.let {
            if (!it.isBlank()) {
                tv_privacy.text = it
            }
        }
        MemoryCache.getLabelText("s_cookie_policy")?.let {
            if (!it.isBlank()) {
                tv_cookie_policy.text = it
            }
        }
        MemoryCache.getLabelText("s_acknowledge_of_3rd")?.let {
            if (!it.isBlank()) {
                tv_acknowledgement.text = it
            }
        }
        MemoryCache.getLabelText("s_terms_conditions")?.let {
            if (!it.isBlank()) {
                tv_terms_conditions.text = it
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:more:legal",
                "/dart/buyer-portal/more/legal",
                "other",
                "buyer portal",
                "more")
    }

    companion object {
        fun showActivity(activity: Activity?) {
            activity?.startActivity(Intent(activity, LegalListActivity::class.java))
        }
    }
}
