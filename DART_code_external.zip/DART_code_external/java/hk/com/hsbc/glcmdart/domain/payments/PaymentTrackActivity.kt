package hk.com.hsbc.glcmdart.domain.payments

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.client.TAG_PAYMENT_GATEWAY_DETAIL
import hk.com.hsbc.glcmdart.client.TAG_PAYMENT_GATEWAY_INVOICE_DETAIL
import hk.com.hsbc.glcmdart.client.TAG_PAYMENT_GATEWAY_TRACK
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentDetailEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentTrackInfo
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.*
import kotlinx.android.synthetic.main.activity_track_payment.*
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.ArrayList

class PaymentTrackActivity: BaseActivity() {

    private var invoiceDetailList: ArrayList<InvoiceAddEntity>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_track_payment)
        initViews()
    }

    private fun initViews() {
        val title = MemoryCache.getLabelText("s_track_payment") ?: getString(R.string.s_track_payment)
        tv_make_payment_date_and_time_tag.text = MemoryCache.getLabelText("s_date_and_time") ?: getString(R.string.s_date_and_time)
        tv_track_amount_tag.text = MemoryCache.getLabelText("s_tracking_no") ?: getString(R.string.s_tracking_no)
        tv_make_payment_invoice_detail_tag.text = MemoryCache.getLabelText("s_invoice_details") ?: getString(R.string.s_invoice_details)
        tv_payment_detail_tag.text = MemoryCache.getLabelText("s_payment_infomation") ?: getString(R.string.s_payment_infomation)
        quitButton.text = MemoryCache.getLabelText("s_talkback_close_button") ?: getString(R.string.s_talkback_close_button)
        val paymentDetail = intent.getSerializableExtra(TAG_PAYMENT_GATEWAY_DETAIL) as PaymentDetailEntity?
        val paymentTrackInfo = intent.getSerializableExtra(TAG_PAYMENT_GATEWAY_TRACK) as PaymentTrackInfo?
        tb_header.title = if (title.isBlank()) getString(R.string.s_track_payment) else title
        tb_header.navigationContentDescription = MemoryCache.getLabelText("s_talkback_close_button") ?: getString(R.string.s_talkback_close_button)
        tb_header.setNavigationOnClickListener {
            TealiumUtil.eventTag("button click", "track payment - ${paymentTrackInfo?.txnStatus}: exit")
            finish()
        }
        quitButton.setOnClickListener { finish() }
        this.invoiceDetailList = intent.getSerializableExtra(TAG_PAYMENT_GATEWAY_INVOICE_DETAIL) as ArrayList<InvoiceAddEntity>?
        ll_confirm_make_payment_invoice_tip_container.removeAllViews()
        invoiceDetailList?.forEach {
            ll_confirm_make_payment_invoice_tip_container.addView(generateInvoiceItems(it))
            val line = View(this)
            var lineLp = line.layoutParams
            if (lineLp == null) {
                lineLp = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ConvertUtil.dp2px(this, 1.0f).toInt())
            } else {
                lineLp.width = ViewGroup.LayoutParams.MATCH_PARENT
                lineLp.height = ConvertUtil.dp2px(this, 1.0f).toInt()
            }
            line.layoutParams = lineLp
            line.background = ContextCompat.getDrawable(this, R.drawable.line_divider)
            ll_confirm_make_payment_invoice_tip_container.addView(line)
        }

        tv_track_status.text = when(paymentTrackInfo?.txnStatus) {
            "usercancelled" -> MemoryCache.getLabelText("s_track_payment_status_fail") ?: getString(R.string.s_track_payment_status_fail)
            "captured" -> MemoryCache.getLabelText("s_track_payment_status_success") ?: getString(R.string.s_track_payment_status_success)
            "bounced" -> MemoryCache.getLabelText("s_track_payment_status_fail") ?: getString(R.string.s_track_payment_status_fail)
            "dropped" -> MemoryCache.getLabelText("s_track_payment_status_fail") ?: getString(R.string.s_track_payment_status_fail)
            "failed" -> MemoryCache.getLabelText("s_track_payment_status_fail") ?: getString(R.string.s_track_payment_status_fail)
            "initiated" -> MemoryCache.getLabelText("s_track_payment_status_inprogress") ?: getString(R.string.s_track_payment_status_inprogress)
            "pending" -> MemoryCache.getLabelText("s_track_payment_status_inprogress") ?: getString(R.string.s_track_payment_status_inprogress)
            "inprogress" -> MemoryCache.getLabelText("s_track_payment_status_inprogress") ?: getString(R.string.s_track_payment_status_inprogress)
            else -> MemoryCache.getLabelText("s_track_payment_status_inprogress") ?: getString(R.string.s_track_payment_status_inprogress)
        }
        val parseDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
        val formatter = SimpleDateFormat("yyyy MM dd HH:mm:ss")
        val txnDate = try {
            TimeZoneTransformsUtil.transforms(paymentTrackInfo?.txnDateTime ?: "")
//            parseDateFormat.parse(paymentTrackInfo?.txnDateTime)
        } catch (e: Exception) {
            ""
        }
//        tv_make_payment_date_and_time.text = if (txnDate == "") "" else formatter.format(txnDate)
        tv_make_payment_date_and_time.text = if (txnDate == "") "" else txnDate
        tv_track_amount.text = paymentTrackInfo?.txnRef
        val updateDate = try {
            TimeZoneTransformsUtil.transforms(paymentDetail?.updatedAt ?: "")
//            parseDateFormat.parse(paymentDetail?.updatedAt)
        } catch (e: Exception) {
            ""
        }
//        tv_track_date.text = if (updateDate == "") "" else formatter.format(updateDate)
        tv_track_date.text = if (updateDate == "") "" else updateDate
        tv_track_reference.text = paymentDetail?.itp?.paymentReference
        tv_make_payment_ref.text = paymentDetail?.itp?.paymentReference
        tv_supplier_name.text = MemoryCache.getOrganisationsMap()[paymentDetail?.itp?.payeeReference]?.name
        ll_status_group.contentDescription = tv_track_status.text.toString() + " " + tv_track_date.text.toString()
        ll_reference_group.contentDescription = tv_track_reference.text.toString() + " " + tv_track_reference_tag.text.toString()
    }

    private fun generateInvoiceItems(invoice: InvoiceAddEntity): View {
        val itemView = LayoutInflater.from(this).inflate(R.layout.item_payment_invoice_detail, null)
        val tvTitle: TextView = itemView.findViewById(R.id.tv_title)
        val tvAmount: TextView = itemView.findViewById(R.id.tv_amount)
        val rlCrNote: View = itemView.findViewById(R.id.rl_cr_note)
        val tvCrAmount: TextView = itemView.findViewById(R.id.tv_cr_amount)
        val tvDeductionAmount: TextView = itemView.findViewById(R.id.tv_deduction)
        val llDeduction: View = itemView.findViewById(R.id.ll_deduction)
        val llNote: View = itemView.findViewById(R.id.ll_note)
        val tvNote: TextView = itemView.findViewById(R.id.tv_note)
        val tvAmountTag: TextView = itemView.findViewById(R.id.tv_amount_tag)
        val tvCrNoteAmountTag: TextView = itemView.findViewById(R.id.tv_cr_note_amount_tag)
        val tvNoteTag: TextView = itemView.findViewById(R.id.tv_note_tag)

        MemoryCache.getLabelText("s_amount")?.let {
            if (!it.isBlank()) {
                tvAmountTag.text = it
            }
        }
        MemoryCache.getLabelText("s_cr_note_amount")?.let {
            if (!it.isBlank()) {
                tvCrNoteAmountTag.text = it
            }
        }
        MemoryCache.getLabelText("s_note")?.let {
            if (!it.isBlank()) {
                tvNoteTag.text = it
            }
        }
        tvTitle.text = invoice.invoice?.reference
        var amountStr = invoice.amount.toString()
        amountStr = if (amountStr.isBlank()) "0.00" else amountStr
        var amountTmpText = invoice.invoice?.summation?.outstanding?.currency + " " +
                IndiaNumberUtil.formatNumByDecimal(amountStr,
                        invoice.invoice?.summation?.outstanding?.currency ?: MARKET_CURRENCY)
        val decimalSymbol = if (invoice.invoice?.summation?.outstanding?.currency == "IDR") {
            ","
        } else {
            "."
        }
//        val subAmountText = amountTmpText.split(decimalSymbol)
//        if (subAmountText.size == 2) {
//            if (subAmountText[1].length == 1)
//                amountTmpText += "0"
//        }
        tvAmount.text = amountTmpText
        if (!TextUtils.isEmpty(invoice.comment)) {
            llNote.visibility = View.VISIBLE
            tvNote.text = invoice.comment
        } else {
            llNote.visibility = View.GONE
        }

        if (!invoice.creditNotesSelected.isNullOrEmpty()) {
            rlCrNote.visibility = View.VISIBLE
            var totalAmount = 0L
            invoice.creditNotesSelected?.forEach {
                totalAmount += it.outstanding?.toLong() ?: 0L
            }
            amountTmpText = "${invoice.invoice?.summation?.outstanding?.currency} -"+
                    IndiaNumberUtil.formatNumByDecimal(totalAmount.toString(), invoice.invoice?.summation?.outstanding?.currency ?: MARKET_CURRENCY).replace("-","")
            val subCRAmountText = amountTmpText.split(decimalSymbol)
            if (subCRAmountText.size == 2) {
                if (subCRAmountText[1].length == 1)
                    amountTmpText += "0"
            }
            tvCrAmount.text = amountTmpText
        } else {
            rlCrNote.visibility = View.GONE
        }

        if (!invoice.taxDeductionSelected.isNullOrEmpty()) {
            llDeduction.visibility = View.VISIBLE
            var totalAmount = 0L
            invoice.taxDeductionSelected?.forEach {
                totalAmount += it.actualAmount?.toLong() ?: 0L
            }
            amountTmpText = "${invoice.invoice?.summation?.outstanding?.currency} -"+
                    IndiaNumberUtil.formatNumByDecimal(totalAmount.toString(),
                            invoice.invoice?.summation?.outstanding?.currency ?: MARKET_CURRENCY).replace("-","")
            val subCRAmountText = amountTmpText.split(decimalSymbol)
            if (subCRAmountText.size == 2) {
                if (subCRAmountText[1].length == 1)
                    amountTmpText += "0"
            }
            tvDeductionAmount.text = amountTmpText
        } else {
            llDeduction.visibility = View.GONE
        }
        return itemView
    }
}