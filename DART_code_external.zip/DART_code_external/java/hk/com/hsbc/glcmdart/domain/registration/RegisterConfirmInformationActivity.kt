/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_REGISTER_CONFIRM_INFORMATION
import hk.com.hsbc.glcmdart.client.TAG_ANSWER_SECURITY_QUESTION_INFO
import hk.com.hsbc.glcmdart.client.TAG_INVITATION_CODE_COMPANY_NAME
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_confirm_information.*

/**
 * Created by Donut on 2018/11/14.
 */
class RegisterConfirmInformationActivity: BaseActivity() {

    companion object {
        fun showActivity(activity: Activity, info: RegistrationChallengeEntity?, companyName: String) {
            activity.startActivityForResult(Intent(activity, RegisterConfirmInformationActivity::class.java).apply {
                putExtra(TAG_ANSWER_SECURITY_QUESTION_INFO, info)
                putExtra(TAG_INVITATION_CODE_COMPANY_NAME, companyName)
            }, REQUEST_CODE_REGISTER_CONFIRM_INFORMATION)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirm_information)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(true, this)
        ll_top.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)

        initViewAndData()
    }

    private fun initViewAndData() {
        val mInfo = intent.getSerializableExtra(TAG_ANSWER_SECURITY_QUESTION_INFO) as RegistrationChallengeEntity?
        if (mInfo == null) {
            Toast.makeText(this, getString(R.string.s_data_error), Toast.LENGTH_SHORT).show()
            finish()
        } else {
            iv_back.setOnClickListener {
                TealiumUtil.eventTag("button click", "registration: confirm information: back")
                finish()
            }
            btn_confirm.setOnClickListener {
                TealiumUtil.eventTag("button click", "registration: confirm information: confirm")
                setResult(Activity.RESULT_OK)
                finish()
            }

            if(mInfo.payload.userType == "S") {
                tv_confirm_information_your_business_tag.visibility = View.GONE
                ll_confirm_information_company_container.visibility = View.GONE
                ll_confirm_information_pan_container.visibility = View.GONE
                ll_confirm_information_email_container.visibility = View.GONE
                ll_supplier_email_container.visibility = View.VISIBLE
                tv_confirm_information_your_contact_tag.text = getString(R.string.s_confirm_information_your_info)
                tv_confirm_information_tip.text = getString(R.string.s_confirm_information_supplier_tip)
                tv_confirm_information_contact_title.text = mInfo.payload.supplierSalesTitle
                tv_confirm_information_first_name.text = mInfo.payload.supplierSalesFirstName
                tv_confirm_information_last_name.text = mInfo.payload.supplierSalesLastName
                tv_confirm_information_supplier_email.text = mInfo.payload.supplierSalesEmailAddress
            } else {
                tv_confirm_information_company.text = intent.getStringExtra(TAG_INVITATION_CODE_COMPANY_NAME)
                tv_confirm_information_pan.text = mInfo.payload.companyTaxNumber
                tv_confirm_information_email.text = mInfo.payload.emailAddress
                tv_confirm_information_contact_title.text = mInfo.payload.buyerTitle
                tv_confirm_information_first_name.text = mInfo.payload.buyerFirstName
                tv_confirm_information_last_name.text = mInfo.payload.buyerLastName
            }
        }

        MemoryCache.getLabelText("s_talkback_back_button")?.let {
            if (!it.isBlank()) {
                iv_back.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_register_main_step3")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_title.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_buyer_tip")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_tip.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_your_business")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_your_business_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_tag_company")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_company_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_tag_PAN_number")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_pan_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_tag_email")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_email_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_your_contact")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_your_contact_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_tag_title")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_contact_title_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_tag_first_name")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_first_name_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_tag_last_name")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_last_name_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_tag_email")?.let {
            if (!it.isBlank()) {
                tv_confirm_information_supplier_email_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm_information_confirm")?.let {
            if (!it.isBlank()) {
                btn_confirm.text = it
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart : buyer portal : registration : confirm information",
                "/dart/buyer portal/registration/confirm information", "verification", "buyer portal",
                "registration", "mobile","en", "registration", "4","registration - confirm information")
    }
}