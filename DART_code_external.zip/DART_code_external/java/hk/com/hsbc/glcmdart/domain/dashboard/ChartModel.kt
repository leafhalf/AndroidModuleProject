/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.dashboard

import com.google.gson.Gson
import hk.com.hsbc.glcmdart.client.HOST_URL
import hk.com.hsbc.glcmdart.util.NetworkManager
import io.reactivex.Observable
import okhttp3.MediaType
import okhttp3.RequestBody

class ChartModel: ChartContract.Model {
    override fun getProfileDetail(): Observable<ProfileDetailEntity> {
        return NetworkManager.getNormalService(ChartServer::class.java, HOST_URL).getProfileDetail()
    }

    override fun getHomeFragmentChannelsData(requestBody: Map<String, Any>): Observable<HomePaymentChannelEntity> {
        val parameterStr = Gson().toJson(requestBody)
        val request = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(ChartServer::class.java, HOST_URL).getHomeFragmentChannelsData(request)
    }

    override fun getHomeInvoiceStatusData(requestBody: Map<String, Any>): Observable<HomeInvoiceStatusEntity> {
        val parameterStr = Gson().toJson(requestBody)
        val request = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(ChartServer::class.java, HOST_URL).getHomeInvoiceStatusData(request)
    }

    override fun getHomeInvoiceSummaryData(requestBody: Map<String, Any>): Observable<HomeInvoiceSummaryEntity> {
        val parameterStr = Gson().toJson(requestBody)
        val request = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(ChartServer::class.java, HOST_URL).getHomeInvoiceSummaryData(request)
    }

    override fun getHomeFragmentMetricsData(requestBody: Map<String, Any>): Observable<HomeInvoiceMetricsEntity> {
        val parameterStr = Gson().toJson(requestBody)
        val request = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(ChartServer::class.java, HOST_URL).getHomeFragmentMetricsData(request)
    }
}