/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.util.Pair
import androidx.core.view.ViewCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.CreditNoteLocal
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.domain.invoices.invoicedetail.InvoiceDetailActivity
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_DEFAULT
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_HIGH_TO_LOW
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_LOW_TO_HIGH
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_NEW_TO_OLD
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListSortPopupWindow.Companion.SORT_TYPE_OLD_TO_NEW
import hk.com.hsbc.glcmdart.domain.payments.AddNewInvoiceActivity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_select_invoice.*
import kotlinx.android.synthetic.main.view_custom_title_bar.*

/**
 * Created by Donut
 *
 * selectable invoice page, support multi-choice
 */
class InvoiceListSelectableActivity : BaseActivity(), InvoiceListContract.View,
        SwipeRefreshLayout.OnRefreshListener, OnRecyclerViewItemClickListener<InvoiceListNativeEntity> {

    private lateinit var mViewModel: InvoiceListViewModel

    //    private val mPresenter = InvoiceListPresenter()
    private var rvContentList: RecyclerView? = null
    private var srlContentRefresher: SwipeRefreshLayout? = null
    private var mAdapter: InvoiceListAdapter? = null
    private var tvNoData: TextView? = null
    private var screenPageItemSize = 0
    private var creditNotes: ArrayList<CreditNoteLocal>? = null
    private var invoicesAdd: ArrayList<InvoiceAddEntity>? = null
    private var deductions: HashMap<String, ArrayList<TaxDeductionInfo>?>? = null
    private var isLoading = false
    private var currency: String? = null
    private var lastSortType = 0
    private var isCreditNoteMethod = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_select_invoice)
        supportActionBar?.hide()
        initViewAndData()
    }

    private fun initViewAndData() {
        MemoryCache.getLabelText("s_show_outstanding_amount")?.let {
            if (!it.isBlank()) {
                tv_select_invoice_outstanding_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_no_record")?.let {
            if (!it.isBlank()) {
                tv_invoice_list_no_data.text = it
            }
        }
        MemoryCache.getLabelText("s_next")?.let {
            if (!it.isBlank()) {
                btn_bottom.text = it
            }
        }
        MemoryCache.getLabelText("s_search")?.let {
            if (!it.isBlank()) {
                et_search.hint = it
            }
        }

//        mPresenter.attachView(this)
        mViewModel = ViewModelProviders.of(this).get(InvoiceListViewModel::class.java)
        mViewModel.invoiceListLiveData.observe(this, Observer {
            val selectableList = it.filter { item -> item.invoice?.status != "O" && item.invoice?.status != "F" }
            if (selectableList.isEmpty()) {
                showData(false)
            } else {
                showData(true)
            }

            mAdapter?.setData(selectableList.toMutableList())
        })
        mViewModel.requestLoadingLiveData.observe(this, Observer {
            setLoading(it)
        })
        mViewModel.invoiceListSummaryLiveData.observe(this, Observer {
            updateRingData(it[0] as Long, it[1] as Long, it[2] as Long, it[3] as Long, it[4] as Long, it[5] as String)
        })

        currency = intent.getStringExtra(TAG_REQUEST_INTENT_DATA_INVOICE_CURRENCY)
        if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE) != null) {
            creditNotes = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE) as ArrayList<CreditNoteLocal>?
        }
//        if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_TAX_DEDUCTION) != null) {
//            deductions = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_TAX_DEDUCTION) as HashMap<String, ArrayList<TaxDeductionInfo>?>?
//        }
        deductions = MemoryCache.getCachedDeduction()
        if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_INVOICE) != null) {
            invoicesAdd = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_INVOICE) as ArrayList<InvoiceAddEntity>?
            mViewModel.setPreList(invoicesAdd)
//            mPresenter.setPreList(invoicesAdd)
        }
        tvNoData = tv_invoice_list_no_data
        tv_title.text = MemoryCache.getLabelText("s_select_invoice")
                ?: getString(R.string.s_select_invoice)
        tv_title.setTextColor(Color.WHITE)
        iv_search_close_or_search.visibility = View.VISIBLE
        tv_back.visibility = View.VISIBLE
        tv_back.setOnClickListener {
            if (et_search.visibility == View.GONE) {
                finish()
                return@setOnClickListener
            }

            if (et_search.text.toString().isEmpty()) {
                et_search.visibility = View.GONE
                tv_title.visibility = View.VISIBLE
                iv_search_close_or_search.visibility = View.VISIBLE
                iv_search_close_or_search.setBackgroundResource(R.drawable.ic_search)
                val imm = it.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(it.windowToken, 0)
                setLoading(true)
                mViewModel.getUploadParameter().search = ""
                mViewModel.doRequest(isLoadMore = false, isSelectable = true)
//                mPresenter.getUploadParameter().search = ""
//                mPresenter.getInvoiceList(isLoadMore = false, isSelectable = true)
            } else {
                et_search.text = null
            }
        }
        isCreditNoteMethod = intent.getBooleanExtra(TAG_REQUEST_INTENT_IS_CREDIT_NOTE_METHOD, false)
        mAdapter = InvoiceListAdapter(mutableListOf(), true).apply {
            onItemClickListener = this@InvoiceListSelectableActivity
            onSelectInvoiceCallback = object : OnSelectInvoiceListener {
                override fun onSelect(position: Int) {
                    mAdapter?.getData()?.let {
                        it[position].isChecked = !it[position].isChecked
                        TealiumUtil.eventTag("checkbox", "add new invoice: ${if (it[position].isChecked) "checked" else "unchecked"}")
                    }
                }
            }
        }
//        if (mAdapter != null) {
//            mPresenter.setAdapter(mAdapter!!)
//        }
        rvContentList = rv_invoice_list.apply {
            layoutManager = LinearLayoutManager(this@InvoiceListSelectableActivity, RecyclerView.VERTICAL, false)
            adapter = mAdapter
        }
        srlContentRefresher = srl_invoice_list_refresher.apply {
            if (rvContentList != null) {
                setScrollUpChild(rvContentList!!)
            }
            setOnRefreshListener(this@InvoiceListSelectableActivity)
        }

        iv_search_close_or_search.setOnClickListener {
            if (et_search.text.toString().isBlank()) {
                et_search.text = null
                tv_back.visibility = View.VISIBLE
                et_search.visibility = View.VISIBLE
                tv_title.visibility = View.GONE
                iv_search_close_or_search.visibility = View.GONE
                val imm = it.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.toggleSoftInput(0, 0)
                et_search.requestFocus()
            } else {
                TealiumUtil.eventTag("button click", "add new invoice: search")
                et_search.visibility = View.VISIBLE
                et_search.text = null
                tv_title.visibility = View.GONE
                iv_search_close_or_search.visibility = View.GONE
            }
        }

        btn_bottom.setOnClickListener {
            TealiumUtil.eventTag("button click", "add new invoice: next")
            val allData = mAdapter?.getData()
            if (allData != null) {
                val selectedData = mutableListOf<InvoiceListItem>()
                allData.forEach { item ->
                    if (item.isChecked) {
                        val selectedItem = InvoiceListItem(item.token, item.invoice, true)
                        selectedData.add(selectedItem)
                    }
                }

                if (selectedData.isEmpty()) {
                    Toast.makeText(this@InvoiceListSelectableActivity, MemoryCache.getLabelText("s_no_invoice_select")
                            ?: getString(R.string.s_no_invoice_select), Toast.LENGTH_SHORT).show()
                } else {
                    AddNewInvoiceActivity.showActivity(this, selectedData, this.creditNotes!!,
                            invoicesAdd!!, currency, REQUEST_CODE_ADD_NEW_INVOICE, isCreditNoteMethod)
                }
            } else {
                Toast.makeText(this@InvoiceListSelectableActivity, MemoryCache.getLabelText("s_empty_data")
                        ?: getString(R.string.s_empty_data), Toast.LENGTH_SHORT).show()
            }
        }


        et_search.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                showLoadingDialogExt()
                mViewModel.getUploadParameter().search = v?.text.toString()
                mViewModel.doRequest(isLoadMore = false, isSelectable = true)
//                mPresenter.getUploadParameter().search = v?.text.toString()
//                mPresenter.getInvoiceList(isLoadMore = false, isSelectable = true)
            }
            false
        }

        et_search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s.isNullOrEmpty()) {
                    iv_search_close_or_search.visibility = View.GONE
                } else {
                    iv_search_close_or_search.visibility = View.VISIBLE
                    iv_search_close_or_search.setBackgroundResource(R.drawable.ic_close_white)
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

        })

        mAdapter?.isShowOutstandingAmount = sw_outstanding.isChecked
        sw_outstanding.setOnCheckedChangeListener { _, isChecked ->
            TealiumUtil.eventTag("radio", "add new invoice: outstanding amount: ${if (isChecked) "enabled" else "disabled"}")
            mAdapter?.isShowOutstandingAmount = isChecked
            rvContentList?.requestLayout()
        }

        srlContentRefresher?.isRefreshing = false
        showLoadingDialogExt()
        mViewModel.getUploadParameter().currency = currency
        mViewModel.getUploadParameter().sorting = InvoiceRequestSort("issueDate", "desc")
        mViewModel.doRequest(isLoadMore = false, isSelectable = true)
//            mPresenter.getUploadParameter().currency = currency
//            mPresenter.getInvoiceList(isLoadMore = false, isSelectable = true)

        iv_sort_condition.setOnClickListener {
            TealiumUtil.eventTag("dropdown", "landing - invoices: sort by expanded")
            it.setBackgroundResource(R.drawable.ic_sorting_red)
            //do sorting when choose sort item
            val timeConditionWindow = InvoiceListSortPopupWindow(this, object : InvoiceSortPopupChoose {
                override fun onChoose(item: String) {
                    it.setBackgroundResource(R.drawable.ic_sorting)
                    when (item) {
                        (MemoryCache.getLabelText("tv_invoice_list_sort_default")
                                ?: getString(R.string.s_default)) -> {
                            TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Default")
                            lastSortType = SORT_TYPE_DEFAULT
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("issueDate", "desc")
                            mViewModel.getUploadParameter().sorting = InvoiceRequestSort("issueDate", "desc")
                        }
                        (MemoryCache.getLabelText("s_new_to_old")
                                ?: getString(R.string.s_new_to_old)) -> {
                            TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Due date: Newest to Oldest")
                            lastSortType = SORT_TYPE_NEW_TO_OLD
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("dueDate", "desc")
                            mViewModel.getUploadParameter().sorting = InvoiceRequestSort("dueDate", "desc")
                        }
                        (MemoryCache.getLabelText("s_old_to_new")
                                ?: getString(R.string.s_old_to_new)) -> {
                            TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Due date: Oldest to Newest")
                            lastSortType = SORT_TYPE_OLD_TO_NEW
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("dueDate", "asc")
                            mViewModel.getUploadParameter().sorting = InvoiceRequestSort("dueDate", "asc")
                        }
                        (MemoryCache.getLabelText("s_high_to_low")
                                ?: getString(R.string.s_high_to_low)) -> {
                            TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Amount: Highest to Lowest")
                            lastSortType = SORT_TYPE_HIGH_TO_LOW
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("amount", "desc")
                            mViewModel.getUploadParameter().sorting = InvoiceRequestSort("amount", "desc")
                        }
                        (MemoryCache.getLabelText("s_low_to_high")
                                ?: getString(R.string.s_low_to_high)) -> {
                            TealiumUtil.eventTag("dropdown", "landing - invoices: sort by: Amount: Lowest to Highest")
                            lastSortType = SORT_TYPE_LOW_TO_HIGH
//                                mPresenter.getUploadParameter().sorting = InvoiceRequestSort("amount", "asc")
                            mViewModel.getUploadParameter().sorting = InvoiceRequestSort("amount", "asc")
                        }

                    }
                    showLoadingDialogExt()
                    mViewModel.doRequest(isLoadMore = false, isSelectable = false)
//                        mPresenter.getInvoiceList(isLoadMore = false, isSelectable = false)
                }
            }).showUpPopupWindow(lastSortType)

            //recover the icon of sorting button
            timeConditionWindow.setOnDismissListener {
                TealiumUtil.eventTag("dropdown", "landing - invoices: sort by collapsed")
                it.setBackgroundResource(R.drawable.ic_sorting)
            }

            //adjust the popup window size
            if (Build.VERSION.SDK_INT >= 24) {
                val location = intArrayOf(0, 0)
                it.getLocationOnScreen(location)
                val h = it.resources.displayMetrics.heightPixels - location[1]
                timeConditionWindow.height = h - it.measuredHeight
            }

            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.N) {
                val location = intArrayOf(0, 0)
                it.getLocationOnScreen(location)
                timeConditionWindow.showAtLocation(it, Gravity.NO_GRAVITY, 0, location[1])
            } else {
                timeConditionWindow.showAsDropDown(it)
            }
        }
    }

    override fun onItemClick(view: View, viewType: Int, data: InvoiceListNativeEntity?, position: Int) {
//        val tvSupplierName = view.findViewById<TextView>(R.id.tv_invoice_list_item_supplier_name)
//        val tvInvoiceId = view.findViewById<TextView>(R.id.tv_invoice_list_item_item_id)
//        val tvInvoiceStatus = view.findViewById<TextView>(R.id.tv_invoice_list_item_state)
//        val invoiceIdName = "invoice_id:" + data?.invoice?.reference
//        val supplierName = "supplier_name:" + data?.invoice?.payee?.name
//        val statusName = "pay_state:" + data?.invoice?.reference + data?.invoice?.status
//        ViewCompat.setTransitionName(tvInvoiceId, invoiceIdName)
//        ViewCompat.setTransitionName(tvSupplierName, supplierName)
//        ViewCompat.setTransitionName(tvInvoiceStatus, statusName)
//        val part1 = Pair(tvSupplierName as View, ViewCompat.getTransitionName(tvSupplierName))
//        val part2 = Pair(tvInvoiceId as View, ViewCompat.getTransitionName(tvInvoiceId))
//        val part3 = Pair(tvInvoiceStatus as View, ViewCompat.getTransitionName(tvInvoiceStatus))
//        val activityOptionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(getFragmentActivity()!!, part1, part2, part3)
        TealiumUtil.eventTag("button click", "landing - invoices: invoice selected")
        val intent = Intent(this, InvoiceDetailActivity::class.java).apply {
            putExtra(TAG_INVOICE_TOKEN, data)
            putExtra(TAG_INVOICE_FROM_PLANNED_PAYMENT_CREATION, true)
        }
//        startActivity(intent, activityOptionsCompat.toBundle())
        startActivity(intent)
    }

    private fun setLoading(loadingFlag: Boolean) {
        isLoading = loadingFlag
        srlContentRefresher?.isRefreshing = loadingFlag
    }

    override fun restoreAdapter(adapter: InvoiceListAdapter) {
        mAdapter = adapter
        mAdapter?.isShowOutstandingAmount = sw_outstanding.isChecked
        screenPageItemSize = (rvContentList?.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()
    }

    override fun getFragmentActivity(): Activity? {
        return this
    }

    override fun getMainListView(): RecyclerView? {
        return rvContentList
    }

    override fun getMainRefresher(): SwipeRefreshLayout? {
        return srlContentRefresher
    }

    override fun updateTodayInvoiceInfo(invoiceCount: Int, invoiceAmount: Double, currency: String) {
    }

    override fun updateRingData(unpaidAmount: Long, partiallyAmount: Long, paidAmount: Long, overpaidAmount: Long, totalAmount: Long, currency: String, isShowOutstanding: Boolean) {
    }

    override fun showData(isHasData: Boolean) {
        hideLoadingDialogExt()
        setLoading(false)
        if (isHasData) {
            tvNoData?.visibility = View.GONE
            srlContentRefresher?.visibility = View.VISIBLE
        } else {
            tvNoData?.visibility = View.VISIBLE
            srlContentRefresher?.visibility = View.GONE
        }
    }

    override fun onRefresh() {
        if (!isLoading) {
            setLoading(true)
            mViewModel.doRequest(isLoadMore = false, isSelectable = true)
//            mPresenter.getInvoiceList(isLoadMore = false, isSelectable = true)
        }
    }

    override fun reAddScrollListener(isAdd: Boolean) {
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (resultCode) {
            Activity.RESULT_OK -> {
                val invoiceSelect = data?.getSerializableExtra(TAG_REQUEST_RESULT_INVOICE)
                val intent = Intent()
                intent.putExtra(TAG_REQUEST_RESULT_INVOICE, invoiceSelect)
                setResult(Activity.RESULT_OK, intent)
                finish()
            }
            Activity.RESULT_CANCELED -> {
                val invoiceSelect = data?.getSerializableExtra(TAG_REQUEST_RESULT_INVOICE) as List<InvoiceListItem>?
                val originList = mAdapter?.getData()
                if (originList != null) {
                    for (item in originList) {
                        if (invoiceSelect.isNullOrEmpty()) {
                            item.isChecked = false
                        } else {
                            var hasMatchItem = false
                            for (selectItem in invoiceSelect) {
                                if (selectItem.token == item.token) {
                                    item.isChecked = true
                                    hasMatchItem = true
                                }
                            }

                            if (!hasMatchItem) {
                                item.isChecked = false
                            }
                        }
                    }
                }
                val resultList = mutableListOf<InvoiceListNativeEntity>()
                if (originList != null) {
                    resultList.addAll(originList)
                }
                mAdapter?.setData(resultList)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart : buyer portal : invoices : add new invoice",
                "/dart/buyer portal/invoices/add new invoice",
                "transaction",
                "buyer portal",
                "invoices"
        )
    }
}