/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.view.RecyclerExtras

class PaymentMethodAdapter(private val context: Context,
                           private val mData: ArrayList<String>,
                           private var mRecyclerView: RecyclerView? = null) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val inflater: LayoutInflater = LayoutInflater.from(context)

    private var selectPosition: Int? = -1

    fun addData(dataList: ArrayList<String>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        notifyDataSetChanged()
    }

    fun setSelector(selectPosition: Int) {
        if (mRecyclerView?.isComputingLayout == false &&
                RecyclerView.SCROLL_STATE_IDLE == mRecyclerView?.scrollState) {
            this.selectPosition = selectPosition
            notifyDataSetChanged()
        } else {
            mRecyclerView?.post {
                this.selectPosition = selectPosition
                notifyDataSetChanged()
            }
        }
    }

    fun getSelector(): Int? = selectPosition


    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_payment_method, parent, false)
        return ItemHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        val titleText = MemoryCache.getLabelText("s_payment_method_label_" + mData[position])
        if (!titleText.isNullOrBlank()) {
            vh.tvTitle.text = titleText
            vh.rbSelect.contentDescription = titleText
        } else {
            vh.tvTitle.text = mData[position]
            vh.rbSelect.contentDescription = mData[position]
        }
        MemoryCache.getLabelText("s_talkback_clickable_item")?.let {
            if (!it.isBlank()) {
                vh.tvTitle.contentDescription = it + "invoice reference " + " " + mData[position]
            } else {
                vh.tvTitle.contentDescription = context.getString(R.string.s_talkback_clickable_item) + "invoice reference " + mData[position]
            }
        }

        vh.rbSelect.isChecked = this.selectPosition == position

        vh.rbSelect.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                setSelector(position)
            }
        }

        vh.rlItem.setAccessibilityDelegate(object : View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        })
        vh.rlItem.setOnClickListener { v ->
            itemClickListener?.onItemClick(v, position)
        }
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val rlItem: RelativeLayout = view.findViewById(R.id.rl_item)
        val tvTitle: TextView = view.findViewById(R.id.tv_title)
        val rbSelect: RadioButton = view.findViewById(R.id.rb_select)
    }

    private var itemClickListener: RecyclerExtras.OnItemClickListener? = null

    fun setOnItemClickListener(listener: RecyclerExtras.OnItemClickListener) {
        this.itemClickListener = listener
    }
}
