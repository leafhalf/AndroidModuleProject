/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.welcome

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.login.LanguageDialog
import hk.com.hsbc.glcmdart.domain.login.LoginActivity
import hk.com.hsbc.glcmdart.domain.login.SelectLanguageCallback
import hk.com.hsbc.glcmdart.domain.registration.RegisterTAndCActivity
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_welcome.*
import kotlinx.android.synthetic.main.activity_welcome.areaText
import kotlinx.android.synthetic.main.activity_welcome.contentLayout
import kotlinx.android.synthetic.main.activity_welcome.logonButton

class WelcomeActivity : BaseActivity(), View.OnClickListener, SelectLanguageCallback {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        removeStatusView(this)
        contentLayout.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)
        logonButton.setOnClickListener(this)
        signupButton.setOnClickListener(this)
        areaText.setAccessibilityDelegate(object: View.AccessibilityDelegate() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        })
        areaText.setOnClickListener(this)

        when(MemoryCache.defaultLanguageFull) {
            "en-in" -> {
                areaText.text = getString(R.string.s_language_tip1)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.login_and_register_india_flag, 0, 0, 0)
            }
            "en-id" -> {
                areaText.text = getString(R.string.s_language_tip2)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_indonezia_flag, 0, 0, 0)
            }
            "id-id" -> {
                areaText.text = getString(R.string.s_language_tip3)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_indonezia_flag, 0, 0, 0)
            }
            "en-au" -> {
                areaText.text = getString(R.string.s_language_tip4)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_australia_flag, 0, 0, 0)
            }
            "en-sg" -> {
                areaText.text = getString(R.string.s_language_tip5)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_singapore_flag, 0, 0, 0)
            }
        }

        MemoryCache.getLabelText("head_welcome")?.let {
            if (!it.isBlank()) {
                welcomeText.text = it
            }
        }

        MemoryCache.getLabelText("message_welcome")?.let {
            if (!it.isBlank()) {
                logonText.text = it
            }
        }

        MemoryCache.getLabelText("button_logon")?.let {
            if (!it.isBlank()) {
                logonButton.text = it
            }
        }

        MemoryCache.getLabelText("button_signUp")?.let {
            if (!it.isBlank()) {
                signupButton.text = it
            }
        }
    }

    override fun onClick(v: View?) {
        when (v) {
            logonButton -> {
                TealiumUtil.eventTag(
                        "button click",
                        "dart - welcome: log on"
                )
                startActivity(Intent(this@WelcomeActivity, LoginActivity::class.java))
                finish()
            }
            signupButton -> {
                TealiumUtil.eventTag(
                        "button click",
                        "dart - welcome: sign up"
                )
                RegisterTAndCActivity.showActivity(this, isFromRegister = true)
            }
            areaText -> {
                LanguageDialog.showLanguageDialog(this, this)
            }
        }
    }

    override fun onLanguageChange(language: String) {
        areaText.text = language
        recreate()
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart:buyer portal:logon:welcome",
                "/dart/buyer-portal/logon/welcome",
                "authentication",
                "buyer portal",
                "logon"
        )
    }
}

