/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.SearchTextChangeCallback
import hk.com.hsbc.glcmdart.domain.payments.adapter.SupplierAdapter
import hk.com.hsbc.glcmdart.domain.payments.contract.SupplierOrCustomerContract
import hk.com.hsbc.glcmdart.domain.payments.presenter.SupplierOrCustomerViewModel
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import kotlinx.android.synthetic.main.activity_suppliers_or_customers_select.*
import kotlinx.android.synthetic.main.view_custom_title_bar.view.*

class SuppliersOrCustomersSelectActivity : BaseActivity(), SupplierOrCustomerContract.View, RecyclerExtras.OnItemClickListener, SearchTextChangeCallback {

    private lateinit var mViewModel: SupplierOrCustomerViewModel
    //    private val mPresenter by lazy { SupplierOrCustomerPresenter() }
    private var itemList = ArrayList<Payee>()
    private val mAdapter by lazy { SupplierAdapter(this, itemList) }
    private var isSelectCustomer = false
    private var isFromInvoicesFilter = false
    private var isTealiumPaymentSupplierEnter = false
    private var isTealiumInvoicesSupplierEnter = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_suppliers_or_customers_select)
        isSelectCustomer = "S" == MemoryCache.getSessionEntity()?.type
        initView()
        mViewModel = ViewModelProviders.of(this).get(SupplierOrCustomerViewModel::class.java)
        mViewModel.requestData(isSelectCustomer)
        mViewModel.organizationLiveData.observe(this, Observer {
            setSuppliersList(it)
        })
    }

    private fun initView() {
        isFromInvoicesFilter = intent.getBooleanExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_FROM_FLAG, false)
        if (isFromInvoicesFilter) {
            tv_supplier_or_buyer_title.visibility = View.GONE
            v_supplier_select_title_bar.tv_back.setBackgroundResource(R.drawable.ic_arrow_back_black)
            v_supplier_select_title_bar.tv_back.visibility = View.VISIBLE
            v_supplier_select_title_bar.iv_search_close_or_search.visibility = View.VISIBLE
            v_supplier_select_title_bar.tv_back.setOnClickListener { finish() }
            MemoryCache.getLabelText("s_talkback_back_button")?.let {
                if (!it.isBlank()) {
                    v_supplier_select_title_bar.tv_back.contentDescription = it
                }
            }
        } else {
            v_supplier_select_title_bar.tv_back.setBackgroundResource(R.drawable.ic_arrow_back_black)
            v_supplier_select_title_bar.tv_back.visibility = View.VISIBLE
            tv_supplier_or_buyer_title.visibility = View.VISIBLE
            v_supplier_select_title_bar.tv_title.text = MemoryCache.getLabelText("s_filters") ?: getString(R.string.s_filters)
        }

        v_supplier_select_title_bar.iv_search_close_or_search.contentDescription =
                if ("B" == MemoryCache.getSessionEntity()?.type)
                    MemoryCache.getLabelText("s_talkback_search_supplier") ?: getString(R.string.s_talkback_search_supplier)
                else
                    MemoryCache.getLabelText("s_talkback_search_buyer") ?: getString(R.string.s_talkback_search_buyer)
        v_supplier_select_title_bar.setBackgroundColor(Color.WHITE)
        v_supplier_select_title_bar.tv_title.setTextColor(Color.BLACK)
        if (isFromInvoicesFilter) {
            v_supplier_select_title_bar.tv_title.text = if (isSelectCustomer) {
                MemoryCache.getLabelText("s_customer") ?: getString(R.string.s_customer)
            } else {
                MemoryCache.getLabelText("s_supplier") ?: getString(R.string.s_supplier)
            }
        } else {
            tv_supplier_or_buyer_title.text = if (isSelectCustomer) {
                MemoryCache.getLabelText("s_customer") ?: getString(R.string.s_customer)
            } else {
                MemoryCache.getLabelText("s_supplier") ?: getString(R.string.s_supplier)
            }
        }
        v_supplier_select_title_bar.iv_search_close_or_search.setBackgroundResource(R.drawable.ic_search_black)
        v_supplier_select_title_bar.iv_search_close_or_search.visibility = View.VISIBLE
        v_supplier_select_title_bar.iv_search_close_or_search.setOnClickListener {
            v_supplier_select_title_bar.iv_search_close_or_search.visibility = View.GONE
            if (v_supplier_select_title_bar.et_search.visibility == View.GONE) {
                v_supplier_select_title_bar.et_search.text = null
                v_supplier_select_title_bar.tv_back.visibility = View.VISIBLE
                v_supplier_select_title_bar.et_search.visibility = View.VISIBLE
                v_supplier_select_title_bar.tv_title.visibility = View.GONE
                if (!isFromInvoicesFilter) {
                    TealiumUtil.eventTag("button click", "payment - filter: search")
                }
            } else {
                if (!isFromInvoicesFilter) {
                    TealiumUtil.eventTag("button click", "planned payments supplier popup: clear search")
                } else {
                    TealiumUtil.eventTag("button click", "invoices supplier popup: clear search")
                }
                v_supplier_select_title_bar.et_search.text = null

                onSearchTextChanged("")
            }
        }
        v_supplier_select_title_bar.et_search.setTextColor(Color.BLACK)
        v_supplier_select_title_bar.et_search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (!isSelectCustomer) {
                    if (!isFromInvoicesFilter) {
                        if (!isTealiumPaymentSupplierEnter) {
                            TealiumUtil.eventTag("text entry", "planned payments supplier popup: search bar entered")
                            isTealiumPaymentSupplierEnter = true
                        }
                    } else {
                        if (!isTealiumInvoicesSupplierEnter) {
                            TealiumUtil.eventTag("text entry", "invoices supplier popup: search bar entered")
                            isTealiumInvoicesSupplierEnter = true
                        }
                    }
                }
                if (!v_supplier_select_title_bar.et_search.text.toString().isBlank()) {
                    if (v_supplier_select_title_bar.iv_search_close_or_search.visibility == View.GONE) {
                        v_supplier_select_title_bar.iv_search_close_or_search.visibility = View.VISIBLE
                        v_supplier_select_title_bar.iv_search_close_or_search.background = ContextCompat.getDrawable(this@SuppliersOrCustomersSelectActivity, R.drawable.ic_close_on_light)
                    }
                }
                onSearchTextChanged(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

        })

        v_supplier_select_title_bar.tv_back.setOnClickListener {
            if (v_supplier_select_title_bar.et_search.visibility == View.GONE) {
                finish()
                return@setOnClickListener
            }
            v_supplier_select_title_bar.et_search.visibility = View.GONE
            v_supplier_select_title_bar.tv_title.visibility = View.VISIBLE
            v_supplier_select_title_bar.iv_search_close_or_search.visibility = View.VISIBLE
            v_supplier_select_title_bar.iv_search_close_or_search.background = ContextCompat.getDrawable(this@SuppliersOrCustomersSelectActivity, R.drawable.ic_search_black)
            onSearchTextChanged("")
        }
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        mAdapter.setOnItemClickListener(this)
        rv_invoice_add_or_edit.adapter = mAdapter

        MemoryCache.getLabelText("s_no_record")?.let {
            if (!it.isBlank()) {
                tv_no_record.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_search")?.let {
            if (!it.isBlank()) {
                v_supplier_select_title_bar.iv_search_close_or_search.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_search")?.let {
            if (!it.isBlank()) {
                v_supplier_select_title_bar.et_search.hint = it
            }
        }
        MemoryCache.getLabelText("s_search")?.let {
            if (!it.isBlank()) {
                v_supplier_select_title_bar.et_search.hint = it
            }
        }
    }

    override fun onItemClick(view: View, position: Int) {
        if (position == 0) {
            if (!isFromInvoicesFilter) {
                TealiumUtil.eventTag("button click", "planned payments supplier popup: all selected")
            } else {
                TealiumUtil.eventTag("button click", "invoices supplier popup: all selected")
            }
        } else {
            if (!isFromInvoicesFilter) {
                TealiumUtil.eventTag("button click", "planned payments supplier popup: supplier selected")
            } else {
                TealiumUtil.eventTag("button click", "invoices supplier popup: supplier selected")
            }
        }

        val resultIntent = Intent().apply {
            putExtra(TAG_SELECT_SUPPLIER_RESULT, mAdapter.getData()?.get(position))
        }
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    override fun setSuppliersList(payees: List<Payee>) {
        val originSupplier = intent?.getStringExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN)
        val originCurrency = intent?.getStringExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN_CURRENCY)
        val dataList = mutableListOf(Payee(MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all),
                MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all),
                null, null, settings = null, isChecked = true)).apply {
            addAll(payees)
        }
        itemList = (dataList.distinctBy { it.reference }) as ArrayList<Payee>
        if (!originSupplier.isNullOrEmpty() && originSupplier != (MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all))) {
            var hasMatch = false
            itemList.forEach {
                it.isChecked = it.reference == originSupplier && (it.account == null || it.account.currency == originCurrency)
                if (!hasMatch) {
                    hasMatch = it.isChecked
                }
            }
            if (!hasMatch) {
                itemList[0].isChecked = true
            }
        } else {
            itemList[0].isChecked = true
        }
        mAdapter.addData(itemList)
    }

    override fun onSearchTextChanged(searchText: String?) {
        val searchList = mutableListOf<Payee>()
        if (searchText.isNullOrEmpty()) {
            searchList.addAll(itemList)
        } else {
            itemList.forEach {
                it.name?.also { name ->
                    if (name.contains(searchText)) {
                        searchList.add(it)
                    }
                }
            }
        }

        if (searchList.isNotEmpty()) {
            tv_no_record.visibility = View.GONE
            rv_invoice_add_or_edit.visibility = View.VISIBLE
            mAdapter.addData(searchList as ArrayList<Payee>)
        } else {
            mAdapter.addData(ArrayList())
            tv_no_record.visibility = View.VISIBLE
            rv_invoice_add_or_edit.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        if (!isSelectCustomer) {
            if (!isFromInvoicesFilter) {
                TealiumUtil.pageTag("dart:buyer portal:planned payments:supplier popup",
                        "/dart/buyer-portal/planned-payments/supplier-popup", "payment", "buyer portal",
                        "planned payments")
            } else {
                TealiumUtil.pageTag("dart:buyer portal:invoices:supplier popup",
                        "/dart/buyer-portal/invoices/supplier-popup", "invoice", "buyer portal",
                        "invoices")
            }
        }
    }

    companion object {
        fun showActivity(activity: Activity?, origin: String?, originCurrency: String?, requestCode: Int, isFromInvoiceFilter: Boolean = false, isSelectCustomers: Boolean = false) {
            val intent = Intent(activity, SuppliersOrCustomersSelectActivity::class.java).apply {
                putExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN, origin)
                putExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN_CURRENCY, originCurrency)
                putExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_FROM_FLAG, isFromInvoiceFilter)
                putExtra(TAG_FILTER_SELECT_SUPPLIER_OR_CUSTOMERS_FLAG, isSelectCustomers)
            }
            activity?.startActivityForResult(intent, requestCode)
        }

        fun showActivity(fragment: Fragment, origin: String?, originCurrency: String?, requestCode: Int, isSelectCustomers: Boolean = false) {
            val intent = Intent(fragment.activity, SuppliersOrCustomersSelectActivity::class.java).apply {
                putExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN, origin)
                putExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN_CURRENCY, originCurrency)
                putExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_FROM_FLAG, false)
                putExtra(TAG_FILTER_SELECT_SUPPLIER_OR_CUSTOMERS_FLAG, isSelectCustomers)
            }
            fragment.startActivityForResult(intent, requestCode)
        }
    }
}
