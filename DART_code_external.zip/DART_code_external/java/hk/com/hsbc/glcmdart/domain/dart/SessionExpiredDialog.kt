/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dart

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.login.LoginActivity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.ConvertUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.dialog_session_expired.*

class SessionExpiredDialog constructor(context: Context): Dialog(context, R.style.AlertDialog) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_session_expired)
        setCanceledOnTouchOutside(false)
        setCancelable(false)
        val params = window.attributes
        params.width = ConvertUtil.dp2px(context, 220.0f).toInt()
        window.attributes = params
        val topActivity = ApplicationManager.getTopActivity()

        MemoryCache.getLabelText("title_session_expired")?.let {
            if (!it.isBlank()) {
                tv_expired_dialog_title.text = it
            }
        }
        MemoryCache.getLabelText("description_session_expired")?.let {
            if (!it.isBlank()) {
                tv_expired_dialog_tip.text = it
            }
        }
        MemoryCache.getLabelText("button_cancel")?.let {
            if (!it.isBlank()) {
                cancelButton.text = it
            }
        }
        MemoryCache.getLabelText("button_logon")?.let {
            if (!it.isBlank()) {
                logonButton.text = it
            }
        }
        logonButton.also {
            it.setOnClickListener {
                TealiumUtil.eventTag("button click", "time out overlay: log on")
                if (topActivity is BaseActivity) {
                    topActivity.startActivity(Intent(topActivity, LoginActivity::class.java))
                    topActivity.finish()
                    ApplicationManager.finishOtherActivities(LoginActivity::class.java)
                }
            }
        }
        cancelButton.also {
            it.setOnClickListener {
                TealiumUtil.eventTag("button click", "time out overlay: cancel")
                dismiss()
            }
        }
    }
}
