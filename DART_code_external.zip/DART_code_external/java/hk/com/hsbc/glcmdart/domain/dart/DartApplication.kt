/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dart

import android.app.Application
import android.app.NotificationManager
import android.content.Context
import android.util.Log
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.tealium.library.Tealium
import com.urbanairship.UAirship
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.client.TAG_IS_NOTIFICATION_ON_FLAG
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.ConnectivityUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.NetworkManager
import no.promon.shield.callbacks.CallbackManager

open class DartApplication : Application() {

    companion object {
        var instance: DartApplication? = null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        // Initialize the crashed handler
//        if (BuildConfig.DEBUG) {
//            Thread.setDefaultUncaughtExceptionHandler(CrashedHandler(this))
//        }
        // Register activity callback
        registerActivityLifecycleCallbacks(ACTIVITY_CALLBACK)

        // Initialize the connectivity util
        ConnectivityUtil.initialize(this)
        // Initialize the application manager
        ApplicationManager.initialize(this)

        // Initialize the network
        NetworkManager.initialize(this)
        NetworkManager.setDebug(BuildConfig.DEBUG)
        NetworkManager.addInterceptor(DartInterceptor())
        //test error return
//        NetworkManager.addInterceptor(TestInterceptor())
//        NetworkManager.addInterceptor(CloseConnectInterceptor())
        NetworkManager.setEnvironment(BuildConfig.FLAVOR_env)
        //test in cert pin mode
//        NetworkManager.setSecurityType(4)
        when (BuildConfig.FLAVOR_secure) {
            "review" -> {
                NetworkManager.setSecurityType(1)
            }
            "certPinning" -> {
                NetworkManager.setSecurityType(2)
            }
            "certValidation" -> {
                NetworkManager.setSecurityType(3)
            }
            "cert", "secure" -> {
                NetworkManager.setSecurityType(4)
            }
        }
        NetworkManager.setPublicKeys(DartCertificate.getPublicKeys(this))

        // Initialize the data storage
        // MFDatastorageKit.init(this)

        // Initialize the RASP
        // MFRASPManager.init(this)

        // Show the env
        if (BuildConfig.FLAVOR_env != "prod" && BuildConfig.DEBUG) {
            Toast.makeText(this,
                    BuildConfig.FLAVOR_env,
                    Toast.LENGTH_LONG).show()
        }

        // Initialize Shield SDK
        if (BuildConfig.FLAVOR_secure == "secure") {
            CallbackManager.setExtendedObserver(applicationContext, EXTENDED_OBSERVER)
        }

        // Enable urban airship
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancelAll()
        UAirship.takeOff(this)
        FirebaseApp.initializeApp(this)
        UAirship.shared().pushManager.userNotificationsEnabled = getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).getBoolean(TAG_IS_NOTIFICATION_ON_FLAG, true)
        val channelId = UAirship.shared().pushManager.channelId
        MemoryCache.saveChannelId(channelId)
        if (BuildConfig.DEBUG) {
            Log.e("test", channelId ?: "")
        }

        // Initialize Tealium SDK
        val tealiumConfig = Tealium.Config.create(this, "hsbc", "global-gbm-dart-mobile",
                if (BuildConfig.FLAVOR_env == "prod") "prod" else "qa").apply {
            datasourceId = "dataId"
            forceOverrideLogLevel = "prod"
        }
        Tealium.createInstance("DART", tealiumConfig)
    }
}