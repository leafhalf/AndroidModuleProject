package hk.com.hsbc.glcmdart.domain.creditnote

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_CREDITNOTES_FILTER
import hk.com.hsbc.glcmdart.domain.creditnote.CreditNoteFilterActivity.Companion.FILTER_CURRENCY
import hk.com.hsbc.glcmdart.domain.creditnote.CreditNoteFilterActivity.Companion.FILTER_SUPPLIER_OR_BUYER
import hk.com.hsbc.glcmdart.domain.dart.CreditnotePayloadLocal
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.home.HomeActivity
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.SearchTextChangeCallback
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.widget.SpacesItemDecoration
import kotlinx.android.synthetic.main.fragment_credit_note.*
import kotlinx.android.synthetic.main.fragment_credit_note.view.*
import kotlinx.android.synthetic.main.view_creditnotes_filter.*
import kotlinx.android.synthetic.main.view_creditnotes_filter.view.*
import java.lang.Exception

class CreditNoteFragment : Fragment(), CreditNoteListContract.View, SwipeRefreshLayout.OnRefreshListener, SearchTextChangeCallback {
    private val itemList = ArrayList<CreditnotePayloadLocal>()
    private val mAdapter by lazy { activity?.let { CreditNoteListAdapter(it, itemList) } }
//    private val mPresenter by lazy { CreditNoteListPresenter() }
    private var mIsRefresh: Boolean = false
    private lateinit var loadingView: ProgressBar
    private var payeeOrPayor: Payee? = null
    private var payeeCreditNoteReference: String? = ""
    private val currencies = ArrayList<String>()
    private var supplierOrBuyer: Boolean = false
    private lateinit var mViewModel: CreditNoteViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val rootView = inflater.inflate(R.layout.fragment_credit_note, container, false)
        mViewModel = ViewModelProviders.of(this).get(CreditNoteViewModel::class.java)
        mViewModel.creditNoteLiveData.observe(this, Observer {
            hideLoadingDialogExt()
            setRequestDataResult(it.filter {
                try {
                    (it.creditNote.amount.toLong() <= 0) && (it.creditNote.outstanding.toLong() <= 0)
                } catch (e: Exception) {
                    false
                }
            })
        })
        mViewModel.requestFailLiveData.observe(this, Observer {
            hideLoadingDialogExt()
            setRequestDataFailed(it ?: "Load Data Fail")
        })
        loadingView = rootView.pb_loading
        MemoryCache.getLabelText("s_no_record")?.let {
            if (!it.isBlank()) {
                rootView.tvNoData.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_invoice_filter")?.let {
            if (!it.isBlank()) {
                rootView.iv_creditnotes_filter.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_show_outstanding_amount")?.let {
            if (!it.isBlank()) {
                rootView.sw_available.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_show_available_amount")?.let {
            if (!it.isBlank()) {
                rootView.tv_available_tag.text = it
            }
        }
        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViewAndEvent()
    }

    private fun initViewAndEvent() {
        supplierOrBuyer = ("S" == MemoryCache.getSessionEntity()?.type)
//        mPresenter.attachView(this)
        loadingView.visibility = View.VISIBLE
        loadingView.announceForAccessibility(MemoryCache.getLabelText("s_loading") ?: getString(R.string.s_loading))
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(activity)
        rv_invoice_add_or_edit.addItemDecoration(activity?.let { SpacesItemDecoration(it, resources.getDimension(R.dimen.d_common_padding_margin_1).toInt()) }!!)
        rv_invoice_add_or_edit.adapter = mAdapter
        refreshLayout.setOnRefreshListener(this)
        iv_creditnotes_filter.setOnClickListener { CreditNoteFilterActivity.showActivity(this, payeeOrPayor, currencies, REQUEST_CODE_CREDITNOTES_FILTER) }
//        mPresenter.requestData
        mViewModel.doRequest(if (payeeOrPayor != null) {
            payeeOrPayor?.reference ?: ""
        } else {
            MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
        }, payeeCreditNoteReference, currencies)
        sw_available.setOnCheckedChangeListener { _, isChecked ->
            mAdapter?.switchAmountDisType(isChecked)
        }

    }

    override fun onRefresh() {
        if (!mIsRefresh) {
            setRefreshState(true)
            payeeCreditNoteReference = (activity as HomeActivity).getCurrentSearchingContent()
//            mPresenter.requestData
            mViewModel.doRequest(if (payeeOrPayor != null) {
                payeeOrPayor?.reference ?: ""
            } else {
                MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
            }, payeeCreditNoteReference, currencies)
        }
    }

    private fun setRefreshState(b: Boolean) {
        if (b) {
            refreshLayout.announceForAccessibility(MemoryCache.getLabelText("s_loading") ?: getString(R.string.s_loading))
        } else {
            refreshLayout.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete") ?: getString(R.string.talkBack_loading_complete))
        }
        mIsRefresh = b
        refreshLayout.isRefreshing = b
    }

    override fun onSearchTextChanged(searchText: String?) {
        if (!mIsRefresh) {
            setRefreshState(true)
            payeeCreditNoteReference = searchText
//            mPresenter.requestData
            mViewModel.doRequest(if (payeeOrPayor != null) {
                payeeOrPayor?.reference ?: ""
            } else {
                MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)
            }, payeeCreditNoteReference, currencies)
        }
    }

    fun changeSearchText(searchText: String?) {
        onSearchTextChanged(searchText)
    }

    override fun setRequestDataResult(creditNoteList: List<CreditnotePayloadLocal>) {
        setRefreshState(false)
        mAdapter?.addData(creditNoteList)
        showOrDismissNoDataView(itemList)
    }

    override fun setRequestDataFailed(msg: String) {
        setRefreshState(false)
        itemList.clear()
        mAdapter?.notifyDataSetChanged()
        showOrDismissNoDataView(itemList)
    }

    private fun showOrDismissNoDataView(creditNoteList: List<CreditnotePayloadLocal>) {
        if (loadingView.visibility == View.VISIBLE) {
            loadingView.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete") ?: getString(R.string.talkBack_loading_complete))
            loadingView.visibility = View.GONE
        }

        if (creditNoteList.isNotEmpty()) {
            rlNull.visibility = View.GONE
            rv_invoice_add_or_edit.visibility = View.VISIBLE
        } else {
            rv_invoice_add_or_edit.visibility = View.GONE
            rlNull.visibility = View.VISIBLE
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && REQUEST_CODE_CREDITNOTES_FILTER == requestCode) {
            currencies.clear()
            if (data?.getSerializableExtra(FILTER_CURRENCY) != null) {
                currencies.addAll(data.getSerializableExtra(FILTER_CURRENCY) as List<String>)
            }
            if (data?.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) != null)
                this.payeeOrPayor = data.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) as Payee?
            else
                this.payeeOrPayor = null
            onRefresh()
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() = CreditNoteFragment()
    }
}
