package hk.com.hsbc.glcmdart.domain.payments.dialog

import android.app.Dialog
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import hk.com.hsbc.glcmdart.domain.payments.adapter.DeductionExtendAdapter
import hk.com.hsbc.glcmdart.domain.payments.adapter.DeductionExtendItemClickListener
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache

object DeductionExtendDialog {

    fun showDialog(c: BaseActivity?, deductions: List<TaxDeductionInfo>, deductionName: String, pos: Int,
        callback: DeductionApplyCallback?) {

        if (c == null) {
            return
        }

        val mDialog = Dialog(c, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(c).inflate(R.layout.dialog_deduction_extend, null)
        val tvDescription = mContentView.findViewById<TextView>(R.id.tv_deduction_name)
        val rvDeductionExtend = mContentView.findViewById<RecyclerView>(R.id.rv_deduction_extend)
        val btnCancel = mContentView.findViewById<Button>(R.id.btn_cancel)
        val btnConfirm = mContentView.findViewById<Button>(R.id.btn_confirm)

        tvDescription.text = deductionName
        var adapter: DeductionExtendAdapter? = null
        var subItemPosition = 0
        for (i in deductions.indices) {
            if (deductions[i].selected) {
                subItemPosition = i
                break
            }
        }
        val onItemClickListener = object: DeductionExtendItemClickListener {
            override fun onItemClick(position: Int) {
                deductions.forEach { it.selected = false }
                deductions[position].selected = true
                subItemPosition = position
                adapter?.notifyDataSetChanged()
            }
        }
        adapter = DeductionExtendAdapter(c, deductions, onItemClickListener)
        rvDeductionExtend.layoutManager = LinearLayoutManager(c)
        rvDeductionExtend.addItemDecoration(DividerItemDecoration(c, DividerItemDecoration.VERTICAL))
        rvDeductionExtend.adapter = adapter

        btnCancel.setOnClickListener { mDialog.cancel() }
        btnConfirm.setOnClickListener {
            mDialog.cancel()
            callback?.onDeductionSelected(deductions, pos, subItemPosition)
        }

        mDialog.setContentView(mContentView)
        mDialog.setCanceledOnTouchOutside(true)
        mDialog.setCancelable(true)
        mDialog.show()
    }

    interface DeductionApplyCallback {
        fun onDeductionSelected(deductions: List<TaxDeductionInfo>, callerPosition: Int, subItemPosition: Int)
    }
}