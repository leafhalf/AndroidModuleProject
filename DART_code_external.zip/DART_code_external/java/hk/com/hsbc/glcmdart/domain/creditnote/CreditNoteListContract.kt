package hk.com.hsbc.glcmdart.domain.creditnote

import hk.com.hsbc.glcmdart.domain.dart.CreditnotePayloadLocal
import hk.com.hsbc.glcmdart.framework.IView

interface CreditNoteListContract {

    interface View : IView {
        fun setRequestDataResult(creditNoteList: List<CreditnotePayloadLocal>)
        fun setRequestDataFailed(msg:String)
    }
}