/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.login

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import java.io.Serializable

@Keep
data class LoginBean(
        val username: String,
        val password: String
) : Serializable

@Keep
data class LoginEntity(
        val payload: LoginPayload,
        val status: String?,
        val code: String?,
        val errorText: String?
) : Serializable

@Keep
data class LoginPayload(
        val AMToken: String,
        val I8Token: String,
        val SessionInfo: SessionInfo
) : Serializable

@Keep
data class SessionInfo(
        val session_id: String,
        val name: String,
        val username: String,
        val user_id: String,
        val org_name: String,
        val org_id: String,
        val type: String
) : Serializable

@Keep
data class SessionEntity(
    val payload: SessionPayload
) : Serializable

@Keep
data class SessionPayload(
    val session_id: String,
    val name: String,
    val username: String,
    val user_id: String,
    val org_name: String,
    val org_id: String,
    val max_time_remaining: Int,
    val idle_time_remaining: Int,
    val type: String?,
    val supplier_email: String?
) : Serializable

@Keep
class LogoutEntity : Serializable

@Keep
data class ProfileEntity(
        val payload: ProfilePayload?
)

@Keep
data class ProfilePayload(
        val user: User?
)

@Keep
data class User(
        val reference: String?,
        val name: String?,
        val type: String,
        val lastLoginDate: String?,
        @SerializedName("country_code")
        val countryCode: String?,
        @SerializedName("external_reference")
        val externalReference: String?,
        val status: String?,
        val email: String?,
        @SerializedName("first_name")
        val firstName: String?,
        @SerializedName("last_name")
        val lastName: String?,
        val guid: String?,
        @SerializedName("user_title")
        val userTitle: String?,
        @SerializedName("payee_reference")
        val payeeReference: String?,
        @SerializedName("payor_reference")
        val payorReference: String?,
        val groups: GroupListInfo?
)

@Keep
data class GroupListInfo(
        val groups: List<GroupInfo>?,
        val sequence: String?
)

@Keep
data class GroupInfo(
        val groupType: String?,
        val groupValue: String
)

@Keep
data class RequestUrbanAirship(
        var channel: String?,
        var user_reference: String?,
        var device: String = "android"
)

@Keep
data class UrbanAirshipEntity(
        val payload: UrbanAirshipPayload?
)

@Keep
data class UrbanAirshipPayload(
        val push_notification_user: UrbanAirshipUserInfo?
)

@Keep
data class UrbanAirshipUserInfo(
        val user_reference: String?,
        val channel: String?,
        val device: String,
        val status: String?,
        val created_at: String?,
        val modified_at: String?
)

@Keep
data class DetachUrbanAirshipEntity(
        val payload: DetachUrbanAirshipPayload?
)

@Keep
data class DetachUrbanAirshipPayload(
        val push_notification_user: DetachUrbanAirshipInfo?
)

@Keep
data class DetachUrbanAirshipInfo(
        val user_reference: String?,
        val status: String?
)