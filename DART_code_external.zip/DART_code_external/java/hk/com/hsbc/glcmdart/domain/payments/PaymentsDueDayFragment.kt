/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.AppBarLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_PAYMENT_DUE_FILTER
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_UPDATE_PAYMENT_LIST
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.home.HomeActivity
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.SearchTextChangeCallback
import hk.com.hsbc.glcmdart.domain.payments.PaymentDueFilterActivity.Companion.FILTER_CURRENCY
import hk.com.hsbc.glcmdart.domain.payments.PaymentDueFilterActivity.Companion.FILTER_SUPPLIER_OR_BUYER
import hk.com.hsbc.glcmdart.domain.payments.adapter.PaymentDueDayAdapter
import hk.com.hsbc.glcmdart.domain.payments.contract.PaymentDueContract
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentDueDayLocalEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.domain.payments.presenter.PaymentDueDayViewModel
import hk.com.hsbc.glcmdart.util.*
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import hk.com.hsbc.glcmdart.widget.StickyHeaderItemDecoration
import kotlinx.android.synthetic.main.fragment_payments_due_day.*
import kotlinx.android.synthetic.main.view_due_today_payment_header.*
import kotlinx.android.synthetic.main.view_payment_filter_item.*
import java.util.*

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * Use the [PaymentsDueDayFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class PaymentsDueDayFragment : Fragment(), PaymentDueContract.View, RecyclerExtras.OnItemClickListener, SearchTextChangeCallback, SwipeRefreshLayout.OnRefreshListener {
    private var param1: Boolean? = true
    private var param2: PlannedPaymentListPayload? = null
//    private val mPresenter by lazy { PaymentDueDayPresenter() }
    private val itemList = ArrayList<PlannedPaymentDueDayLocalEntity>()
    private val mAdapter by lazy { activity?.let { PaymentDueDayAdapter(it, itemList) } }
    private var mIsRefresh: Boolean = false
    private lateinit var loadingView: ProgressBar
    private var payeeOrPayor: Payee? = null
    private var currentSearch: String? = ""
    var currency: String? = null
    private lateinit var mViewModel: PaymentDueDayViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getBoolean(ARG_PARAM1, true)
            if (param1 == false)
                param2 = it.getSerializable(ARG_PARAM2) as PlannedPaymentListPayload
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_payments_due_day, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
//        mPresenter.attachView(this)
        mViewModel = ViewModelProviders.of(this).get(PaymentDueDayViewModel::class.java)
        mViewModel.paymentDueDaySummaryLiveData.observe(this, androidx.lifecycle.Observer {
            setHeaderViewData(it[0], it[1])
        })

        mViewModel.paymentDueDayLiveData.observe(this, androidx.lifecycle.Observer {
            setDuePaymentList(it)
        })

        mViewModel.paymentErrorLiveData.observe(this, androidx.lifecycle.Observer {
            setRequestDataFailed(it ?: "")
        })
        if (param1 == true) {
            currency = MemoryCache.defaultCurrency
            loadingView.visibility = View.VISIBLE
            loadingView.announceForAccessibility(MemoryCache.getLabelText("s_loading") ?: getString(R.string.s_loading))
            mViewModel.requestData(if (payeeOrPayor != null) {
                payeeOrPayor?.reference ?: ""
            } else {
                getString(R.string.s_all)
            }, currentSearch, currency, true)
        } else {
            refreshLayout.isEnabled = false
            mViewModel.dealWithData(param2)
        }
    }

    private fun initView() {
        if (param1 == true) {
            abl_title.visibility = View.VISIBLE
        }
        loadingView = pb_loading
        tv_today_invoice_header_date.text = TimeZoneTransformsUtil.formatTime(DateUtil.getDateStrBySimpleDateFormate(Date()))
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(activity)
        mAdapter?.setOnItemClickListener(this)
        rv_invoice_add_or_edit.adapter = mAdapter
        refreshLayout.setOnRefreshListener(this)
        abl_title.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { _, verticalOffset ->
            refreshLayout.isEnabled = verticalOffset >= 0
        })
        rv_invoice_add_or_edit.addItemDecoration(StickyHeaderItemDecoration(rv_invoice_add_or_edit, mAdapter as PaymentDueDayAdapter))
        ib_filter.setOnClickListener {
            PaymentDueFilterActivity.showActivity(this, payeeOrPayor, currency, REQUEST_CODE_PAYMENT_DUE_FILTER)
        }

        MemoryCache.getLabelText("s_as_of_today")?.let {
            if (!it.isBlank()) {
                today_invoice_header_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_overdue_payments")?.let {
            if (!it.isBlank()) {
                tv_today_invoice_header_overdue_invoices_num_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_amount_to_pay")?.let {
            if (!it.isBlank()) {
                tv_today_invoice_header_amount_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_payment_filter")?.let {
            if (!it.isBlank()) {
                ib_filter.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_no_amount_due")?.let {
            if (!it.isBlank()) {
                tv_today_invoice_header_amount.text = it
            }
        }
    }

    private fun setRefreshState(b: Boolean) {
        if (b) {
            refreshLayout.announceForAccessibility(MemoryCache.getLabelText("s_loading") ?: getString(R.string.s_loading))
        } else {
            refreshLayout.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete") ?: getString(R.string.talkBack_loading_complete))
        }
        mIsRefresh = b
        refreshLayout.isRefreshing = b
    }

    @SuppressLint("SetTextI18n")
    override fun setHeaderViewData(overDueNumber: Long, overDueAmount: Long) {
        tv_today_invoice_header_overdue_invoices_num.text = overDueNumber.toString()
        tv_today_invoice_header_amount.text = "$currency " + IndiaNumberUtil.formatNum(MemoryCache.globalDecimal.format(overDueAmount.toDouble() / 100.00), currency ?: MARKET_CURRENCY)
    }

    override fun onItemClick(view: View, position: Int) {
        TealiumUtil.eventTag("button click", "landing - planned payments: payment selected")
        PlannedPaymentDetailActivity.showActivity(this, itemList[position].token!!, REQUEST_CODE_UPDATE_PAYMENT_LIST)
    }

    override fun onSearchTextChanged(searchText: String?) {
        TealiumUtil.eventTag("text entry", "planned payments - payments due: search bar: text entered")
        if (!mIsRefresh) {
            setRefreshState(true)
            v_payment_due_today_header.visibility = View.GONE
            this.currentSearch = searchText
            mViewModel.requestData(if (payeeOrPayor != null) {
                payeeOrPayor?.reference ?: ""
            } else {
                getString(R.string.s_all)
            }, currentSearch, currency)
        }
    }

    override fun clearSearchEditText() {
        TealiumUtil.eventTag("button click", "planned payments - payments due: search bar: clear search")
    }

    override fun setDuePaymentList(plannedPaymentLocalEntities: List<PlannedPaymentDueDayLocalEntity>) {
        setRefreshState(false)
        showOrDismissNoDataView(plannedPaymentLocalEntities)
        mAdapter?.addData(plannedPaymentLocalEntities as ArrayList<PlannedPaymentDueDayLocalEntity>)
    }

    override fun onRefresh() {
        if (!mIsRefresh) {
            if (activity is HomeActivity) {
                this.currentSearch = (activity as HomeActivity).getCurrentSearchingContent()
            }
            setRefreshState(true)
            mViewModel.requestData(if (payeeOrPayor != null) {
                payeeOrPayor?.reference ?: ""
            } else {
                getString(R.string.s_all)
            }, currentSearch, currency)
        }
    }

    override fun setRequestDataFailed(msg: String) {
        setRefreshState(false)
        itemList.clear()
        mAdapter?.notifyDataSetChanged()
        setHeaderViewData(0L, 0L)
        showOrDismissNoDataView(itemList)
    }

    private fun showOrDismissNoDataView(plannedPaymentLocalEntities: List<PlannedPaymentDueDayLocalEntity>) {
        if (loadingView.visibility == View.VISIBLE) {
            loadingView.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete") ?: getString(R.string.talkBack_loading_complete))
            loadingView.visibility = View.GONE
        }

        if (plannedPaymentLocalEntities.isNotEmpty()) {
            tv_no_data.visibility = View.GONE
            rv_invoice_add_or_edit.visibility = View.VISIBLE
            v_payment_due_today_header.visibility = View.VISIBLE
        } else {
            rv_invoice_add_or_edit.visibility = View.GONE
            tv_no_data.visibility = View.VISIBLE
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CODE_PAYMENT_DUE_FILTER -> {
                    currency = data?.getStringExtra(FILTER_CURRENCY)
                    if (data?.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) != null)
                        this.payeeOrPayor = data.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) as Payee?
                    else
                        this.payeeOrPayor = null
                    onRefresh()
                }
                REQUEST_CODE_UPDATE_PAYMENT_LIST -> {
                    onRefresh()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:planned payments:payments due",
                "/dart/buyer-portal/planned-payments/payments-due", "landing", "buyer portal",
                "planned payments")
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment PaymentsDueDayFragment.
         */
        @JvmStatic
        fun newInstance(param1: Boolean, param2: PlannedPaymentListPayload?) =
                PaymentsDueDayFragment().apply {
                    arguments = Bundle().apply {
                        putBoolean(ARG_PARAM1, param1)
                        putSerializable(ARG_PARAM2, param2)
                    }
                }
    }
}
