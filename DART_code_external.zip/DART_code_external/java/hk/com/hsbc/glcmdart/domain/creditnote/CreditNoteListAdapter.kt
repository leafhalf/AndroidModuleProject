/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.creditnote

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.dart.CreditnotePayloadLocal
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache

class CreditNoteListAdapter(context: Context, private val mData: ArrayList<CreditnotePayloadLocal>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var swAmount = true

    fun addData(dataList: List<CreditnotePayloadLocal>) {
        this.mData.clear()
        if (!dataList.isNullOrEmpty())
            this.mData.addAll(dataList)
        notifyDataSetChanged()
    }

    fun switchAmountDisType(swAmount: Boolean?) {
        this.swAmount = swAmount ?: false
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_creditnotes_list, parent, false)
        return ItemHolder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        vh.tvRole.text = mData[position].supplierOrBuyerName
        vh.tvPreference.text = mData[position].creditnotePreference
        vh.tvAmount.text = "${mData[position].currency} " + IndiaNumberUtil.formatNumByDecimal(if (swAmount) {
            mData[position].creditNote.outstanding
        } else {
            mData[position].creditNote.amount
        },mData[position].currency).replace("-", "")
        vh.tvStatus.text = MemoryCache.getLabelText("s_creditnote_status_" + mData[position].creditNote.status)
        vh.llCreditnote.setOnClickListener { }
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val llCreditnote: View = view.findViewById<View>(R.id.llCreditnote)
        val tvRole: TextView = view.findViewById(R.id.tvRole)
        val tvPreference: TextView = view.findViewById(R.id.tvPreference)
        val tvAmount: TextView = view.findViewById(R.id.tvAmount)
        val tvStatus: TextView = view.findViewById(R.id.tvStatus)
    }

}
