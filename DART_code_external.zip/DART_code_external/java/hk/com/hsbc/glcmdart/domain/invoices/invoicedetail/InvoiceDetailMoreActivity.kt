/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.invoices.invoicedetail

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_INVOICE_DETAIL
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.activity_invoice_detail_more.*

class InvoiceDetailMoreActivity : BaseActivity() {

    companion object {
        fun showActivity(activity: Activity, invoiceDetail: InvoiceDetailEntity?) {
            val intent = Intent(activity, InvoiceDetailMoreActivity::class.java).apply {
                putExtra(TAG_INVOICE_DETAIL, invoiceDetail)
            }

            activity.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invoice_detail_more)
        tl_invoice_detail_more.setNavigationOnClickListener { finish() }
        MemoryCache.getLabelText("s_more_information")?.let {
            if (!it.isBlank()) {
                tl_invoice_detail_more.title = it
            }
        }
        tv_invoice_detail_more_supplier_account_tag.text = MemoryCache.getLabelText("s_supplier_account") ?:
                getString(R.string.s_supplier_account)
        tv_invoice_detail_more_buyer_account_tag.text = MemoryCache.getLabelText("s_buyer_account") ?:
                getString(R.string.s_buyer_account)
        tv_invoice_detail_more_buyer_address_tag.text = MemoryCache.getLabelText("s_address") ?:
                getString(R.string.s_address)
        tv_invoice_detail_more_supplier_address_tag.text = MemoryCache.getLabelText("s_address") ?:
                getString(R.string.s_address)
        val invoiceDetailInfo = intent?.extras?.getSerializable(TAG_INVOICE_DETAIL) as InvoiceDetailEntity?
        invoiceDetailInfo?.let {
            initViewAndData(it)
        }

    }

    private fun initViewAndData(invoiceDetailEntity: InvoiceDetailEntity) {
        val labels = MemoryCache.getInvoiceExtraLabelObject()
        tv_invoice_detail_more_buyer_info_tag.text = labels.buyerAddress.title
        tv_invoice_detail_more_buyer_pod_tag.text = labels.buyerAddress.addressPrefix
        tv_invoice_detail_more_supplier_info_tag.text = labels.supplierAddress.title
        tv_invoice_detail_more_supplier_pod_tag.text = labels.supplierAddress.addressPrefix
        tv_invoice_detail_more_summary_tag.text = labels.charges.title
        tv_invoice_detail_more_taxable_tag.text = labels.charges.taxableValue
        tv_invoice_detail_more_cgst_tag.text = labels.charges.cgst
        tv_invoice_detail_more_sgst_tag.text = labels.charges.sgst
        tv_invoice_detail_more_igst_tag.text = labels.charges.igst
        tv_invoice_detail_more_total_tag.text = labels.charges.totalHeadingLabel
        tv_invoice_detail_more_eway_tag.text = labels.eway.title
        tv_invoice_detail_more_bill_num_tag.text = labels.eway.heading.ewayBillNum
        tv_invoice_detail_more_bill_date_tag.text = labels.eway.heading.ewayBillDate
        tv_invoice_detail_more_vehicle_tag.text = labels.eway.heading.ewayVehicle
        tv_invoice_detail_more_status_tag.text = labels.eway.heading.ewayStatus
        tv_invoice_detail_more_gstn_tag.text = labels.gstn.title
        tv_invoice_detail_more_gstn_upload_tag.text = labels.gstn.heading.gstnUploadStatus
        tv_invoice_detail_more_gstn_ack_tag.text = labels.gstn.heading.gstnAck
        tv_invoice_detail_gstn_rf_tag.text = labels.gstn.heading.gstrStatus
        tv_invoice_detail_more_gstn_rec_tag.text = labels.gstn.heading.gstnReconciliation
        tv_invoice_detail_more_buyer_account.text = invoiceDetailEntity.payload.invoice?.invoice?.payor?.account?.display ?: "-"
        tv_invoice_detail_more_buyer_taxid.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.payorGstin ?: "-"
        tv_invoice_detail_more_buyer_address.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.payorAddress ?: "-"
        tv_invoice_detail_more_buyer_pod.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.payorState ?: "-"
        tv_invoice_detail_more_supplier_account.text = invoiceDetailEntity.payload.invoice?.invoice?.payee?.account?.display ?: "-"
        tv_invoice_detail_more_supplier_taxid.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.payeeGstin ?: "-"
        tv_invoice_detail_more_supplier_address.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.payeeAddress ?: "-"
        tv_invoice_detail_more_supplier_pod.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.payeeState ?: "-"
        val taxableNumber =  invoiceDetailEntity.payload.invoice?.invoice?.extra?.taxableValue
        val currency = invoiceDetailEntity.payload.invoice?.invoice?.payor?.account?.currency
        tv_invoice_detail_more_taxable.text =  if (taxableNumber.isNullOrEmpty()) "-" else { "$currency " +
                IndiaNumberUtil.formatNumByDecimal(taxableNumber,currency ?: (MemoryCache.defaultCurrency ?: "")) }
        val cgstNum = invoiceDetailEntity.payload.invoice?.invoice?.extra?.cgst
        tv_invoice_detail_more_cgst.text =  if (cgstNum.isNullOrEmpty()) "-" else "$currency " +
                IndiaNumberUtil.formatNumByDecimal(cgstNum,currency ?: (MemoryCache.defaultCurrency ?: ""))
        val sgstNum = invoiceDetailEntity.payload.invoice?.invoice?.extra?.sgst
        tv_invoice_detail_more_sgst.text =  if (sgstNum.isNullOrEmpty()) "-" else "$currency " +
                IndiaNumberUtil.formatNumByDecimal(sgstNum,currency ?: (MemoryCache.defaultCurrency ?: ""))
        val igstNum = invoiceDetailEntity.payload.invoice?.invoice?.extra?.igst
        tv_invoice_detail_more_igst.text =  if (igstNum.isNullOrEmpty()) "-" else "$currency " +
                IndiaNumberUtil.formatNumByDecimal(igstNum,currency ?: (MemoryCache.defaultCurrency ?: ""))
        val totalAmount = invoiceDetailEntity.payload.invoice?.invoice?.summation?.total?.amount
        tv_invoice_detail_more_total.text = if (totalAmount.isNullOrEmpty()) "-" else "$currency " +
                IndiaNumberUtil.formatNumByDecimal(totalAmount,currency ?: (MemoryCache.defaultCurrency ?: ""))
        tv_invoice_detail_more_bill_num.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.ewayBillNum ?: "-"
        tv_invoice_detail_more_bill_date.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.ewayBillDate ?: "-"
        tv_invoice_detail_more_vehicle.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.ewayVehicle ?: "-"
        tv_invoice_detail_more_status.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.ewayStatus ?: "-"
        tv_invoice_detail_more_gstn_upload.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.gstnUploadStatus ?: "-"
        tv_invoice_detail_more_gstn_ack.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.gstnAck ?: "-"
        tv_invoice_detail_gstn_rf.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.gstrStatus ?: "-"
        tv_invoice_detail_more_gstn_rec.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.gstnReconciliation ?: "-"

        if (labels.charges.taxableValue == "-") {
            tv_invoice_detail_more_taxable_tag.visibility = View.GONE
            tv_invoice_detail_more_taxable.visibility = View.GONE
        }

        if (labels.charges.cgst == "-") {
            tv_invoice_detail_more_cgst_tag.visibility = View.GONE
            tv_invoice_detail_more_cgst.visibility = View.GONE
        }

        if (labels.charges.sgst == "-") {
            tv_invoice_detail_more_sgst_tag.visibility = View.GONE
            tv_invoice_detail_more_sgst.visibility = View.GONE
        }

        if (labels.charges.igst == "-") {
            tv_invoice_detail_more_igst_tag.visibility = View.GONE
            tv_invoice_detail_more_igst.visibility = View.GONE
        }

        if (labels.eway.heading.ewayBillNum == "-") {
            tv_invoice_detail_more_bill_num_tag.visibility = View.GONE
            tv_invoice_detail_more_bill_num.visibility = View.GONE
        }

        if (labels.eway.heading.ewayBillDate == "-") {
            tv_invoice_detail_more_bill_date_tag.visibility = View.GONE
            tv_invoice_detail_more_bill_date.visibility = View.GONE
        }

        if (labels.eway.heading.ewayVehicle == "-") {
            tv_invoice_detail_more_vehicle_tag.visibility = View.GONE
            tv_invoice_detail_more_vehicle.visibility = View.GONE
        }

        if (labels.eway.heading.ewayStatus == "-") {
            tv_invoice_detail_more_status_tag.visibility = View.GONE
            tv_invoice_detail_more_status.visibility = View.GONE
        }

        if (labels.gstn.heading.gstnUploadStatus == "-") {
            tv_invoice_detail_more_gstn_upload_tag.visibility = View.GONE
            tv_invoice_detail_more_gstn_upload.visibility = View.GONE
        }

        if (labels.gstn.heading.gstnAck == "-") {
            tv_invoice_detail_more_gstn_ack_tag.visibility = View.GONE
            tv_invoice_detail_more_gstn_ack.visibility = View.GONE
        }

        if (labels.gstn.heading.gstrStatus == "-") {
            tv_invoice_detail_gstn_rf_tag.visibility = View.GONE
            tv_invoice_detail_gstn_rf.visibility = View.GONE
        }

        if (labels.gstn.heading.gstnReconciliation == "-") {
            tv_invoice_detail_more_gstn_rec_tag.visibility = View.GONE
            tv_invoice_detail_more_gstn_rec.visibility = View.GONE
        }

        //ID invoice template, here is special handling for ID, more countries need more common handling
        if (MemoryCache.defaultCountry == "ID") {
            tv_invoice_detail_more_buyer_taxid_tag.visibility = View.GONE
            tv_invoice_detail_more_buyer_taxid.visibility = View.GONE
            tv_invoice_detail_more_supplier_taxid_tag.visibility = View.GONE
            tv_invoice_detail_more_supplier_taxid.visibility = View.GONE
            tv_invoice_detail_more_vehicle_tag.visibility = View.GONE
            tv_invoice_detail_more_vehicle.visibility = View.GONE
            tv_invoice_detail_more_status_tag.visibility = View.GONE
            tv_invoice_detail_more_status.visibility = View.GONE
            tv_invoice_detail_gstn_rf_tag.visibility = View.GONE
            tv_invoice_detail_gstn_rf.visibility = View.GONE
            tv_invoice_detail_more_gstn_rec_tag.visibility = View.GONE
            tv_invoice_detail_more_gstn_rec.visibility = View.GONE
            tv_invoice_detail_more_bill_num.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.gstnUploadStatus ?: "-"
            tv_invoice_detail_more_bill_date.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.gstnAck ?: "-"
            tv_invoice_detail_more_gstn_upload.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.gstrStatus ?: "-"
            tv_invoice_detail_more_gstn_ack.text = invoiceDetailEntity.payload.invoice?.invoice?.extra?.gstnReconciliation ?: "-"
        }
    }
}