package hk.com.hsbc.glcmdart.domain.payments.presenter

import android.annotation.SuppressLint
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import hk.com.hsbc.glcmdart.client.CREDITNOTE
import hk.com.hsbc.glcmdart.client.MARKET_COUNTRY
import hk.com.hsbc.glcmdart.domain.dart.*
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionPayload
import hk.com.hsbc.glcmdart.util.DynamicJsonUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.BiFunction
import io.reactivex.functions.Function3
import io.reactivex.functions.Function4
import io.reactivex.schedulers.Schedulers
import kotlin.math.abs

open class CreditNoteAndPaymentMethodViewModel: PaymentBaseViewModel() {

    val paymentMethodLiveData = MutableLiveData<PaymentMethod?>()
    val creditNoteAvailableLiveData = MutableLiveData<List<CreditNoteLocal>?>()
    val deductionLiveData = MutableLiveData<MutableMap<String, List<TaxDeductionInfo>?>>()

    fun requestPaymentMethods(payee: String?, country: String?, currency: String?) {
        val disposable = paymentsModel.getPaymentMethods(payee,country,currency)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    paymentMethodLiveData.postValue(it.payload)
                }, {
                    requestLoadingLiveData.postValue(false)
                })
    }

    fun requestCreditNotes(countryCode:String?,currency:String?) {
        val dataMap = mutableMapOf<String, String>()
        if (!countryCode.isNullOrBlank())
            dataMap["countryCode"] = countryCode
        if (!currency.isNullOrBlank())
            dataMap["currency"] = currency
        val observable1 = paymentsModel.getPlannedPaymentList(dataMap)
        val observable2 = paymentsModel.requestCreditNotes(Gson().toJson(CreditnotesBean(pagination = PaginationBean(currentPage = 1, limit = Int.MAX_VALUE))))
        val disposable = Observable.zip(observable1, observable2, BiFunction<PlannedPaymentListPayload?, CreditnotesEntity?, List<CreditNoteLocal>?> { t1, t2 ->
            dealCreditNoteData(t1, t2)
        })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    creditNoteAvailableLiveData.postValue(it)
                }, {
                    requestLoadingLiveData.postValue(false)
                })
    }

    @SuppressLint("CheckResult")
    fun requestBoth(payeeRef: String?, country: String?, currency: String?) {
        val dataMap = mutableMapOf<String, String>()
        if (!country.isNullOrBlank())
            dataMap["countryCode"] = country
        if (!currency.isNullOrBlank())
            dataMap["currency"] = currency

        Observable.zip(paymentsModel.getPaymentMethods(payeeRef,country,currency).subscribeOn(Schedulers.io()),
                paymentsModel.getPlannedPaymentList(dataMap).subscribeOn(Schedulers.io()),
                paymentsModel.requestCreditNotes(Gson().toJson(CreditnotesBean(pagination = PaginationBean(currentPage = 1, limit = Int.MAX_VALUE)))),
                Function3<PaymentMethodPayload?, PlannedPaymentListPayload?, CreditnotesEntity?, MutableMap<String, Any?>> { t1, t2, t3->
                    val result = mutableMapOf<String, Any?>()
                    result["paymentMethod"] = t1
                    result["creditNote"] = dealCreditNoteData(t2, t3)
                    result
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    paymentMethodLiveData.postValue((it["paymentMethod"] as PaymentMethodPayload).payload)
//                    val deductionPayload = (it["deductionPayload"] as TaxDeductionPayload?)?.payload
//                    // get deduction first then push creditnote
//                    if (deductionPayload != null && MemoryCache.deductionsActive!!) {
////                        val deductionMap = mutableMapOf<String, Any?>()
////                        DynamicJsonUtil.deformatJsonOnce(deductionPayload.toString(), deductionMap)
//                        val deductionMapHandled = mutableMapOf<String, List<TaxDeductionInfo>?>()
//                        val deductionKeys = deductionPayload.keys
//                        deductionKeys.forEach { key ->
//                            deductionMapHandled[key] = deductionPayload[key]
//                        }
//                        if (!deductionMapHandled.isNullOrEmpty()) {
//                            deductionLiveData.postValue(deductionMapHandled)
//                        } else {
//                            deductionLiveData.postValue(mutableMapOf())
//                        }
//                    }
                    creditNoteAvailableLiveData.postValue(it["creditNote"] as List<CreditNoteLocal>?)
                }, {
                    requestLoadingLiveData.postValue(false)
                })
    }

    fun requestDeductions(payeeRef: String?, country: String?, currency: String?, payeeAccountRef: String?) {
        val disposable = paymentsModel.requestDeductionList(payeeRef ?: "", country ?: MARKET_COUNTRY, payeeAccountRef ?: "")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    val deductionMapHandled = mutableMapOf<String, List<TaxDeductionInfo>?>()
                    val deductionKeys = it.payload?.keys
                    deductionKeys?.forEach { key ->
                        deductionMapHandled[key] = it.payload?.get(key)
                    }
                    if (!deductionMapHandled.isNullOrEmpty() && MemoryCache.deductionsActive == true) {
                        deductionLiveData.postValue(deductionMapHandled)
                    } else {
                        deductionLiveData.postValue(mutableMapOf())
                    }
                    requestBoth(payeeRef, country, currency)
                }, {
                    deductionLiveData.postValue(mutableMapOf())
                    requestBoth(payeeRef, country, currency)
                })
    }

    protected fun dealCreditNoteData (t1: PlannedPaymentListPayload?, t2: CreditnotesEntity?): List<CreditNoteLocal> {
        val creditNotes = mutableListOf<CreditNoteLocal>()
        val creditNotesAvailable = mutableListOf<CreditNoteLocal>()
        if (t2 != null && t2.payload.creditNotes != null) {
            for (i in t2.payload.creditNotes.indices) {
                val creditNoteLocal = CreditNoteLocal(t2.payload.creditNotes[i], t2.payload.Tokens[i], "")
                // check if credit note is available (with 'U' or 'P' status)
                if ("U" == t2.payload.creditNotes[i].status || "P" == t2.payload.creditNotes[i].status) {
                    creditNoteLocal.creditNote?.originOutstanding = creditNoteLocal.creditNote?.outstanding
                    creditNotesAvailable.add(creditNoteLocal)
                }
            }
        }
        // map for storing credit note used amount
        val creditNoteUsedMap = mutableMapOf<String, Long>()
        if (t1 != null && t1.payload?.itps != null) {
            for (i in t1.payload?.itps?.indices!!) {
                val itp = t1.payload?.itps?.get(i)
                val itpStatus = t1.payload?.statuses?.get(i)
                // calculate used credit note amount, only for the payment out of 'revoked' and 'closed' status
                if (itpStatus != "revoked_payor" && itpStatus != "revoked" && itpStatus != "revoked_payee" && itpStatus != "closed") {
                    if (itp?.lines != null && itp.lines.isNotEmpty()) {
                        for (item in itp.lines) {
                            // check if payment has credit note
                            if (CREDITNOTE == item.type) {
                                if (creditNoteUsedMap.contains(item.token)) {
                                    var usedAmount = creditNoteUsedMap[item.token.toString()]
                                    usedAmount = usedAmount!! + abs(item.amount?.amount?.toLong()!!)
                                    creditNoteUsedMap[item.token.toString()] = usedAmount
                                } else {
                                    val usedAmount = item.amount?.amount?.toLong()
                                    creditNoteUsedMap[item.token.toString()] = abs(usedAmount!!)
                                }
                            }
                        }
                    }
                }
            }
        }
        val creditNotesOutstanding = mutableListOf<CreditNoteLocal>()
        if (creditNoteUsedMap.isNotEmpty()) {
            for (item in creditNotesAvailable) {
                if (creditNoteUsedMap.contains(item.token)) {
                    val usedAmount = creditNoteUsedMap[item.token] ?: 0L
                    val amount = item.creditNote?.outstanding?.toLong() ?: 0L
                    item.creditNote?.outstanding = (-(abs(amount) - abs(usedAmount))).toString()
                    item.creditNote?.originOutstanding = item.creditNote?.outstanding
                    if ((item.creditNote?.outstanding?.toLong() ?: 0L) <= 0L) {
                        creditNotesOutstanding.add(item)
                    }
                } else {
                    creditNotesOutstanding.add(item)
                }
            }
        }
        creditNotes.addAll(creditNotesOutstanding)
        if (t1 == null || t1.payload?.itps == null || creditNotes.isEmpty()) {
            creditNotes.addAll(creditNotesAvailable)
        }
        return creditNotes
    }
}