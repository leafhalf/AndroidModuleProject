package hk.com.hsbc.glcmdart.domain.registration

import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class RegisterAnswerSecurityQuestionViewModel: BaseViewModel() {

    private val mModel by lazy { RegistrationModel() }
    private var wrongTime = 0

    val answerLiveData = MutableLiveData<MutableMap<String, Any?>>()
    val expirationLiveData = MutableLiveData<Boolean>()

    fun uploadAnswer(invitationCode: String,answer1: String, answer2: String, answer3: String, isRecoveryUserName: Boolean) {
        val requestParameter = RequestSecurityQuestionEntity(answer1, answer2, answer3)

        val disposable = if (!isRecoveryUserName) {
            mModel.uploadSecurityQuestionAnswer(invitationCode, requestParameter)
        } else {
            mModel.recoverUsername(invitationCode, requestParameter)
        }
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    val resultMap = mutableMapOf<String, Any?>()
                    if (it.payload.errorCode == "E") {
                        wrongTime++
                        resultMap["isCorrect"] = false
                        resultMap["entity"] = null
                        resultMap["wrongTime"] = wrongTime
                        answerLiveData.postValue(resultMap)
//                        mRootView?.answerResult(false, null, wrongTime)
                        return@subscribe
                    }

                    if (it.payload.invitationCodeStatus == "U") {
                        resultMap["isCorrect"] = false
                        resultMap["entity"] = null
                        resultMap["wrongTime"] = 3
                        answerLiveData.postValue(resultMap)
//                        mRootView?.answerResult(false, null, 3)
                        return@subscribe
                    }

                    if(it.payload.challengeQuestionStatus == "S" || it.payload.challengeQuestionStatus == "R") {
                        resultMap["isCorrect"] = true
                        resultMap["entity"] = it
                        resultMap["wrongTime"] = 0
                        answerLiveData.postValue(resultMap)
//                        mRootView?.answerResult(true, it)
                    } else {
                        wrongTime++
                        resultMap["isCorrect"] = false
                        resultMap["entity"] = null
                        resultMap["wrongTime"] = wrongTime
                        answerLiveData.postValue(resultMap)
//                        mRootView?.answerResult(false, null, wrongTime)
                    }
                },{
                    wrongTime++
                    val resultMap = mutableMapOf<String, Any?>()
                    resultMap["isCorrect"] = false
                    resultMap["entity"] = null
                    resultMap["wrongTime"] = wrongTime
                    answerLiveData.postValue(resultMap)
                    exceptionLiveData.postValue(it.message)
//                    mRootView?.answerResult(false, null, wrongTime)
//                    Toast.makeText(DartApplication.instance, it.message, Toast.LENGTH_SHORT).show()
                })
    }

    fun uploadExpiredAnswer(invitationCode: String, answer1: String) {
        val disposable = mModel.recoverExpiredInvitationCode(invitationCode, answer1)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    it.payload?.response?.let { expiredResponse ->
                        if (expiredResponse.challengeQuestionStatus == "S" && expiredResponse.errorCode == "S") {
                            expirationLiveData.postValue(true)
//                            RegisterExpiredRecoverSuccessActivity.showActivity(mRootView?.getActivity())
                        } else {
                            val resultMap = mutableMapOf<String, Any?>()
                            if (expiredResponse.invitationCodeStatus != null && expiredResponse.invitationCodeStatus == "U") {
                                resultMap["isCorrect"] = false
                                resultMap["entity"] = null
                                resultMap["wrongTime"] = 3
                                answerLiveData.postValue(resultMap)
//                                mRootView?.answerResult(false, null, 3)
                                return@subscribe
                            }
                            wrongTime++
                            resultMap["isCorrect"] = false
                            resultMap["entity"] = null
                            resultMap["wrongTime"] = wrongTime
                            answerLiveData.postValue(resultMap)
//                            mRootView?.answerResult(false, null, wrongTime)
                        }
                    }
                },{
                    wrongTime++
                    val resultMap = mutableMapOf<String, Any?>()
                    resultMap["isCorrect"] = false
                    resultMap["entity"] = null
                    resultMap["wrongTime"] = wrongTime
                    answerLiveData.postValue(resultMap)
                    exceptionLiveData.postValue(it.message)
//                    mRootView?.answerResult(false, null, wrongTime)
//                    Toast.makeText(DartApplication.instance, it.message, Toast.LENGTH_SHORT).show()
                })
    }
}