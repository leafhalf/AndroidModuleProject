/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dashboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

class PointView : View {

    fun setColor(s: String) {
        mColorfulPaint.color = Color.parseColor(s)
        postInvalidate()
    }

    fun setColor(color: Int) {
        mColorfulPaint.color = color
        postInvalidate()
    }

    private val mColorfulPaint = Paint()
    private var mRadius = 0

    constructor(context: Context?) : super(context)

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs)

    init {
        mColorfulPaint.isAntiAlias = true
        mColorfulPaint.style = Paint.Style.FILL
        mColorfulPaint.textAlign = Paint.Align.CENTER
        mColorfulPaint.color = Color.TRANSPARENT
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        postInvalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val wideSize = MeasureSpec.getSize(widthMeasureSpec)
        val wideMode = MeasureSpec.getMode(widthMeasureSpec)
        val heightSize = MeasureSpec.getSize(heightMeasureSpec)
        val heightMode = MeasureSpec.getMode(heightMeasureSpec)
        var width: Int?
        var height: Int?
        if (wideMode == MeasureSpec.EXACTLY) {
            width = wideSize
        } else {
            width = mRadius * 2 + paddingLeft + paddingRight
            if (wideMode == MeasureSpec.AT_MOST) {
                width = min(width, wideSize)
            }
        }
        if (heightMode == MeasureSpec.EXACTLY) {
            height = heightSize
        } else {
            height = mRadius * 2 + paddingTop + paddingBottom
            if (heightMode == MeasureSpec.AT_MOST) {
                height = min(height, heightSize)
            }
        }
        setMeasuredDimension(width, height)
        mRadius = (min(width - paddingLeft - paddingRight, height - paddingTop - paddingBottom) * 1.0f / 2).toInt()
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        canvas?.apply {
            val centerX = (width - paddingLeft - paddingRight)/2F + paddingLeft
            val centerY = (height - paddingTop - paddingBottom)/2F + paddingTop
            drawCircle(centerX, centerY, mRadius.toFloat(), mColorfulPaint)
        }
    }
}