/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.forgetpassword

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.registration.Question
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.widget.LoadingButton
import kotlinx.android.synthetic.main.activity_forget_recovery_question.*

class ForgetPwdRecoveryQuestionActivity : BaseActivity(), View.OnClickListener, TextWatcher, ForgetPwdEnterUsernameContract.View {

    companion object {
        fun showActivity(activity: Activity, requestCode: Int = 0, recoveryQuestions: ArrayList<Question> = ArrayList(), resetUsername: String ,isResetFail: Boolean = false) {
            if (requestCode == 0) {
                activity.startActivity(Intent(activity, ForgetPwdRecoveryQuestionActivity::class.java).apply {
                    putExtra(TAG_FORGET_ANSWER_QUESTION_FLAG, false)
                    putExtra(TAG_FORGET_RESET_USERNAME, resetUsername)
                })
            } else {
                activity.startActivityForResult(Intent(activity, ForgetPwdRecoveryQuestionActivity::class.java).apply {
                    putExtra(TAG_FORGET_ANSWER_QUESTION_FLAG, true)
                    putExtra(TAG_FORGET_RECOVERY_QUESTIONS, recoveryQuestions)
                    putExtra(TAG_FORGET_RECOVERY_QUESTIONS_FLAG, isResetFail)
                    putExtra(TAG_FORGET_RESET_USERNAME, resetUsername)
                }, requestCode)
            }
        }
    }

    private lateinit var mViewModel: ForgetPwdUserNameViewModel
    //    private val mPresenter by lazy { ForgetPwdEnterUserNamePresenter() }
    private lateinit var mQuestions: ArrayList<Question>
    private var isTealiumFirstQuestionEnter = false
    private var isTealiumSecondQuestionEnter = false
    private var isTealiumThirdQuestionEnter = false
    private var isAnswerFail = false
    private var resetUsername = ""
    private var resetToken = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_recovery_question)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(true, this)
        tv_back.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)
        removeStatusView(this)

        mQuestions = intent?.getSerializableExtra(TAG_FORGET_RECOVERY_QUESTIONS) as ArrayList<Question>
        isAnswerFail = intent.getBooleanExtra(TAG_FORGET_RECOVERY_QUESTIONS_FLAG, false)
        resetUsername = intent.getStringExtra(TAG_FORGET_RESET_USERNAME)
        initViewAndData()
    }

    private fun initViewAndData() {
        MemoryCache.getLabelText("s_talkback_back_button")?.let {
            if (!it.isBlank()) {
                tv_back.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_forget_answer_questions_title")?.let {
            if (!it.isBlank()) {
                tv_recovery_title.text = it
            }
        }
        MemoryCache.getLabelText("s_forget_answer_questions_tip")?.let {
            if (!it.isBlank()) {
                tv_recovery_tip.text = it
            }
        }
        MemoryCache.getLabelText("s_next")?.let {
            if (!it.isBlank()) {
                tv_next.text = it
            }
        }

        tv_next.setOnClickListener(this)
        tv_back.setOnClickListener(this)
        et_recovery_answer_1.addTextChangedListener(this)
        et_recovery_answer_2.addTextChangedListener(this)
        et_recovery_answer_3.addTextChangedListener(this)

        if (!isAnswerFail) {
            tv_recovery_question_1.text = mQuestions[0].caption
            tv_recovery_question_2.text = mQuestions[1].caption
            tv_recovery_question_3.text = mQuestions[2].caption
            et_recovery_answer_1.setText(mQuestions[0].answer)
            et_recovery_answer_2.setText(mQuestions[1].answer)
            et_recovery_answer_3.setText(mQuestions[2].answer)
        } else {
//            mPresenter.attachView(this)
            mViewModel = ViewModelProviders.of(this).get(ForgetPwdUserNameViewModel::class.java)
            mViewModel.userNameValidationLiveData.observe(this, Observer {
                if (it != null) {
                    checkUserNameResult(ArrayList(it.payload.questions), it.payload.ResetToken)
                }
            })
            showLoadingDialog()
            mViewModel.doCheckUserName(resetUsername)
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tv_back -> {
                TealiumUtil.eventTag("button click", "recovery questions: back")
                startActivity(Intent(this, ForgetPwdMainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra(TAG_FORGET_ANSWER_RESULT, mQuestions)
                })
                finish()
            }
            R.id.tv_next -> {
                TealiumUtil.eventTag("button click", "recovery questions: next")
                val resultIntent = Intent(this@ForgetPwdRecoveryQuestionActivity, ForgetPwdMainActivity::class.java).apply {
                    mQuestions[0].answer = et_recovery_answer_1.text.toString()
                    mQuestions[1].answer = et_recovery_answer_2.text.toString()
                    mQuestions[2].answer = et_recovery_answer_3.text.toString()
                    putExtra(TAG_FORGET_ANSWER_RESULT, mQuestions)
                    putExtra(TAG_FORGET_RESET_TOKEN, resetToken)
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                startActivity(resultIntent)
                finish()
            }
        }
    }

    override fun afterTextChanged(s: Editable?) {
        if (!isTealiumFirstQuestionEnter && et_recovery_answer_1.text.toString().isNotEmpty()) {
            TealiumUtil.eventTag("text entry", "recovery password: recovery questions: first question: answer entered")
            isTealiumFirstQuestionEnter = true
        }

        if (!isTealiumSecondQuestionEnter && et_recovery_answer_2.text.toString().isNotEmpty()) {
            TealiumUtil.eventTag("text entry", "recovery password: recovery questions: second question: answer entered")
            isTealiumSecondQuestionEnter = true
        }

        if (!isTealiumThirdQuestionEnter && et_recovery_answer_3.text.toString().isNotEmpty()) {
            TealiumUtil.eventTag("text entry", "recovery password: recovery questions: third question: answer entered")
            isTealiumThirdQuestionEnter = true
        }

        tv_next.isEnabled = et_recovery_answer_1.text.toString().isNotEmpty() &&
                et_recovery_answer_2.text.toString().isNotEmpty() &&
                et_recovery_answer_3.text.toString().isNotEmpty()
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
    }

    override fun checkUserNameResult(recoveryQuestions: ArrayList<Question>, resetToken: String) {
            tv_recovery_question_1.text = recoveryQuestions[0].caption
            tv_recovery_question_2.text = recoveryQuestions[1].caption
            tv_recovery_question_3.text = recoveryQuestions[2].caption
            this.resetToken = resetToken
    }

    //not use
    override fun obtainSubmitButton(): LoadingButton {
        return LoadingButton(this)
    }

    override fun getActivity(): Activity {
        return this
    }

    override fun showInvalidMessage() {
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart : buyer portal : recover password : recovery questions",
                "/dart/buyer portal/recover password/recovery questions",
                "verification",
                "buyer portal",
                "recover password",
                "mobile",
                "en",
                "recover password",
                "3",
                "recover password - recovery questions")
    }
}