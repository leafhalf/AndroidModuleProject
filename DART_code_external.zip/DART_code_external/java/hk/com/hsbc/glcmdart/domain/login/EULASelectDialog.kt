package hk.com.hsbc.glcmdart.domain.login

import android.app.Dialog
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.EULA_STATIC_URL
import hk.com.hsbc.glcmdart.domain.more.LegalPageActivity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache

object EULASelectDialog {

    fun showDialog(c: BaseActivity) {
        val mDialog = Dialog(c, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(c).inflate(R.layout.dialog_language_selection, null)
        val tvINEnglish = mContentView.findViewById<Button>(R.id.btn_in_english)
        val tvIDEnglish = mContentView.findViewById<Button>(R.id.btn_id_english)
        val tvBahasa = mContentView.findViewById<Button>(R.id.btn_bahasa)

        val onClickListener = View.OnClickListener {
            mDialog.cancel()
            when (it.id) {
                R.id.btn_id_english -> {
                    var url = EULA_STATIC_URL
                    url = url.replace("{country}", "ID")
                    url = url.replace("{language}", "en-id")
                    url = url.replace("EULA.html", "EULA-en-id.html")
                    LegalPageActivity.showActivity(c, MemoryCache.getLabelText("s_about_EULA")
                            ?: c.getString(R.string.s_about_EULA), url, true)
                }
                R.id.btn_in_english -> {
                    var url = EULA_STATIC_URL
                    url = url.replace("{country}", "IN")
                    url = url.replace("{language}", "en-in")
                    url = url.replace("EULA.html", "EULA-en-in.html")
                    LegalPageActivity.showActivity(c, MemoryCache.getLabelText("s_about_EULA")
                            ?: c.getString(R.string.s_about_EULA), url, true)
                }
                R.id.btn_bahasa -> {
                    var url = EULA_STATIC_URL
                    url = url.replace("{country}", "ID")
                    url = url.replace("{language}", "id-id")
                    url = url.replace("EULA.html", "EULA-id-id.html")
                    LegalPageActivity.showActivity(c, MemoryCache.getLabelText("s_about_EULA")
                            ?: c.getString(R.string.s_about_EULA), url, true)
                }
            }
        }

        tvIDEnglish.setOnClickListener(onClickListener)
        tvINEnglish.setOnClickListener(onClickListener)
        tvBahasa.setOnClickListener(onClickListener)
        mContentView.findViewById<Button>(R.id.btn_cancel).setOnClickListener(onClickListener)

        mDialog.setContentView(mContentView)
        val layoutParams = mContentView.layoutParams
        layoutParams.width = c.resources.displayMetrics.widthPixels
        mContentView.layoutParams = layoutParams
        mDialog.window?.setGravity(Gravity.BOTTOM)
        mDialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        mDialog.setCanceledOnTouchOutside(true)
        mDialog.setCancelable(true)
        mDialog.window?.setWindowAnimations(R.style.Animation_Bottom)
        mDialog.show()
    }
}
