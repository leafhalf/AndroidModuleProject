/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.dart

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.urbanairship.AirshipReceiver
import com.urbanairship.push.PushMessage
import hk.com.hsbc.glcmdart.BuildConfig


class NotificationAirshipReceiver : AirshipReceiver() {

    private var notificationIdCount = 0

    override fun onChannelCreated(context: Context, channelId: String) {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Channel created. Channel Id:$channelId.")
        }
        // Broadcast that the channel was created. Used to refresh the channel ID on the home fragment
        LocalBroadcastManager.getInstance(context).sendBroadcast(Intent(ACTION_UPDATE_CHANNEL))
    }

    override fun onChannelUpdated(context: Context, channelId: String) {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Channel updated. Channel Id:$channelId.")
        }
        // Broadcast that the channel was updated. Used to refresh the channel ID on the home fragment
        LocalBroadcastManager.getInstance(context).sendBroadcast(Intent(ACTION_UPDATE_CHANNEL))
    }

    override fun onChannelRegistrationFailed(context: Context) {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Channel registration failed.")
        }
    }

    override fun onPushReceived(context: Context, message: PushMessage, notificationPosted: Boolean) {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Received push message. Alert: " + message.alert + ". posted notification: " + notificationPosted)
        }
//        val notificationBuilder = Notification.Builder(context)
//                .setContentTitle(message.title)
//                .setContentText(message.alert)
//                .setSmallIcon(R.mipmap.ic_launcher)
//                .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.mipmap.ic_launcher))
//                .setBadgeIconType(R.drawable.ic_point_red_10dp)

//        val mChannel = NotificationChannel("dart_channel",BuildConfig.APPLICATION_ID, NotificationManager.IMPORTANCE_DEFAULT)
//        mChannel.description = "notification by DART"
//        mChannel.lightColor = Color.CYAN
//        mChannel.canShowBadge()
//        mChannel.setShowBadge(true)

//        val packageName = BuildConfig.APPLICATION_ID
//        val pendingIntent = if (isAppRunning(context, packageName)) {
//            PendingIntent.getActivity(context, 1200, Intent(), PendingIntent.FLAG_UPDATE_CURRENT)
//        } else {
//            PendingIntent.getActivity(context, 1234, Intent(context, SplashActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT)
//        }
//        val notification = notificationBuilder
//                .setContentIntent(pendingIntent)
//                .build()
//        notification.flags = Notification.FLAG_AUTO_CANCEL
//
//        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
//        val notificationId = 1000 + (notificationIdCount % 10)
//        notificationIdCount++
////        manager.createNotificationChannel(mChannel)
//        manager.notify(notificationId, notification)
    }

    override fun onNotificationPosted(context: Context, notificationInfo: NotificationInfo) {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Notification posted. Alert: " + notificationInfo.message.alert + ". NotificationId: " + notificationInfo.notificationId)
        }
    }

    override fun onNotificationOpened(context: Context, notificationInfo: NotificationInfo): Boolean {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Notification opened. Alert: " + notificationInfo.message.alert + ". NotificationId: " + notificationInfo.notificationId)
        }
        // Return false here to allow Urban Airship to auto launch the launcher activity
        return isAppRunning(context, context.packageName)
    }

    override fun onNotificationOpened(context: Context, notificationInfo: NotificationInfo, actionButtonInfo: ActionButtonInfo): Boolean {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Notification action button opened. Button ID: " + actionButtonInfo.buttonId + ". NotificationId: " + notificationInfo.notificationId)
        }
        // Return false here to allow Urban Airship to auto launch the launcher
        // activity for foreground notification action buttons
        return isAppRunning(context, context.packageName)
    }

    override fun onNotificationDismissed(context: Context, notificationInfo: NotificationInfo) {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "Notification dismissed. Alert: " + notificationInfo.message.alert + ". Notification ID: " + notificationInfo.notificationId)
        }
    }

    private fun isAppRunning(context: Context, packageName: String): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val list = am.getRunningTasks(100)
        if (list.size <= 0) {
            return false
        }
        for (info in list) {
            if (info.baseActivity.packageName == packageName) {
                return true
            }
        }
        return false
    }

    companion object {

        private const val TAG = "DARTReceiver"

        /**
         * Intent action sent as a local broadcast to update the channel.
         */
        const val ACTION_UPDATE_CHANNEL = "ACTION_UPDATE_CHANNEL"
    }
}
