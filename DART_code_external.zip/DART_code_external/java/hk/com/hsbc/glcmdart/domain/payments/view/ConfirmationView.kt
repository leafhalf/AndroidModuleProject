/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.view

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.PaymentMethod
import hk.com.hsbc.glcmdart.domain.invoices.invoicedetail.InvoiceDetailActivity
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListNativeEntity
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentCreationActivity.Companion.STEP_ONE
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentCreationActivity.Companion.STEP_THREE
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentCreationActivity.Companion.STEP_TWO
import hk.com.hsbc.glcmdart.domain.payments.adapter.PaymentInvoiceReviewDetailAdapter
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import kotlinx.android.synthetic.main.view_ach_mandate.view.*
import kotlinx.android.synthetic.main.view_cheque_detail_review.view.*
import kotlinx.android.synthetic.main.view_common_beneficiary_info.view.*
import kotlinx.android.synthetic.main.view_payment_detail_review.view.*
import kotlinx.android.synthetic.main.view_va_payment_code.view.*

class ConfirmationView(context: Context?) : LinearLayout(context), RecyclerExtras.OnItemClickListener {

    private val itemList = ArrayList<InvoiceAddEntity>()
    private val mAdapter by lazy { context?.let { PaymentInvoiceReviewDetailAdapter(it, itemList) } }
    private var llPaymentState: View? = null
    private var llPaymentStateMiddle: View? = null
    private var tvPaymentDate: TextView? = null
    private var currency: String? = null

    init {
        val mInflater = LayoutInflater.from(context)
        val view = mInflater.inflate(R.layout.view_payment_detail_review, this, false)
        addView(view)
        initEventAndData()
        TealiumUtil.pageTag(
                "dart : buyer portal : payments : confirm planned payment - confirmation",
                "/dart/buyer portal/payments/confirm planned payment-confirmation",
                "transaction",
                "buyer portal",
                "payments",
                "mobile",
                " en",
                " create planned payment",
                "4",
                "create planned payment - completed",
                "complete",
                "transaction")
    }

    private fun initEventAndData() {
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(context)
        mAdapter?.setOnItemClickListener(this)
        rv_invoice_add_or_edit.adapter = mAdapter
        MemoryCache.getLabelText("s_bank_code_label")?.let {
            if (!it.isBlank()) {
                tv_IFSC_code_title.text = it
            }
        }
        tv_IFSC_code.text = MemoryCache.bankCode
        MemoryCache.getLabelText("s_payment_infomation")?.let {
            if (!it.isBlank()) {
                tv_payment_details_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_method")?.let {
            if (!it.isBlank()) {
                tv_payment_method_title.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_date")?.let {
            if (!it.isBlank()) {
                tv_payment_date_title.text = it
            }
        }
        MemoryCache.getLabelText("s_invoice_infomation")?.let {
            if (!it.isBlank()) {
                tv_invoice_summary_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_cheque_date")?.let {
            if (!it.isBlank()) {
                tv_cheque_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_cheque_number")?.let {
            if (!it.isBlank()) {
                tv_cheque_number_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_cheque_amount")?.let {
            if (!it.isBlank()) {
                et_cheque_amount_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_urn_number")?.let {
            if (!it.isBlank()) {
                tv_URN_number_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_expiration_date")?.let {
            if (!it.isBlank()) {
                tv_expiration_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_maximum_amount")?.let {
            if (!it.isBlank()) {
                tv_maximum_amount_tag.text = it
            }
        }
        MemoryCache.getLabelText("head_payment_bank_name")?.let {
            if (!it.isBlank()) {
                tv_bankname_title.text = it
            }
        }
        MemoryCache.getLabelText("s_account_name")?.let {
            if (!it.isBlank()) {
                tv_account_name_title.text = it
            }
        }
        MemoryCache.getLabelText("head_payment_account_number")?.let {
            if (!it.isBlank()) {
                tv_account_number_title.text = it
            }
        }
        MemoryCache.getLabelText("s_beneficiary_info")?.let {
            if (!it.isBlank()) {
                tv_baneficiary_info_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_bank_name_tag")?.let {
            if (!it.isBlank()) {
                tv_va_bank_name_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_code_tag")?.let {
            if (!it.isBlank()) {
                tv_va_payment_code_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_code_tip")?.let {
            if (!it.isBlank()) {
                tv_payment_code_tip.text = it
            }
        }
    }

    fun setMainPageWidget(llPaymentState: View?, llPaymentStateMiddle: View?, tvPaymentDate: TextView?, currency: String?) {
        this.llPaymentState = llPaymentState
        this.llPaymentStateMiddle = llPaymentStateMiddle
        this.tvPaymentDate = tvPaymentDate
        this.currency = currency
    }

    fun updateMainPageWidgetState() {
        llPaymentState?.visibility = View.GONE
        llPaymentStateMiddle?.visibility = View.VISIBLE
        tvPaymentDate?.visibility = View.VISIBLE
    }

    @SuppressLint("SetTextI18n")
    fun backFillStepInfo(step: Int, data: Map<String, Any>, paymentMethos: PaymentMethod?) {
        when (step) {
            //Beneficiary info
            STEP_ONE -> {
                val bankName = MemoryCache.getLabelText("s_bank_name_value")
                if (!bankName.isNullOrBlank()) {
                    tv_bankname.text = bankName
                } else {
                    tv_bankname.text = context.getString(R.string.s_bank_name_value)
                }
                MemoryCache.getLabelText("s_bank_code_label")?.let {
                    if (!it.isBlank()) {
                        tv_IFSC_code_title.text = it
                    }
                }
                tv_IFSC_code.text = MemoryCache.bankCode
                tv_account_number.text = data["payeeAccountDisplay"].toString()
                tv_account_name.text = data["payeeAccountName"].toString()
                //other view
                view_ach.visibility = View.GONE
                views_cheque.visibility = View.GONE
            }
            //Invoice information
            STEP_TWO -> {
                mAdapter?.addData(data["invoices"] as ArrayList<InvoiceAddEntity>)
                view_ach.visibility = View.GONE
                views_cheque.visibility = View.GONE
            }
            //Payment info
            STEP_THREE -> {
                tv_payment_details_tag.visibility = View.VISIBLE
                rl_payment_method_container.visibility = View.VISIBLE
                rl_payment_date_container.visibility = View.VISIBLE
                when (data["paymentMethod"].toString()) {
                    ProvidePaymentInfoView.cheque -> {
                        tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_" + ProvidePaymentInfoView.cheque)
                    }
                    ProvidePaymentInfoView.ach -> {
                        tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_" + ProvidePaymentInfoView.ach)
                    }
                    ProvidePaymentInfoView.bank_transfer -> {
                        tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_" + ProvidePaymentInfoView.bank_transfer)
                    }
                    ProvidePaymentInfoView.rtgs -> {
                        tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_" + ProvidePaymentInfoView.rtgs)
                    }
                    ProvidePaymentInfoView.dcms -> {
                        tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_" + ProvidePaymentInfoView.dcms)
                    }
                    ProvidePaymentInfoView.credit_note -> {
                        tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_" + ProvidePaymentInfoView.credit_note)
                    }
                    ProvidePaymentInfoView.deduction -> {
                        tv_payment_details_tag.visibility = View.GONE
                        rl_payment_method_container.visibility = View.GONE
                        rl_payment_date_container.visibility = View.GONE
                    }
                    ProvidePaymentInfoView.va -> {
                        tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_" + ProvidePaymentInfoView.va)
                    }
                }
                tv_payment_date.text = TimeZoneTransformsUtil.formatTime(data["expectedDate"].toString())
                when (data["paymentMethod"].toString()) {
                    ProvidePaymentInfoView.ach -> {
                        view_ach.visibility = View.VISIBLE
                        if(paymentMethos?.ach?.extra == null) {
                            ll_ach_detail.visibility = View.GONE
                        } else {
                            ll_ach_detail.visibility = View.VISIBLE
                        }
                        tv_ach_invalid.visibility = View.GONE
                        views_cheque.visibility = View.GONE
                        if (paymentMethos != null) {
                            tv_URN_number.text = paymentMethos.ach?.extra?.ACH_mandate_urn ?: ""
                            tv_expiration_date.text = TimeZoneTransformsUtil.formatTime(paymentMethos.ach?.extra?.ACH_mandate_date
                                    ?: "")
                            tv_maximum_amount.text = "$currency " + IndiaNumberUtil.formatNumByDecimal(paymentMethos.ach?.extra?.ACH_mandate_amount
                                    ?: "", currency ?: MARKET_CURRENCY)
                        }
                    }

                    ProvidePaymentInfoView.cheque -> {
                        views_cheque.visibility = View.VISIBLE
                        view_ach.visibility = View.GONE
                        val extraMap = data["extra"] as Map<String, Any>
                        if (extraMap.containsKey("payment_cheque_date")) {
                            tv_cheque_date.text = TimeZoneTransformsUtil.formatTime(extraMap["payment_cheque_date"].toString())
                        }
                        if (extraMap.containsKey("payment_cheque_number")) {
                            tv_cheque_number.text = extraMap["payment_cheque_number"].toString()
                        }
                        if (extraMap.containsKey("payment_cheque_amount")) {
                            val tmpText = "$currency " +  IndiaNumberUtil.formatNumByDecimal(extraMap["payment_cheque_amount"].toString(), currency ?: MARKET_CURRENCY)
                            et_cheque_amount.text = tmpText
                        }
                    }

                    ProvidePaymentInfoView.va -> {
                        view_va.visibility = View.VISIBLE
                        iv_bank_name_right.visibility = View.GONE
                        iv_payment_code_right.visibility = View.GONE
                        tv_va_bank_name.text = data["va_name"].toString()
                        tv_va_payment_code.text = data["va_code"].toString()
                    }
                }
            }
        }
    }

    override fun onItemClick(view: View, position: Int) {
        val detailIntent = Intent(context, InvoiceDetailActivity::class.java).apply {
            val invoice = InvoiceListNativeEntity(itemList[position].token
                    , itemList[position].invoice, false, isShowHeader = false)
            putExtra(TAG_INVOICE_TOKEN, invoice)
            putExtra(TAG_INVOICE_FROM_PLANNED_PAYMENT_CREATION, true)
        }
        context.startActivity(detailIntent)
    }
}