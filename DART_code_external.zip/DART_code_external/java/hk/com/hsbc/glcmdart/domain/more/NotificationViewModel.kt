package hk.com.hsbc.glcmdart.domain.more

import android.annotation.SuppressLint
import com.urbanairship.UAirship
import hk.com.hsbc.glcmdart.domain.dart.SchedulerTransformer
import hk.com.hsbc.glcmdart.domain.login.LoginModel
import hk.com.hsbc.glcmdart.domain.login.RequestUrbanAirship
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import hk.com.hsbc.glcmdart.util.MemoryCache
import io.reactivex.Observable

class NotificationViewModel: BaseViewModel() {

    private val mModel by lazy { LoginModel() }

    @SuppressLint("CheckResult")
    fun doUploadUrbanAirship() {
        Observable.just(0)
                .map {
                    if(MemoryCache.getProfile()?.payload?.user?.reference != null) {
                        mModel.uploadUrbanAirshipInfo(RequestUrbanAirship(UAirship.shared().pushManager.channelId,
                                MemoryCache.getProfile()?.payload?.user?.reference ?: ""))
                    }
                }
                .compose(SchedulerTransformer())
                .subscribe({

                }, {

                })
    }

    @SuppressLint("CheckResult")
    fun doDetachUrbanAirship() {
        Observable.just(0)
                .map {
                    if(MemoryCache.getProfile()?.payload?.user?.reference != null) {
                        mModel.detachUrbanAirship(MemoryCache.getProfile()?.payload?.user?.reference ?: "")
                    }
                }
                .compose(SchedulerTransformer())
                .subscribe({
                }, {
                })
    }
}