/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_REQUEST_INTENT_DATA_FAQ
import hk.com.hsbc.glcmdart.domain.more.adapter.FAQDetailAdapter
import hk.com.hsbc.glcmdart.domain.more.entity.FAQ
import hk.com.hsbc.glcmdart.domain.more.entity.Section
import hk.com.hsbc.glcmdart.framework.BaseActivity
import kotlinx.android.synthetic.main.activity_faqdetail.*

class FAQDetailActivity : BaseActivity() {

    private val itemList = ArrayList<FAQ>()
    private val mAdapter by lazy { FAQDetailAdapter(this@FAQDetailActivity, itemList) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_faqdetail)
        initViewAndEvent()
    }

    @SuppressLint("ResourceAsColor")
    private fun initViewAndEvent() {
        tl_head.title =""
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            finish()
        }
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        rv_invoice_add_or_edit.adapter = mAdapter
        if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_FAQ) != null) {
            val section = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_FAQ) as Section
            tl_head.title = section.title
            mAdapter.addData(section.faqs as ArrayList<FAQ>)
        }
    }

    companion object {
        fun showActivity(activity: Activity, section: Section) {
            activity.startActivity(Intent(activity, FAQDetailActivity::class.java).let {
                it.putExtra(TAG_REQUEST_INTENT_DATA_FAQ, section)
                it
            })
        }
    }
}
