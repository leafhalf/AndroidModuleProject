/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import hk.com.hsbc.glcmdart.client.URL_INVOICE_LIST
import hk.com.hsbc.glcmdart.client.URL_INVOICE_LIST_OVERDUE
import io.reactivex.Observable
import okhttp3.RequestBody
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

/**
 * Created by Donut
 *
 * api interface for invoice
 */
interface InvoiceListService {

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST(URL_INVOICE_LIST)
    fun getInvoiceList(@Body body: RequestBody): Observable<InvoiceListEntity>

    @Headers("Content-Type: application/json", "Accept: */*")
    @POST(URL_INVOICE_LIST_OVERDUE)
    fun getOverdueInvoiceList(@Body body: RequestBody): Observable<InvoiceListOverdueEntity>
}