package hk.com.hsbc.glcmdart.domain.payments.presenter

import android.annotation.SuppressLint
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import hk.com.hsbc.glcmdart.domain.dart.*
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentDetailEntityPayload
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.util.MemoryCache
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Function3
import io.reactivex.schedulers.Schedulers

class PaymentDetailViewModel : CreditNoteAndPaymentMethodViewModel() {

    val paymentDetailLiveData = MutableLiveData<PaymentDetailEntityPayload>()
    val paymentDetailUpdateLiveData = MutableLiveData<PaymentDetailEntityPayload?>()
    val revokeLiveData = MutableLiveData<Boolean>()
    val allPaymentList = MutableLiveData<PlannedPaymentListPayload>()

    fun requestPaymentDetailData(filter: String) {
        val disposable = paymentsModel.getPlannedPaymentListByFilter(filter)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    paymentDetailLiveData.postValue(it)
//                        setPlannedPaymentDetail(it)
                }, {

                })
    }

    fun updatePaymentDetail(token: String?, itp: Map<String, Any>?) {
        requestLoadingLiveData.postValue(true)
        val disposable = paymentsModel.requestUpdateItp(token ?: "", itp ?: mutableMapOf())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    requestLoadingLiveData.postValue(false)
                    paymentDetailUpdateLiveData.postValue(it)
                }, {
                    Toast.makeText(DartApplication.instance, "Update fail", Toast.LENGTH_SHORT).show()
                    requestLoadingLiveData.postValue(false)
                    paymentDetailUpdateLiveData.postValue(null)
                })
    }

    fun requestItpRevoke(token: String?, payorReference: String?) {
//        showLoadingDialogExt()
        val dataMap = mutableMapOf<String, Any>()
        if ("S" == MemoryCache.getSessionEntity()?.type) {
            dataMap["payeeReference"] = payorReference ?: ""
        } else {
            dataMap["payorReference"] = payorReference ?: ""
        }
        val disposable = paymentsModel.requestItpRevoke(token!!, dataMap)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
//                        hideLoadingDialogExt()
                .subscribe({
                    revokeLiveData.postValue(true)
//                        setItpRevokeResult()
                }, {
                    revokeLiveData.postValue(false)
//                    hideLoadingDialogExt()
                })
    }

    @SuppressLint("CheckResult")
    fun requestPaymentList(currency: String?) {
        val dataMap = mutableMapOf<String, Any>()
        dataMap["payeeReference"] = ""
        dataMap["statuses"] = { "Processing" }
        if (!currency.isNullOrEmpty())
            dataMap["currencies"] = listOf(currency)

        paymentsModel.searchPlannedPayment(dataMap)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    allPaymentList.postValue(it)
                }, {
                    paymentErrorLiveData.postValue(it.message)
                })
    }

    @SuppressLint("CheckResult")
    fun requestDetailAndCreditnote(filter: String, countryCode: String?, currency: String?) {
        val dataMap = mutableMapOf<String, String>()
        if (!countryCode.isNullOrBlank())
            dataMap["countryCode"] = countryCode
        if (!currency.isNullOrBlank())
            dataMap["currency"] = currency

        val observable1 = paymentsModel.getPlannedPaymentList(dataMap)
        val observable2 = paymentsModel.requestCreditNotes(Gson().toJson(CreditnotesBean(pagination = PaginationBean(currentPage = 1, limit = Int.MAX_VALUE))))
        Observable.zip(paymentsModel.getPlannedPaymentListByFilter(filter).subscribeOn(Schedulers.io()),
                observable1, observable2, Function3<PaymentDetailEntityPayload?, PlannedPaymentListPayload?, CreditnotesEntity?, MutableMap<String, Any?>> { t1, t2, t3 ->
            val result = mutableMapOf<String, Any?>()
            result["paymentDetail"] = t1
            result["creditNote"] = dealCreditNoteData(t2, t3)
            result
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    // set credit note first, to provide total credit note list
                    creditNoteAvailableLiveData.postValue(it["creditNote"] as List<CreditNoteLocal>?)
                    paymentDetailLiveData.postValue((it["paymentDetail"] as PaymentDetailEntityPayload))
                }, {
                    requestLoadingLiveData.postValue(false)
                })
    }
}