/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.fragment.app.Fragment
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.fragment_register_useraccountrecovery.*
import kotlinx.android.synthetic.main.fragment_register_useraccountrecovery.view.*

class RegisterUserAccountRecoveryFragment : Fragment(),
        RegisterCreateNewUserProfileContract.FragmentCallback,
        View.OnClickListener {

    companion object {
        @JvmStatic
        fun newInstance() =
                RegisterUserAccountRecoveryFragment()
    }

    private lateinit var mActivity: RegisterCreateNewUserProfileActivity
    private val inflater by lazy { LayoutInflater.from(activity) }
    private lateinit var mListContainer: LinearLayout

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mActivity = context as RegisterCreateNewUserProfileActivity
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.fragment_register_useraccountrecovery, container, false)
        mListContainer = rootView.findViewById(R.id.mContainerLayout)
        MemoryCache.getLabelText("s_talkback_back_button")?.let {
            if (!it.isBlank()) {
                rootView.backButton2nd.contentDescription = it
            }
        }
        MemoryCache.getLabelText("head_userAccountRecovery")?.let {
            if (!it.isBlank()) {
                rootView.tv_register_recovery_title.text = it
            }
        }
        MemoryCache.getLabelText("description_userAccountRecovery_1st")?.let {
            if (!it.isBlank()) {
                rootView.descriptionText.text = it
            }
        }
        return rootView
    }

    override fun onResume() {
        super.onResume()
        backButton2nd.setOnClickListener(this)
        updateContentView()

        val list = mActivity.mQuestions
        val array = arrayOf("first", "second", "third")
        val filters = list.filter {
            !it.answer.isNullOrEmpty()
        }
        val tag = array[if (filters.size <= 2) filters.size else 2]
        if (array.contains(tag)) {
            TealiumUtil.pageTag(
                    "dart : buyer portal : registration : choose $tag question",
                    "/dart/buyer portal/registration/choose $tag question",
                    "verification",
                    "buyer portal",
                    "registration",
                    "mobile",
                    "en",
                    "registration",
                    "7",
                    "registration - choose $tag question"
            )
        }
    }

    override fun updateContentView() {
        val list = mActivity.mQuestions
        val array = arrayOf("first", "second", "third")
        val filters = list.filter {
            !it.answer.isNullOrEmpty()
        }
        val tag = array[if (filters.size <= 2) filters.size else 2]
        descriptionText.text = if (tag.contentEquals("first")) {
            String.format(MemoryCache.getLabelText("description_userAccountRecovery_1st") ?: getString(R.string.description_userAccountRecovery_1st), tag)
        } else {
            String.format(MemoryCache.getLabelText("description_userAccountRecovery_1st") ?: getString(R.string.description_userAccountRecovery_2nd), tag)
        }

        list.also {
            mListContainer.removeAllViews()
            val size = it.size
            for ((index, value) in it.withIndex()) {
                val view = inflater.inflate(R.layout.item_register_useraccountrecovery, null, false)
                val itemLayout = view.findViewById<View>(R.id.itemLayout)
                val content = view.findViewById<AppCompatTextView>(R.id.contentText)
                val image  = view.findViewById<AppCompatImageView>(R.id.rightImage)
                value.caption?.let { caption ->
                    val label = MemoryCache.getLabelText(caption)
                    if (!label.isNullOrBlank()) {
                        content.text = label
                    } else {
                        content.text = value.caption
                    }
                }
                if (value.answer.isNullOrEmpty()) {
                    image.visibility = View.INVISIBLE
                } else {
                    image.visibility = View.VISIBLE
                }
                itemLayout.tag = value.id
                itemLayout.setOnClickListener(this)
                mListContainer.addView(view)

                if (index < size -1) {
                    val line = inflater.inflate(R.layout.view_register_useraccountrecovery, null, false)
                    mListContainer.addView(line)
                }
            }
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.backButton2nd -> {
                (activity as View.OnClickListener).onClick(v)
            }
            else -> {
                (activity as View.OnClickListener).onClick(v)
            }
        }
    }
}

