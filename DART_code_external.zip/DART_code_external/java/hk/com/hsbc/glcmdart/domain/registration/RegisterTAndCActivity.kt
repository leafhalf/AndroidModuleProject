/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.http.SslError
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.SslErrorHandler
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.EULA_STATIC_URL
import hk.com.hsbc.glcmdart.client.TAG_FROM_REGISTER_FLAG
import hk.com.hsbc.glcmdart.domain.welcome.WelcomeActivity
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.NetworkManager
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_register_tandc.*
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

/**
 * Created by Donut on 2018/11/14.
 */
class RegisterTAndCActivity: BaseActivity() {

    private var isFromRegistration: Boolean = false

    companion object {
        fun showActivity(activity: Activity, isFromRegister: Boolean = false) {
            activity.startActivity(Intent(activity, RegisterTAndCActivity::class.java).apply {
                putExtra(TAG_FROM_REGISTER_FLAG, isFromRegister)
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_tandc)
        isFromRegistration = intent.getBooleanExtra(TAG_FROM_REGISTER_FLAG, false)

        MemoryCache.getLabelText("s_tandc_welcome_title")?.let {
            if (!it.isBlank()) {
                tl_head.title = it
            }
        }

//        if (isFromRegistration) {
            MemoryCache.getLabelText("s_tandc_agreement")?.let {
                if (!it.isBlank()) {
                    tv_register_tandc_agreement.text = it
                }
            }
//        } else {
//            tv_register_tandc_agreement.text = getString(R.string.s_agree_button)
//        }
        tl_head.setTitleTextColor(Color.BLACK)
        tl_head.setBackgroundColor(Color.WHITE)
        setSupportActionBar(tl_head)
        if (isFromRegistration) {
            tl_head.setNavigationIcon(R.drawable.ic_close_on_light)
            tl_head.setNavigationOnClickListener {
                finish()
            }
        }

        tv_register_tandc_agreement.setOnClickListener {
            if (isFromRegistration) {
                TealiumUtil.eventTag("button click", "registration: review terms and conditions: i have read and agree")
                RegisterMainActivity.showActivity(this@RegisterTAndCActivity)
            } else {
                TealiumUtil.eventTag("button click", "review legal info: i have read and agree")
                startActivity(Intent(this, WelcomeActivity::class.java))
            }
            finish()
        }
        wv_tandc.clearCache(true)
        wv_tandc.settings.apply {
            cacheMode = WebSettings.LOAD_NO_CACHE
        }

        wv_tandc.webViewClient =  object : WebViewClient() {
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {

            }
        }

        wv_tandc.setOnClickListener { }
        wv_tandc.setOnLongClickListener { true}

        showLoadingDialogExt()
        val urlOrigin = EULA_STATIC_URL
        val country = when(MemoryCache.defaultLanguageFull) {
            "en-in" -> "IN"
            "en-id" -> "ID"
            "id-id" -> "ID"
            "en-au" -> "AU"
            "en-sg" -> "SG"
            else -> "IN"
        }
        var url = urlOrigin.replace("{country}", country)
        url = url.replace("{language}", MemoryCache.defaultLanguageFull ?: "en-in")
        url = url.replace("EULA.html", "EULA-${MemoryCache.defaultLanguageFull}.html")
        val request = Request.Builder().url(url).build()
        NetworkManager.normalClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                hideLoadingDialogExt()
                Handler(Looper.getMainLooper()).post {
                    tv_register_tandc_agreement.isEnabled = false
                    tv_register_tandc_agreement.setBackgroundColor(ContextCompat.getColor(this@RegisterTAndCActivity, R.color.secondary_gray))
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                hideLoadingDialogExt()
                if (response.code() != 200) {
                    Handler(Looper.getMainLooper()).post {
                        tv_register_tandc_agreement.isEnabled = false
                        tv_register_tandc_agreement.setBackgroundColor(ContextCompat.getColor(this@RegisterTAndCActivity, R.color.secondary_gray))
                    }
                } else {
                    response.body()?.string()?.apply {
                        Handler(Looper.getMainLooper()).post {
                            tv_register_tandc_agreement.isEnabled = true
                            tv_register_tandc_agreement.setBackgroundColor(ContextCompat.getColor(this@RegisterTAndCActivity, R.color.primary_red))
                            wv_tandc.loadDataWithBaseURL(null,this, "text/html", "utf-8", null)
                        }
                    }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (isFromRegistration) {
            TealiumUtil.pageTag("dart : buyer portal : registration : review terms and conditions",
                    "/dart/buyer portal/registration/review term and conditions", "verification", "buyer portal",
                    "registration")
        } else {
            TealiumUtil.pageTag("dart:buyer portal:logon:review legal info",
                    "/dart/buyer-portal/logon/review-legal-info", "authentication", "buyer portal",
                    "logon")
        }
    }
}