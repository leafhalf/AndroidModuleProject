/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import androidx.annotation.Keep
import hk.com.hsbc.glcmdart.domain.dart.ITPListItem
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import hk.com.hsbc.glcmdart.domain.dart.Pagination
import hk.com.hsbc.glcmdart.domain.dart.RequestPagination
import hk.com.hsbc.glcmdart.util.MemoryCache
import java.io.Serializable

@Keep
data class InvoiceListEntity(val payload: InvoiceListPayLoad?): Serializable

@Keep
data class InvoiceListPayLoad(
        val invoices: List<Invoice>?,
        val itps: List<ITPListItem?>?,
        val pagination: Pagination?,
        val tokens: List<String>?
): Serializable

@Keep
data class InvoiceRequestParameter(
        var pagination: RequestPagination?,
        var payeeReference: String?,
        var search: String?,
        var status: MutableList<String>,
        var dateField: String?,
        var dateFrom: String?,
        var dateTo: String?,
        var amount: InvoiceRequestAmount?,
        var sorting: InvoiceRequestSort?,
        var payeeAccountReference: String? = null,
        var payorReference: String? = null,
        var payeeName: String? = null,
        var payorName: String? = null,
        var payeeCurrency: String? = null,
        var payorCurrency: String? = null,
        var payorAccountReference: String? = null,
        var currency: String? = MemoryCache.defaultCurrency,
        var outstanding: InvoiceRequestAmount? = null,
        var reference: String? = null,
        var token: String? = null,
        var tokens: MutableList<String>? = null
): Serializable

@Keep
data class InvoiceRequestSort(
        var field: String,
        var order: String?
): Serializable

@Keep
data class InvoiceRequestAmount(
        var gte: String,
        var lte: String
): Serializable

@Keep
data class InvoiceOverdueRequestParameter(
        var events: List<String>,
        var pagination: RequestPagination?,
        var payeeReference: String?,
        var payorReference: String?,
        var statuses: List<String>,
        var uiDate: String
): Serializable

