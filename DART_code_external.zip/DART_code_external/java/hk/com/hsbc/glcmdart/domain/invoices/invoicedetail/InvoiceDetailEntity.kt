/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicedetail

import androidx.annotation.Keep
import hk.com.hsbc.glcmdart.domain.dart.ITPListItem
import hk.com.hsbc.glcmdart.domain.dart.InvoiceDeductionItem
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionPayload
import java.io.Serializable

/**
 * Created by Donut
 *
 * invoice detail entity
 */
@Keep
data class InvoiceDetailEntity(val payload: InvoiceDetailPayload): Serializable

@Keep
data class InvoiceDetailPayload(
        val invoice: InvoiceListItem?,
        val itps: List<ITPListItem>?,
        val deductions: HashMap<String, List<TaxDeductionInfo>>?
): Serializable