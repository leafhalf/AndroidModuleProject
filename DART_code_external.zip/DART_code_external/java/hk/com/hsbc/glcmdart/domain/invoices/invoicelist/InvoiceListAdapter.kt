/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.util.DateUtil
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import hk.com.hsbc.glcmdart.view.BaseHolder
import kotlinx.android.synthetic.main.item_invoice_list.view.*
import java.util.*

/**
 * Created by Donut
 * adapter for all invoices, base on InvoiceListNativeEntity which is the local entity to deal with server data
 */
class InvoiceListAdapter(private var mList: MutableList<InvoiceListNativeEntity>, private val isSelectable: Boolean) : RecyclerView.Adapter<InvoiceItemViewHolder>() {

    //two type for invoice, normal is for showing total amount, outstanding is for showing outstanding amount
    private val TYPE_NORMAL = 0
    private val TYPE_OUTSTANDING = 1

    var onItemClickListener: OnRecyclerViewItemClickListener<InvoiceListNativeEntity>? = null
    var onSelectInvoiceCallback: OnSelectInvoiceListener? = null
    //according to this field to change showing
    var isShowOutstandingAmount = false
        set(value) {
            field = value
            notifyItemRangeChanged(0, itemCount)
        }

    override fun getItemViewType(position: Int): Int {
        return if (isShowOutstandingAmount) {
            TYPE_OUTSTANDING
        } else {
            TYPE_NORMAL
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): InvoiceItemViewHolder {
        val rootView = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_invoice_list, viewGroup, false)
        return InvoiceItemViewHolder(rootView, isShowOutstandingAmount, isSelectable).apply {
            setOnItemClickListener(object : BaseHolder.OnViewClickListener {
                override fun onViewClick(view: View, position: Int) {
                    if (onItemClickListener != null && mList.size > 0) {
                        onItemClickListener?.onItemClick(rootView, viewType, mList[position], position)
                    }
                }
            })

            onSelectInvoiceListener = onSelectInvoiceCallback
        }
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    override fun onBindViewHolder(viewHolder: InvoiceItemViewHolder, position: Int) {
        viewHolder.setData(mList[position], position)
    }

    fun setData(list: MutableList<InvoiceListNativeEntity>?) {
        mList = mutableListOf()
        if (list != null) {
            mList.addAll(list)
        }
        notifyDataSetChanged()
//        notifyItemRangeChanged(0, mList.size)
    }

    fun getData(): List<InvoiceListNativeEntity>? {
        return mList
    }
}

/**
* all invoice holder
* isSelectable is for multi-select function, this is used for select invoice in creating plan payment
*/
class InvoiceItemViewHolder(private val view: View, private var isShowOutstandingAmount: Boolean, private val isSelectable: Boolean) : BaseHolder<InvoiceListNativeEntity>(view) {

    private val tvSupplierName = view.tv_invoice_list_item_supplier_name
    private val tvAmount = view.tv_invoice_list_item_amount
    private val tvInvoiceId = view.tv_invoice_list_item_item_id
    private val tvOverDueFlag = view.tv_invoice_list_item_over_due_flag
    private val tvStatus = view.tv_invoice_list_item_state
    private val tvDueDate = view.tv_invoice_list_item_due_date
    private val cbCheck = view.cb_invoice_list_item_check
    private val isSupplierUser = "S" == MemoryCache.getSessionEntity()?.type
    var onSelectInvoiceListener: OnSelectInvoiceListener? = null

    override fun setData(data: InvoiceListNativeEntity, position: Int) {
        view.setAccessibilityDelegate(object: View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        })

        val organizationsMap = MemoryCache.getOrganisationsMap()
        val payeeReferenceName = if (isSupplierUser) {
            if (organizationsMap.containsKey(data.invoice?.payor?.reference))
                (organizationsMap[data.invoice?.payor?.reference] as Payee).name
            else
                data.invoice?.payor?.name
        } else {
            if (organizationsMap.containsKey(data.invoice?.payee?.reference))
                (organizationsMap[data.invoice?.payee?.reference] as Payee).name
            else
                data.invoice?.payee?.name
        }
        tvSupplierName.text = payeeReferenceName
        val amountNum = if (isShowOutstandingAmount) {
            data.invoice?.summation?.outstanding?.amount ?: ""
        } else {
            data.invoice?.summation?.total?.amount ?: ""
        }
        val amountTxt = data.invoice?.summation?.total?.currency + " " + IndiaNumberUtil.formatNumByDecimal(amountNum, data.invoice?.summation?.total?.currency ?: MARKET_CURRENCY)
        tvAmount.text = amountTxt
        tvInvoiceId.text = data.invoice?.reference
        tvOverDueFlag.visibility = if (DateUtil.judgeDueDate(data.invoice?.dueDate) &&
                (data.invoice?.status == "U" || data.invoice?.status == "P")) {
            View.VISIBLE
        } else {
            View.GONE
        }

        if (data.invoice?.dueDate != null) {
            tvDueDate.text = TimeZoneTransformsUtil.formatTime(data.invoice.dueDate)
        } else {
            tvDueDate.text = TimeZoneTransformsUtil.formatTime(Date())
        }
        tvStatus.text = MemoryCache.getLabelText("s_invoice_status_" +  data.invoice?.status)
        if (data.invoice?.status == "F") {
            tvStatus.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_paid_closed, 0, 0, 0)
//        } else if (data.invoice?.status == "P") {
//            tvStatus.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_alert_blue, 0, 0, 0)
        } else {
            tvStatus.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0)

        }
        if (isSelectable) {
            cbCheck.visibility = View.VISIBLE
            tvStatus.visibility = View.GONE
            cbCheck.isChecked = data.isChecked
            cbCheck.isEnabled = !data.isPreChecked
            cbCheck.setOnClickListener {
                if (onSelectInvoiceListener != null) {
                    onSelectInvoiceListener?.onSelect(position)
                }
            }
        } else {
            cbCheck.visibility = View.GONE
            tvStatus.visibility = View.VISIBLE
        }
        view.contentDescription = (MemoryCache.getLabelText("s_talkback_clickable_item") ?: view.context.getString(R.string.s_talkback_clickable_item)) + " " + data.invoice?.reference

        MemoryCache.getLabelText("s_overdue")?.let {
            if (!it.isBlank()) {
                tvOverDueFlag.text = it
            }
        }
    }
}

interface OnRecyclerViewItemClickListener<T> {
    fun onItemClick(view: View, viewType: Int, data: InvoiceListNativeEntity?, position: Int)
}

interface OnSelectInvoiceListener{
    fun onSelect(position: Int)
}