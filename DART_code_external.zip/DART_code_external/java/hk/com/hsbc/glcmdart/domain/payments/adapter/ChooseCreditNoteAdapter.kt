/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.app.Activity
import android.content.Context
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.CreditNoteLocal
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import java.lang.StringBuilder
import java.math.BigDecimal
import java.util.regex.Pattern
import kotlin.math.abs

class ChooseCreditNoteAdapter(private val context: Context, private val mData: ArrayList<CreditNoteLocal>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val inflater: LayoutInflater = LayoutInflater.from(context)
    val inputMap = mutableMapOf<String, String>()
    var selectPostion = mutableMapOf<Int, Boolean>()
    var originalSelectFlag: Boolean = false
    private var btnUpdate: Button? = null
    private var currency: String? = null

    fun setBtnUpdateWidget(btn_update: Button?) {
        this.btnUpdate = btn_update
    }

    fun setCurrency(currency: String?) {
        this.currency = currency
    }

    fun getSelectItems(): List<CreditNoteLocal> {
        val creditNotesSelects = mutableListOf<CreditNoteLocal>()
        if (selectPostion.containsValue(true)) {
            for (item in selectPostion) if (item.value) {
                val creditNote = mData[item.key]
                if (!creditNote.outstanding.isNullOrEmpty()) {
                    val doubleValue = creditNote.outstanding?.toDouble() ?: 0.0
                    val decimalValue = BigDecimal.valueOf(doubleValue)
                    creditNote.outstanding = (decimalValue * BigDecimal.valueOf(100)).toLong().toString()
                    creditNotesSelects.add(mData[item.key])
                }
            }
        }
        return creditNotesSelects
    }

    fun addData(dataList: ArrayList<CreditNoteLocal>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        for (item in mData) {
            if (!item.outstanding.isNullOrEmpty()) {
                originalSelectFlag = true
                break
            }
        }
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_choose_credit_note, parent, false)
        return ItemHolder(view, InputTextWatcher(), FocusChangeListener())
    }

    private val sb = StringBuilder()
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        sb.clear()
        for (item in mData) {
            sb.append(item.selected).append(",")
        }
        Log.e("test", position.toString() + ": " + sb.toString())
        val vh: ItemHolder = holder as ItemHolder
        vh.tvCreditNote.hint = "$currency ${if (currency == "IDR") "0,00" else "0.00"}"
        vh.etAmountAllocate.hint = "$currency ${if (currency == "IDR") "0,00" else "0.00"}"
        val token = mData[position].creditNote?.payorCreditNoteReference ?: ""
        vh.cbCreditNote.setOnCheckedChangeListener(null)
        if (!mData[position].outstanding.isNullOrEmpty()) {
            inputMap[token] = MemoryCache.globalDecimal.format(abs(mData[position].outstanding?.toDouble()
                    ?: 0.00))
            vh.cbCreditNote.isChecked = true
            Log.e("test", "1")
            selectPostion[position] = true
            updateSelectViewState(vh.llAllocate, position)
        } else {
            selectPostion[position] = mData[position].selected == true
            vh.cbCreditNote.isChecked = mData[position].selected == true
            if (mData[position].selected == true) {
                vh.llAllocate.visibility = View.VISIBLE
            } else {
                vh.llAllocate.visibility = View.GONE
            }
            Log.e("test", "2: " + vh.cbCreditNote.isChecked.toString())
        }
        vh.tvAmountToAllocateTag.text = MemoryCache.getLabelText("s_amount_to_allocate") ?: context.getString(R.string.s_amount_to_allocate)
        val tmpAmount = IndiaNumberUtil.formatNumByDecimal(mData[position].creditNote?.outstanding
                ?: "0.00",
                currency ?: MARKET_CURRENCY)
        val valiableText = "${MemoryCache.getLabelText("s_available_begin_line") ?: context.getString(R.string.s_available_begin_line)}: $currency " + tmpAmount.replace("-", "")
        vh.tvAvailable.text = valiableText
        val tmpText = "$token ${MemoryCache.getLabelText("s_or_cr") ?: context.getString(R.string.s_or_cr)}: $currency " +
                IndiaNumberUtil.formatNumByDecimal(mData[position].creditNote?.amount?.replace("-", "")
                        ?: "0.00",
                        currency ?: MARKET_CURRENCY)
        vh.tvCreditNote.text = tmpText
        vh.cbCreditNote.setOnCheckedChangeListener { _, isChecked ->
            TealiumUtil.eventTag("checkbox", "choose credit note: credit note ${if (isChecked) "checked" else "unchecked"}")
            selectPostion[position] = isChecked
            updateSelectViewState(vh.llAllocate, position)
            if (position > -1) {
                mData[position].selected = isChecked
                Log.e("test", "3: position " + position.toString() + mData[position].selected.toString())
                if (selectPostion.containsKey(position) && (selectPostion[position] as Boolean)) {
                    val creditNoteOutstanding = mData[position].creditNote?.outstanding?.replace("-", "")?.toLong()
                            ?: 0L
                    var creditNoteAmountInput = 0L
                    if (!vh.etAmountAllocate.text.isNullOrEmpty())
                        creditNoteAmountInput = (vh.etAmountAllocate.text.toString().replace("$currency", "").replace(",", "").trim().toDouble() * 100).toLong()
                    if (creditNoteAmountInput == 0L || (creditNoteAmountInput > creditNoteOutstanding)) {
                        setUpdateButtonState(false, vh.tvAmountValidate, creditNoteAmountInput)
                    } else {
                        setUpdateButtonState(true, vh.tvAmountValidate, creditNoteAmountInput)
                    }
                } else {
                    refreshButtonState()
                }
            }
        }
        vh.etAmountAllocate.tag = token
        vh.inputTextWatcher.token = token
        vh.inputTextWatcher.mCreditNoteLocal = mData[position]
        vh.inputTextWatcher.position = position
        vh.inputTextWatcher.tvAmountValidate = vh.tvAmountValidate
        setEditTextInput(token, vh.etAmountAllocate)
        vh.etAmountAllocate.setOnEditorActionListener { _, _, _ ->
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.toggleSoftInput(0, 0)
            true
        }
        vh.inputTextWatcher.etAmountAllocate = vh.etAmountAllocate
    }

    private fun updateSelectViewState(ll_allocate: View?, position: Int) {
        if (selectPostion.containsKey(position) && selectPostion[position] == true) {
            ll_allocate?.visibility = View.VISIBLE
        } else {
            ll_allocate?.visibility = View.GONE
        }

        val selectedCount = selectPostion.count {value -> value.value}
        val inputCount = mData.count { !it.outstanding.isNullOrEmpty() }
        btnUpdate?.isEnabled = selectedCount == inputCount
    }

    override fun getItemViewType(position: Int): Int {
        return PlannedPaymentInvoiceAdapter.ITEM_INVOICE_DETAIL
    }

    inner class ItemHolder(view: View, internal var inputTextWatcher: InputTextWatcher, private var focusChangeListener: FocusChangeListener) : RecyclerView.ViewHolder(view) {
        val tvAvailable: TextView = view.findViewById(R.id.tv_available)
        val tvCreditNote: TextView = view.findViewById(R.id.tv_credit_note)
        val llAllocate: View = view.findViewById(R.id.ll_allocate)
        val etAmountAllocate: EditText = view.findViewById(R.id.et_amount_allocate)
        val cbCreditNote: CheckBox = view.findViewById(R.id.cb_credit_note)
        val tvAmountValidate: TextView = view.findViewById(R.id.tv_amount_validate)
        val tvAmountToAllocateTag: TextView = view.findViewById(R.id.tv_amount_to_allocate_tag)

        init {
            etAmountAllocate.addTextChangedListener(inputTextWatcher)
            etAmountAllocate.onFocusChangeListener = this.focusChangeListener
        }
    }

    private fun setEditTextInput(reference: String, et: EditText?) {
        if (TextUtils.isEmpty(reference))
            return
        if (inputMap.containsKey(reference)) {
            val tmpText = if (inputMap[reference].isNullOrBlank()) "0.00" else inputMap[reference]
            val decimalNumber = MemoryCache.globalDecimal.format(tmpText?.toDouble())
            val etText = "$currency " + IndiaNumberUtil.formatNum(decimalNumber, currency ?: "")
            et?.setText(etText)
        } else {
            et?.setText("")
        }
    }

    inner class InputTextWatcher : TextWatcher {

        var token: String = ""
        var mCreditNoteLocal: CreditNoteLocal? = null
        var position: Int? = -1
        var tvAmountValidate: TextView? = null
        var etAmountAllocate: EditText? = null

        override fun afterTextChanged(s: Editable) {
            if (etAmountAllocate?.hasFocus() == true) {
                val input = s.toString()
                inputMap[etAmountAllocate?.tag.toString() + "origin"] = input
                val decimalSymbol = if (currency == "IDR") {
                    ","
                } else {
                    "."
                }

                val banDecimalSymbol = if (currency == "IDR") {
                    "."
                } else {
                    ","
                }

                if (s.toString().contains(banDecimalSymbol)) {
                    etAmountAllocate?.setText(s.toString().replace(banDecimalSymbol, ""))
                    etAmountAllocate?.setSelection(etAmountAllocate?.text.toString().length)
                    //在textchangewatcher中settext会调用第二次watcher，用return来结束第一次的调用，因为第一次会保留原字符
                    return
                }

                if (s.toString().contains(decimalSymbol)) {
                    if (etAmountAllocate?.text.toString().indexOf(decimalSymbol) >= 0) {
                        if (etAmountAllocate?.text.toString().indexOf(decimalSymbol, etAmountAllocate?.text.toString().indexOf(decimalSymbol) + 1) > 0) {
                            etAmountAllocate?.setText(etAmountAllocate?.text.toString().substring(0, etAmountAllocate?.text.toString().length - 1))
                            etAmountAllocate?.setSelection(etAmountAllocate?.text.toString().length)
                        }

                    }
                }

                //这部分是处理如果用户输入以.开头，在前面加上0
                if (s.toString().trim().substring(0) == decimalSymbol) {
                    val tmpZeroText = "0$s"
                    etAmountAllocate?.setText(tmpZeroText)
                    etAmountAllocate?.setSelection(2)
                    //在textchangewatcher中settext会调用第二次watcher，用return来结束第一次的调用，因为第一次会保留原字符
                    return
                }
                //这里处理用户 多次输入.的处理 比如输入 1..6的形式，是不可以的
                if (s.toString().startsWith("0")
                        && s.toString().trim().length > 1) {
                    if (s.toString().substring(1, 2) != decimalSymbol) {
                        etAmountAllocate?.setText(s.subSequence(0, 1))
                        etAmountAllocate?.setSelection(1)
                        return
                    }
                }
                if (((context as Activity).currentFocus != null) && !TextUtils.isEmpty(token)) {
                    var inputAmount = ""
                    if (input.isNotEmpty()) {
                        inputAmount = if (input.endsWith(decimalSymbol)) {
                            (input + "00").replace("$currency", "")
                        } else {
                            input.replace("$currency", "")
                        }
                        inputAmount = inputAmount.replace(decimalSymbol, ".")
                        inputAmount = inputAmount.replace(banDecimalSymbol, ".")
                    }
                    if (inputAmount.contains(".")) {
                        val pattern = Pattern.compile("(.)\\1+")
                        val matcher = pattern.matcher(inputAmount)
                        val sb = StringBuffer()
                        while (matcher.find()) {
                            val single = matcher.group(1)
                            if (single == ".") {
                                matcher.appendReplacement(sb, single)
                            }
                        }
                        matcher.appendTail(sb)
                        inputAmount = sb.toString()
                    }
                    if (inputAmount.contains(".")) {
                        val subStr = inputAmount.split(".")
                        if (subStr.size > 2) {
                            inputAmount = subStr[0] + "." + subStr[1]
                        }
                    }
                    inputMap[token] = inputAmount
                    if (inputAmount.isNotEmpty()) {
                        mCreditNoteLocal?.outstanding = inputAmount
                    } else {
                        mCreditNoteLocal?.outstanding = ""
                    }
                    if (position ?: -1 > -1) {
                        if (selectPostion.containsKey(position) && (selectPostion[position] == true)) {
                            val creditNoteOutstanding = (mData[position
                                    ?: 0].creditNote?.outstanding?.replace("-", "")?.toLong()
                                    ?: 0L) / 100
                            var creditNoteAmountInput = 0L
                            if (inputAmount.isNotEmpty())
                                creditNoteAmountInput = (inputAmount.toDouble()).toLong()
                            if (creditNoteAmountInput == 0L || (creditNoteAmountInput > creditNoteOutstanding)) {
                                setUpdateButtonState(false, tvAmountValidate, creditNoteAmountInput)
                            } else {
                                setUpdateButtonState(true, tvAmountValidate, creditNoteAmountInput)
                            }
                        }
                    }
                }
            }
        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

        }

        //limit 2 decimal
        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
        }
    }

    private fun setUpdateButtonState(b: Boolean, tv_amount_validate: TextView?, creditNoteAmountInput: Long) {
        if (b)
            tv_amount_validate?.visibility = View.GONE
        else {
            if (creditNoteAmountInput == 0L) {
                tv_amount_validate?.visibility = View.GONE
            } else {
                tv_amount_validate?.visibility = View.VISIBLE
                MemoryCache.getLabelText("s_amount_greater_tips2")?.let {
                    if (!it.isBlank()) {
                        tv_amount_validate?.text = it
                    }
                }
            }
        }
        refreshButtonState()
    }

    private fun refreshButtonState() {
        var validateFlag = true
        if (selectPostion.containsValue(true)) {
            for (item in selectPostion) {
                val position = item.key
                if (item.value) {
                    val creditNoteOutstanding = (mData[position].creditNote?.outstanding?.replace("-", "")?.toLong()
                            ?: 0L)
                    var creditNoteAmountInput = 0L
                    if (!mData[position].outstanding.isNullOrEmpty())
                        creditNoteAmountInput = ((mData[position].outstanding?.replace("-", "")?.toDouble()
                                ?: 0.00) * 100).toLong()
                    validateFlag = validateFlag && (item.value && (creditNoteAmountInput > 0) && (creditNoteAmountInput <= creditNoteOutstanding))
                }
            }
        } else {
            validateFlag = originalSelectFlag
        }
        btnUpdate?.isEnabled = validateFlag
    }

    inner class FocusChangeListener : View.OnFocusChangeListener {
        override fun onFocusChange(v: View?, hasFocus: Boolean) {
            val inputEditText = v as EditText
            val reference = v.getTag().toString()
            val input: String?
            var inputShow: String? = ""
            val decimalSymbol = if (currency == "IDR") "," else "."
            if (inputMap.containsKey(reference)) {
                input = if (inputMap[reference].isNullOrBlank()) {
                    ""
                } else {
                    var tmpInput = inputMap[reference] ?: "0"
                    tmpInput = if (tmpInput.contains(decimalSymbol)) {
                        val tmpInputSubStr = tmpInput.split(decimalSymbol)
                        if (tmpInputSubStr[1].length == 1) {
                            tmpInput += "0"
                        }
                        if (tmpInputSubStr[1].length > 2) {
                            tmpInput = tmpInputSubStr[0] + decimalSymbol + tmpInputSubStr[1].subSequence(0, 2)
                        }

                        tmpInput
                    } else {
                        (tmpInput.toDouble()).toString()
                    }
                    tmpInput
                }
                if (!TextUtils.isEmpty(input)) {
                    val exchange = (if (input.isNullOrBlank())
                        ""
                    else
                        MemoryCache.globalDecimal.format(input.toDouble())).replace(".", if (currency == "IDR") "," else ".")
                    inputShow = "$currency $exchange"
                }
            }
            if (!hasFocus) {
                inputEditText.setText(inputShow)
            } else {
                val tmpInput = if (inputMap[reference + "origin"].isNullOrBlank()) v.text.toString().replace(currency
                        ?: "", "").trim()
                else inputMap[reference + "origin"]
                inputEditText.setText(tmpInput)
            }
        }
    }

}
