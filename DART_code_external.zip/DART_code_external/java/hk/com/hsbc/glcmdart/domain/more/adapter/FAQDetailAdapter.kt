/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.more.entity.FAQ

class FAQDetailAdapter(context: Context, private val mData: ArrayList<FAQ>) : RecyclerView.Adapter<RecyclerView.ViewHolder>(){
    val inflater: LayoutInflater = LayoutInflater.from(context)

    fun addData(dataList: ArrayList<FAQ>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        notifyDataSetChanged()
    }


    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_faq_detail_view, parent, false)
        return ItemHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        vh.tvTitle.text = (position+1).toString()+"."+this.mData[position].question.text
        vh.tvContent.text =this.mData[position].answer[0].text
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tv_title)
        val tvContent: TextView = view.findViewById(R.id.tv_content)
    }
}
