/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_register_main.*

/**
 * Created by Donut on 2018/11/14.
 */
class RegisterMainActivity : BaseActivity(), View.OnClickListener {

    private var invitationCode: String = ""
    private var registerType: String = ""
    private var companyName: String = ""
    private var answerSecurityQuestionResult: RegistrationChallengeEntity? = null
    private var isRecoveryUserName = false
    private var isInvitationCodeExpired = false
    private var registerOrRecoverCountryCode = MemoryCache.defaultCountry

    companion object {
        fun showActivity(activity: Activity, isRecoveryUserNameFlag: Boolean = false) {
            val intent = Intent(activity, RegisterMainActivity::class.java).apply {
                putExtra(TAG_FORGET_TYPE_FLAG, isRecoveryUserNameFlag)
            }
            activity.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_main)
        StatusBarUtil.setStatusTextColor(false, this)
        StatusBarUtil.setTransparentStatusBar(this, false)
        removeStatusView(this)

        initViewAndData()
    }

    private fun initViewAndData() {
        isRecoveryUserName = intent.getBooleanExtra(TAG_FORGET_TYPE_FLAG, false)
        if (isRecoveryUserName) {
            ll_register_confirm_information.visibility = View.GONE
            ll_register_account_setup.visibility = View.GONE
            tv_register_main_tip.text = getString(R.string.s_recover_username_main_top_tip)
            MemoryCache.getLabelText("s_recover_username_main_title")?.let {
                if (!it.isBlank()) {
                    tv_register_main_title.text = it
                }
            }
            MemoryCache.getLabelText("s_recover_username_main_top_tip")?.let {
                if (!it.isBlank()) {
                    tv_register_main_tip.text = it
                }
            }
        } else {
            MemoryCache.getLabelText("s_register_main_title")?.let {
                if (!it.isBlank()) {
                    tv_register_main_title.text = it
                }
            }
            MemoryCache.getLabelText("s_register_main_top_tip")?.let {
                if (!it.isBlank()) {
                    tv_register_main_tip.text = it
                }
            }
        }

        val buttonAccessibilityDelegate = object: View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        }

        ll_register_enter_invitation_code.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_register_answer_security_question.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_register_confirm_information.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_register_account_setup.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_register_enter_invitation_code.setOnClickListener(this)
        ll_register_answer_security_question.setOnClickListener(this)
        ll_register_confirm_information.setOnClickListener(this)
        ll_register_account_setup.setOnClickListener(this)
        tv_register_cancel.setOnClickListener(this)

        ll_register_answer_security_question.isEnabled = false
        ll_register_confirm_information.isEnabled = false
        ll_register_account_setup.isEnabled = false

        MemoryCache.getLabelText("s_register_main_step1")?.let {
            if (!it.isBlank()) {
                tv_register_enter_invitation_code.text = it
            }
        }
        MemoryCache.getLabelText("s_register_main_step2")?.let {
            if (!it.isBlank()) {
                tv_register_answer_security_question.text = it
            }
        }
        MemoryCache.getLabelText("s_register_main_step3")?.let {
            if (!it.isBlank()) {
                tv_register_confirm_information.text = it
            }
        }
        MemoryCache.getLabelText("s_register_main_step4")?.let {
            if (!it.isBlank()) {
                tv_register_account_setup.text = it
            }
        }
        MemoryCache.getLabelText("s_cancel")?.let {
            if (!it.isBlank()) {
                tv_register_cancel.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_register_cancel")?.let {
            if (!it.isBlank()) {
                tv_register_cancel.contentDescription = it
            }
        }
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.ll_register_enter_invitation_code -> {
//                val intent = Intent(this, RegisterCreateNewUserProfileActivity::class.java).apply {
//                    putExtra(TAG_INVITATION_CODE, "000000")
//                    putExtra(TAG_ANSWER_SECURITY_QUESTION_INFO, RegistrationChallengeEntity(ChallengePayload("","","","","","","","","","","","","","","","","","","","","","","","","","","","","","")))
//                }
//                startActivity(intent)

                if (isRecoveryUserName) {
                    TealiumUtil.eventTag("button click", "recover username: overview: enter registration code")
                } else {
                    TealiumUtil.eventTag("button click", "registration: registration overview: enter registration code")
                }
                RegisterEnterInvitationCodeActivity.showActivity(this, isRecoveryUserName)
            }
            R.id.ll_register_answer_security_question -> {
                if (isRecoveryUserName) {
                    TealiumUtil.eventTag("button click", "recover username: overview: answer security questions")
                } else {
                    TealiumUtil.eventTag("button click", "registration: registration overview: answer security question")
                }
                RegisterAnswerSecurityQuestionActivity.showActivity(this, invitationCode, registerType, registerOrRecoverCountryCode, isInvitationCodeExpired,isRecoveryUserName)
            }
            R.id.ll_register_confirm_information -> {
                TealiumUtil.eventTag("button click", "registration: registration overview: confirm information")
                RegisterConfirmInformationActivity.showActivity(this, answerSecurityQuestionResult, companyName)
            }
            R.id.ll_register_account_setup -> {
                TealiumUtil.eventTag("button click", "registration: registration overview: account setup")
                val creationIntent = Intent(this, RegisterUserProfileSelectionActivity::class.java).apply {
                    putExtra(TAG_INVITATION_CODE, invitationCode)
                    putExtra(TAG_ANSWER_SECURITY_QUESTION_INFO, answerSecurityQuestionResult)
                }
                startActivity(creationIntent)
            }
            R.id.tv_register_cancel -> {
                if (isRecoveryUserName) {
                    TealiumUtil.eventTag("button click", "recover username: overview: cancel")
                } else {
                    TealiumUtil.eventTag("button click", "registration: registration overview: cancel")
                }
                finish()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK)
            when (requestCode) {
                REQUEST_CODE_REGISTER_ENTER_INVITATION_CODE -> {
                    ll_register_enter_invitation_code.isEnabled = false
                    tv_register_enter_invitation_code.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this, R.drawable.ic_done), null)
                    tv_register_enter_invitation_code_num.setBackgroundResource(R.drawable.bg_green_circle_15dp)
                    ll_register_answer_security_question.isEnabled = true
                    tv_register_answer_security_question.setTextColor(Color.BLACK)
                    tv_register_answer_security_question.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this, R.drawable.ic_next_page), null)
                    tv_register_answer_security_question_num.setTextColor(Color.WHITE)
                    tv_register_answer_security_question_num.setBackgroundResource(R.drawable.bg_black_circle_15dp)
                    if (data != null) {
                        invitationCode = data.getStringExtra(TAG_INVITATION_CODE_RESULT)
                        registerType = data.getStringExtra(TAG_INVITATION_CODE_TYPE)
                        companyName = data.getStringExtra(TAG_INVITATION_CODE_COMPANY_NAME)
                        registerOrRecoverCountryCode = data.getStringExtra(TAG_INVITATION_CODE_COUNTRY)
                        isInvitationCodeExpired = data.getBooleanExtra(TAG_INVITATION_CODE_EXPIRED, false)
                        if (isInvitationCodeExpired) {
                            tv_register_main_title.text = getString(R.string.s_invitation_expired_main_title)
                            tv_register_main_tip.text = getString(R.string.s_invitation_expired_main_tip)
                            ll_register_confirm_information.visibility = View.GONE
                            ll_register_account_setup.visibility = View.GONE
                        }
                    }
                }
                REQUEST_CODE_REGISTER_ANSWER_SECURITY_QUESTION -> {
                    ll_register_answer_security_question.isEnabled = false
                    tv_register_answer_security_question.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this, R.drawable.ic_done), null)
                    tv_register_answer_security_question_num.setBackgroundResource(R.drawable.bg_green_circle_15dp)
                    ll_register_confirm_information.isEnabled = true
                    tv_register_confirm_information.setTextColor(Color.BLACK)
                    tv_register_confirm_information.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this,R.drawable.ic_next_page), null)
                    tv_register_confirm_information_num.setTextColor(Color.WHITE)
                    tv_register_confirm_information_num.setBackgroundResource(R.drawable.bg_black_circle_15dp)
                    if (data != null) {
                        answerSecurityQuestionResult = data.getSerializableExtra(TAG_ANSWER_SECURITY_QUESTION_RESULT) as RegistrationChallengeEntity?
                    }
                }
                REQUEST_CODE_REGISTER_CONFIRM_INFORMATION -> {
                    ll_register_confirm_information.isEnabled = false
                    tv_register_confirm_information.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this, R.drawable.ic_done), null)
                    tv_register_confirm_information_num.setBackgroundResource(R.drawable.bg_green_circle_15dp)
                    ll_register_account_setup.isEnabled = true
                    tv_register_account_setup.setTextColor(Color.BLACK)
                    tv_register_account_setup.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this,R.drawable.ic_next_page), null)
                    tv_register_account_setup_num.setTextColor(Color.WHITE)
                    tv_register_account_setup_num.setBackgroundResource(R.drawable.bg_black_circle_15dp)
                }
            }
    }

    override fun onResume() {
        super.onResume()
        if (isRecoveryUserName) {
            TealiumUtil.pageTag("dart : buyer portal : recover username : overview",
                    "/dart/buyer portal/recover username/overview", "verification", "buyer portal",
                    "recover username")
        } else {
            TealiumUtil.pageTag("dart : buyer portal : registration : registration overview",
                    "/dart/buyer portal/registration/registration overview", "verification", "buyer portal",
                    "registration", "mobile","en", "registration", "1", "registration - start")
        }
    }
}