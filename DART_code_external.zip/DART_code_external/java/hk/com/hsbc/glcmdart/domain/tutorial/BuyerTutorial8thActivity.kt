/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.tutorial

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.activity_buyer_tutorial_5th.*
import kotlin.math.roundToInt

class BuyerTutorial8thActivity : BaseActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buyer_tutorial_8th)
        gotitButton.setOnClickListener(this)

        MemoryCache.getLabelText("button_gotit")?.let {
            if (!it.isBlank()) {
                gotitButton.text = it
            }
        }

//        if (MemoryCache.defaultCountry == "ID" && MemoryCache.defaultLanguageFull == "id-id") {
//            pfl_buyer_tutorial_5.background = getDrawable(R.mipmap.buyer_tutorial_5th_id)
//        }

//        val gotitLp = gotitButton.layoutParams as ConstraintLayout.LayoutParams
//        gotitLp.bottomMargin = (resources.displayMetrics.heightPixels * 0.15).roundToInt()
//        gotitButton.layoutParams = gotitLp
    }

    override fun onClick(v: View?) {
        when (v) {
            gotitButton -> {
                finish()
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}

