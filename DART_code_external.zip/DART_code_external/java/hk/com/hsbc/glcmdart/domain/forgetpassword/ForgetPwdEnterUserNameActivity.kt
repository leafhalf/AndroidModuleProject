/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.forgetpassword

import android.app.Activity
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_FORGET_RECOVERY_QUESTIONS_RESULT
import hk.com.hsbc.glcmdart.client.TAG_FORGET_RESET_TOKEN
import hk.com.hsbc.glcmdart.client.TAG_FORGET_RESET_USERNAME
import hk.com.hsbc.glcmdart.domain.registration.Question
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.widget.LoadingButton
import hk.com.hsbc.glcmdart.widget.LoadingCompletedCallback
import kotlinx.android.synthetic.main.activity_enter_invitation_code.*

class ForgetPwdEnterUserNameActivity: BaseActivity(), ForgetPwdEnterUsernameContract.View {

    private lateinit var mViewModel: ForgetPwdUserNameViewModel
    //    private val mPresenter by lazy { ForgetPwdEnterUserNamePresenter() }
    private var isTealiumUserNameEnter = false

    companion object {
        fun showActivity(activity: Activity, requestCode: Int) {
            activity.startActivityForResult(Intent(activity, ForgetPwdEnterUserNameActivity::class.java), requestCode)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enter_invitation_code)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        ll_enter_invitation_code_title_container.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)

        tv_enter_invitation_code_tip.visibility = View.GONE
        tv_enter_invitation_code_title.text = MemoryCache.getLabelText("s_forget_password_user_name_title") ?: getString(R.string.s_forget_password_user_name_title)
        tv_enter_invitation_code_input_tip.text = MemoryCache.getLabelText("s_forget_password_user_name_title") ?: getString(R.string.s_forget_password_user_name_title)
        tv_enter_invitation_code_invalid_tip.text = MemoryCache.getLabelText("s_forget_password_user_name_error_tip") ?: getString(R.string.s_forget_password_user_name_error_tip)

        MemoryCache.getLabelText("s_talkback_back_button")?.let {
            if (!it.isBlank()) {
                iv_back.contentDescription = it
            }
        }

//        mPresenter.attachView(this)
        mViewModel = ViewModelProviders.of(this).get(ForgetPwdUserNameViewModel::class.java)
        mViewModel.userNameValidationLiveData.observe(this, Observer {
            if (it == null) {
                lb_submit.enableButton(false)
                lb_submit.setButtonText(MemoryCache.getLabelText("s_next") ?: getString(R.string.s_next))
            } else {
                checkUserNameResult(ArrayList(it.payload.questions), it.payload.ResetToken)
                lb_submit.endLoadingAnimation(true)
            }
        })
        iv_back.setOnClickListener {
            TealiumUtil.eventTag("button click", "recover password: enter username: back")
            finish()
        }
        et_enter_invitation_code.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(editable: Editable?) {
                if (!isTealiumUserNameEnter && et_enter_invitation_code.text.toString().isNotEmpty()) {
                    TealiumUtil.eventTag("text entry", "recover password: enter username: username entered")
                    isTealiumUserNameEnter = true
                }
                lb_submit.enableButton(editable.toString().isNotEmpty())
                if (tv_enter_invitation_code_invalid_tip.visibility == View.VISIBLE) {
                    tv_enter_invitation_code_invalid_tip.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

        })
        lb_submit.enableButton(false)
        lb_submit.setOnButtonClickListener(View.OnClickListener {
            TealiumUtil.eventTag("button click", "recover password: enter username: next")
            tv_enter_invitation_code_invalid_tip.visibility = View.GONE
            lb_submit.startLoadingAnimation()
            mViewModel.doCheckUserName(et_enter_invitation_code.text.toString())
        })

        addLayoutListener(lb_submit)
    }

    override fun getActivity(): Activity {
        return this
    }

    override fun obtainSubmitButton(): LoadingButton {
        return lb_submit
    }

    override fun showInvalidMessage() {
        tv_enter_invitation_code_invalid_tip.visibility = View.VISIBLE
        lb_submit.enableButton(false)
        lb_submit.setButtonText(MemoryCache.getLabelText("s_next") ?: getString(R.string.s_next))
    }

    override fun checkUserNameResult(recoveryQuestions: ArrayList<Question>, resetToken: String) {
        lb_submit.animationEndCallback = object : LoadingCompletedCallback {
            override fun onAnimationCompleted() {
                val completedIntent = Intent().apply {
                    putExtra(TAG_FORGET_RECOVERY_QUESTIONS_RESULT, recoveryQuestions)
                    putExtra(TAG_FORGET_RESET_TOKEN, resetToken)
                    putExtra(TAG_FORGET_RESET_USERNAME, et_enter_invitation_code.text.toString())
                }
                setResult(Activity.RESULT_OK, completedIntent)
                finish()
            }
        }
    }

    private fun addLayoutListener(bottomView: View) {
        window.decorView.viewTreeObserver.addOnGlobalLayoutListener {
            val rect = Rect()
            window.decorView.getWindowVisibleDisplayFrame(rect)
            val invisibleHeight = window.decorView.height - rect.bottom
            if (invisibleHeight > 150) {
                bottomView.animate().translationY(-invisibleHeight.toFloat()).setDuration(0).start()
            } else {
                bottomView.animate().translationY(0F).start()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart : buyer portal : recover password : enter username",
                "/dart/buyer portal/recover password/enter username",
                "verification",
                "buyer portal",
                "recover password",
                "mobile",
                "en",
                "recover password",
                "2",
                "recover password - enter username")
    }
}