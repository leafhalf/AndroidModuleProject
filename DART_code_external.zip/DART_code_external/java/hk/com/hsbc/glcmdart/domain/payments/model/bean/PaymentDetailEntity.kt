/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.model.bean

import androidx.annotation.Keep
import hk.com.hsbc.glcmdart.domain.dart.CreditNoteLocal
import hk.com.hsbc.glcmdart.domain.dart.ITP
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import java.io.Serializable

@Keep
data class PaymentDetailEntityPayload(val payload: PaymentDetailEntity?):Serializable

@Keep
data class PaymentDetailEntity(
        val amount: String?,
        val createdAt: String?,
        val invoices: List<InvoiceListItem>?,
        val creditNotes:List<CreditNoteLocal>?,
        val deductions: HashMap<String, List<TaxDeductionInfo>>?,
        val itp: ITP?,
        val status: String?,
        val token: String?,
        val updatedAt: String?
):Serializable

@Keep
data class TaxDeductionWrap(
        val active: Boolean?,
        val deduction: TaxDeductionInfo?,
        val token: String?
):Serializable
