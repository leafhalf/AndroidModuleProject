package hk.com.hsbc.glcmdart.domain.creditnote

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.MemoryCache

class CreditNoteCurrencyAdapter(context: Context, private var mData: Map<String, MutableList<String>>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val inflater: LayoutInflater = LayoutInflater.from(context)

    private val keyList = mutableListOf<String>()
    private val itemSelects = mutableListOf<String>()

    fun addData(dataList: Map<String, MutableList<String>>) {
        this.keyList.clear()
        this.mData = dataList
        for (item in dataList) {
            keyList.addAll(item.value)
            itemSelects.addAll(item.value)
        }
        notifyDataSetChanged()
    }

    fun resetSelectState() {
        itemSelects.clear()
        for (items in mData) {
            itemSelects.addAll(items.value)
        }
        notifyDataSetChanged()
    }

    fun setSelectState(selectItem: List<String>) {
        itemSelects.clear()
        itemSelects.addAll(selectItem)
        notifyDataSetChanged()
    }

    fun getSelectItem(): List<String> {
        return itemSelects
    }

    override fun getItemCount(): Int = keyList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_creditnotes_check, parent, false)
        return ItemHolder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        vh.tvCurrency.text = keyList[position]
        MemoryCache.getLabelText("s_closed")?.let {
            if (!it.isBlank()) {
                vh.cbCurrency.contentDescription = it
            }
        }
        vh.cbCurrency.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!itemSelects.contains(keyList[position]))
                    itemSelects.add(keyList[position])
            } else {
                itemSelects.remove(keyList[position])
            }
        }
        vh.cbCurrency.isChecked = itemSelects.contains(keyList[position])
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvCurrency: TextView = view.findViewById(R.id.tv_currency)
        val cbCurrency: CheckBox = view.findViewById(R.id.cb_currency)
    }

}
