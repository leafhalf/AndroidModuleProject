/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.view

import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.dashboard.HomePaymentChannelEntity
import hk.com.hsbc.glcmdart.domain.dashboard.HomePaymentChannelInfo
import hk.com.hsbc.glcmdart.domain.payments.adapter.PaymentSummaryAdapter
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.widget.CubeOutTransformer
import hk.com.hsbc.glcmdart.widget.EnhanceTabLayout
import hk.com.hsbc.glcmdart.widget.SpacesItemDecoration
import kotlinx.android.synthetic.main.view_payment_summary.view.*

class PaymentSummaryView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyle: Int = 0):
        LinearLayout(context, attrs, defStyle), TabLayout.OnTabSelectedListener {

    companion object {
        const val SUMMARY_FILTER_TYPE_METHOD = "method"
        const val SUMMARY_FILTER_TYPE_STATUS = "status"
    }

    init {
        LayoutInflater.from(context).inflate(R.layout.view_payment_summary, this, true)
    }

    private var currentSelection = 0
    private val cubeTransformer60d = CubeOutTransformer(60.0f)
    private val cubePageChangeListener = object : ViewPager.OnPageChangeListener {
        override fun onPageScrollStateChanged(p0: Int) {
            vp_supplier_payment.setPageTransformer(true, cubeTransformer60d)
        }

        override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {
        }

        override fun onPageSelected(position: Int) {
            wvp_content.currentItem = position
//            tab_title.removeOnTabSelectedListener(this@PaymentSummaryView)
            tab_title.tabLayout?.getTabAt(position)?.select()
//            tab_title.addOnTabSelectedListener(this@PaymentSummaryView)
        }
    }

    fun setPaymentSummaryView(filterType: String, channel: HomePaymentChannelEntity?, currency: String?) {
        val channelMap = LinkedHashMap<String, ArrayList<HomePaymentChannelInfo>>()
        when (filterType) {
            SUMMARY_FILTER_TYPE_METHOD -> {
//                channelMap["ach"] = ArrayList()
//                channelMap["bank_transfer"] = ArrayList()
//                channelMap["cheque"] = ArrayList()
//                channelMap["rtgs"] = ArrayList()
//                if (MemoryCache.defaultCountry == "IN") {
//                    channelMap["dcms"] = ArrayList()
//                }
            }
            SUMMARY_FILTER_TYPE_STATUS -> {
                channelMap["paid"] = ArrayList()
                channelMap["planned"] = ArrayList()
                channelMap["due"] = ArrayList()
            }
        }
        if (channel?.payload?.items != null) {
            for (item in channel.payload.items) {
                if (item.channel == "full_deduction" || item.channel == "credit_note") {
                    continue
                }
                var sortType = ""
                when (filterType) {
                    SUMMARY_FILTER_TYPE_STATUS -> sortType = item.paidStatus!!
                    SUMMARY_FILTER_TYPE_METHOD -> sortType = item.channel!!
                }
                if (channelMap.containsKey(sortType)) {
                    val channelList = channelMap[sortType]
                    channelList?.add(item)
                    channelMap[sortType] = channelList ?: ArrayList()
                } else {
                    val channelList = ArrayList<HomePaymentChannelInfo>()
                    channelList.add(item)
                    channelMap[sortType] = channelList
                }
            }
        }
        setTabLayoutView(filterType, channelMap, currency)
        vp_supplier_payment.addOnPageChangeListener(cubePageChangeListener)
    }

    private fun setTabLayoutView(filterType: String, channelMap: LinkedHashMap<String, ArrayList<HomePaymentChannelInfo>>, currency: String?) {
        val viewList = mutableListOf<View>()
        tab_title.removeAllTab()
        wvp_content.removeAllViews()
        for (item in channelMap) {
            val view = LayoutInflater.from(context).inflate(R.layout.view_payment_summary_listview, null)
            val mRecyclerView = view.findViewById<RecyclerView>(R.id.rv_invoice_add_or_edit)
            val mAdapter = PaymentSummaryAdapter(context, item.value, filterType)
            mAdapter.setCurrency(currency)
            mRecyclerView.layoutManager = LinearLayoutManager(context)
            mRecyclerView.addItemDecoration(SpacesItemDecoration(context as Activity, resources.getDimension(R.dimen.d_common_padding_margin_8).toInt()))
            mRecyclerView.adapter = mAdapter
            mRecyclerView.isFocusableInTouchMode = false
            mRecyclerView.requestFocus()
            viewList.add(view)
            if (filterType == SUMMARY_FILTER_TYPE_STATUS)
                tab_title.addTab(MemoryCache.getLabelText("s_payment_method_label_" + item.key) ?: "", EnhanceTabLayout.INDICATOR_WIDTH_TYPE_MAX)
            else {
                tab_title.addTab(MemoryCache.getLabelText("s_payment_method_label_" + item.key) ?: "", EnhanceTabLayout.INDICATOR_WIDTH_TYPE_MIN)
            }
        }
        tab_title.addOnTabSelectedListener(this)
        wvp_content.offscreenPageLimit = 5
        wvp_content.adapter = object : PagerAdapter() {
            override fun isViewFromObject(p0: View, p1: Any): Boolean {
                return p0 == p1
            }

            override fun getCount(): Int {
                return viewList.size
            }

            override fun instantiateItem(container: ViewGroup, position: Int): Any {
                wvp_content.addView(viewList[position])
                return viewList[position]
            }

            override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
                wvp_content.removeView(viewList[position])
            }
        }
        wvp_content.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tab_title.tabLayout))
        tab_title.setupWithViewPager(wvp_content)
    }

    override fun onTabReselected(p0: TabLayout.Tab?) {
    }

    override fun onTabUnselected(p0: TabLayout.Tab?) {

    }

    override fun onTabSelected(tab: TabLayout.Tab?) {
        tab?.let {
            currentSelection = it.position
            wvp_content.currentItem = it.position
//            vp_supplier_payment.removeOnPageChangeListener(cubePageChangeListener)
//            vp_supplier_payment.setPageTransformer(true, cubeTransformer0d)
            vp_supplier_payment.currentItem = it.position
//            vp_supplier_payment.addOnPageChangeListener(cubePageChangeListener)
        }
    }

    fun alignChartAndTabCurrentItem() {
        vp_supplier_payment.currentItem = currentSelection
    }
}