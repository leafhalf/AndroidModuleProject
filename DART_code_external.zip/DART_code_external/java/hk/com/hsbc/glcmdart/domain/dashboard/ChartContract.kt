/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.dashboard

import hk.com.hsbc.glcmdart.domain.dart.Account
import hk.com.hsbc.glcmdart.framework.IView
import io.reactivex.Observable

interface ChartContract {

    interface View: IView {
        fun updateChannelsData(entity: HomePaymentChannelEntity?)
        fun updateInvoiceStatusData(entity: HomeInvoiceStatusEntity?)
        fun updateInvoiceSummaryData(entity: HomeInvoiceSummaryEntity)
        fun updateFragmentMetricsData(entity: HomeInvoiceMetricsEntity)
        fun saveAccounts(accounts: List<Account>?)
    }

    interface Model {
        fun getHomeFragmentChannelsData(requestBody: Map<String, Any>): Observable<HomePaymentChannelEntity>
        fun getHomeInvoiceStatusData(requestBody: Map<String, Any>): Observable<HomeInvoiceStatusEntity>
        fun getHomeInvoiceSummaryData(requestBody: Map<String, Any>): Observable<HomeInvoiceSummaryEntity>
        fun getHomeFragmentMetricsData(requestBody: Map<String, Any>): Observable<HomeInvoiceMetricsEntity>
        fun getProfileDetail(): Observable<ProfileDetailEntity>
    }
}