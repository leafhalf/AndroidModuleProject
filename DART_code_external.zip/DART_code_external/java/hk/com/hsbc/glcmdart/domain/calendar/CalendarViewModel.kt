package hk.com.hsbc.glcmdart.domain.calendar

import android.annotation.SuppressLint
import android.util.SparseArray
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.CalendarListItem
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.domain.dart.ITPListItem
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.Logger
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import io.reactivex.Observable
import io.reactivex.functions.Function3
import io.reactivex.schedulers.Schedulers
import okhttp3.MediaType
import okhttp3.RequestBody
import java.text.SimpleDateFormat
import java.util.*

class CalendarViewModel : BaseViewModel() {

    val calendarLiveData = MutableLiveData<MutableMap<String, CalendarListItem>>()
    val chatLiveData = MutableLiveData<SparseArray<Any>>()
    private var mInvoiceGroup = mutableMapOf<String, MutableList<InvoiceListItem>>()
    private var mItpGroup = mutableMapOf<String, MutableList<ITPListItem>>()
    private var mSelectCurrency: String? = null
    private val mModel by lazy { CalendarModel() }

    // BiFunction need API24, but lowest is 21, replace with function3
    @SuppressLint("CheckResult")
    fun doRequest(currency: String?, country: String?) {
        mSelectCurrency = currency
        val jsonBody = if (currency == null) "{}" else "{\"currencies\": [\"$currency\"]}"
        val requestBody = RequestBody.create(MediaType.parse("application/json"), jsonBody)
        Observable.zip(mModel.requestInvoiceList(requestBody).subscribeOn(Schedulers.io()),
                mModel.requestPlannedPaymentList(requestBody).subscribeOn(Schedulers.io()),
                Observable.just(0),
                Function3<InvoiceListEntity, PlannedPaymentListPayload, Int, SparseArray<Any>> { t1, t2, t3 ->
                    val result = SparseArray<Any>()
                    result.put(0, t1)
                    result.put(1, t2)
                    result.put(2, t3)
                    result
                })
                .subscribe({
                    mInvoiceGroup = mutableMapOf()
                    mItpGroup = mutableMapOf()
                    val mInvoicesEntity = it[0] as InvoiceListEntity
                    val invoiceTokens = mInvoicesEntity.payload?.tokens
                    val invoices = mInvoicesEntity.payload?.invoices
                    if (invoiceTokens != null &&
                            invoices != null &&
                            invoiceTokens.size == invoices.size) {
                        for (index in invoiceTokens.indices) {
                            val status = invoices[index].status
                            status?.also {
                                if (it.contentEquals("U") || it.contentEquals("P")) {
                                    val item = InvoiceListItem(token = invoiceTokens[index], invoice = invoices[index], active = true)
                                    val date = item.invoice?.dueDate ?: ""
                                    if (mInvoiceGroup[date] == null) {
                                        mInvoiceGroup[date] = ArrayList()
                                    }
                                    mInvoiceGroup[date]?.add(item)
                                }
                            }
                        }
                    }

                    val mItpsEntity = it[1] as PlannedPaymentListPayload
                    // Process itps
                    val paymentTokens = mItpsEntity.payload?.tokens
                    val amounts = mItpsEntity.payload?.amounts
                    val createdAts = mItpsEntity.payload?.createdAts
                    val itps = mItpsEntity.payload?.itps
                    val statuses = mItpsEntity.payload?.statuses
                    val updatedAts = mItpsEntity.payload?.updatedAts
                    if (paymentTokens != null &&
                            amounts != null &&
                            createdAts != null &&
                            itps != null &&
                            statuses != null &&
                            updatedAts != null) {
                        for (index in paymentTokens.indices) {
                            val status = statuses[index]
                            status.also {
                                if (it.contentEquals("created")) {
                                    val item = ITPListItem(token = paymentTokens[index],
                                            itp = itps[index],
                                            createdAt = createdAts[index],
                                            updatedAt = updatedAts[index],
                                            status = statuses[index],
                                            amount = amounts[index])
                                    val date = item.itp?.expectedDate ?: ""
                                    if (mItpGroup[date] == null) {
                                        mItpGroup[date] = ArrayList()
                                    }
                                    mItpGroup[date]?.add(item)
                                }
                            }
                        }
                    }
                    // Process calendar
                    val mDates = mutableSetOf<String>()
                    mDates.addAll(mInvoiceGroup.keys)
                    mDates.addAll(mItpGroup.keys)
//                    Logger.i("dates: $mDates")
//                    Logger.i("dates: ${mDates.size}")
                    val mCalendarGroup = mutableMapOf<String, CalendarListItem>()
                    mDates.forEach {
                        val dueOrExpectedDate = it

                        var invoiceAmount = 0L
                        var invoiceCurrency: String? = ""
                        var itpAmount = 0L
                        var itpCurrency: String? = ""

                        val dueInvoices = mInvoiceGroup[it]
                        val expectedPayments = mItpGroup[it]

                        // Total invoice amount
                        dueInvoices?.forEach { item ->
                            item.invoice?.also { invoice ->
                                invoice.summation?.outstanding?.also { outstanding ->
                                    outstanding.amount?.also { amount ->
                                        invoiceAmount = invoiceAmount.plus(amount.toLong())
                                    }
                                    outstanding.currency?.also { currency ->
                                        invoiceCurrency = currency
                                    }
                                }
                            }
                        }

                        // Total payment amount
                        expectedPayments?.forEach { item ->
                            item.itp?.also { itp ->
                                itp.lines?.forEach { line ->
                                    line.type?.also { type ->
                                        if (!type.contentEquals("creditNote")) {
                                            line.amount?.amount?.also { amount ->
                                                itpAmount = itpAmount.plus(amount.toLong())
                                            }
                                            line.amount?.currency?.also { currency ->
                                                itpCurrency = currency
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Create calendar entity
                        val mCalendar = CalendarListItem(dueOrExpectedDate = dueOrExpectedDate,
                                invoiceAmount = invoiceAmount.toString(),
                                invoiceCurrency = invoiceCurrency,
                                itpAmount = itpAmount.toString(),
                                itpCurrency = itpCurrency)
                        dueInvoices?.also { dueList ->
                            mCalendar.dueInvoices.addAll(dueList)
                        }
                        expectedPayments?.also { itpList ->
                            mCalendar.expectedPayments.addAll(itpList)
                        }
                        mCalendarGroup[it] = mCalendar
                    }

                    val timeFormatter = SimpleDateFormat("yyyy-MM-dd")
                    val date = timeFormatter.format(Date())
                    val calculateResult = try {
                        //to support dynamic date, so apart year/month/day
                        val year = date.subSequence(0,4).toString().toInt()
                        val month = date.subSequence(5,7).toString().toInt()
                        val day = date.subSequence(8,10).toString().toInt()
                        val result = SparseArray<Any>()
                        val dateInvoicesSet = mInvoiceGroup.keys
                        val datePaymentsSet = mItpGroup.keys
                        val calendarStart = Calendar.getInstance()
                        val calendarEnd = Calendar.getInstance()

                        calendarEnd.set(Calendar.YEAR, year)
                        calendarEnd.set(Calendar.MONTH, month - 1)
                        calculateSinglePieChart(calendarStart, calendarEnd, 0, dateInvoicesSet, datePaymentsSet, result)
                        calendarStart.set(Calendar.YEAR, year)
                        calendarStart.set(Calendar.MONTH, month - 1)
                        calendarEnd.set(Calendar.MONTH, month)
                        calculateSinglePieChart(calendarStart, calendarEnd, 1, dateInvoicesSet, datePaymentsSet, result)
                        calendarStart.set(Calendar.MONTH, month - 1)
                        calendarEnd.set(Calendar.MONTH, month + 2)
                        calendarEnd.set(Calendar.DAY_OF_MONTH, day)
                        calculateSinglePieChart(calendarStart, calendarEnd, 2, dateInvoicesSet, datePaymentsSet, result)

                        result
                    } catch (e: Exception) {
                        null
                    }
                    chatLiveData.postValue(calculateResult)
                    calendarLiveData.postValue(mCalendarGroup.toSortedMap())
                }, {
                    requestLoadingLiveData.postValue(false)
                    exceptionLiveData.postValue(it.message)
//                    Toast.makeText(DartApplication.instance, "load fail: " + it.message, Toast.LENGTH_SHORT).show()
                })
    }

    /**
     * @param calendarStart     check start date
     * @param calendarEnd       check end date
     * @param index             chart index, curentlly 3 for max
     * @param invoiceKeySet     invoice due day key set
     * @param paymentKeySet     payment due day key set
     * @param result            return result
     */
    private fun calculateSinglePieChart(calendarStart: Calendar, calendarEnd: Calendar, index: Int,
                                        invoiceKeySet: MutableSet<String>, paymentKeySet: MutableSet<String>, result: SparseArray<Any>) {
        val invoicesAmount: Double
        val paymentsAmount: Double
        val invoices = mutableListOf<InvoiceListItem>()
        val payments = mutableListOf<ITPListItem>()

        for (key in invoiceKeySet) {
            //0 is behalf of up to today, just check end day
            if (index == 0) {
                if (TimeZoneTransformsUtil.calDaysBetween(key, TimeZoneTransformsUtil.formatParameterTime(calendarEnd.time)).toInt() >= 0) {
                    invoices.addAll(mInvoiceGroup[key] ?: emptyList())
                }
            } else {
                if (TimeZoneTransformsUtil.calDaysBetween(key, TimeZoneTransformsUtil.formatParameterTime(calendarStart.time)).toInt() <= 0 &&
                        TimeZoneTransformsUtil.calDaysBetween(key, TimeZoneTransformsUtil.formatParameterTime(calendarEnd.time)).toInt() >= 0) {
                    invoices.addAll(mInvoiceGroup[key] ?: emptyList())
                }
            }
        }

        for (key in paymentKeySet) {
            //0 is behalf of up to today, just check end day
            if (index == 0) {
                if (TimeZoneTransformsUtil.calDaysBetween(key, TimeZoneTransformsUtil.formatParameterTime(calendarEnd.time)).toInt() >= 0) {
                    payments.addAll(mItpGroup[key] ?: emptyList())
                }
            } else {
                if (TimeZoneTransformsUtil.calDaysBetween(key, TimeZoneTransformsUtil.formatParameterTime(calendarStart.time)).toInt() <= 0 &&
                        TimeZoneTransformsUtil.calDaysBetween(key, TimeZoneTransformsUtil.formatParameterTime(calendarEnd.time)).toInt() >= 0) {
                    payments.addAll(mItpGroup[key] ?: emptyList())
                }
            }
        }

        result.append(4 * index, invoices)

        result.append(4 * index + 1, if (invoices.isNullOrEmpty()) {
            "$mSelectCurrency 0.00"
        } else {
            invoicesAmount = invoices.sumByDouble {
                if (it.invoice?.summation?.outstanding?.amount == null) {
                    0.0
                } else {
                    it.invoice.summation.outstanding.amount.toDouble()
                }
            }
            "$mSelectCurrency\t${IndiaNumberUtil.formatNumByDecimal(invoicesAmount.toString(), mSelectCurrency ?: MARKET_CURRENCY)}"
        }
        )
        result.append(4 * index + 2, payments)

        result.append(4 * index + 3, if (payments.isNullOrEmpty()) {
            "$mSelectCurrency 0.00"
        } else {
            paymentsAmount = payments.sumByDouble {
                if (it.itp?.lines.isNullOrEmpty()) {
                    0.0
                } else {
                    it.itp?.lines?.sumByDouble { line ->
                        if (line.type != null && !line.type.contentEquals("creditNote")) {
                            line.amount?.amount?.toDouble() ?: 0.00
                        } else {
                            0.0
                        }
                    } ?: 0.0
                }
            }
            "$mSelectCurrency\t${IndiaNumberUtil.formatNumByDecimal(paymentsAmount.toString(), mSelectCurrency ?: MARKET_CURRENCY)}"
        }
        )
    }
}