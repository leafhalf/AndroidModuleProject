/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.registration

import com.google.gson.Gson
import hk.com.hsbc.glcmdart.client.HOST_URL_CONSENT
import hk.com.hsbc.glcmdart.util.NetworkManager
import io.reactivex.Observable
import okhttp3.MediaType
import okhttp3.RequestBody
import retrofit2.http.Body

class RegistrationModel {

    fun checkInvitationCode(invitation: String): Observable<RegistrationInvitationEntity> {
        return NetworkManager.getNormalService(RegistrationService::class.java, HOST_URL_CONSENT).uploadInvitationCode(invitation)
    }

    fun uploadSecurityQuestionAnswer(invitation: String, answers: RequestSecurityQuestionEntity): Observable<RegistrationChallengeEntity> {
        val parameterStr = Gson().toJson(answers)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(RegistrationService::class.java, HOST_URL_CONSENT).answerSecurityQuestion(invitation, requestBody)
    }

    fun requestRecoveryQuestions(): Observable<RecoveryQuestionsEntity> {
        return NetworkManager.getNormalService(RegistrationService::class.java, HOST_URL_CONSENT)
                .requestRecoveryQuestions()
    }

    fun requestUsernameValidation(invitation: String, token: String, @Body body: UsernameValidationBean): Observable<UsernameValidationEntity> {
        return NetworkManager.getNormalService(RegistrationService::class.java, HOST_URL_CONSENT)
                .requestUsernameValidation(invitation, "Bearer $token", body)
    }

    fun requestProfileCreation(invitation: String, token: String, @Body body: ProfileCreationBean): Observable<ProfileCreationEntity> {
        return NetworkManager.getNormalService(RegistrationService::class.java, HOST_URL_CONSENT)
                .requestProfileCreation(invitation, "Bearer $token", body)
    }

    fun recoverUsername(invitation: String, answers: RequestSecurityQuestionEntity): Observable<RegistrationChallengeEntity> {
        val parameterStr = Gson().toJson(answers)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(RegistrationService::class.java, HOST_URL_CONSENT).recoverUsername(invitation, requestBody)
    }

    fun recoverExpiredInvitationCode(invitation: String, answers: String): Observable<ExpiredInvitationEntity> {
        val parameter = mutableMapOf(Pair("answer1", answers))
        val parameterStr = Gson().toJson(parameter)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(RegistrationService::class.java, HOST_URL_CONSENT).recoverExpiredInvitationCode(invitation, requestBody)
    }
}