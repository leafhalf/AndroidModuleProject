/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.google.gson.Gson
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.*
import hk.com.hsbc.glcmdart.domain.payments.contract.PaymentCreationContract
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentPayload
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.domain.payments.presenter.PaymentCreateViewModel
import hk.com.hsbc.glcmdart.domain.payments.view.*
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showShortToast
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.widget.LoadingCompletedCallback
import kotlinx.android.synthetic.main.activity_planned_payment_creation.*
import kotlinx.android.synthetic.main.view_create_payment.*
import java.io.IOException
import java.lang.Exception

class PlannedPaymentCreationActivity : BaseActivity(), PaymentCreationContract.View {

    private lateinit var mViewModel: PaymentCreateViewModel
    private var confirming: Boolean = false
    //    private val mPresenter by lazy { PaymentCreationPresenter() }
    private val mCreatePaymentView by lazy { CreatePaymentView(this) }
    private val mStepInfoView by lazy { StepInfoView(this) }
    private val mBeneficiaryInfoView by lazy { BeneficiaryInfoView(this) }
    private val mProvidePaymentInfoView by lazy { ProvidePaymentInfoView(this) }
    private val mInvoiceTobePaidView by lazy { InvoiceTobePaidView(this) }
    private val mConfirmationView by lazy { ConfirmationView(this) }
    private var currentStep: Int = STEP_ONE
    private var invoice: Invoice? = null
    private var invoices: ArrayList<InvoiceListItem>? = null
    private var paymentMethods: PaymentMethod? = null
    private var currency: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planned_payment_creation)
        initEventAndData()
    }

    @SuppressLint("ResourceAsColor")
    private fun initEventAndData() {
        MemoryCache.getLabelText("s_cancel")?.let {
            if (!it.isBlank()) {
                btn_cancle.text = it
            }
        }
        MemoryCache.getLabelText("s_confirm")?.let {
            if (!it.isBlank()) {
                btn_step.text = it
                btn_step_last.setButtonText(it)
            }
        }

        tl_head.title = MemoryCache.getLabelText("create_planned_payment_title") ?: getString(R.string.create_planned_payment_title)
        tl_head.subtitle = "1 of 4"
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            returnBack()
        }
        mStepInfoView.setCurrentStep(STEP_ONE)
        ll_stepview.addView(mStepInfoView)
        ll_topview.addView(mCreatePaymentView)
        ll_contentview.addView(mBeneficiaryInfoView)
//        mPresenter.attachView(this)
        mViewModel = ViewModelProviders.of(this).get(PaymentCreateViewModel::class.java)

        mViewModel.paymentMethodLiveData.observe(this, Observer {
            setPaymentMethods(it)
        })

        mViewModel.bankHolidayLiveData.observe(this, Observer {
            setBankCalendar(it)
        })

        mViewModel.paymentCreationLiveData.observe(this, Observer {
            createSuccessful(it)
        })

        mViewModel.creditNoteAvailableLiveData.observe(this, Observer {
            hideLoadingDialogExt()
            setCreditNotes(it)
        })

        mViewModel.deductionLiveData.observe(this, Observer {
            setDeductions(it)
        })

        mViewModel.requestLoadingLiveData.observe(this, Observer {
            if (it) { showLoadingDialogExt() } else { hideLoadingDialogExt() }
        })

        mViewModel.paymentErrorLiveData.observe(this, Observer {
            if (confirming) {
                btn_step_last.endLoadingAnimation(false)
                btn_step_last.enableButton(true)
                btn_step_last.setButtonText(MemoryCache.getLabelText("s_confirm") ?: getString(R.string.s_confirm))
            }
            confirming = false
            hideLoadingDialogExt()
            showFailedToast(it ?: "Unknown Exception")
//            Toast.makeText(this@PlannedPaymentCreationActivity, it ?: "Unknown Exception", Toast.LENGTH_SHORT).show()
        })

        btn_step.setOnClickListener {
            when (btn_step.tag) {
                STEP_TWO -> {
                    var isWithCN = false
                    val invoiceTobePaidData = mInvoiceTobePaidView.getCurrentViewData()
                    if (invoiceTobePaidData.isNotEmpty() && invoiceTobePaidData.contains("lines")) {
                        val lines = invoiceTobePaidData["lines"] as ArrayList<Line>
                        if (lines.isNotEmpty()) {
                            for (item in lines) {
                                if (item.type == CREDITNOTE) {
                                    isWithCN = true
                                    break
                                }
                            }
                        }
                    }
                    if (isWithCN) {
                        TealiumUtil.eventTag("button click", "confirm planned payment - invoice details with credit note: next")
                    } else {
                        TealiumUtil.eventTag("button click", "confirm planned payment - invoice details: next")
                    }
                }
                STEP_THREE -> {
                    TealiumUtil.eventTag("button click", "confirm planned payment - payment {info|info bank|info cheque|info ach|info rtgs|info neft}: next")
                    btn_step_last.visibility = View.VISIBLE
                    btn_step.visibility = View.GONE
                }
            }

            if (btn_step.tag != STEP_FOUR) {
//                TealiumUtil.eventTag("button click", "confirm planned payment - confirmation: confirm")
//                showLoadingDialogExt()
//                confirmSubmission()
//            } else {
                if (currentStep < STEP_FOUR) {
                    currentStep++
                }
                btn_step_last.visibility = View.GONE
                btn_step.visibility = View.VISIBLE
                handleStepViewAndData()
            }
        }

        btn_step_last.setOnButtonClickListener (View.OnClickListener {
            TealiumUtil.eventTag("button click", "confirm planned payment - confirmation: confirm")
            btn_step_last.startLoadingAnimation()
            confirmSubmission()
        })

        btn_cancle.setOnClickListener {
            TealiumUtil.eventTag("button click", "confirm planned payment - confirmation: cancel")
            finish()
        }
        invoices = intent.getSerializableExtra(INTENT_DATA_INVOICES) as ArrayList<InvoiceListItem>
        invoice = invoices?.get(0)?.invoice
        currency = invoice?.summation?.total?.currency
        mBeneficiaryInfoView.setMainPageWidget(ll_payment_state, ll_payment_state_middle)
        mInvoiceTobePaidView.setMainPageWidget(ll_payment_state, ll_payment_state_middle, amountText,
                amountTextMiddle, btn_step, creditnoteAmountMiddle, deductionAmountMiddle, tv_due_date, currency)
        mConfirmationView.setMainPageWidget(ll_payment_state, ll_payment_state_middle, null, currency)
        mProvidePaymentInfoView.setMainPageWidget(ll_payment_state, ll_payment_state_middle, amountText,
                amountTextMiddle, deductionAmountMiddle, btn_step, null, invoice?.payee?.name, currency)
        mCreatePaymentView.setInvoiceEntity(invoices?.get(0))
        mCreatePaymentView.setAmount(0, null)
        mBeneficiaryInfoView.setInvoiceEntity(invoices?.get(0))
        showLoadingDialogExt()
        mViewModel.requestDeductions(invoice?.payee?.reference, invoice?.payee?.account?.countryCode, invoice?.payee?.account?.currency,
                invoice?.payee?.account?.reference)
        mViewModel.requestBankCalendar(MemoryCache.defaultCountry ?: MARKET_COUNTRY)
    }

    private fun returnBack() {
        if (currentStep == STEP_ONE)
            finish()
        else {
            currentStep--
            handleStepViewAndData()
        }
    }

    override fun onBackPressed() {
        returnBack()
    }

    private fun handleStepViewAndData() {
        when (currentStep) {
            STEP_ONE -> {
                tl_head.subtitle = "1 of 4"
                ll_contentview.removeAllViews()
                btn_cancle.visibility = View.GONE
                btn_step.text = MemoryCache.getLabelText("s_next") ?: getString(R.string.s_next)
                btn_step.tag = STEP_ONE
                btn_step.isEnabled = true
                updateStepButtonMargin(currentStep)
                mBeneficiaryInfoView.updateMainPageWidgetState()
                ll_contentview.addView(mBeneficiaryInfoView)
                mStepInfoView.setCurrentStep(currentStep)
                btn_step_last.visibility = View.GONE
                btn_step.visibility = View.VISIBLE
            }
            STEP_TWO -> {
                TealiumUtil.eventTag("button click", "confirm planned payment - beneficiary info: confirm")
                tl_head.subtitle = "2 of 4"
                ll_contentview.removeAllViews()
                btn_cancle.visibility = View.GONE
                btn_step.text = MemoryCache.getLabelText("s_next") ?: getString(R.string.s_next)
                btn_step.contentDescription = MemoryCache.getLabelText("s_talkback_button_next") ?: getString(R.string.s_talkback_button_next)
                btn_step.tag = STEP_TWO
                btn_step.isEnabled = mInvoiceTobePaidView.checkInputData()
                updateStepButtonMargin(currentStep)
                mInvoiceTobePaidView.updateMainPageWidgetState()
                ll_contentview.addView(mInvoiceTobePaidView)
                mStepInfoView.setCurrentStep(currentStep)
                btn_step_last.visibility = View.GONE
                btn_step.visibility = View.VISIBLE
            }
            STEP_THREE -> {
                TealiumUtil.eventTag("button click", "confirm planned payment - invoice details with credit note: invoice selected")
                tl_head.subtitle = "3 of 4"
                if (mInvoiceTobePaidView.checkInputData()) {
                    ll_contentview.removeAllViews()
                    btn_cancle.visibility = View.GONE
                    btn_step.text = MemoryCache.getLabelText("s_next") ?: getString(R.string.s_next)
                    btn_step.contentDescription = MemoryCache.getLabelText("s_talkback_button_next") ?: getString(R.string.s_talkback_button_next)
                    btn_step.tag = STEP_THREE
                    btn_step.isEnabled = mProvidePaymentInfoView.checkInputData()
                    updateStepButtonMargin(currentStep)
                    mProvidePaymentInfoView.updateMainPageWidgetState()
                    ll_contentview.addView(mProvidePaymentInfoView)
                    TealiumUtil.pageTag("dart : buyer portal : payments : confirm planned payment - payment info",
                            "/dart/buyer portal/payments/confirm planned payment-payment info",
                            "transaction",
                            "buyer portal",
                            "payments",
                            "mobile",
                            "en",
                            "create planned payment",
                            "3",
                            "create planned payment - payment info")
                    mStepInfoView.setCurrentStep(currentStep)
                } else {
                    currentStep--
                }
                btn_step_last.visibility = View.GONE
                btn_step.visibility = View.VISIBLE
            }
            STEP_FOUR -> {
                tl_head.subtitle = "4 of 4"
                if (mProvidePaymentInfoView.checkInputData()) {
                    ll_contentview.removeAllViews()
                    btn_cancle.visibility = View.VISIBLE
                    btn_step.text = MemoryCache.getLabelText("s_confirm") ?: getString(R.string.s_confirm)
                    btn_step.tag = STEP_FOUR
                    mStepInfoView.setCurrentStep(currentStep)
                    updateStepButtonMargin(currentStep)
                    mConfirmationView.updateMainPageWidgetState()
                    ll_contentview.addView(mConfirmationView)
                    backFillStepInfo()
                } else {
                    currentStep--
                }
                btn_step_last.visibility = View.VISIBLE
                btn_step.visibility = View.GONE
            }
        }
        nsContainer.scrollTo(0, 0)
    }

    private fun updateStepButtonMargin(currentStep: Int) {
        val stepButtonlp = btn_step.layoutParams as RelativeLayout.LayoutParams
        val cancleButtonlp = btn_cancle.layoutParams as LinearLayout.LayoutParams
        val stepLastButtonlp = btn_step_last.layoutParams as RelativeLayout.LayoutParams
        val dimen16 = resources.getDimension(R.dimen.d_common_padding_margin_16).toInt()
        val dimen24 = resources.getDimension(R.dimen.d_common_padding_margin_16).toInt()
        when (currentStep) {
            STEP_ONE, STEP_TWO, STEP_THREE -> {
                stepButtonlp.setMargins(0, dimen24, 0, 0)
                btn_step.layoutParams = stepButtonlp
            }
            else -> {
                stepButtonlp.setMargins(dimen16, dimen24, dimen16, 0)
                btn_step.layoutParams = stepButtonlp
                stepLastButtonlp.setMargins(dimen16, dimen24, dimen16, 0)
                btn_step_last.layoutParams = stepLastButtonlp
                cancleButtonlp.setMargins(dimen16, dimen16, dimen16, dimen16)
                btn_cancle.layoutParams = cancleButtonlp
            }
        }
    }


    private fun backFillStepInfo() {
        //step1
        mConfirmationView.backFillStepInfo(STEP_ONE, getBeneficiaryInfoViewData(), paymentMethods)
        //step2(extra\paymentMethod)
        val invoiceTobePaidData = mInvoiceTobePaidView.getCurrentViewDataDisplay()
        mConfirmationView.backFillStepInfo(STEP_TWO, invoiceTobePaidData, paymentMethods)
        //step3(lines)
        val providePaymentInfoData = mProvidePaymentInfoView.getCurrentViewData()
        mConfirmationView.backFillStepInfo(STEP_THREE, providePaymentInfoData, paymentMethods)
    }

    private fun getBeneficiaryInfoViewData(): Map<String, Any> {
        val dataMap = mutableMapOf<String, Any>()
        dataMap["payeeAccountReference"] = invoice?.payee?.account?.reference ?: ""
        dataMap["payeeAccountDisplay"] = invoice?.payee?.account?.display ?: "-"
        dataMap["payeeAccountName"] = invoice?.payee?.name ?: "-"
        return dataMap
    }

    private fun confirmSubmission() {
        if (confirming) {
            return
        }

        confirming = true
        val dataMap = mutableMapOf<String, Any>()
        //step2(extra\paymentMethod)
        val invoiceTobePaidData = mInvoiceTobePaidView.getCurrentViewData()
        for (item in invoiceTobePaidData) {
            dataMap[item.key] = item.value
        }
        //step3(lines)
        val providePaymentInfoData = mProvidePaymentInfoView.getCurrentViewData()
        for (item in providePaymentInfoData) {
            dataMap[item.key] = item.value
        }
        val payeeAccount = Account(invoice?.payee?.account?.reference, invoice?.payee?.account?.currency,
                invoice?.payee?.account?.countryCode, invoice?.payee?.account?.referenceGroup,
                invoice?.payee?.account?.display)
        val payorAccount = Account(invoice?.payor?.account?.reference, invoice?.payor?.account?.currency,
                invoice?.payor?.account?.countryCode, invoice?.payor?.account?.referenceGroup,
                invoice?.payor?.account?.display)
        //payee
        dataMap["payeeAccount"] = payeeAccount
        dataMap["payeeReference"] = invoice?.payee?.reference ?: ""
        //payor
        dataMap["payorAccount"] = payorAccount
        dataMap["payorReference"] = invoice?.payor?.reference ?: ""
//        showLoadingDialogExt()
        mViewModel.requestValidateItp(dataMap)
    }

    override fun setPaymentMethods(paymentMethods: PaymentMethod?) {
        if (paymentMethods == null) {
            return
        }
        this.paymentMethods = paymentMethods
        mProvidePaymentInfoView.setPaymentMethods(paymentMethods)
    }

    override fun setBankCalendar(bankCalendarIn: List<BankCalendarDate>) {
        mProvidePaymentInfoView.setBankCalendar(bankCalendarIn)
    }

    override fun createSuccessful(plannedPaymentPayload: PlannedPaymentPayload?) {
//        hideLoadingDialogExt()
        btn_step_last.animationEndCallback = object: LoadingCompletedCallback {
            override fun onAnimationCompleted() {
                PlannedPaymentDetailActivity.showActivity(this@PlannedPaymentCreationActivity,
                        plannedPaymentPayload?.payload?.token.toString(), 0, true)
            }
        }

        btn_step_last.endLoadingAnimation(true)
//        PlannedPaymentDetailActivity.showActivity(this, plannedPaymentPayload?.payload?.token.toString(), 0, true)
    }

    override fun setCreditNotes(creditNotes: List<CreditNoteLocal>?) {
        hideLoadingDialogExt()
        mInvoiceTobePaidView.setInvoicesAndCreditNotes(this.invoices!!, creditNotes?.filter {
            try {
                (it.creditNote!!.amount.toLong() < 0) && (it.creditNote!!.outstanding.toLong() < 0)
            } catch (e: Exception) {
                false
            }
        })
    }

    fun setDeductions(deduction: MutableMap<String, List<TaxDeductionInfo>?>) {
        mInvoiceTobePaidView.setDeductions(deduction = deduction as MutableMap<String, ArrayList<TaxDeductionInfo>?>)
    }

    override fun showFailedToast(msg: String) {
        var title = ""
        var message = ""
        when {
            msg.contains("achMandateExpired") -> {
                title = MemoryCache.getLabelText("s_ach_invalid_payment_date") ?: getString(R.string.s_ach_invalid_payment_date)
                message = (MemoryCache.getLabelText("s_ach_mandate_tips") ?: getString(R.string.s_ach_mandate_tips))
                        .replace("ACH", MemoryCache.getLabelText("s_payment_method_label_" + "ach") ?: "")
            }
            msg.contains("achPaymentWithin48Hours") -> {
                title = MemoryCache.getLabelText("s_ach_invalid_payment_date") ?: getString(R.string.s_ach_invalid_payment_date)
                message = MemoryCache.getLabelText("s_ach_date_tips") ?: getString(R.string.s_ach_date_tips)
            }
            msg.contains("achMandateAmountTooLarge") -> {
                title = MemoryCache.getLabelText("s_ach_invalid_payment_Amout") ?: getString(R.string.s_ach_invalid_payment_Amout)
                message = (MemoryCache.getLabelText("s_ach_payment_Amout_tips")?.replace("INR", currency ?: MARKET_CURRENCY)
                        ?.replace("ACH", MemoryCache.getLabelText("s_payment_method_label_" + "ach") ?: "")
                        ?: getString(R.string.s_ach_payment_Amout_tips)).replace("ACH", MemoryCache.getLabelText("s_payment_method_label_" + "ach") ?: "")
                try {
                    val map = Gson().fromJson<MutableMap<String, String>>(msg, MutableMap::class.java)
                    if (map.isNotEmpty() && map.containsKey("achMandateAmount")) {
                        message += IndiaNumberUtil.formatNumByDecimal(map["achMandateAmount"].toString(), currency ?: MARKET_CURRENCY)
                        message = message.replace("INR", currency ?: MARKET_CURRENCY)
                    }
                } catch (e: IOException) {

                }
            }
        }
        if (title.isBlank()) {
            showShortToast(msg)
        } else {
            CommonDialog.showAlertDialog(this, title,
                    message,
                    MemoryCache.getLabelText("s_amend") ?: getString(R.string.s_amend), object : CommonDialogExtras.OnButtonListener {
                override fun positiveButtonListener() {
                    if (msg.contains("achMandateAmountTooLarge")) {
                        if (currentStep == STEP_ONE)
                            finish()
                        else {
                            currentStep--
                            currentStep--
                            handleStepViewAndData()
                        }
                    } else {
                        returnBack()
                    }

                }

                override fun negativeButtonListener() {

                }
            }, MemoryCache.getLabelText("s_cancel") ?: getString(R.string.s_cancel))
        }
    }

    override fun showProgressDialog(msg: String) {
        showLoadingDialogExt()
    }

    override fun dismissProgressDialog() {
        hideLoadingDialogExt()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CODE_SELECT_INVOICE, REQUEST_CODE_INVOICE_EDIT_DETAIL -> {
                    mInvoiceTobePaidView.onActivityResult(data)
                }
                REQUEST_CODE_GET_PAYMENT_METHOD -> {
                    mProvidePaymentInfoView.onActivityResult(requestCode, data)
                }
                REQUEST_CODE_CHOOSE_VA_BANK_LIST -> {
                    mProvidePaymentInfoView.onActivityResult(requestCode, data)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:invoices:create planned payment",
                "/dart/buyer-portal/invoices/create-planned-payment", "payment", "buyer portal",
                "invoices")
    }

    companion object {
        const val STEP_ONE = 0
        const val STEP_TWO = 1
        const val STEP_THREE = 2
        const val STEP_FOUR = 3
        const val INTENT_DATA_INVOICES = "invoices"
        fun showActivity(activity: Activity?, invoices: ArrayList<InvoiceListItem?>, requestCode: Int = 404) {
            val intent = Intent(activity, PlannedPaymentCreationActivity::class.java)
            intent.putExtra(INTENT_DATA_INVOICES, invoices)
            activity?.startActivityForResult(intent, requestCode)
        }
    }
}
