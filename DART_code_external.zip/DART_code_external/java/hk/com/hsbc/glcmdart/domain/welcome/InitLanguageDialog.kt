package hk.com.hsbc.glcmdart.domain.welcome

import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.GLOBAL_LANGUAGE
import hk.com.hsbc.glcmdart.client.TAG_SAVED_COUNTRY
import hk.com.hsbc.glcmdart.client.TAG_SAVED_LANGUAGE
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache

/**
 * when change country package, please change this dialog as well
 */
object InitLanguageDialog {

    fun showLanguageDialog(c: BaseActivity, callback: SelectLanguageCallback?) {
        val mDialog = Dialog(c, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(c).inflate(R.layout.dialog_language_selection, null)
        val tvINEnglish = mContentView.findViewById<TextView>(R.id.btn_in_english)
        val tvIDEnglish = mContentView.findViewById<TextView>(R.id.btn_id_english)
        val tvBahasa = mContentView.findViewById<TextView>(R.id.btn_bahasa)
        val tvAustralia = mContentView.findViewById<TextView>(R.id.btn_australia)
        val tvSingapore = mContentView.findViewById<TextView>(R.id.btn_singapore)
        val tvTitle = mContentView.findViewById<TextView>(R.id.tv_language_dialog_title)
        val tvCancel = mContentView.findViewById<Button>(R.id.btn_cancel)
        tvCancel.visibility = View.GONE
        tvTitle.visibility = View.VISIBLE

        val onClickListener = View.OnClickListener {
            mDialog.cancel()
            when (it.id) {
                R.id.btn_in_english -> {
                    mDialog.dismiss()
                    if (MemoryCache.changeLanguage("en-in", "IN")) {
                        callback?.onLanguageChange(c.getString(R.string.s_language_tip1))
                        val sharePre = c.getSharedPreferences(c.applicationInfo.packageName, Context.MODE_PRIVATE)
                        val editor = sharePre.edit()
                        editor.putString(TAG_SAVED_LANGUAGE, MemoryCache.defaultLanguageFull
                                ?: GLOBAL_LANGUAGE)
                        editor.putString(TAG_SAVED_COUNTRY, "IN")
                        editor.apply()
                        MemoryCache.defaultCountry = "IN"
                    } else {
                        MemoryCache.defaultCountry = "IN"
                        doRequest(c, "en-in", callback)
                    }
                }
                R.id.btn_id_english -> {
                    mDialog.dismiss()
                    if (MemoryCache.changeLanguage("en-id", "ID")) {
                        callback?.onLanguageChange(c.getString(R.string.s_language_tip2))
                        val sharePre = c.getSharedPreferences(c.applicationInfo.packageName, Context.MODE_PRIVATE)
                        val editor = sharePre.edit()
                        editor.putString(TAG_SAVED_LANGUAGE, MemoryCache.defaultLanguageFull
                                ?: GLOBAL_LANGUAGE)
                        editor.putString(TAG_SAVED_COUNTRY, "ID")
                        editor.apply()
                        MemoryCache.defaultCountry = "ID"
                    } else {
                        MemoryCache.defaultCountry = "ID"
                        doRequest(c, "en-id", callback)
                    }
                }
                R.id.btn_bahasa -> {
                    mDialog.dismiss()
                    if (MemoryCache.defaultLanguageFull != "id-id") {
                        if (MemoryCache.changeLanguage("id-id", "ID")) {
                            callback?.onLanguageChange(c.getString(R.string.s_language_tip3))
                            val sharePre = c.getSharedPreferences(c.applicationInfo.packageName, Context.MODE_PRIVATE)
                            val editor = sharePre.edit()
                            editor.putString(TAG_SAVED_LANGUAGE, MemoryCache.defaultLanguageFull
                                    ?: GLOBAL_LANGUAGE)
                            editor.putString(TAG_SAVED_COUNTRY, "ID")
                            editor.apply()
                            MemoryCache.defaultCountry = "ID"
                        } else {
                            MemoryCache.defaultCountry = "ID"
                            doRequest(c, "id-id", callback)
                        }
                    }
                }
                R.id.btn_australia -> {
                    mDialog.dismiss()
                    if (MemoryCache.defaultLanguageFull != "en-au") {
                        if (MemoryCache.changeLanguage("en-au", "AU")) {
                            callback?.onLanguageChange(c.getString(R.string.s_language_tip4))
                            val sharePre = c.getSharedPreferences(c.applicationInfo.packageName, Context.MODE_PRIVATE)
                            val editor = sharePre.edit()
                            editor.putString(TAG_SAVED_LANGUAGE, MemoryCache.defaultLanguageFull
                                    ?: GLOBAL_LANGUAGE)
                            editor.putString(TAG_SAVED_COUNTRY, "AU")
                            editor.apply()
                            MemoryCache.defaultCountry = "AU"
                        } else {
                            MemoryCache.defaultCountry = "AU"
                            doRequest(c, "en-au", callback)
                        }
                    }
                }
                R.id.btn_singapore -> {
                    mDialog.dismiss()
                    if (MemoryCache.defaultLanguageFull != "en-sg") {
                        if (MemoryCache.changeLanguage("en-sg", "SG")) {
                            callback?.onLanguageChange(c.getString(R.string.s_language_tip4))
                            val sharePre = c.getSharedPreferences(c.applicationInfo.packageName, Context.MODE_PRIVATE)
                            val editor = sharePre.edit()
                            editor.putString(TAG_SAVED_LANGUAGE, MemoryCache.defaultLanguageFull
                                    ?: GLOBAL_LANGUAGE)
                            editor.putString(TAG_SAVED_COUNTRY, "SG")
                            editor.apply()
                            MemoryCache.defaultCountry = "SG"
                        } else {
                            MemoryCache.defaultCountry = "SG"
                            doRequest(c, "en-sg", callback)
                        }
                    }
                }
            }
        }

        tvIDEnglish.setOnClickListener(onClickListener)
        tvINEnglish.setOnClickListener(onClickListener)
        tvBahasa.setOnClickListener(onClickListener)
        tvAustralia.setOnClickListener(onClickListener)
        tvSingapore.setOnClickListener(onClickListener)

        mDialog.setContentView(mContentView)
        mDialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        mDialog.window?.setDimAmount(0.1f)
        mDialog.setCanceledOnTouchOutside(false)
        mDialog.setCancelable(false)
        mDialog.window?.setWindowAnimations(R.style.Animation_Bottom)
        mDialog.show()
    }

    private fun doRequest(activity: BaseActivity, languageFull: String, callback: SelectLanguageCallback?) {
        when (languageFull) {
            "en-in" -> {
                val sharePre = activity.getSharedPreferences(activity.applicationInfo.packageName, Context.MODE_PRIVATE)
                val editor = sharePre.edit()
                editor.putString(TAG_SAVED_LANGUAGE, languageFull)
                editor.putString(TAG_SAVED_COUNTRY, "IN")
                editor.apply()
            }
            "en-id" -> {
                val sharePre = activity.getSharedPreferences(activity.applicationInfo.packageName, Context.MODE_PRIVATE)
                val editor = sharePre.edit()
                editor.putString(TAG_SAVED_LANGUAGE, languageFull)
                editor.putString(TAG_SAVED_COUNTRY, "ID")
                editor.apply()
            }
            "id-id" -> {
                val sharePre = activity.getSharedPreferences(activity.applicationInfo.packageName, Context.MODE_PRIVATE)
                val editor = sharePre.edit()
                editor.putString(TAG_SAVED_LANGUAGE, languageFull)
                editor.putString(TAG_SAVED_COUNTRY, "ID")
                editor.apply()
            }
            "en-au" -> {
                val sharePre = activity.getSharedPreferences(activity.applicationInfo.packageName, Context.MODE_PRIVATE)
                val editor = sharePre.edit()
                editor.putString(TAG_SAVED_LANGUAGE, languageFull)
                editor.putString(TAG_SAVED_COUNTRY, "AU")
                editor.apply()
            }
            "en-sg" -> {
                val sharePre = activity.getSharedPreferences(activity.applicationInfo.packageName, Context.MODE_PRIVATE)
                val editor = sharePre.edit()
                editor.putString(TAG_SAVED_LANGUAGE, languageFull)
                editor.putString(TAG_SAVED_COUNTRY, "SG")
                editor.apply()
            }
            else -> {
                val sharePre = activity.getSharedPreferences(activity.applicationInfo.packageName, Context.MODE_PRIVATE)
                val editor = sharePre.edit()
                editor.putString(TAG_SAVED_LANGUAGE, "en-id")
                editor.putString(TAG_SAVED_COUNTRY, "IN")
                editor.apply()
            }
        }
        activity.showLoadingDialog()

        val mViewModel = ViewModelProviders.of(activity).get(ConfigViewModel::class.java)
        mViewModel.languageLiveData.observe(activity, Observer{
            activity.hideLoadingDialog()
            if (it < 0) {
                return@Observer
            }
            MemoryCache.defaultLanguageFull = languageFull
            val sharePre = activity.getSharedPreferences(activity.applicationInfo.packageName, Context.MODE_PRIVATE)
            val editor = sharePre.edit()
            editor.putString(TAG_SAVED_LANGUAGE, MemoryCache.defaultLanguageFull ?: GLOBAL_LANGUAGE)
            editor.putString(TAG_SAVED_COUNTRY, MemoryCache.defaultCountry)
            editor.apply()
            activity.hideLoadingDialog()
            callback?.onLanguageChange(when(languageFull) {
                "en-in" -> activity.getString(R.string.s_language_tip1)
                "en-id" -> activity.getString(R.string.s_language_tip2)
                "id-id" -> activity.getString(R.string.s_language_tip3)
                "en-au" -> activity.getString(R.string.s_language_tip4)
                "en-sg" -> activity.getString(R.string.s_language_tip5)
                else -> activity.getString(R.string.s_language_tip1)
            })
        })
        mViewModel.getLanguageStringsFile(languageFull)
    }
}

interface SelectLanguageCallback {
    fun onLanguageChange(language: String)
}