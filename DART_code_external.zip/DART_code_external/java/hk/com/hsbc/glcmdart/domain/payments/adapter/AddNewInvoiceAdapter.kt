/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.app.Activity
import android.content.Context
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.CreditNoteLocal
import hk.com.hsbc.glcmdart.domain.payments.adapter.PlannedPaymentInvoiceAdapter.Companion.ITEM_INVOICE_DETAIL
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import java.math.BigDecimal
import java.util.*
import java.util.regex.Pattern
import kotlin.math.abs

const val TYPE_INPUT_AMOUNT = "amount"
const val TYPE_INPUT_COMMENT = "comment"

class AddNewInvoiceAdapter
(private val context: Context, private val mData: ArrayList<InvoiceAddEntity>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val inflater: LayoutInflater = LayoutInflater.from(context)
    val inputMap = mutableMapOf<String, MutableMap<String, String>>()
    private val creditNoteSizeMap = mutableMapOf<String, Int>()
    var type: Int? = -1
    var addButton: Button? = null
    private var saveButton: Button? = null
    private var currency: String? = null
    var needUpdateCreditNoteAmount = false
    var isCreditNoteMethod = false
    var runningBalanceReduce = 0.00
    private var finalBalanceAmountMap = mutableMapOf<String, Double>()
    private var usingRunningBalanceMap = mutableMapOf<String, Boolean>()

    fun addData(dataList: ArrayList<InvoiceAddEntity>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        needUpdateCreditNoteAmount = true
        notifyDataSetChanged()
    }

    fun setType(type: Int) {
        this.type = type
    }

    fun setCurrency(currency: String?) {
        this.currency = currency
    }

    fun setButton(addButton: Button?) {
        this.addButton = addButton
    }

    fun setSaveButton(save: Button?) {
        this.saveButton = save
    }

    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_add_invoice, parent, false)
        return ItemHolder(view, InputTextWatcher(view), FocuseChangeListener())
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        MemoryCache.getLabelText("s_delete")?.let {
            if (!it.isBlank()) {
                vh.ivDelete.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_amount_to_pay")?.let {
            if (!it.isBlank()) {
                vh.tvAmountToPayTag.text = it
            }
        }
        MemoryCache.getLabelText("s_credit_note")?.let {
            if (!it.isBlank()) {
                vh.tvCreditNoteTitle.text = it
            }
        }
        MemoryCache.getLabelText("s_your_note_to_supplier")?.let {
            if (!it.isBlank()) {
                vh.etTitle.text = it
            }
        }
        MemoryCache.getLabelText("s_enter_here")?.let {
            if (!it.isBlank()) {
                vh.etNote.hint = it
            }
        }
        MemoryCache.getLabelText("s_use_running_balance")?.let {
            if (!it.isBlank()) {
                vh.tvUseRunningBalanceTag.text = it
            }
        }
        MemoryCache.getLabelText("s_enter_amount_to_pay")?.let {
            if (!it.isBlank()) {
                vh.tvEnterAmountTag.text = it
            }
        }
        vh.tvTaxDeductionTitle.text = MemoryCache.getLabelText("s_deduction") ?: context.getString(R.string.s_deduction)
        val reference = mData[position].invoice?.reference
        if (mData[position].creditNotesSelected != null) creditNoteSizeMap[reference!!] = mData[position].creditNotesSelected?.size
                ?: 0
        else creditNoteSizeMap[reference!!] = 0
        val amountMap = mutableMapOf<String, String>()
        var creditNoteAmount = 0L
        var invoiceAmountInput = 0.toBigDecimal()
        val invoiceOutstanding = BigDecimal.valueOf(mData[position].invoice?.summation?.outstanding?.amount?.toLong()
                ?: 0L) / BigDecimal.valueOf(100.0)

//        if (MemoryCache.defaultCountry == "IN") {
//            vh.rbEditAmount.visibility = View.VISIBLE
//            vh.rbUseRunningBalance.visibility = View.VISIBLE
//            vh.tvAmount.visibility = View.VISIBLE
//            vh.tvUseRunningBalanceTag.visibility = View.VISIBLE
//            vh.tvEnterAmountTag.visibility = View.VISIBLE
//        } else {
//            vh.rbEditAmount.visibility = View.GONE
//            vh.rbUseRunningBalance.visibility = View.GONE
//            vh.tvAmount.visibility = View.GONE
//            vh.tvUseRunningBalanceTag.visibility = View.GONE
//            vh.tvEnterAmountTag.visibility = View.GONE
//        }

        if (!mData[position].amount.isNullOrEmpty()) {
//            val originalAmount = (MemoryCache.globalDecimal.format((mData[position].amount?.toDouble()
//                    ?: 0.00)).toString())
            if (mData[position].useRunningBalance) {
                val originalAmount = (MemoryCache.globalDecimal.format((mData[position].invoice?.summation?.outstanding?.amount?.toBigDecimal()
                        ?: 0.00)).toString())
                amountMap[TYPE_INPUT_AMOUNT] = originalAmount
            } else {
                amountMap[TYPE_INPUT_AMOUNT] = mData[position].amount!!
            }
        } else {
            val originalAmount = (MemoryCache.globalDecimal.format((mData[position].invoice?.summation?.outstanding?.amount?.toBigDecimal()
                    ?: 0.00)).toString())
            amountMap[TYPE_INPUT_AMOUNT] = originalAmount
        }
        amountMap[TYPE_INPUT_COMMENT] = mData[position].comment ?: ""
        inputMap[reference] = amountMap
        vh.tvInvoiceNumber.text = reference
        val outstandingTmpText = if (MemoryCache.getLabelText("s_outstanding_amount").isNullOrBlank()) {
            context.getString(R.string.s_outstanding_amount)
        } else {
            MemoryCache.getLabelText("s_outstanding_amount")
        } + " $currency " + IndiaNumberUtil.formatNumByDecimal(mData[position].invoice?.summation?.outstanding?.amount
                ?: "0.00", currency ?: MARKET_CURRENCY)
        vh.tvInvoiceOutstanding.text = outstandingTmpText
        vh.ivDelete.setOnClickListener { v ->
            itemDeleteClickListener?.onItemDeleteClick(v, position)
        }
        vh.etAmount.hint = "$currency ${if (currency == "IDR") "0,00" else "0.00"}"
        vh.etAmount.tag = reference
        vh.rbEditAmount.setOnCheckedChangeListener { _, isCheck ->
            if (isCheck) {
                vh.etAmount.isEnabled = true
                vh.etAmount.setTextColor(ContextCompat.getColor(context, R.color.primary_gray))
                vh.tvEnterAmountTag.setTextColor(ContextCompat.getColor(context, R.color.primary_gray))
                vh.rbUseRunningBalance.isChecked = false
                vh.tvUseRunningBalanceTag.setTextColor(ContextCompat.getColor(context, R.color.secondary_gray))
                vh.tvAmount.setTextColor(ContextCompat.getColor(context, R.color.secondary_gray))
                val amount = vh.etAmount.text.toString().
                replace(",", "").
                replace(".", "").
                replace(currency ?: MARKET_CURRENCY, "").
                trim()
                mData[position].amount = amount
                vh.tvDeductionAmountValidate.visibility = View.GONE
                if ((BigDecimal.valueOf(creditNoteAmount) + invoiceAmountInput) > invoiceOutstanding) {
                    mData[position].overPaid = true
                    vh.tvAmountValidate.visibility = View.VISIBLE
                    val tmpText = IndiaNumberUtil.formatNum((invoiceOutstanding - BigDecimal.valueOf(creditNoteAmount)).toString().replace("-", ""), currency
                            ?: MARKET_CURRENCY)
                    val amountValidateTmpText = "${if (MemoryCache.getLabelText("s_amount_greater_tips1").isNullOrBlank()) {
                        context.getString(R.string.s_amount_greater_tips1).replace("INR", currency ?: MARKET_CURRENCY)
                    } else {
                        MemoryCache.getLabelText("s_amount_greater_tips1")!!.replace("INR", currency ?: MARKET_CURRENCY)
                    }} $tmpText"
                    vh.tvAmountValidate.text = amountValidateTmpText
                } else {
                    mData[position].overPaid = false
                    vh.tvAmountValidate.visibility = View.GONE
                }
                mData[position].useRunningBalance = false
                usingRunningBalanceMap[mData[position].token!!] = mData[position].useRunningBalance
            } else {
                vh.etAmount.isEnabled = false
                vh.etAmount.setTextColor(ContextCompat.getColor(context, R.color.secondary_gray))
                vh.rbUseRunningBalance.isChecked = true
                vh.tvAmount.setTextColor(ContextCompat.getColor(context, R.color.primary_gray))
                mData[position].useRunningBalance = true
                usingRunningBalanceMap[mData[position].token!!] = mData[position].useRunningBalance
            }
            var hasNegativeAmount = false
            for (item in finalBalanceAmountMap) {
                if (item.value < 0 && usingRunningBalanceMap[item.key] == true) {
                    hasNegativeAmount = true
                    break
                }
            }
            if (hasNegativeAmount) {
                addButton?.isEnabled = false
                saveButton?.isEnabled = false
            } else {
                addButton?.isEnabled = true
                saveButton?.isEnabled = true
            }
        }

        vh.rbUseRunningBalance.setOnCheckedChangeListener { _, isCheck ->
            if (isCheck) {
                vh.etAmount.isEnabled = false
                vh.etAmount.setTextColor(ContextCompat.getColor(context, R.color.secondary_gray))
                vh.tvEnterAmountTag.setTextColor(ContextCompat.getColor(context, R.color.secondary_gray))
                vh.rbEditAmount.isChecked = false
                vh.tvAmount.setTextColor(ContextCompat.getColor(context, R.color.primary_gray))
                vh.tvUseRunningBalanceTag.setTextColor(ContextCompat.getColor(context, R.color.primary_gray))
                val amount = vh.tvAmount.text.toString().
                replace(",", "").
                replace(".", "").
                replace(currency ?: MARKET_CURRENCY, "").
                trim()
                mData[position].amount = amount
                mData[position].overPaid = false
                mData[position].useRunningBalance = true
                usingRunningBalanceMap[mData[position].token!!] = mData[position].useRunningBalance
                vh.tvAmountValidate.visibility = View.GONE
            } else {
                vh.etAmount.isEnabled = true
                vh.etAmount.setTextColor(ContextCompat.getColor(context, R.color.primary_gray))
                vh.rbEditAmount.isChecked = true
                vh.tvAmount.setTextColor(ContextCompat.getColor(context, R.color.secondary_gray))
                mData[position].useRunningBalance = false
                usingRunningBalanceMap[mData[position].token!!] = mData[position].useRunningBalance
            }
            var hasNegativeAmount = false
            for (item in finalBalanceAmountMap) {
                if (item.value < 0 && usingRunningBalanceMap[item.key] == true) {
                    hasNegativeAmount = true
                    break
                }
            }
            if (hasNegativeAmount) {
                addButton?.isEnabled = false
                saveButton?.isEnabled = false
            } else {
                addButton?.isEnabled = true
                saveButton?.isEnabled = true
            }
        }

//        if (MemoryCache.defaultCountry == "IN") {
        vh.rbUseRunningBalance.isChecked = mData[position].useRunningBalance
        vh.rbEditAmount.isChecked = !mData[position].useRunningBalance
        usingRunningBalanceMap[mData[position].token!!] = mData[position].useRunningBalance
//        } else {
//            vh.rbEditAmount.isChecked = true
//        }
        vh.inputTextWatcher.reference = reference
        vh.inputTextWatcher.mInvoiceAddEntity = mData[position]
        vh.inputTextWatcher.tvAmountValidate = vh.tvAmountValidate
        vh.inputTextWatcher.position = position
        vh.inputTextWatcher.currency = currency
        vh.inputTextWatcher.etAmount = vh.etAmount
        setEditTextInput(reference, vh.etAmount)
        setEditTextInput(reference, vh.etNote)
        var runningBalanceReduce = 0.0
        if (!mData[position].taxDeductionSelected.isNullOrEmpty()) {
            vh.rbEditAmount.isEnabled = false
            vh.rbUseRunningBalance.isChecked = true
            vh.tvDeductionPrompt.visibility = View.VISIBLE
            vh.tvDeductionPrompt.text = MemoryCache.getLabelText("s_deduction_chosen_prompt") ?:
                    context.getString(R.string.s_deduction_chosen_prompt)
            var reduceAmount = 0.toBigDecimal()
            for (item in mData[position].taxDeductionSelected!!) {
                reduceAmount += if (item.maxRate == null) {
                    item.maxAmount!!.toBigDecimal()
                } else {
                    mData[position].invoice?.summation?.total?.amount!!.toBigDecimal() * item.maxRate!!.toBigDecimal() / 100.toBigDecimal()
                }
            }
            runningBalanceReduce -= reduceAmount.setScale(2 , BigDecimal.ROUND_HALF_UP).toDouble()
            mData[position].amount = ((mData[position].invoice?.summation?.outstanding?.amount?.toBigDecimal() ?: 0.toBigDecimal()) +
                    runningBalanceReduce.toBigDecimal()).setScale(2 , BigDecimal.ROUND_HALF_UP).toDouble().toString()
        } else {
            vh.rbEditAmount.isEnabled = true
            vh.tvDeductionPrompt.visibility = View.GONE
            vh.rbUseRunningBalance.isChecked = vh.rbUseRunningBalance.isChecked
        }

        var textColor = 0
        textColor = if (mData[position].taxDeductionSelected.isNullOrEmpty())
            ContextCompat.getColor(context, R.color.primary_gray)
        else
            ContextCompat.getColor(context, R.color.secondary_gray)
        vh.tvEnterAmountTag.setTextColor(textColor)
        if (!mData[position].creditNotes.isNullOrEmpty()) {
            val creditNoteTmpText = " (${mData[position].creditNotes?.size} ${if (MemoryCache.getLabelText("s_available").isNullOrBlank()) {
                context.getString(R.string.s_available)
            } else {
                MemoryCache.getLabelText("s_available")
            }})"
            vh.llCreditNote.visibility = View.VISIBLE
            vh.tvCreditNoteNum.text = creditNoteTmpText
            vh.llCreditNote.setAccessibilityDelegate(object : View.AccessibilityDelegate() {

                override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info?.className = Button::class.java.name
                }
            })
            vh.llCreditNote.setOnClickListener { v ->
                itemClickListener?.onItemClick(v, position)
            }
        } else {
            vh.llCreditNote.visibility = View.GONE
        }

        if (!mData[position].taxDeductions.isNullOrEmpty()) {
            val taxDeductionTmpText = " (${mData[position].taxDeductions?.size} ${if (MemoryCache.getLabelText("s_available").isNullOrBlank()) {
                context.getString(R.string.s_available)
            } else {
                MemoryCache.getLabelText("s_available")
            }})"
            vh.llTaxDeduction.visibility = View.VISIBLE
            vh.tvTaxDeductionNum.text = taxDeductionTmpText
            vh.llTaxDeduction.setAccessibilityDelegate(object : View.AccessibilityDelegate() {

                override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info?.className = Button::class.java.name
                }
            })
            vh.llTaxDeduction.setOnClickListener { v ->
                itemClickListener?.onItemClick(v, position)
            }
        } else {
            vh.llTaxDeduction.visibility = View.GONE
        }

        if (vh.etAmount.text.isNotEmpty()) {
            invoiceAmountInput = if (currency == "IDR") {
                if (isCreditNoteMethod) {
                    0.toBigDecimal()
                } else {
                    val tmpText = vh.etAmount.text.toString()
                    if (tmpText.contains(",")) {
                        (vh.etAmount.text.toString().replace("$currency", "").
                        replace(".", "").replace(",", ".").trim().toBigDecimal())
                    } else {
                        (vh.etAmount.text.toString().replace("$currency", "").replace(".", "").trim()).toBigDecimal()
                    }
                }
            } else {
                if (isCreditNoteMethod) {
                    0.toBigDecimal()
                } else {
                    (vh.etAmount.text.toString().replace("$currency", "").
                    replace(",", "").trim().toDouble()).toBigDecimal()
                }
            }
        } else {
            invoiceAmountInput = 0.toBigDecimal()
        }
        if (mData[position].creditNotesSelected != null) {
            vh.rvCreditNote.adapter = CreditNoteAdapter(context, mData[position].creditNotesSelected as ArrayList<CreditNoteLocal>, currency
                    ?: MARKET_CURRENCY)
            (vh.rvCreditNote.adapter as CreditNoteAdapter).needUpdateAmount = needUpdateCreditNoteAmount
            mData[position].creditNotesSelected?.forEach {
                creditNoteAmount += (abs(it.outstanding?.toLong() ?: 0L))
            }
            mData[position].amount = ((mData[position].invoice?.summation?.outstanding?.amount?.toLong() ?: 0L).toBigDecimal() +
                    runningBalanceReduce.toBigDecimal() - BigDecimal.valueOf(creditNoteAmount)).setScale(2 , BigDecimal.ROUND_HALF_UP).toDouble().toString()
            runningBalanceReduce -= (creditNoteAmount.toBigDecimal()).setScale(2 , BigDecimal.ROUND_HALF_UP).toDouble()
        } else {
            vh.rvCreditNote.adapter = null
        }

        if (!mData[position].taxDeductionSelected.isNullOrEmpty()) {
            vh.rvDeduction.adapter = TaxDeductionAdapter(context, mData[position].taxDeductionSelected as ArrayList<TaxDeductionInfo>, currency
                    ?: MARKET_CURRENCY, position)
        } else {
            vh.rvDeduction.adapter = null
        }

        val tmp1 = BigDecimal.valueOf(mData[position].invoice?.summation?.outstanding?.amount?.toDouble() ?: 0.00)
        val tmp2 = BigDecimal.valueOf(runningBalanceReduce.toDouble())
        val tmp3 = BigDecimal.valueOf(100.00)
        val finalRunningBalanceTmp = ((tmp1 + tmp2).divide(tmp3)).setScale(2, BigDecimal.ROUND_HALF_UP).toDouble()
        val finalRunningBalance = finalRunningBalanceTmp
//        val runningAmountText = if (runningBalanceReduce == 0.00 && creditNoteAmount == 0.00) {
//            vh.etAmount.text.toString()
//        } else {
//            "$currency ${IndiaNumberUtil.formatNum(finalRunningBalance.toString(), currency ?: MARKET_CURRENCY)}"
//        }
//        vh.tvAmount.text = runningAmountText
        vh.tvAmount.text = "$currency ${IndiaNumberUtil.formatNumByDecimal((finalRunningBalance.toBigDecimal() * 100.toBigDecimal()).toString(), currency ?: MARKET_CURRENCY)}"

        if (vh.rbEditAmount.isChecked) {
            if ((BigDecimal.valueOf(creditNoteAmount) + invoiceAmountInput) > invoiceOutstanding) {
                if (vh.rbEditAmount.isChecked) {
                    mData[position].overPaid = true
                } else {
                    mData[position].overPaid = false
                }
                if (vh.rbEditAmount.isChecked) {
                    vh.tvAmountValidate.visibility = View.VISIBLE
                    val tmpText = IndiaNumberUtil.formatNum((invoiceOutstanding - BigDecimal.valueOf(creditNoteAmount)).toString().replace("-", ""), currency
                            ?: MARKET_CURRENCY)
                    val amountValidateTmpText = "${
                        if (MemoryCache.getLabelText("s_amount_greater_tips1").isNullOrBlank()) {
                            context.getString(R.string.s_amount_greater_tips1).replace("INR", currency ?: MARKET_CURRENCY)
                        } else {
                            MemoryCache.getLabelText("s_amount_greater_tips1")!!.replace("INR", currency ?: MARKET_CURRENCY)
                        }
                    } $tmpText"
                    vh.tvAmountValidate.text = amountValidateTmpText
                } else {
                    vh.tvAmountValidate.visibility = View.GONE
                }
            } else {
                mData[position].overPaid = false
                vh.tvAmountValidate.visibility = View.GONE
            }
        } else {
            mData[position].overPaid = false
            vh.tvAmountValidate.visibility = View.GONE
        }
//        if (isCreditNoteMethod) {
//            vh.llAmountAllocation.visibility = View.GONE
//            vh.etAmount.text
//        } else {
//            vh.llAmountAllocation.visibility = View.VISIBLE
//        }
        finalBalanceAmountMap[mData[position].token!!] = finalRunningBalance.toDouble()
        var hasNegativeAmount = false
        for (item in finalBalanceAmountMap) {
            if (item.value < 0) {
                hasNegativeAmount = true
                break
            }
        }
        if (hasNegativeAmount) {
            addButton?.isEnabled = false
            saveButton?.isEnabled = false
        } else {
            addButton?.isEnabled = true
            saveButton?.isEnabled = true
        }

        if (finalRunningBalance < 0) {
            vh.tvDeductionAmountValidate.visibility = View.VISIBLE
            vh.tvDeductionAmountValidate.text = MemoryCache.getLabelText("s_deduction_over_prompt") ?:
                    context.getString(R.string.s_deduction_over_prompt)
        } else {
            vh.tvDeductionAmountValidate.visibility = View.GONE
        }

        if (vh.rbEditAmount.isChecked) {
            mData[position].amount = vh.etAmount.text.toString()
                    .replace(currency ?: MARKET_CURRENCY, "")
                    .replace(",", "")
                    .replace(".", "")
                    .trim()
        } else {
            mData[position].amount = vh.tvAmount.text.toString()
                    .replace(currency ?: MARKET_CURRENCY, "")
                    .replace(",", "")
                    .replace(".", "")
                    .trim()
        }
    }

    override fun getItemViewType(position: Int): Int {
        return ITEM_INVOICE_DETAIL
    }

    inner class ItemHolder(view: View, internal var inputTextWatcher: InputTextWatcher, private var focuseChangeListener: FocuseChangeListener) : RecyclerView.ViewHolder(view) {
        val ivDelete: ImageView = view.findViewById(R.id.iv_delete)
        val tvInvoiceNumber: TextView = view.findViewById(R.id.tv_invoice_number)
        val etAmount: EditText = view.findViewById(R.id.et_amount)
        val tvAmount: TextView = view.findViewById(R.id.tv_amount)
        val rbEditAmount: RadioButton = view.findViewById(R.id.rb_enter_amount)
        val rbUseRunningBalance: RadioButton = view.findViewById(R.id.rb_use_running_balance)
        val llAmountAllocation: LinearLayout = view.findViewById(R.id.ll_amount_allocation)
        val etNote: EditText = view.findViewById(R.id.et_note)
        val llCreditNote: LinearLayout = view.findViewById(R.id.ll_credit_note)
        val tvCreditNoteNum: TextView = view.findViewById(R.id.tv_credit_note_num)
        val rvCreditNote: RecyclerView = view.findViewById(R.id.rv_invoice_add_or_edit)
        val llTaxDeduction: LinearLayout = view.findViewById(R.id.ll_tax_deduction)
        val tvTaxDeductionNum: TextView = view.findViewById(R.id.tv_tax_deduction_num)
        val rvDeduction: RecyclerView = view.findViewById(R.id.rv_deduction)
        val tvAmountValidate: TextView = view.findViewById(R.id.tv_amount_validate)
        val tvInvoiceOutstanding: TextView = view.findViewById(R.id.tv_invoice_outstanding)
        val tvAmountToPayTag: TextView = view.findViewById(R.id.tv_amount_to_pay_tag)
        val tvCreditNoteTitle: TextView = view.findViewById(R.id.tv_credit_note_title)
        val tvTaxDeductionTitle: TextView = view.findViewById(R.id.tv_tax_deduction_title)
        val etTitle: TextView = view.findViewById(R.id.et_title)
        val tvDeductionAmountValidate: TextView = view.findViewById(R.id.tv_deduction_amount_validate)
        val tvDeductionPrompt: TextView = view.findViewById(R.id.tv_deduction_prompt)
        val tvEnterAmountTag: TextView = view.findViewById(R.id.tv_enter_amount_tag)
        val tvUseRunningBalanceTag: TextView = view.findViewById(R.id.tv_running_balance_tag)

        init {
            if (type == 1) {
                ivDelete.visibility = View.GONE
            } else {
                ivDelete.visibility = View.VISIBLE
            }
            etAmount.addTextChangedListener(inputTextWatcher)
            etAmount.onFocusChangeListener = this.focuseChangeListener
            etNote.addTextChangedListener(inputTextWatcher)
            rvCreditNote.layoutManager = LinearLayoutManager(context)
            rvDeduction.layoutManager = LinearLayoutManager(context)
            etAmount.isCursorVisible = false
        }
    }

    private var itemDeleteClickListener: RecyclerExtras.OnItemDeleteClickListener? = null

    fun setOnItemDeleteClickListener(listener: RecyclerExtras.OnItemDeleteClickListener) {
        this.itemDeleteClickListener = listener
    }

    private fun setEditTextInput(reference: String, et: EditText?) {
        if (TextUtils.isEmpty(reference))
            return
        when (et?.id) {
            R.id.et_amount -> {
                if (inputMap.containsKey(reference)) {
                    val infoMap = inputMap[reference] as MutableMap<String, String>
                    if (infoMap.containsKey(TYPE_INPUT_AMOUNT)) {
                        if (!TextUtils.isEmpty(infoMap[TYPE_INPUT_AMOUNT])) {
                            val decimalNumber = MemoryCache.globalDecimal.format((infoMap[TYPE_INPUT_AMOUNT]?.toDouble()
                                    ?: 0.00))
                            val indiaAmount = IndiaNumberUtil.formatNumByDecimal(decimalNumber, currency
                                    ?: "")
                            et.setText("$currency $indiaAmount")
                        } else {
                            et.setText("")
                        }
                    } else {
                        et.setText("")
                    }
                } else {
                    et.setText("")
                }
                et.isCursorVisible = false
            }
            R.id.et_note -> {
                if (inputMap.containsKey(reference)) {
                    val infoMap = inputMap[reference] as MutableMap<String, String>
                    if (infoMap.containsKey(TYPE_INPUT_COMMENT)) {
                        et.setText(infoMap[TYPE_INPUT_COMMENT])
                    } else {
                        et.setText("")
                    }
                } else {
                    et.setText("")
                }
            }
        }
    }

    inner class InputTextWatcher constructor(val view: View) : TextWatcher {

        var reference: String = ""
        var mInvoiceAddEntity: InvoiceAddEntity? = null
        var tvAmountValidate: TextView? = null
        var position: Int = -1
        var currency: String? = null
        var etAmount: EditText? = null
        private val editText = view.findViewById<EditText>(R.id.et_note)

        override fun afterTextChanged(s: Editable) {
            val input = s.toString()
            if (editText.hasFocus()) {
                if (inputMap.containsKey(reference)) {
                    val infoMap = inputMap[reference] as MutableMap<String, String>
                    infoMap[TYPE_INPUT_COMMENT] = input
                } else {
                    val infoMap = mutableMapOf<String, String>()
                    infoMap[TYPE_INPUT_COMMENT] = input
                    inputMap[reference] = infoMap
                }
                mInvoiceAddEntity?.comment = input

                val titleText = view.findViewById<TextView>(R.id.et_title)
                val announceText = MemoryCache.getLabelText("s_my_own_reference_announce")
                        ?: context.getString(R.string.s_my_own_reference_announce)
                val size = 64 - editText.text.length
                titleText.announceForAccessibility(size.toString() + announceText)
                return
            }

            if (etAmount?.hasFocus() == true) {
                inputMap[etAmount?.tag.toString()]?.put("origin", input)
                val decimalSymbol = if (currency == "IDR") {
                    ","
                } else {
                    "."
                }

                val banDecimalSymbol = if (currency == "IDR") {
                    "."
                } else {
                    ","
                }

                if (s.toString().contains(banDecimalSymbol)) {
                    etAmount?.setText(s.toString().replace(banDecimalSymbol, ""))
                    etAmount?.setSelection(etAmount?.text.toString().length)
                    //在textchangewatcher中settext会调用第二次watcher，用return来结束第一次的调用，因为第一次会保留原字符
                    return
                }

                if (s.toString().contains(decimalSymbol)) {
                    if (etAmount?.text.toString().indexOf(decimalSymbol) >= 0) {
                        if (etAmount?.text.toString().indexOf(decimalSymbol, etAmount?.text.toString().indexOf(decimalSymbol) + 1) > 0) {
                            etAmount?.setText(etAmount?.text.toString().substring(0, etAmount?.text.toString().length - 1))
                            etAmount?.setSelection(etAmount?.text.toString().length)
                        }
                    }
                }

                //这部分是处理如果用户输入以.开头，在前面加上0
                if (s.toString().trim().substring(0) == decimalSymbol) {
                    etAmount?.setText("0$s")
                    etAmount?.setSelection(2)
                    //在textchangewatcher中settext会调用第二次watcher，用return来结束第一次的调用，因为第一次会保留原字符
                    return
                }
                //这里处理用户 多次输入.的处理 比如输入 1..6的形式，是不可以的
                if (s.toString().startsWith("0")
                        && s.toString().trim().length > 1) {
                    if (s.toString().substring(1, 2) != decimalSymbol) {
                        etAmount?.setText(s.subSequence(0, 1))
                        etAmount?.setSelection(1)
                        return
                    }
                }
                if (((context as Activity).currentFocus != null) && !TextUtils.isEmpty(reference) && mInvoiceAddEntity != null) {
                    when (context.currentFocus?.id) {
                        R.id.et_amount -> {
                            var inputAmount = ""
                            if (input.isNotEmpty()) {
                                inputAmount = if (input.endsWith(decimalSymbol)) {
                                    (input + "00").replace("$currency", "")
                                } else {
                                    input.replace("$currency", "")
                                }
                                inputAmount = inputAmount.replace(decimalSymbol, ".")
                                inputAmount = inputAmount.replace(banDecimalSymbol, ".")
                            }
                            if (inputAmount.contains(".")) {
                                val pattern = Pattern.compile("(.)\\1+")
                                val matcher = pattern.matcher(inputAmount)
                                val sb = StringBuffer()
                                while (matcher.find()) {
                                    val single = matcher.group(1)
                                    if (single == ".") {
                                        matcher.appendReplacement(sb, single)
                                    }
                                }
                                matcher.appendTail(sb)
                                inputAmount = sb.toString()
                            }
                            if (inputAmount.contains(".")) {
                                val subStr = inputAmount.split(".")
                                val sb = StringBuilder()
                                if (subStr.size > 2) {
                                    for (i in 0 until subStr.size - 1) {
                                        sb.append(subStr[i])
                                    }
                                    inputAmount = sb.toString() + "." + subStr[subStr.size - 1]
                                }
                            }
                            if (inputMap.containsKey(reference)) {
                                val infoMap = inputMap[reference] as MutableMap<String, String>
                                infoMap[TYPE_INPUT_AMOUNT] = inputAmount
                            } else {
                                val infoMap = mutableMapOf<String, String>()
                                infoMap[TYPE_INPUT_AMOUNT] = inputAmount
                                inputMap[reference] = infoMap
                            }
                            if (inputAmount.isEmpty()) {
                                mInvoiceAddEntity?.amount = inputAmount
                            } else {
                                val tmpSubStr = inputAmount.split(".")
                                val tmpAmount = if (tmpSubStr.size == 2) {
                                    val subDecimal = if (tmpSubStr[1].length > 2) {
                                        tmpSubStr[1].substring(0, 2)
                                    } else {
                                        tmpSubStr[1]
                                    }
                                    tmpSubStr[0].toLong() * 100 + if (subDecimal.length == 1) subDecimal.toLong() * 10 else subDecimal.toLong()
                                } else {
                                    tmpSubStr[0].toLong() * 100
                                }
                                mInvoiceAddEntity?.amount = tmpAmount.toString()
                            }
                            if (position > -1) {
                                var creditNoteAmount = 0L
                                var invoiceAmountInput = 0L
                                if (!mInvoiceAddEntity?.amount.isNullOrEmpty())
                                    invoiceAmountInput = mInvoiceAddEntity?.amount?.toLong() ?: 0L
                                val invoiceOutstanding = mData[position].invoice?.summation?.outstanding?.amount?.toLong()
                                        ?: 0L
                                mData[position].creditNotesSelected?.forEach {
                                    creditNoteAmount += (it.outstanding?.toLong() ?: 0L)
                                }
                                if ((creditNoteAmount + invoiceAmountInput) > invoiceOutstanding) {
                                    mData[position].overPaid = true
                                    this.tvAmountValidate?.visibility = View.VISIBLE
                                    val tmpText = IndiaNumberUtil.formatNumByDecimal((invoiceOutstanding - creditNoteAmount).toString().replace("-", ""), currency
                                            ?: MARKET_CURRENCY)
                                    val amountValidateTmpText = "${if (MemoryCache.getLabelText("s_amount_greater_tips1").isNullOrBlank()) {
                                        context.getString(R.string.s_amount_greater_tips1).replace("INR", currency
                                                ?: MARKET_CURRENCY)
                                    } else {
                                        MemoryCache.getLabelText("s_amount_greater_tips1")?.replace("INR", currency
                                                ?: MARKET_CURRENCY)
                                    }} $tmpText"
                                    tvAmountValidate?.text = amountValidateTmpText
                                } else {
                                    mData[position].overPaid = false
                                    tvAmountValidate?.visibility = View.GONE
                                }
                            }
                            updateAddButtonState()
                        }
//                        R.id.et_note -> {
//                            if (inputMap.containsKey(reference)) {
//                                val infoMap = inputMap[reference] as MutableMap<String, String>
//                                infoMap[TYPE_INPUT_COMMENT] = input
//                            } else {
//                                val infoMap = mutableMapOf<String, String>()
//                                infoMap[TYPE_INPUT_COMMENT] = input
//                                inputMap[reference] = infoMap
//                            }
//                            mInvoiceAddEntity?.comment = input
//
//                            val editText = view.findViewById<EditText>(R.id.et_note)
//                            val titleText = view.findViewById<TextView>(R.id.et_title)
//                            val announceText = MemoryCache.getLabelText("s_my_own_reference_announce")
//                                    ?: context.getString(R.string.s_my_own_reference_announce)
//                            val size = 64 - editText.text.length
//                            titleText.announceForAccessibility(size.toString() + announceText)
//                        }
                    }
                }
            }
        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    private fun updateAddButtonState() {
        if (addButton != null) {
            if (inputMap.isNotEmpty()) {
                var validateFlag = true
                for (item in inputMap) {
                    val hasCreditNoteFlag = (creditNoteSizeMap[item.key] == 0)
                    if (item.value.containsKey(TYPE_INPUT_AMOUNT)) {
                        if ((item.value[TYPE_INPUT_AMOUNT].isNullOrEmpty() || item.value.getValue(TYPE_INPUT_AMOUNT).isNotEmpty() && item.value.getValue(TYPE_INPUT_AMOUNT).toDouble() <= 0) && hasCreditNoteFlag) {
                            validateFlag = false
                            break
                        }
                    }
                }
                addButton?.isEnabled = validateFlag
            } else {
                addButton?.isEnabled = false
            }
        }
    }

    inner class FocuseChangeListener : View.OnFocusChangeListener {
        override fun onFocusChange(v: View?, hasFocus: Boolean) {
            val inputEditText = v as EditText
            inputEditText.isCursorVisible = true
            val reference = v.getTag().toString()
            var input: String? = ""
            var inputShow: String? = ""
            if (inputMap.containsKey(reference)) {
                val infoMap = inputMap[reference] as MutableMap<String, String>
                if (infoMap.containsKey(TYPE_INPUT_AMOUNT)) {
                    input = infoMap[TYPE_INPUT_AMOUNT]
                    if (!TextUtils.isEmpty(input)) {
                        val exchange = MemoryCache.globalDecimal.format(input!!.toDouble())
                        infoMap[TYPE_INPUT_AMOUNT] = exchange
                        inputMap[reference] = infoMap
                        inputShow = "$currency " + IndiaNumberUtil.formatNum(exchange!!, currency
                                ?: "")
                    }
                }
            }
            if (!hasFocus) {
                inputEditText.setText(inputShow)
            } else {
                val tmpInput = if (inputMap[reference]?.get("origin").isNullOrBlank()) v.text.toString().replace(currency
                        ?: "", "").trim() else inputMap[reference]?.get("origin")
                inputEditText.setText(tmpInput)
            }
        }
    }

    private var itemClickListener: RecyclerExtras.OnItemClickListener? = null

    fun setOnItemClickListener(listener: RecyclerExtras.OnItemClickListener) {
        this.itemClickListener = listener
    }
}
