/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.http.SslError
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.SslErrorHandler
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.FAQ_BUYER_STATIC_URL
import hk.com.hsbc.glcmdart.client.TAG_REQUEST_INTENT_DATA_LEGAL
import hk.com.hsbc.glcmdart.client.TAG_REQUEST_INTENT_DATA_LEGAL_FROM_FLAG
import hk.com.hsbc.glcmdart.client.TAG_REQUEST_INTENT_DATA_LEGAL_URL
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.NetworkManager
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_legal_page.*
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Request
import okhttp3.Response
import java.io.IOException


class LegalPageActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_legal_page)
        initView()
    }

    @SuppressLint("ResourceAsColor")
    private fun initView() {
        val isFromLogin = intent.getBooleanExtra(TAG_REQUEST_INTENT_DATA_LEGAL_FROM_FLAG, false)
        val titleText = intent.getStringExtra(TAG_REQUEST_INTENT_DATA_LEGAL)
        tl_head.title = titleText
        if (isFromLogin) {
            tl_head.setTitleTextColor(Color.BLACK)
            tl_head.setBackgroundColor(Color.WHITE)
            tl_head.setNavigationIcon(R.drawable.ic_close_on_light)
        } else {
            tl_head.setTitleTextColor(Color.WHITE)
            tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        }
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            TealiumUtil.eventTag(
                    "button click",
                    "$titleText: close"
            )
            finish()
        }
        webView.clearCache(true)
        webView.settings.apply {
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {

            }
        }
        // webView.loadUrl(intent.getStringExtra(TAG_REQUEST_INTENT_DATA_LEGAL_URL))

        showLoadingDialogExt()
        var url = intent.getStringExtra(TAG_REQUEST_INTENT_DATA_LEGAL_URL)
        url = url.replace("{country}", MemoryCache.defaultCountry ?: "IN")
        url = url.replace("{language}", MemoryCache.defaultLanguageFull ?: "en-in")
        val request = Request.Builder().url(url).build()
        NetworkManager.normalClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                hideLoadingDialogExt()
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                hideLoadingDialogExt()
                response.body()?.string()?.apply {
                    Handler(Looper.getMainLooper()).post {
                        webView.loadDataWithBaseURL(null, this, "text/html", "utf-8", null)
                    }
                }
            }
        })
    }

    companion object {
        fun showActivity(activity: Activity?, title: String?, url: String, isFromLogin: Boolean = false) {
            activity?.startActivity(Intent(activity, LegalPageActivity::class.java).let {
                it.putExtra(TAG_REQUEST_INTENT_DATA_LEGAL, title)
                it.putExtra(TAG_REQUEST_INTENT_DATA_LEGAL_URL, url)
                it.putExtra(TAG_REQUEST_INTENT_DATA_LEGAL_FROM_FLAG, isFromLogin)
                it
            })
        }
    }

    override fun onResume() {
        super.onResume()
        when (intent.getStringExtra(TAG_REQUEST_INTENT_DATA_LEGAL_URL)) {
            FAQ_BUYER_STATIC_URL -> {
                TealiumUtil.pageTag("dart:buyer portal:more:faq - detail",
                        "/dart/buyer-portal/more/faq/details",
                        "other",
                        "buyer portal",
                        "more")
            }
        }
    }
}

