package hk.com.hsbc.glcmdart.domain.more

import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.activity_tutorial_list.*

class TutorialActivity: BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tutorial_list)
        tb_head.setNavigationOnClickListener { finish() }
        tv_tutorial_first_in.text = MemoryCache.getLabelText("s_tutorial_first") ?: getString(R.string.s_tutorial_first)
        tv_tutorial_first_in.setOnClickListener { TutorialVideoActivity.showActivity(this, TutorialVideoActivity.TYPE_FIRST_IN) }
        if (MemoryCache.defaultCountry == "ID" || "S" == MemoryCache.getSessionEntity()?.type) {
            tv_tutorial_online_payment.visibility = View.GONE
            tv_tutorial_make_payment.visibility = View.GONE
        } else {
            tv_tutorial_online_payment.visibility = View.VISIBLE
            tv_tutorial_make_payment.visibility = View.VISIBLE
            tv_tutorial_online_payment.setOnClickListener { TutorialVideoActivity.showActivity(this, TutorialVideoActivity.TYPE_ONLINE_PAYMENT) }
            tv_tutorial_make_payment.setOnClickListener { TutorialVideoActivity.showActivity(this, TutorialVideoActivity.TYPE_MAKE_PAYMENT) }
        }
    }
}