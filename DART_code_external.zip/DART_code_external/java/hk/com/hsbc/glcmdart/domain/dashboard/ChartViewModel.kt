package hk.com.hsbc.glcmdart.domain.dashboard

import android.annotation.SuppressLint
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.dart.Account
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.*
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.util.*

class ChartViewModel: BaseViewModel() {

    private val mModel by lazy {
        ChartModel()
    }
    private val mInvoiceModel by lazy {
        InvoiceListModel()
    }

    val channelLiveData = MutableLiveData<HomePaymentChannelEntity?>()
    val statusLiveData = MutableLiveData<HomeInvoiceStatusEntity?>()
    val summaryLiveData = MutableLiveData<HomeInvoiceSummaryEntity?>()
    val metricsLiveData = MutableLiveData<HomeInvoiceMetricsEntity?>()
    val accountsLiveData = MutableLiveData<List<Account>?>()
    private var uploadParameter = InvoiceRequestParameter(null, null, null, mutableListOf("F", "U", "O", "P", "C"), null, null, null, null, InvoiceRequestSort("issueDate", "desc"))
    var isInvoiceLoaded = false
    var isDashboardLoaded = false

    fun getHomeFragmentChannelsData(requestBody: Map<String, Any>) {
        val disposable = mModel.getHomeFragmentChannelsData(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    channelLiveData.postValue(it)
                },{
                    channelLiveData.postValue(null)
                })
    }

    fun getHomeInvoiceStatusData(requestBody: Map<String, Any>) {
        val disposable = mModel.getHomeInvoiceStatusData(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    statusLiveData.postValue(it)
                },{
                    statusLiveData.postValue(null)
                })
    }

    fun getHomeInvoiceSummaryData(requestBody: Map<String, Any>) {
        val disposable = mModel.getHomeInvoiceSummaryData(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    if (it.payload != null) {
                        summaryLiveData.postValue(it)
                    }
                },{
                    summaryLiveData.postValue(null)
                })
    }

    fun getHomeFragmentMetricsData(requestBody: Map<String, Any>) {
        val disposable = mModel.getHomeFragmentMetricsData(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    if (it.payload != null) {
                        metricsLiveData.postValue(it)
                    }
                },{
                    metricsLiveData.postValue(null)
                })
    }

    fun getProfileDetail(requestParameter: HashMap<String, Any>) {
        val disposable = mModel.getProfileDetail()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    if (it.payload?.accounts != null) {
                        val accounts = mutableListOf<Account>()
                        for (item in it.payload.accounts) {
                            if (item.currency == requestParameter["currency"]) {
                                accounts.add(item)
                            }
                        }
                        accountsLiveData.postValue(it.payload.accounts)
                        MemoryCache.saveProfileDetail(it)
                        requestParameter["payee_accounts"] = accounts
//                        val organizationList = MemoryCache.getOrganisations()
//                        val buyerList = mutableListOf<String>()
//                        organizationList?.payload?.payors?.forEach { payor ->
//                            if (!payor.reference.isNullOrBlank()) {
//                                buyerList.add(payor.reference)
//                            }
//                        }
//                        if (buyerList.size > 0) {
//                            requestParameter["buyers"] = buyerList
//                        }
                        getHomeInvoiceSummaryData(requestParameter)
                        getHomeInvoiceStatusData(requestParameter)
                        getHomeFragmentChannelsData(requestParameter)
//                        requestParameter["dateField"] = "issueDate"
//                        requestParameter["minDate"] = TimeZoneTransformsUtil.formatParameterTime(Date())
//                        requestParameter["maxDate"] = TimeZoneTransformsUtil.formatParameterTime(Date())
                        getHomeFragmentMetricsData(requestParameter)
//                        requestParameter.remove("dateField")
//                        requestParameter.remove("dateFrom")
//                        requestParameter.remove("dateTo")
                    } else {
                        requestLoadingLiveData.postValue(false)
                        exceptionLiveData.postValue("No accounts in this profile !")
                    }
                    isDashboardLoaded = true
                    if (isDashboardLoaded && isInvoiceLoaded) {
                        requestLoadingLiveData.postValue(false)
                    }
                },{
//                    Toast.makeText(DartApplication.instance, "Load Data Fail", Toast.LENGTH_SHORT).show()
                    requestLoadingLiveData.postValue(false)
                    exceptionLiveData.postValue("Load Data Fail: " + it.message)
                })
    }

    @SuppressLint("CheckResult")
    fun doInvoiceRequest() {
        requestLoadingLiveData.postValue(true)
        mInvoiceModel.getInvoiceList(uploadParameter)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        {
                            //filter special department invoices， when has department name return from logon， then filter matching invoices
                            var rebuildEntity: InvoiceListEntity? = null
                            if (MemoryCache.departmentName.isNotEmpty()) {
                                if (!it.payload?.invoices.isNullOrEmpty()) {
                                    val invoiceList = mutableListOf<Invoice>()
                                    val tokens = mutableListOf<String>()
                                    for (i in it.payload?.invoices?.indices!!) {
                                        if (it.payload.invoices[i].payor?.name?.contains("(") == true) {
                                            val belongDepartmentName = it.payload.invoices[i].payor?.name?.split("(") ?: mutableListOf()
                                            if (belongDepartmentName.size <= 1) {
                                                continue
                                            }
                                            val belongDepartNameChecker = belongDepartmentName[1].
                                            replace(")", "").
                                            replace(" ", "")
                                            for (item in MemoryCache.departmentName) {
                                                if (item == belongDepartNameChecker) {
                                                    invoiceList.add(it.payload.invoices[i])
                                                    tokens.add(it.payload.tokens?.get(i)!!)
                                                    break
                                                }
                                            }
                                        }
                                    }
                                    rebuildEntity = InvoiceListEntity(InvoiceListPayLoad(invoiceList,
                                            it.payload.itps, it.payload.pagination, tokens))
                                }
                            }
                            MemoryCache.initInvoiceList = rebuildEntity ?: it
                            isInvoiceLoaded = true
                            if (isDashboardLoaded && isInvoiceLoaded) {
                                requestLoadingLiveData.postValue(false)
                            }
                        }, {
                    requestLoadingLiveData.postValue(false)
                    exceptionLiveData.postValue(it.message)
//                    Toast.makeText(DartApplication.instance, it.message, Toast.LENGTH_LONG).show()
                })
    }
}