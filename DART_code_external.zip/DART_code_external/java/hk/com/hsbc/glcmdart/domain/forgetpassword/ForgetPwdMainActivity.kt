/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.forgetpassword

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.registration.Question
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.NetworkManager
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_forget_password_main.*

class ForgetPwdMainActivity: BaseActivity(), View.OnClickListener {

    companion object {
        fun showActivity(activity: Activity) {
            activity.startActivity(Intent(activity, ForgetPwdMainActivity::class.java))
        }
    }

    private var questionMap: ArrayList<Question> = ArrayList()
    private var resetToken: String = ""
    private var resetUsername: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_password_main)
        StatusBarUtil.setStatusTextColor(false, this)
        StatusBarUtil.setTransparentStatusBar(this, false)
        removeStatusView(this)

        NetworkManager.clearCookies()
        MemoryCache.clear()
        initViewAndData()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        questionMap = intent?.getSerializableExtra(TAG_FORGET_ANSWER_RESULT) as ArrayList<Question>
        val token = intent.getStringExtra(TAG_FORGET_RESET_TOKEN)
        if (!token.isNullOrBlank()) {
            resetToken = token
        }
        val selected = questionMap.filter { question ->
            !question.answer.isNullOrEmpty()
        }

        if (selected.size == 3) {
            ll_forget_answer_questions_container.isEnabled = false
            tv_forget_answer_question.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this, R.drawable.ic_done), null)
            tv_forget_answer_question_num.setBackgroundResource(R.drawable.bg_green_circle_15dp)
            ll_forget_create_password_container.isEnabled = true
            tv_forget_create_password.setTextColor(Color.BLACK)
            tv_forget_create_password.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this,R.drawable.ic_next_page), null)
            tv_forget_create_password_num.setTextColor(Color.WHITE)
            tv_forget_create_password_num.setBackgroundResource(R.drawable.bg_black_circle_15dp)
        } else {
            if (!ll_forget_enter_username_container.isEnabled) {
                ll_forget_answer_questions_container.isEnabled = true
                tv_forget_answer_question.setTextColor(Color.BLACK)
                tv_forget_answer_question.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this, R.drawable.ic_next_page), null)
                tv_forget_answer_question_num.setTextColor(Color.WHITE)
                tv_forget_answer_question_num.setBackgroundResource(R.drawable.bg_black_circle_15dp)
                ll_forget_create_password_container.isEnabled = false
                tv_forget_create_password.setTextColor(ContextCompat.getColor(this, R.color.secondary_gray))
                tv_forget_create_password.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, null, null)
                tv_forget_create_password_num.setTextColor(ContextCompat.getColor(this, R.color.secondary_gray))
                tv_forget_create_password_num.setBackgroundResource(R.drawable.bg_gray_transparent_15dp)
            }
        }
    }

    private fun initViewAndData() {
        MemoryCache.getLabelText("s_forget_main_title")?.let {
            if (!it.isBlank()) {
                tv_forget_main_title.text = it
            }
        }
        MemoryCache.getLabelText("s_forget_main_tip")?.let {
            if (!it.isBlank()) {
                tv_forget_main_tip.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_enter_username")?.let {
            if (!it.isBlank()) {
                ll_forget_enter_username_container.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_forget_main_enter_username")?.let {
            if (!it.isBlank()) {
                tv_forget_enter_username.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_answer_recovery_questions")?.let {
            if (!it.isBlank()) {
                ll_forget_answer_questions_container.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_forget_main_answer_questions")?.let {
            if (!it.isBlank()) {
                tv_forget_answer_question.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_create_a_new_password")?.let {
            if (!it.isBlank()) {
                ll_forget_create_password_container.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_forget_main_create_password")?.let {
            if (!it.isBlank()) {
                tv_forget_create_password.text = it
            }
        }
        MemoryCache.getLabelText("s_cancel")?.let {
            if (!it.isBlank()) {
                tv_forget_cancel.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_cancel")?.let {
            if (!it.isBlank()) {
                tv_forget_cancel.contentDescription = it
            }
        }

        val buttonAccessibilityDelegate = object: View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        }

        ll_forget_enter_username_container.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_forget_answer_questions_container.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_forget_create_password_container.setAccessibilityDelegate(buttonAccessibilityDelegate)

        ll_forget_enter_username_container.setOnClickListener(this)
        ll_forget_answer_questions_container.setOnClickListener(this)
        ll_forget_create_password_container.setOnClickListener(this)
        tv_forget_cancel.setOnClickListener(this)

        ll_forget_answer_questions_container.isEnabled = false
        ll_forget_create_password_container.isEnabled = false
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.ll_forget_enter_username_container -> {
                TealiumUtil.eventTag("button click", "recover password: recover password overview: enter username")
                ForgetPwdEnterUserNameActivity.showActivity(this, REQUEST_CODE_RESET_PWD_USERNAME)
            }
            R.id.ll_forget_answer_questions_container -> {
                TealiumUtil.eventTag("button click", "recover password: recover password overview: answer recovery questions")
                ForgetPwdRecoveryQuestionActivity.showActivity(this, REQUEST_CODE_RESET_PWD_QUESTIONS, questionMap, resetUsername)
            }
            R.id.ll_forget_create_password_container -> {
                TealiumUtil.eventTag("button click", "recover password: recover password overview: create a new password")
                ForgetPwdResetActivity.showActivity(this, questionMap, resetToken, resetUsername)
            }
            R.id.tv_forget_cancel -> {
                TealiumUtil.eventTag("button click", "recover password: recover password overview: cancel")
                finish()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_CANCELED) {
            if (requestCode == REQUEST_CODE_RESET_PWD_QUESTIONS) {
                return
            }
        }
        if (resultCode == Activity.RESULT_OK)
            when (requestCode) {
                REQUEST_CODE_RESET_PWD_USERNAME -> {
                    ll_forget_enter_username_container.isEnabled = false
                    tv_forget_enter_username.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this, R.drawable.ic_done), null)
                    tv_forget_enter_username_num.setBackgroundResource(R.drawable.bg_green_circle_15dp)
                    ll_forget_answer_questions_container.isEnabled = true
                    tv_forget_answer_question.setTextColor(Color.BLACK)
                    tv_forget_answer_question.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this, R.drawable.ic_next_page), null)
                    tv_forget_answer_question_num.setTextColor(Color.WHITE)
                    tv_forget_answer_question_num.setBackgroundResource(R.drawable.bg_black_circle_15dp)
                    if (data != null) {
                        questionMap = data.getSerializableExtra(TAG_FORGET_RECOVERY_QUESTIONS_RESULT) as ArrayList<Question>
                        resetToken = data.getStringExtra(TAG_FORGET_RESET_TOKEN)
                        resetUsername = data.getStringExtra(TAG_FORGET_RESET_USERNAME)
                    }
                }
                REQUEST_CODE_RESET_PWD_QUESTIONS -> {
                    ll_forget_answer_questions_container.isEnabled = false
                    tv_forget_answer_question.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this, R.drawable.ic_done), null)
                    tv_forget_answer_question_num.setBackgroundResource(R.drawable.bg_green_circle_15dp)
                    ll_forget_create_password_container.isEnabled = true
                    tv_forget_create_password.setTextColor(Color.BLACK)
                    tv_forget_create_password.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(this,R.drawable.ic_next_page), null)
                    tv_forget_create_password_num.setTextColor(Color.WHITE)
                    tv_forget_create_password_num.setBackgroundResource(R.drawable.bg_black_circle_15dp)
                    if (data != null) {
                        questionMap = data.getSerializableExtra(TAG_FORGET_ANSWER_RESULT) as ArrayList<Question>
                        val token = data.getStringExtra(TAG_FORGET_RESET_TOKEN)
                        if (token.isNotBlank()) {
                            resetToken = token
                        }
                    }
                }
            }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart : buyer portal : recover password : recover password overview",
                "/dart/buyer portal/recover password/recover password overview",
                "verification",
                "buyer portal",
                "recover password",
                "mobile",
                "en",
                "recover password",
                "1",
                "recover password - start")
    }
}