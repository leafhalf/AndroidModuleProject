/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_CHOOSE_TAX_DEDUCTION_EXTEND
import hk.com.hsbc.glcmdart.client.TAG_REQUEST_INTENT_DATA_SELECTED_TAX_DEDUCTION
import hk.com.hsbc.glcmdart.client.TAG_REQUEST_INTENT_DATA_TAX_DEDUCTION
import hk.com.hsbc.glcmdart.domain.dart.CommonDialog
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import hk.com.hsbc.glcmdart.domain.payments.ChooseTaxDeductionExtendActivity.Companion.INTENT_TAG_INDEX
import hk.com.hsbc.glcmdart.domain.payments.ChooseTaxDeductionExtendActivity.Companion.INTENT_TAG_RESULT_DEDUCTION_EXTEND_LIST
import hk.com.hsbc.glcmdart.domain.payments.adapter.ChooseTaxDeductionAdapter
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfoGrouped
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.widget.SpacesItemDecoration
import kotlinx.android.synthetic.main.activity_choose_tax_deduction.*
import java.math.BigDecimal

class ChooseTaxDeductionActivity : BaseActivity() {

    private val itemList = ArrayList<TaxDeductionInfoGrouped>()
    private lateinit var mAdapter: ChooseTaxDeductionAdapter
    private var currency: String? = null
    private lateinit var invoice: Invoice

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_tax_deduction)
        initViewAndEvent()
    }

    @SuppressLint("ResourceAsColor")
    private fun initViewAndEvent() {
        tl_head.title = MemoryCache.getLabelText("s_choose_deductions")
                ?: getString(R.string.s_choose_deductions)
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            backAction()
        }
        currency = intent.getStringExtra(TAG_DEDUCTION_CURRENCY)
        invoice = intent.getSerializableExtra(TAG_INVOICE) as Invoice
        mAdapter = ChooseTaxDeductionAdapter(this, itemList, invoice)
        mAdapter.setCurrency(currency)
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        rv_invoice_add_or_edit.addItemDecoration(SpacesItemDecoration(this, resources.getDimension(R.dimen.d_common_padding_margin_8).toInt()))
        rv_invoice_add_or_edit.adapter = mAdapter
        btn_update.isEnabled = true
//        mAdapter.setBtnUpdateWidget(btn_update)
        if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_TAX_DEDUCTION) != null) {
            val taxDeductions = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_TAX_DEDUCTION) as ArrayList<TaxDeductionInfo>
            val selectedDeductions = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_SELECTED_TAX_DEDUCTION) as ArrayList<TaxDeductionInfo>?
            val taxDeductionGroups = mutableListOf<TaxDeductionInfoGrouped>()
            val initGroupItem = TaxDeductionInfoGrouped(mutableListOf(), null)
            taxDeductionGroups.add(initGroupItem)
            taxDeductions.forEach {
                var inGroup = false
                taxDeductionGroups.forEach { group ->
                    if (group.taxDeductionOptions.size > 0) {
                        if (group.taxDeductionOptions[0].name == it.name && group.taxDeductionOptions[0].type == it.type) {
                            group.taxDeductionOptions.add(it)
                            inGroup = true
                        }
                    } else {
                        group.taxDeductionOptions.add(it)
                        inGroup = true
                    }
                }
                if (!inGroup) {
                    val groupItem = TaxDeductionInfoGrouped(mutableListOf(), null)
                    groupItem.taxDeductionOptions.add(it)
                    taxDeductionGroups.add(groupItem)
                }
            }

            if (!selectedDeductions.isNullOrEmpty()) {
                for (item in selectedDeductions) {
                    for (groupItem in taxDeductionGroups) {
                        for (optionItem in groupItem.taxDeductionOptions) {
                            if (optionItem.code == item.code) {
                                groupItem.selectedDeduction = item
                                groupItem.selected = true
                            }
                        }
                    }
                }
            }
            mAdapter.addData(taxDeductionGroups as ArrayList<TaxDeductionInfoGrouped>)
        }

        btn_update.setOnClickListener {
            TealiumUtil.eventTag("button click", "choose credit note: update")
            val taxDeductionSelected = mAdapter.getSelectItems()
            val intent = Intent().apply { putExtra(TAG_REQUEST_INTENT_DATA_TAX_DEDUCTION, taxDeductionSelected as ArrayList<TaxDeductionInfo>?) }
            setResult(Activity.RESULT_OK, intent)
            finish()
        }

        MemoryCache.getLabelText("s_update")?.let {
            if (!it.isBlank()) {
                btn_update.text = it
            }
        }
    }

    companion object {
        const val TAG_DEDUCTION_CURRENCY = "type_invoice_currency"
        const val TAG_INVOICE = "invoice"
        fun showActivity(activity: Activity, taxDeductions: List<TaxDeductionInfo>,
                         currency: String?, invoice: Invoice?, selectedDeductionList: List<TaxDeductionInfo>? = null, requestCode: Int) {
            val intent = Intent(activity, ChooseTaxDeductionActivity::class.java).apply {
                putExtra(TAG_REQUEST_INTENT_DATA_TAX_DEDUCTION, taxDeductions as ArrayList<TaxDeductionInfo>)
                putExtra(TAG_REQUEST_INTENT_DATA_SELECTED_TAX_DEDUCTION, selectedDeductionList as ArrayList<TaxDeductionInfo>?)
                putExtra(TAG_DEDUCTION_CURRENCY, currency)
                putExtra(TAG_INVOICE, invoice)
            }
            activity.startActivityForResult(intent, requestCode)
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart : buyer portal : invoices : choose credit note",
                "/dart/buyer portal/invoices/choose credit note",
                "accounts",
                "buyer portal",
                "invoices"
        )
    }

    private fun backAction() {
        if (mAdapter.didOperation) {
            CommonDialog.showDialog(this, null, MemoryCache.getLabelText("s_exit_choose_deduction_dialog_tip")
                    ?: getString(R.string.s_exit_choose_deduction_dialog_tip),
                    MemoryCache.getLabelText("s_exit_choose_deduction_dialog_confirm")
                            ?: getString(R.string.s_exit_choose_deduction_dialog_confirm),
                    MemoryCache.getLabelText("s_exit_choose_deduction_dialog_cancel")
                            ?: getString(R.string.s_exit_choose_deduction_dialog_cancel),
                    null, View.OnClickListener { finish() })
        } else {
            finish()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            backAction()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_CHOOSE_TAX_DEDUCTION_EXTEND) {
                val itemIndex = data?.getIntExtra(INTENT_TAG_INDEX, 0)
                val itemOptionList = data?.getSerializableExtra(INTENT_TAG_RESULT_DEDUCTION_EXTEND_LIST) as MutableList<TaxDeductionInfo>
                var selectedIndex = 0
                for (i in 0 until itemOptionList.size) {
                    if (itemOptionList[i].selected) {
                        selectedIndex = i
                        break
                    }
                }
                itemList[itemIndex ?: 0].selectedDeduction = itemOptionList[selectedIndex]
                val deductionAmount = if (itemList[itemIndex ?: 0].selectedDeduction?.maxRate == null) {
                    itemList[itemIndex ?: 0].selectedDeduction?.maxAmount
                } else {
                    ((invoice.summation?.total?.amount?.toBigDecimal() ?: 0.toBigDecimal()) *
                            itemList[itemIndex ?: 0].selectedDeduction?.maxRate!!.toBigDecimal() / 100.toBigDecimal())
                            .setScale(2, BigDecimal.ROUND_HALF_UP).toString()
                }
                itemList[itemIndex ?: 0].selectedDeduction?.actualAmount = deductionAmount
                itemList[itemIndex ?: 0].taxDeductionOptions = itemOptionList
                mAdapter.notifyItemChanged(itemIndex ?: 0)
            }
        }
    }
}
