package hk.com.hsbc.glcmdart.domain.payments

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.SpannedString
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.activity_choose_va_bank.*

class ChooseVABankActivity(): BaseActivity(), BankNameItemClickListener {

    private val keyList = mutableListOf<String>()
    private val nameList = mutableListOf<String>()

//    private val mockBankName = mutableListOf("Permata  88560-001123456789", "Mandiri  88999-001123456789",
//            "Sinarmas  88900-001123456789", "Alfa Group  88888-001123456789", "Indomaret  88xxx-001123456789",
//            "Danamon  8922x-001123456789", "Extra mock up bank 1  12345-001123456789",
//            "Extra mock up bank 2  23456-001123456789", "Extra mock up bank 3  34567-001123456789",
//            "Extra mock up bank 4  45678-001123456789")

    companion object {
        const val INTENT_TAG_REQUEST_VA_BANK_NAME = "bankName"
        const val INTENT_TAG_REQUEST_VA_BANK_NAME_LIST = "bankNameList"
        const val INTENT_TAG_RESULT_VA_BANK_NAME = "resultBankName"
        fun showActivityForResult(context: BaseActivity, requestCode: Int, vaCodeList: ArrayList<String>, originSelection: String) {
            val intent = Intent(context, ChooseVABankActivity::class.java)
            intent.putExtra(INTENT_TAG_REQUEST_VA_BANK_NAME, originSelection)
            intent.putExtra(INTENT_TAG_REQUEST_VA_BANK_NAME_LIST, vaCodeList)
            context.startActivityForResult(intent, requestCode)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_va_bank)
        initViewsAndData()
    }

    private fun initViewsAndData() {
        tb_head.title = MemoryCache.getLabelText("s_choose_va_payment_code") ?: getString(R.string.s_choose_va_payment_code)
        tb_head.setTitleTextColor(Color.WHITE)
        tb_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        tb_head.setNavigationOnClickListener { finish() }
        val vaCodeList = intent.getStringArrayListExtra(INTENT_TAG_REQUEST_VA_BANK_NAME_LIST)
        for (item in vaCodeList) {
            if (item.length < 5) {
                continue
            }
            var bankName = MemoryCache.getVABankNameMap(this, item.substring(0, 5)) ?: "Unmatched bank name"
            bankName = if (item.contains("-")) {
                "$bankName  $item"
            } else {
                val prefix = item.substring(0, 5)
                val postfix = item.substring(5)
                "$bankName  $prefix-$postfix"
            }
            nameList.add(bankName)
        }
//        val vaBankNameMap = MemoryCache.getVABankNameMap(this)
//        val keySet = vaBankNameMap?.keys
//        keySet?.forEach {
//            keyList.add(it)
//            nameList.add(vaBankNameMap[it]!!)
//        }

        val originSelection = intent.getStringExtra(INTENT_TAG_REQUEST_VA_BANK_NAME)
        var originSelectionHandled = ""
        if (!originSelection.isNullOrBlank()) {
            val subOriginSelection = originSelection.split("  ")
            val prefix = subOriginSelection[1].substring(0, 5)
            val postfix = subOriginSelection[1].substring(5)
            originSelectionHandled = "${subOriginSelection[0]}  $prefix-$postfix"
        }
        rv_choose_va_bank.layoutManager = LinearLayoutManager(this)
        rv_choose_va_bank.adapter = BankNameAdapter(this, nameList,
                originSelectionHandled,this)
    }

    override fun onItemClick(position: Int) {
        val bankName = nameList[position].replace("-", "")
        setResult(Activity.RESULT_OK, Intent().also {
            it.putExtra(INTENT_TAG_RESULT_VA_BANK_NAME, bankName)
        })
        finish()
    }

    class BankNameAdapter(private val context: Context, private val dataList: List<String>,
                          private val originSelection: String,
                          private val onClickListener: BankNameItemClickListener?):
            RecyclerView.Adapter<BankNameVH>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BankNameVH {
            val itemView = LayoutInflater.from(context).inflate(R.layout.item_simple_text, null)
            return BankNameVH(itemView)
        }

        override fun onBindViewHolder(holder: BankNameVH, position: Int) {

            if (dataList[position] == originSelection) {
                holder.ivSelected.visibility = View.VISIBLE
            } else {
                holder.ivSelected.visibility = View.GONE
            }
            val lastBlankIndex = dataList[position].lastIndexOf(" ")
            val spanningText = SpannableString(dataList[position])
            spanningText.setSpan(ForegroundColorSpan(ContextCompat.getColor(context, R.color.secondary_gray)),
                    lastBlankIndex, dataList[position].length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            holder.tvBankName.text = spanningText
            onClickListener?.let { onItemClick ->
                holder.tvBankName.setOnClickListener {
                    onItemClick.onItemClick(position)
                }
            }
            if (position == dataList.size - 1) {
                holder.vLine.visibility = View.GONE
            } else {
                holder.vLine.visibility = View.VISIBLE
            }
        }

        override fun getItemCount(): Int {
            return dataList.size
        }

    }

    class BankNameVH(itemView: View): RecyclerView.ViewHolder(itemView) {
        val tvBankName = itemView.findViewById<TextView>(R.id.tv_simple_text)
        val ivSelected = itemView.findViewById<ImageView>(R.id.iv_selected)
        val vLine = itemView.findViewById<View>(R.id.v_payment_code_divide)
    }
}

interface BankNameItemClickListener {
    fun onItemClick(position: Int)
}