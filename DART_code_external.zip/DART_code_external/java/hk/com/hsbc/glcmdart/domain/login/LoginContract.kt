/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.login

import android.app.Activity
import hk.com.hsbc.glcmdart.domain.dart.PayeeEntity
import hk.com.hsbc.glcmdart.domain.dashboard.ProfileDetailEntity
import hk.com.hsbc.glcmdart.framework.IView
import io.reactivex.Observable
import retrofit2.Response

class LoginContract {

    interface View: IView {
        fun showLoginView(code: Int?, msg: String?)
        fun hideLoginView(code: Int?, msg: String?)

        fun getActivity(): Activity
    }

    interface Presenter {
        fun doRequest(bean: LoginBean)
    }

    interface Model {
        fun requestLogin(jsonBody: LoginBean): Observable<Response<LoginEntity>>
        fun requestSession(): Response<SessionEntity>
        fun requestProfile(): Observable<Response<ProfileEntity>>
        fun requestProfileDetail(loginType: String?): Observable<Response<ProfileDetailEntity>>
        fun requestOrganisations(loginType: String?): Observable<Response<PayeeEntity>>
        fun requestLogout(): Response<LogoutEntity>
        fun uploadUrbanAirshipInfo(jsonBody: RequestUrbanAirship): Observable<UrbanAirshipEntity>
        fun detachUrbanAirship(userId: String): Observable<DetachUrbanAirshipEntity>
    }
}