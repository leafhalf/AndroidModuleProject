/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_REQUEST_INTENT_DATA_CREDIT_NOTE
import hk.com.hsbc.glcmdart.client.TAG_REQUEST_INTENT_DATA_CREDIT_NOTE_SELECTED
import hk.com.hsbc.glcmdart.domain.dart.CommonDialog
import hk.com.hsbc.glcmdart.domain.dart.CreditNoteLocal
import hk.com.hsbc.glcmdart.domain.payments.adapter.ChooseCreditNoteAdapter
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.widget.SpacesItemDecoration
import kotlinx.android.synthetic.main.activity_choose_credit_note.*

class ChooseCreditNoteActivity : BaseActivity() {

    private val itemList = ArrayList<CreditNoteLocal>()
    private val mAdapter by lazy { ChooseCreditNoteAdapter(this, itemList) }
    private var currency: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_credit_note)
        initViewAndEvent()
    }

    @SuppressLint("ResourceAsColor")
    private fun initViewAndEvent() {
        tl_head.title = MemoryCache.getLabelText("s_choose_credit_note")
                ?: getString(R.string.s_choose_credit_note)
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            backAction()
        }
        currency = intent.getStringExtra(TAG_CREDITNOTE_CURRENCY)
        mAdapter.setCurrency(currency)
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        rv_invoice_add_or_edit.addItemDecoration(SpacesItemDecoration(this, resources.getDimension(R.dimen.d_common_padding_margin_8).toInt()))
        rv_invoice_add_or_edit.adapter = mAdapter
        mAdapter.setBtnUpdateWidget(btn_update)
        if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE) != null) {
            val creditNotes = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE) as ArrayList<CreditNoteLocal>
            val filterCreditNotes = arrayListOf<CreditNoteLocal>()
            creditNotes.forEach {
                if (!(it.creditNote?.status == "C" || it.creditNote?.status == "O")) {
                    if (it.creditNote?.payeeAccount?.currency == currency && ((it.creditNote?.amount?.toLong()
                                    ?: 1) <= 0)) {
                        filterCreditNotes.add(it)
                    }
                }
            }
            filterCreditNotes.forEach { it.selected = false }
            if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE_SELECTED) != null) {
                val creditNotesSelected = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE_SELECTED) as ArrayList<CreditNoteLocal>
                if (creditNotesSelected.size > 0) {
                    val map = mutableMapOf<String, CreditNoteLocal>()
                    for (item in creditNotesSelected) {
                        map[item.token.toString()] = item
                    }
                    for (item in filterCreditNotes) {
                        if (map.contains(item.token)) {
                            item.outstanding = ((map[item.token]?.outstanding?.toDouble()
                                    ?: 0.00) / 100).toString()
                            item.selected = true
                        }
                    }
                }
            }
            mAdapter.addData(filterCreditNotes)
        }
        btn_update.setOnClickListener {
            TealiumUtil.eventTag("button click", "choose credit note: update")
            val creditNotes = mAdapter.getSelectItems()
            val intent = Intent().apply { putExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE, creditNotes as ArrayList<CreditNoteLocal>) }
            setResult(Activity.RESULT_OK, intent)
            finish()
        }

        MemoryCache.getLabelText("s_update")?.let {
            if (!it.isBlank()) {
                btn_update.text = it
            }
        }
    }

    companion object {
        const val TAG_CREDITNOTE_CURRENCY = "type_invoice_currency"
        fun showActivity(activity: Activity, creditNotes: List<CreditNoteLocal>, creditNotesSelected: List<CreditNoteLocal>?, currency: String?, requestCode: Int) {
            val intent = Intent(activity, ChooseCreditNoteActivity::class.java).apply {
                putExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE, creditNotes as ArrayList<CreditNoteLocal>)
                if (creditNotesSelected != null && creditNotesSelected.isNotEmpty())
                    putExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE_SELECTED, creditNotesSelected as ArrayList<CreditNoteLocal>)
                putExtra(TAG_CREDITNOTE_CURRENCY, currency)
            }
            activity.startActivityForResult(intent, requestCode)
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart : buyer portal : invoices : choose credit note",
                "/dart/buyer portal/invoices/choose credit note",
                "accounts",
                "buyer portal",
                "invoices"
        )
    }

    private fun backAction() {
        CommonDialog.showDialog(this, null, MemoryCache.getLabelText("s_exit_choose_deduction_dialog_tip")
                ?: getString(R.string.s_exit_choose_deduction_dialog_tip),
                MemoryCache.getLabelText("s_exit_choose_deduction_dialog_confirm")
                        ?: getString(R.string.s_exit_choose_deduction_dialog_confirm),
                MemoryCache.getLabelText("s_exit_choose_deduction_dialog_cancel")
                        ?: getString(R.string.s_exit_choose_deduction_dialog_cancel),
                null, View.OnClickListener { finish() })
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            backAction()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
