package hk.com.hsbc.glcmdart.domain.payments.presenter

import android.text.TextUtils
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.client.INVOICE
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentExpectedDate
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentLocalEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.Timestap
import hk.com.hsbc.glcmdart.util.DateUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import io.reactivex.Observable
import io.reactivex.ObservableOnSubscribe
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class MyPaymentsViewModel: PaymentBaseViewModel() {

    val myPaymentsLiveData = MutableLiveData<Map<String, Any>>()

    fun requestData(payorOrPayee: String?, searchKey: String?, currency: String?,statuses:List<String>?,
                    gtCondition: Timestap? = null, ltCondition: Timestap? = null, isInitRequest: Boolean = false) {
        if (isInitRequest) {
            if (MemoryCache.initITPList != null) {
                handleCallbackPlannedPaymentData(MemoryCache.initITPList!!)
                return
            }
        }

        val dataMap = mutableMapOf<String, Any>()
        if (TextUtils.isEmpty(payorOrPayee).not()) {
            if ("S" == MemoryCache.getSessionEntity()?.type) {
                if ("All" == payorOrPayee) {
                    dataMap["payorReference"] = ""
                } else {
                    dataMap["payorReference"] = payorOrPayee ?: ""
                }
            } else {
                if ("All" == payorOrPayee) {
                    dataMap["payeeReference"] = ""
                } else {
                    dataMap["payeeReference"] = payorOrPayee ?: ""
                }
            }
        }
        if (!searchKey.isNullOrEmpty())
            dataMap["search"] = searchKey
        if (!currency.isNullOrEmpty())
            dataMap["currencies"] = listOf(currency)
        if (!statuses.isNullOrEmpty())
            dataMap["statuses"] = statuses
        if (gtCondition != null) {
            if (dataMap["expectedDate"] != null) {
                (dataMap["expectedDate"] as PaymentExpectedDate).gt = gtCondition
            } else {
                val expectedDate = PaymentExpectedDate(gtCondition, null)
                dataMap["expectedDate"] = expectedDate
            }
        }
        if (ltCondition != null) {
            if (dataMap["expectedDate"] != null) {
                (dataMap["expectedDate"] as PaymentExpectedDate).lt = ltCondition
            } else {
                val expectedDate = PaymentExpectedDate(null, ltCondition)
                dataMap["expectedDate"] = expectedDate
            }
        }
        val disposable = paymentsModel.searchPlannedPayment(dataMap)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    handleCallbackPlannedPaymentData(it)
                }, {
                    paymentErrorLiveData.postValue(it.message)
                })
    }

    private fun handleCallbackPlannedPaymentData(payload: PlannedPaymentListPayload) {
        val disposable = Observable.create(ObservableOnSubscribe<Map<String, Any>> {
            it.onNext(dealAllPaymentDatas(payload))
            it.onComplete()
        }).subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    myPaymentsLiveData.postValue(it)
                }, {
                    paymentErrorLiveData.postValue(it.message)
                })
    }

    private fun dealAllPaymentDatas(it: PlannedPaymentListPayload): Map<String, Any> {
        val organizationsMap = MemoryCache.getOrganisationsMap()
        val map = mutableMapOf<String, Any>()
        val all = mutableListOf<PlannedPaymentLocalEntity>()
        var allAmount = 0L
        var allCreatedAmount = 0L
        var allRevokedAmount = 0L
        var allClosedAmount = 0L
        var allProcessingAmount = 0L
        var allReceivedAmount = 0L
        for (i in it.payload?.itps?.indices!!) {
            val itp = it.payload?.itps?.get(i)
            var amount: Long? = 0L
            if (itp?.lines != null) {
                for (item in itp.lines) {
                    if (INVOICE == item.type) {
                        amount = (amount ?: 0L) + (item.amount?.amount?.toLong() ?: 0L)
                    }
                }
            }
            val organization = if ("S" == MemoryCache.getSessionEntity()?.type) {
                if (organizationsMap.containsKey(itp?.payorReference))
                    (organizationsMap[itp?.payorReference] as Payee).name
                else
                    ""
            } else {
                if (organizationsMap.containsKey(itp?.payeeReference))
                    (organizationsMap[itp?.payeeReference] as Payee).name
                else
                    ""
            }
            itp?.amount = amount.toString()
            val plannedPaymentLocalEntity = PlannedPaymentLocalEntity(
                    it.payload?.amounts?.get(i), it.payload?.createdAts?.get(i),
                    it.payload?.itps?.get(i), it.payload?.statuses?.get(i),
                    it.payload?.tokens?.get(i), it.payload?.updatedAts?.get(i), organization
            )
            when (plannedPaymentLocalEntity.statuse) {
                "created" -> {
                    allCreatedAmount += (amount ?: 0L)
                }
                "revoked_payor" -> {
                    allRevokedAmount += (amount ?: 0L)
                }
                "closed" -> {
                    allClosedAmount += (amount ?: 0L)
                }
                "processing" -> {
                    allProcessingAmount += (amount ?: 0L)
                }
                "payment_received" -> {
                    allReceivedAmount += (amount ?: 0L)
                }
            }
            allAmount += (amount ?: 0L)
            all.add(plannedPaymentLocalEntity)
        }
        all.sortByDescending { it.itp?.amount?.toLong() }
        all.sortByDescending { DateUtil.stringConversionToTimestamp(it.itp?.expectedDate) }
        map["all"] = all
        map["allAmount"] = allAmount
        map["allCreatedAmount"] = allCreatedAmount
        map["allRevokedAmount"] = allRevokedAmount
        map["allClosedAmount"] = allClosedAmount
        map["allProcessingAmount"] = allProcessingAmount
        map["allReceivedAmount"] = allReceivedAmount
        return map
    }
}