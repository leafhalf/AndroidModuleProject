/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.AppBarLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_PAYMENT_ALL_FILTER
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_UPDATE_PAYMENT_LIST
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.dashboard.RingData
import hk.com.hsbc.glcmdart.domain.dashboard.RingView
import hk.com.hsbc.glcmdart.domain.home.HomeActivity
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.SearchTextChangeCallback
import hk.com.hsbc.glcmdart.domain.payments.AllPaymentFilterActivity.Companion.FILTER_CURRENCY
import hk.com.hsbc.glcmdart.domain.payments.AllPaymentFilterActivity.Companion.FILTER_DATE_GT
import hk.com.hsbc.glcmdart.domain.payments.AllPaymentFilterActivity.Companion.FILTER_DATE_LT
import hk.com.hsbc.glcmdart.domain.payments.AllPaymentFilterActivity.Companion.FILTER_STATUSES
import hk.com.hsbc.glcmdart.domain.payments.AllPaymentFilterActivity.Companion.FILTER_SUPPLIER_OR_BUYER
import hk.com.hsbc.glcmdart.domain.payments.adapter.PaymentDetailAdapter
import hk.com.hsbc.glcmdart.domain.payments.contract.MyPaymentsContract
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentLocalEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.Timestap
import hk.com.hsbc.glcmdart.domain.payments.presenter.MyPaymentsViewModel
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import hk.com.hsbc.glcmdart.widget.SpacesItemDecoration
import kotlinx.android.synthetic.main.fragment_my_payments.*
import kotlinx.android.synthetic.main.fragment_my_payments.view.*
import kotlinx.android.synthetic.main.view_payment_filter_item.*

// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [MyPaymentsFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [MyPaymentsFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class MyPaymentsFragment : Fragment(), MyPaymentsContract.View, RecyclerExtras.OnItemClickListener, SwipeRefreshLayout.OnRefreshListener, SearchTextChangeCallback {
    private var param1: String? = null
    private var param2: String? = null
//    private val mPresenter by lazy { MyPaymentsPresenter() }
    private val itemList = ArrayList<PlannedPaymentLocalEntity>()
    private val mAdapter by lazy { activity?.let { PaymentDetailAdapter(it, itemList) } }
    private var mIsRefresh: Boolean = false
    private lateinit var llPaymentSummaryPointContainer: LinearLayout
    private lateinit var llPaymentSummaryChartContainer: LinearLayout
    private lateinit var llPaymentSummaryContainer: LinearLayout
    private lateinit var rvPaymentSummaryChart: RingView
    private lateinit var loadingView: ProgressBar
    private var currentSearch: String? = ""
    private var payeeOrPayor: Payee? = null
    private var currency: String? = null
    private val statuses = mutableListOf<String>()
    private var gtCondition: Timestap? = null
    private var ltCondition: Timestap? = null
    private var hasProcessingData = false
    private lateinit var mViewModel: MyPaymentsViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
        currency = MemoryCache.defaultCurrency
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val rootView = inflater.inflate(R.layout.fragment_my_payments, container, false)
        llPaymentSummaryChartContainer = rootView.ll_payment_summary_chart_container
        llPaymentSummaryPointContainer = rootView.ll_payment_summary_point_container
        llPaymentSummaryContainer = rootView.ll_payment_summary_chart_container
        rvPaymentSummaryChart = rootView.rv_payment_summary_chart_container
        loadingView = rootView.pb_loading
        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
//        mPresenter.attachView(this)
        mViewModel = ViewModelProviders.of(this).get(MyPaymentsViewModel::class.java)

        mViewModel.paymentErrorLiveData.observe(this, Observer {
            setRequestDataFailed(it ?: "")
        })

        mViewModel.myPaymentsLiveData.observe(this, Observer {
            setPlannedPaymentList(it)
        })

        loadingView.visibility = View.VISIBLE
        loadingView.announceForAccessibility(MemoryCache.getLabelText("s_loading") ?: getString(R.string.s_loading))
        currency = MemoryCache.defaultCurrency
        mViewModel.requestData(if (payeeOrPayor != null) {
            payeeOrPayor?.reference ?: ""
        } else {
            getString(R.string.s_all)
        }, currentSearch, currency, statuses, null, null, true)
    }

    private fun initView() {
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(activity)
        mAdapter?.setOnItemClickListener(this)
        rv_invoice_add_or_edit.adapter = mAdapter
        rv_invoice_add_or_edit.itemAnimator = DefaultItemAnimator()
        rv_invoice_add_or_edit.addItemDecoration(SpacesItemDecoration(activity!!, 2))
        refreshLayout.setOnRefreshListener(this)
        abl_title.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { p0, verticalOffset ->
            refreshLayout.isEnabled = verticalOffset >= 0
        })

        ib_filter.setOnClickListener {
            TealiumUtil.eventTag("button click", "landing - planned payments: filter")
            AllPaymentFilterActivity.showActivity(this, payeeOrPayor, currency, statuses,
                    gtCondition, ltCondition, REQUEST_CODE_PAYMENT_ALL_FILTER)
        }

        MemoryCache.getLabelText("s_talkback_payment_filter")?.let {
            if (!it.isBlank()) {
                ib_filter.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_all_payments")?.let {
            if (!it.isBlank()) {
                tv_my_payments_all_payment_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_no_record")?.let {
            if (!it.isBlank()) {
                tv_no_data_tag.text = it
            }
        }
    }

    override fun onItemClick(view: View, position: Int) {
        TealiumUtil.eventTag("button click", "landing - planned payments: payment selected")
        PlannedPaymentDetailActivity.showActivity(this, itemList[position].token!!, REQUEST_CODE_UPDATE_PAYMENT_LIST)
    }

    override fun onSearchTextChanged(searchText: String?) {
        TealiumUtil.eventTag("text entry", "planned payments - all payments: search bar: text entered")
        if (!mIsRefresh) {
            setRefreshState(true)
            this.currentSearch = searchText
            mViewModel.requestData(if (payeeOrPayor != null) {
                payeeOrPayor?.reference
            } else {
                getString(R.string.s_all)
            }, currentSearch, currency, statuses)
        }
    }


    override fun clearSearchEditText() {
        TealiumUtil.eventTag("button click", "planned payments - all payments: search bar: clear search")
    }

    override fun setPlannedPaymentList(map: Map<String, Any>) {
        setRefreshState(false)
        showOrDismissNoDataView(map["all"] as List<PlannedPaymentLocalEntity>)
        mAdapter?.addData(map["all"] as ArrayList<PlannedPaymentLocalEntity>)
        updateRingData(map["allCreatedAmount"] as Long, map["allClosedAmount"] as Long, map["allRevokedAmount"] as Long,
                map["allProcessingAmount"] as Long, map["allReceivedAmount"] as Long, map["allAmount"] as Long)
    }

    override fun onRefresh() {
        if (!mIsRefresh) {
            if (activity is HomeActivity) {
                this.currentSearch = (activity as HomeActivity).getCurrentSearchingContent()
            }
            setRefreshState(true)
            mViewModel.requestData(if (payeeOrPayor != null) {
                payeeOrPayor?.reference
            } else {
                getString(R.string.s_all)
            }, currentSearch, currency, statuses, gtCondition, ltCondition)
        }
    }

    override fun setRequestDataFailed(msg: String) {
        setRefreshState(false)
        itemList.clear()
        mAdapter?.notifyDataSetChanged()
        showOrDismissNoDataView(itemList)
    }

    private fun showOrDismissNoDataView(plannedPaymentLocalEntities: List<PlannedPaymentLocalEntity>) {
        if (loadingView.visibility == View.VISIBLE) {
            loadingView.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete") ?: getString(R.string.talkBack_loading_complete))
            loadingView.visibility = View.GONE
        }

        if (plannedPaymentLocalEntities.isNotEmpty()) {
            tv_no_data.visibility = View.GONE
            rv_invoice_add_or_edit.visibility = View.VISIBLE
            llPaymentSummaryContainer.visibility = View.VISIBLE
        } else {
            rv_invoice_add_or_edit.visibility = View.GONE
            tv_no_data.visibility = View.VISIBLE
            llPaymentSummaryContainer.visibility = View.GONE
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CODE_PAYMENT_ALL_FILTER -> {
                    currency = data?.getStringExtra(FILTER_CURRENCY)
                    if (data?.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) != null)
                        this.payeeOrPayor = data.getSerializableExtra(FILTER_SUPPLIER_OR_BUYER) as Payee?
                    else
                        this.payeeOrPayor = null
                    if (data?.getSerializableExtra(FILTER_STATUSES) != null) {
                        statuses.clear()
                        statuses.addAll(data.getSerializableExtra(FILTER_STATUSES) as List<String>)
                    }
                    if (data?.getSerializableExtra(FILTER_DATE_GT) != null) {
                        gtCondition = data.getSerializableExtra(FILTER_DATE_GT) as Timestap
                    }
                    if (data?.getSerializableExtra(FILTER_DATE_LT) != null) {
                        ltCondition = data.getSerializableExtra(FILTER_DATE_LT) as Timestap
                    }
                    onRefresh()
                }
                REQUEST_CODE_UPDATE_PAYMENT_LIST -> {
                    onRefresh()
                }
            }
        }
    }

    @SuppressLint("InflateParams", "SetTextI18n")
    override fun updateRingData(createAmount: Long, closedAmount: Long, revokedAmount: Long,
                                processingAmount: Long, receivedAmount: Long, totalAmount: Long) {
        if ("S" == MemoryCache.getSessionEntity()?.type) {
            llPaymentSummaryChartContainer.visibility = View.GONE
            return
        }
        if (totalAmount == 0L) {
            llPaymentSummaryChartContainer.visibility = View.GONE
        } else {
            activity?.let {
                llPaymentSummaryChartContainer.visibility = View.VISIBLE
                val map = mutableListOf("created", "revoked_payor", "closed")

                val invoiceSummaryList = mutableListOf(RingData(createAmount.toDouble() / totalAmount.toDouble(), getPaymentStatusColor("created"), null),
                        RingData(revokedAmount.toDouble() / totalAmount.toDouble(), getPaymentStatusColor("revoked_payor"), null),
                        RingData(closedAmount.toDouble() / totalAmount.toDouble(), getPaymentStatusColor("closed"), null))

                if (processingAmount != 0L) {
                    hasProcessingData = true
                    map.add("processing")
                    invoiceSummaryList.add(RingData(processingAmount.toDouble() / totalAmount.toDouble(), getPaymentStatusColor("processing"), null))
                }

                if (receivedAmount != 0L) {
                    map.add("payment_received")
                    invoiceSummaryList.add(RingData(receivedAmount.toDouble() / totalAmount.toDouble(), getPaymentStatusColor("payment_received"), null))
                }

                rvPaymentSummaryChart.setData(invoiceSummaryList)

                llPaymentSummaryPointContainer.removeAllViews()
                for (key in map) {
                    val view = LayoutInflater.from(it).inflate(R.layout.item_chart_invoice, null, false)
                    val pointView = view.findViewById<ImageView>(R.id.pointView)
                    val countText = view.findViewById<TextView>(R.id.countText)
                    val currencyText = view.findViewById<TextView>(R.id.currencyText)
                    val totalValue = when (key) {
                        "created" -> createAmount
                        "closed" -> closedAmount
                        "revoked_payor" -> revokedAmount
                        "processing" -> processingAmount
                        "payment_received" -> receivedAmount
                        else -> 0
                    }
                    pointView.setBackgroundColor(getPaymentStatusColor(key))
                    var statusText = MemoryCache.getLabelText("s_payment_status_$key")
                    if (statusText == "Processed") {
                        if (MemoryCache.defaultCountry == "IN") {
                            statusText = "Processing"
                        }
                    }
                    countText.text = statusText
                    currencyText.text = "$currency " + IndiaNumberUtil.formatNumByDecimal(totalValue.toString(), currency ?: "")
                    llPaymentSummaryPointContainer.addView(view)
                }
            }
        }
    }

    private fun getPaymentStatusColor(s: String): Int {
        return context?.let {
            when (s) {
                "created" -> ContextCompat.getColor(it, R.color.c_ring_payment_created)
                "closed" -> ContextCompat.getColor(it, R.color.c_ring_payment_closed)
                "revoked_payor" -> ContextCompat.getColor(it, R.color.c_ring_payment_revoked)
                "processing" -> ContextCompat.getColor(it, R.color.c_ring_payment_processing)
                "payment_received" -> ContextCompat.getColor(it, R.color.c_ring_payment_received)
                else -> 0xFFFFFF
            }
        } ?: 0xFFFFFF
    }

    private fun setRefreshState(b: Boolean) {
        if (b) {
            refreshLayout.announceForAccessibility(MemoryCache.getLabelText("s_loading") ?: getString(R.string.s_loading))
        } else {
            refreshLayout.announceForAccessibility(MemoryCache.getLabelText("talkBack_loading_complete") ?: getString(R.string.talkBack_loading_complete))
        }
        mIsRefresh = b
        refreshLayout.isRefreshing = b
    }


    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment MyPaymentsFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                MyPaymentsFragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM1, param1)
                        putString(ARG_PARAM2, param2)
                    }
                }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart : buyer portal : payments : planned payments - all payments",
                "/dart/buyer-portal/payments/planned payments-all payments", "transaction", "buyer portal",
                "payments")
    }
}
