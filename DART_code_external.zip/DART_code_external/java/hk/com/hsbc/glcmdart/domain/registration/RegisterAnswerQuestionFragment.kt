/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.content.Context
import android.graphics.Rect
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.Logger
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.fragment_register_answerquestion.*

class RegisterAnswerQuestionFragment : Fragment(),
        RegisterCreateNewUserProfileContract.FragmentCallback,
        View.OnClickListener,
        TextWatcher {

    companion object {
        @JvmStatic
        fun newInstance() =
                RegisterAnswerQuestionFragment()
    }

    private lateinit var mActivity: RegisterCreateNewUserProfileActivity
    private var mUpdating = false
    private var mPosition  = 0
    private var isTealiumQuestionFilled1 = false
    private var isTealiumQuestionFilled2 = false
    private var isTealiumQuestionFilled3 = false
    private val array = arrayOf("first", "second", "third")
    private var entryTag: String? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mActivity = context as RegisterCreateNewUserProfileActivity
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_register_answerquestion, container, false)
    }

    override fun onStart() {
        super.onStart()

        backButton3th.setOnClickListener(this)
        answerText.addTextChangedListener(this)
        continueButton3th.enableButton(false)
        continueButton3th.setOnButtonClickListener(this)
    }

    override fun onResume() {
        super.onResume()
        val list = mActivity.mQuestions
        val filters = list.filter {
            !it.answer.isNullOrEmpty()
        }
        val ids = mutableListOf<String>()
        filters.forEach {
            ids.add(it.id)
        }
        if (ids.contains(mActivity.mSelectedQuestion?.id)) {
            mPosition =  filters.size
            mUpdating = true
        } else {
            mPosition = filters.size + 1
            mUpdating = false
        }

        updateContentView()
        addLayoutListener(continueButton3th)

        entryTag = array[mPosition - 1]
        entryTag?.also {
            if (array.contains(tag)) {
                TealiumUtil.pageTag(
                        "dart : buyer portal : registration : $tag question entry",
                        "/dart/buyer portal/registration/$tag question entry",
                        "verification",
                        "buyer portal",
                        "registration",
                        "mobile",
                        "en",
                        "registration",
                        "registration - $tag question entry"
                )
            }
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.backButton3th -> {
                TealiumUtil.eventTag("button click", "registration: $entryTag question entry: back")
                v.also {
                    (activity as View.OnClickListener).onClick(v)
                }
            }
            R.id.tv_submit -> {
                TealiumUtil.eventTag("button click", "registration: $entryTag question entry: continue")
                val item = mActivity.mSelectedQuestion
                val preSelected = mActivity.mQuestions.filter {
                    !it.answer.isNullOrEmpty()
                }
                if (validateProfile()) {
                    item?.also {
                        it.answer = answerText.text.toString()
                        if (!it.answer.isNullOrEmpty()) {
                            val selected = mActivity.mQuestions.filter { question ->
                                !question.answer.isNullOrEmpty()
                            }
                            if (selected.size > preSelected.size) {
                                it.index = selected.size
                            }
                        }
                    }
                    (activity as View.OnClickListener).onClick(v)
                }
            }
        }
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

    }

    override fun afterTextChanged(s: Editable?) {
        when(mPosition) {
            1 -> {
                if (!isTealiumQuestionFilled1) {
                    TealiumUtil.eventTag("text entry", "registration: first question entry: answer entered")
                    isTealiumQuestionFilled1 = true
                }
            }
            2 -> {
                if (!isTealiumQuestionFilled2) {
                TealiumUtil.eventTag("text entry", "registration: second question entry: answer entered")
                isTealiumQuestionFilled2 = true
            }
            }
            3 -> {
                if (!isTealiumQuestionFilled3) {
                    TealiumUtil.eventTag("text entry", "registration: third question entry: answer entered")
                    isTealiumQuestionFilled3 = true
                }
            }
        }

        if (!answerText.text.isNullOrEmpty()) {
            continueButton3th.enableButton(true)
        } else {
            continueButton3th.enableButton(false)
        }
    }

    override fun updateContentView() {
        if (mPosition >= 3) {
            continueButton3th.setButtonText(MemoryCache.getLabelText("button_answerQuestion_register") ?: resources.getText(R.string.button_answerQuestion_register))
        } else {
            continueButton3th.setButtonText(MemoryCache.getLabelText("button_answerQuestion_continue") ?: resources.getText(R.string.button_answerQuestion_continue))
        }
        val item = mActivity.mSelectedQuestion
//        Logger.i("received item: $item")
        item?.also {
            it.caption?.also { caption ->
                val question = MemoryCache.getLabelText(caption)
                if (!question.isNullOrBlank()) {
                    questionText.text = question
                } else {
                    questionText.text = caption
                }
            }
            answerText.setText((if (it.answer.isNullOrEmpty()) "" else it.answer).toString())
        }
    }

    internal fun updateLoadingView() {
        continueButton3th.startLoadingAnimation()
    }

    internal fun removeLoadingView(flag: Boolean) {
        continueButton3th.endLoadingAnimation(flag)
        continueButton3th.enableButton(true)
        if (mPosition >= 3) {
            continueButton3th.setButtonText(MemoryCache.getLabelText("button_answerQuestion_register") ?: resources.getText(R.string.button_answerQuestion_register))
        } else {
            continueButton3th.setButtonText(MemoryCache.getLabelText("button_answerQuestion_continue") ?: resources.getText(R.string.button_answerQuestion_continue))
        }
    }

    private fun validateProfile(): Boolean {
        val answer = answerText.text?.toString()
        if (answer.isNullOrEmpty()) {
            return false
        }
        return true
    }

    private var originVisionHeight = 0
    private fun addLayoutListener(bottomView: View) {
        activity?.window?.decorView?.viewTreeObserver?.addOnGlobalLayoutListener {
            if (activity?.window == null) {
                return@addOnGlobalLayoutListener
            }

            val rect = Rect()
            activity?.window?.decorView?.getWindowVisibleDisplayFrame(rect)
            if (originVisionHeight == 0) {
                originVisionHeight = rect.height()
            }
            val invisibleHeight = originVisionHeight - rect.height()
            if (invisibleHeight > 150) {
                bottomView.animate().translationY(-invisibleHeight.toFloat()).setDuration(0).start()
            } else {
                bottomView.animate().translationY(0F).start()
            }
        }
    }
}
