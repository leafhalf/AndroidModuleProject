/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_CURRENCY
import hk.com.hsbc.glcmdart.client.TAG_INVOICE_DUE_DATE
import hk.com.hsbc.glcmdart.client.TAG_INVOICE_DUE_DATE_DEFAULT_LIST
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.view_custom_title_bar.*

/**
 * Created by Donut on 2018/11/5.
 * an activity for showing due invoice. just an activity decorate the due fragment
 * all content is from due fragment
 */
class InvoiceDueTodayActivity : BaseActivity() {

    companion object {
        fun showActivity(activity: Activity?, dueDay: String, currency: String, defaultList: ArrayList<InvoiceListItem>? = null) {
            val intent = Intent(activity, InvoiceDueTodayActivity::class.java).apply {
                putExtra(TAG_CURRENCY, currency)
                putExtra(TAG_INVOICE_DUE_DATE, dueDay)
                putExtra(TAG_INVOICE_DUE_DATE_DEFAULT_LIST, defaultList)
            }

            activity?.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invoice_due_today)
        supportActionBar?.hide()
        initViewAndData()
    }

    private fun initViewAndData() {
        iv_search_close_or_search.visibility = View.GONE
        tv_title.text = MemoryCache.getLabelText("navigation_invoices_title") ?: getString(R.string.navigation_invoices_title)
        tv_back.visibility = View.VISIBLE
        tv_back.setOnClickListener { finish() }
        tv_back.setBackgroundResource(R.drawable.ic_arrow_back_white)
        val dueDateStr = intent?.getStringExtra(TAG_INVOICE_DUE_DATE) as String
        val defaultList = intent?.getSerializableExtra(TAG_INVOICE_DUE_DATE_DEFAULT_LIST) as ArrayList<InvoiceListItem>?
        val dueDateFragment = InvoiceListDueTodayFragment.newInstance(false, dueDateStr, defaultList)
        val transaction = supportFragmentManager.beginTransaction()
        transaction.add(R.id.fl_invoice_due_container, dueDateFragment)
        transaction.show(dueDateFragment).commitAllowingStateLoss()
    }
}