package hk.com.hsbc.glcmdart.domain.forgetpassword

import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class ForgetPwdUserNameViewModel: BaseViewModel() {

    private val mModel by lazy { ForgetPwdModel() }

    val userNameValidationLiveData = MutableLiveData<ForgetCheckUserNameEntity?>()

    fun doCheckUserName(userName: String) {
        val disposable = mModel.checkUserName(userName)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    userNameValidationLiveData.postValue(it)
                },{
                    userNameValidationLiveData.postValue(null)
                })
    }
}