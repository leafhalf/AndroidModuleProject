package hk.com.hsbc.glcmdart.domain.payments.dialog

import android.app.Dialog
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.Invoice
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache

object DeductionDialog {

    fun showDialog(c: BaseActivity?, deductions: List<TaxDeductionInfo>, invoice: Invoice, pos: Int,
        callback: DeductionApplyCallback?) {

        if (c == null) {
            return
        }

        val mDialog = Dialog(c, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(c).inflate(R.layout.dialog_add_deduction, null)
        val tvDescription = mContentView.findViewById<TextView>(R.id.tv_tax_deduction_description)
        val tvTitle = mContentView.findViewById<TextView>(R.id.tv_title)
        val spApplyDeduction = mContentView.findViewById<Spinner>(R.id.sp_apply_deduction)
        val tvDeductionRate = mContentView.findViewById<TextView>(R.id.tv_deduction_approach_only)
        val tvDeductionAmount = mContentView.findViewById<TextView>(R.id.tv_deduction_amount)
        val btnCancel = mContentView.findViewById<Button>(R.id.btn_cancel)
        val btnConfirm = mContentView.findViewById<Button>(R.id.btn_confirm)
        val llDeductionInfo = mContentView.findViewById<LinearLayout>(R.id.ll_deduction_info)

        tvTitle.text = "Apply deduction"
        val deductionNames = mutableListOf<String>()
        deductions.forEach {
            deductionNames.add(it.name ?: "")
        }
        var selectedDeduction: TaxDeductionInfo? = null
        val spinnerAdapter = ArrayAdapter<String>(c, R.layout.item_simple_text, deductionNames)
        spinnerAdapter.setDropDownViewResource(R.layout.item_simple_drop_down)
        spApplyDeduction.adapter = spinnerAdapter
        spApplyDeduction.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedDeduction = deductions[position]
                llDeductionInfo.visibility = View.VISIBLE
                tvDescription.text = if (selectedDeduction?.type == "1") "Official deduction" else "Commercial dedution"
                tvDeductionRate.text = "${selectedDeduction?.maxRate} %"
                val deductionAmount = IndiaNumberUtil.formatNum((invoice.summation?.total?.amount!!.toLong() * selectedDeduction?.maxRate!!.toDouble() / 100.0 / 100.0).toLong().toString(),
                invoice.summation.subTotal?.currency ?: MARKET_CURRENCY)
                tvDeductionAmount.text = "${invoice.summation.subTotal?.currency ?: MARKET_CURRENCY} $deductionAmount"
            }

        }

        btnCancel.setOnClickListener { mDialog.cancel() }
        btnConfirm.setOnClickListener {
            mDialog.cancel()
            if (selectedDeduction != null) {
                selectedDeduction?.actualAmount = (invoice.summation?.total?.amount!!.toLong() * selectedDeduction?.maxRate!!.toDouble() / 100.0 ).toLong().toString()
                callback?.onDeductionSelected(selectedDeduction!!, pos)
            }
        }

        mDialog.setContentView(mContentView)
        mDialog.setCanceledOnTouchOutside(true)
        mDialog.setCancelable(true)
        mDialog.show()
    }

    interface DeductionApplyCallback {
        fun onDeductionSelected(deduction: TaxDeductionInfo, callerPosition: Int)
    }
}