/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.payments.adapter.PaymentsPagerAdapter
import hk.com.hsbc.glcmdart.domain.payments.contract.PaymentsContract
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.fragment_payments.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [PaymentsFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [PaymentsFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class PaymentsFragment : Fragment(), PaymentsContract.View, TabLayout.OnTabSelectedListener {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var listener: OnFragmentInteractionListener? = null
    private var titles: MutableList<String>? = null
    private val mPaymentsDueDayFragment = PaymentsDueDayFragment.newInstance(true, null)
    private val mMyPaymentFragment = MyPaymentsFragment.newInstance("", "")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_payments, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initTabLayout()
        initTabViewPager()
        initOtherView()
    }

    private fun initTabLayout() {
        titles = mutableListOf(MemoryCache.getLabelText("payments_first_tab") ?: getString(R.string.payments_first_tab),
                MemoryCache.getLabelText("payments_second_tab") ?: getString(R.string.payments_second_tab))
        tab_title.addTab(tab_title.newTab().setText(titles?.get(0)))
        tab_title.addTab(tab_title.newTab().setText(titles?.get(1)))
        tab_title.addOnTabSelectedListener(this)
    }

    private fun initTabViewPager() {
        val fragments = listOf<Fragment>(mPaymentsDueDayFragment, mMyPaymentFragment)
        vp_content.adapter = PaymentsPagerAdapter(activity!!.supportFragmentManager, titles!!, fragments)
        vp_content.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) {
                tab_title.getTabAt(position)?.select()
            }
        })
    }

    private fun initOtherView() {

    }

    override fun onTabReselected(p0: TabLayout.Tab?) {}

    override fun onTabUnselected(p0: TabLayout.Tab?) {}

    override fun onTabSelected(tab: TabLayout.Tab?) {
        vp_content.currentItem = tab?.position ?: 0
        if (tab?.position == 0) {
            TealiumUtil.eventTag("tab", "landing - planned payments: payments due")
            TealiumUtil.eventTag("tab", "planned payments: payments due selected")
        } else {
            TealiumUtil.eventTag("tab", "landing - planned payments: all payments")
            TealiumUtil.eventTag("tab", "planned payments: all payments selected")
        }
    }

    fun changeSearchText(searchText: String?) {
        if (vp_content.currentItem == 0) {
            mPaymentsDueDayFragment.onSearchTextChanged(searchText)
        } else {
            mMyPaymentFragment.onSearchTextChanged(searchText)
        }
    }

    fun clearSearchEditText() {
        if (vp_content.currentItem == 0) {
            mPaymentsDueDayFragment.clearSearchEditText()
        } else {
            mMyPaymentFragment.clearSearchEditText()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnFragmentInteractionListener) {
            listener = context
        } else {
//            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     *
     * See the Android Training lesson [Communicating with Other Fragments]
     * (http://developer.android.com/training/basics/fragments/communicating.html)
     * for more information.
     */
    interface OnFragmentInteractionListener

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment PaymentsFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                PaymentsFragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM1, param1)
                        putString(ARG_PARAM2, param2)
                    }
                }
    }
}
