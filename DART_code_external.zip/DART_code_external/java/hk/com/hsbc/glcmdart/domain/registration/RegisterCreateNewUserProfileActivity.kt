/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_ANSWER_SECURITY_QUESTION_INFO
import hk.com.hsbc.glcmdart.client.TAG_INVITATION_CODE
import hk.com.hsbc.glcmdart.domain.dart.CommonDialog
import hk.com.hsbc.glcmdart.domain.login.LoginActivity
import hk.com.hsbc.glcmdart.domain.welcome.WelcomeActivity
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.Logger
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_register_createnewuserprofile.*

class RegisterCreateNewUserProfileActivity : BaseActivity(),
        RegisterCreateNewUserProfileContract.View,
        RegisterCreateNewUserProfileContract.ActivityCallback,
        View.OnClickListener {

    override fun getInvitationCode(): String? {
        return mInvitationCode
    }

    override fun getRegistrationChallengeEntity(): RegistrationChallengeEntity? {
        return mRegistrationChallengeEntity
    }

    override fun getQuestions(): MutableList<Question>? {
        return mQuestions
    }

    override fun getUsernameValidationBean(): UsernameValidationBean? {
        return mUsernameValidationBean
    }

    override fun getProfileCreationBean(): ProfileCreationBean? {
        return mProfileCreationBean
    }

    private lateinit var mViewModel: RegisterCreateProfileViewModel
    //    private val mPresenter by lazy { RegisterCreateNewUserProfilePresenter() }
    private var mInvitationCode: String? = null
    private var mRegistrationChallengeEntity: RegistrationChallengeEntity? = null
    private var mToken: String? = null
    internal val mQuestions = mutableListOf<Question>()
    internal var mSelectedQuestion: Question? = null
    internal var mUsernameValidationBean: UsernameValidationBean? = null
    private var mProfileCreationBean: ProfileCreationBean? = null
    private var isSuccessfully = false

    private val mRegisterUserInformationFragment by lazy { RegisterUserInformationFragment.newInstance() }
    private val mRegisterUserAccountRecoveryFragment by lazy { RegisterUserAccountRecoveryFragment.newInstance() }
    private val mRegisterAnswerQuestionFragment by lazy { RegisterAnswerQuestionFragment.newInstance() }
    private val mRegisterSuccessfullyFragment by lazy { RegisterSuccessfullyFragment.newInstance(false, "", mRegistrationChallengeEntity?.payload?.userType ?: "B") }
    private var mCurrentFragment: Fragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_createnewuserprofile)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        mLayout.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)
        removeStatusView(this)
//        registerPresenter(mPresenter as IPresenter<*>)

        mViewModel = ViewModelProviders.of(this).get(RegisterCreateProfileViewModel::class.java)
        mViewModel.showCreationViewLiveData.observe(this, Observer {
            showCreationView(it)
        })
        mViewModel.expirationLiveData.observe(this, Observer {
            showSessionExpiredDialog()
        })
        mViewModel.questionsLiveData.observe(this, Observer {
            showRequestView(it)
        })
        mViewModel.validationLiveData.observe(this, Observer {
            showValidationView(it, it != null)
        })
        intent?.also {
            mInvitationCode = it.getStringExtra(TAG_INVITATION_CODE)
            mRegistrationChallengeEntity = it.getSerializableExtra(TAG_ANSWER_SECURITY_QUESTION_INFO) as RegistrationChallengeEntity
            mToken = mRegistrationChallengeEntity?.payload?.ChallengeToken
        }

        showFragment(mRegisterUserInformationFragment)

        mInvitationCode?.also {
            mViewModel.doRequest()
        }
    }

    override fun onBackPressed() {
        if (isSuccessfully) {
            startActivity(Intent(this, WelcomeActivity::class.java).let {
                it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                it
            })
            finish()
        } else {
            super.onBackPressed()
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.backButton1st -> {// User information: back
                finish()
            }
            R.id.continueButton1st -> {// User information: continue
                v.also {
                    val bean = v.tag as UsernameValidationBean
                    showLoadingDialogExt()
                    mViewModel.doValidation(mInvitationCode ?: "", mToken ?: "", bean)
                }
            }
            R.id.backButton2nd -> {// User account recovery: back
                finish()
            }
            R.id.backButton3th -> {// Answer question: back
                val selected = mQuestions.filter {
                    !it.answer.isNullOrEmpty()
                }
                if (selected.size == 3) {
                    finish()
                } else {
                    showFragment(mRegisterUserAccountRecoveryFragment)
                }
            }
            R.id.tv_submit -> {// Answer question: submit
                mSelectedQuestion = null
                val selected = mQuestions.filter {
                    !it.answer.isNullOrEmpty()
                }
                if (selected.isNotEmpty() && selected.size >= 3) {
                    val answers = mutableListOf<Answer>()
                    for (value in selected) {
                        val item = Answer(index = value.index ?: -1, id = value.id, caption = value.answer ?: "")
                        answers.add(item)
                    }
                    val entity = mRegistrationChallengeEntity?.payload
                    val firstName = if ("B" == entity?.userType) entity.buyerFirstName else entity?.supplierSalesFirstName
                    val lastName = if ("B" == entity?.userType) entity.buyerLastName else entity?.supplierSalesLastName
                    val email = if ("B" == entity?.userType) entity.emailAddress else entity?.supplierSalesEmailAddress
                    val payorId =  if ("B" == entity?.userType) entity.payorID else entity?.customerID
                    val bean = ProfileCreationBean(invitationCode = mInvitationCode ?: "",
                            user = mUsernameValidationBean?.username ?: "",
                            password = mUsernameValidationBean?.password ?: "",
                            userDisplayName = "$firstName $lastName",
                            firstName = firstName ?: "",
                            lastName = lastName ?: "",
                            payorReference = payorId,
                            payeeReference = entity?.customerID ?: "",
                            accounts = mutableListOf(),
                            mail = email ?: "",
                            email = email ?: "",
                            answers = answers)
                    mRegisterAnswerQuestionFragment.updateLoadingView()
                    mViewModel.doCreation(mInvitationCode ?: "", mToken ?: "", bean)
                } else {
                    showFragment(mRegisterUserAccountRecoveryFragment)
                }
            }
            R.id.deleteButton -> {// Register successfully: delete
                startActivity(Intent(this, WelcomeActivity::class.java).let {
                    ApplicationManager.finishActivity(RegisterMainActivity::class.java)
                    finish()
                    it
                })
            }
            R.id.logonButton -> {// Register successfully: log on
                startActivity(Intent(this, LoginActivity::class.java).let {
                    ApplicationManager.finishActivity(RegisterMainActivity::class.java)
                    finish()
                    it
                })
            }
            else -> {// User account: item
                v.also {
                    val id = it?.tag
                    if (id is String) {
                        mSelectedQuestion = mQuestions.filter {
                            it.id.contentEquals(id)
                        }[0]
//                        Logger.i("clicked item: $mSelectedQuestion")
                        val selected = mQuestions.filter {
                            !it.answer.isNullOrEmpty()
                        }
                        if (selected.isEmpty() || selected.size < 3) {
                            val questionIndex = when (selected.size) {
                                0 -> "first"
                                1 -> "second"
                                2 -> "third"
                                else -> "first"
                            }
                            val questionContent = mSelectedQuestion?.caption
                            TealiumUtil.eventTag("button click", "registration: choose $questionIndex question: $questionContent")
                            showFragment(mRegisterAnswerQuestionFragment)
                        }
                    }
                }
            }
        }
    }

    private fun showFragment(fragment: Fragment) {
        val array = arrayOf(RegisterUserInformationFragment::class.java.canonicalName,
                RegisterUserAccountRecoveryFragment::class.java.canonicalName,
                RegisterAnswerQuestionFragment::class.java.canonicalName,
                RegisterSuccessfullyFragment::class.java.canonicalName)
        val currentIndex = mCurrentFragment?.let {
            array.indexOf(it.javaClass.canonicalName)
        }
        val newIndex = array.indexOf(fragment.javaClass.canonicalName)
        val transaction = supportFragmentManager
                .beginTransaction()
                .replace(R.id.mLayout, fragment)
        when {
            currentIndex == null || currentIndex == newIndex -> {
                transaction.setTransition(FragmentTransaction.TRANSIT_NONE)
            }
            newIndex > currentIndex -> {
                transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
            }
            newIndex < currentIndex -> {
                transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_CLOSE)
            }
        }
        transaction.commitAllowingStateLoss()
        mCurrentFragment = fragment
    }

    override fun showRequestView(list: List<Question>) {
        list.also {
            mQuestions.clear()
            mQuestions.addAll(it)
        }
    }

    override fun showValidationView(body: UsernameValidationBean?, flag: Boolean?) {
        hideLoadingDialogExt()
        when (flag) {
            true -> {
                mUsernameValidationBean = body
                showFragment(mRegisterUserAccountRecoveryFragment)
            }
            false -> {
                mRegisterUserInformationFragment.updateErrorView()
            }
            else -> {
                // showLongToast("Server error!")
            }
        }
    }

    override fun showCreationView(flag: Boolean) {
        if (flag) {
            isSuccessfully = true
            mRegisterAnswerQuestionFragment.removeLoadingView(true)
            showFragment(mRegisterSuccessfullyFragment)
        } else {
            mRegisterAnswerQuestionFragment.removeLoadingView(false)
        }
    }

    override fun showRegisterExpiredDialog() {
        CommonDialog.showDialog(this, getString(R.string.s_register_expired_dialog_title),
                getString(R.string.s_register_expired_dialog_msg), getString(R.string.s_register_expired_dialog_register),
                getString(R.string.s_register_expired_dialog_quit), View.OnClickListener {
            ApplicationManager.finishOtherActivities(RegisterCreateNewUserProfileActivity::class.java)
            RegisterTAndCActivity.showActivity(this, isFromRegister = true)
            finish()
        }, View.OnClickListener {
            ApplicationManager.finishOtherActivities(RegisterCreateNewUserProfileActivity::class.java)
            startActivity(Intent(this, WelcomeActivity::class.java))
            finish()
        })
    }
}

