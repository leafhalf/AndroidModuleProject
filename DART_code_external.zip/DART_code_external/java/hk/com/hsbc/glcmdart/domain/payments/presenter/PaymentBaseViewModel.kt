package hk.com.hsbc.glcmdart.domain.payments.presenter

import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.payments.model.PaymentsModel
import hk.com.hsbc.glcmdart.framework.BaseViewModel

abstract class PaymentBaseViewModel: BaseViewModel() {

    protected val paymentsModel: PaymentsModel by lazy { PaymentsModel() }

    val paymentErrorLiveData = MutableLiveData<String?>()
}