/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.calendar

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.calendar.BaseMonthView
import hk.com.hsbc.glcmdart.calendar.BaseWeekView
import hk.com.hsbc.glcmdart.calendar.Calendar
import hk.com.hsbc.glcmdart.calendar.CalendarView
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.calendar.CalendarFilterActivity.Companion.REQUEST_CODE_CALENDAR_FILTER
import hk.com.hsbc.glcmdart.domain.dart.CalendarListItem
import hk.com.hsbc.glcmdart.domain.dart.ITP
import hk.com.hsbc.glcmdart.domain.dart.ITPListItem
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.domain.dashboard.RingData
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceDueTodayActivity
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentDueDayActivity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentList
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.json
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.util.*
import hk.com.hsbc.glcmdart.widget.CubeOutTransformer
import kotlinx.android.synthetic.main.fragment_calendar.*
import kotlinx.android.synthetic.main.fragment_calendar.view.*
import kotlinx.android.synthetic.main.item_calendar_summary.view.*
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.atomic.AtomicBoolean

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class CalendarFragment : Fragment(),
        CalendarContract.View,
        View.OnClickListener,
        CalendarView.OnCalendarSelectListener,
        CalendarView.OnViewChangeListener,
        CalendarView.OnMonthChangeListener,
        CalendarView.OnWeekChangeListener {

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                CalendarFragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM1, param1)
                        putString(ARG_PARAM2, param2)
                    }
                }
    }

    private var isLoading: Boolean = false
    private var param1: String? = null
    private var param2: String? = null
//    private val presenter by lazy { CalendarPresenter() }
    private var mCurrentMonthView: BaseMonthView? = null
    private var mCurrentWeekView: BaseWeekView? = null
    private var mSelectedCountry: String? = MemoryCache.defaultCountry
    private var mSelectedCurrency: String? = MemoryCache.defaultCurrency
    private lateinit var rootView: View
    private lateinit var mViewModel: CalendarViewModel
    private var isDateChangeDueToMonthChangePre = false
    private var isDateChangeDueToMonthChangeNext = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.also {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val buttonAccessibilityDelegate = object : View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        }

        // Initialize view
        rootView = inflater.inflate(R.layout.fragment_calendar, container, false)
        mViewModel = ViewModelProviders.of(this).get(CalendarViewModel::class.java)
        MemoryCache.getLabelText("talkBack_lastPage")?.let {
            if (!it.isBlank()) {
                rootView.calendarLeftImage.contentDescription = it
            }
        }
        MemoryCache.getLabelText("talkBack_lastDay")?.let {
            if (!it.isBlank()) {
                rootView.calendarLeftSecImage.contentDescription = it
            }
        }
        MemoryCache.getLabelText("talkBack_nextPage")?.let {
            if (!it.isBlank()) {
                rootView.calendarRightImage.contentDescription = it
            }
        }
        MemoryCache.getLabelText("talkBack_nextDay")?.let {
            if (!it.isBlank()) {
                rootView.calendarRightSecImage.contentDescription = it
            }
        }
        MemoryCache.getLabelText("message_calendar_payment")?.let {
            if (!it.isBlank()) {
                rootView.markPaymentDueText.text = it
            }
        }
        MemoryCache.getLabelText("message_calendar_invoice")?.let {
            if (!it.isBlank()) {
                rootView.markInvoiceDueText.text = it
            }
        }
        MemoryCache.getLabelText("message_calendar_no_items")?.let {
            if (!it.isBlank()) {
                rootView.noItemsText.text = it
            }
        }
        MemoryCache.getLabelText("message_calendar_go")?.let {
            if (!it.isBlank()) {
                rootView.nextItemButton.text = it
            }
        }
        MemoryCache.getLabelText("head_calendar_invoice")?.let {
            if (!it.isBlank()) {
                rootView.tv_invoice_calendar_more_detail_title.text = it
            }
        }
        MemoryCache.getLabelText("content_calendar_invoice")?.let {
            if (!it.isBlank()) {
                rootView.invoiceNumberTitle.text = it
            }
        }
        MemoryCache.getLabelText("content_calendar_amount")?.let {
            if (!it.isBlank()) {
                rootView.invoiceAmountTop.text = it
            }
        }
        MemoryCache.getLabelText("head_calendar_payment")?.let {
            if (!it.isBlank()) {
                rootView.tv_payment_calendar_more_detail_title.text = it
            }
        }
        MemoryCache.getLabelText("content_calendar_payment")?.let {
            if (!it.isBlank()) {
                rootView.paymentNumberTitle.text = it
            }
        }
        MemoryCache.getLabelText("content_calendar_amount")?.let {
            if (!it.isBlank()) {
                rootView.paymentAmountTop.text = it
            }
        }

        rootView.currencyText.text = String.format(MemoryCache.getLabelText("head_currency") ?: getString(R.string.head_currency), mSelectedCurrency)
        rootView.currencyText.setOnClickListener {
            CalendarFilterActivity.showActivity(this, mSelectedCurrency, REQUEST_CODE_CALENDAR_FILTER)
        }
        rootView.calendarView.setMonthView(CalendarMonthView::class.java)
        rootView.calendarView.setWeekView(CalendarWeekView::class.java)
        rootView.calendarView.setWeekBar(CalendarWeekBar::class.java)
        val minYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        val minMonth = java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1
        val minDay = 1
        rootView.calendarView.setRange(minYear, minMonth, minDay, minYear + 20, minMonth, minDay)
        val banDateList = mutableListOf<String>()
        val todayDay = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_MONTH)
        for (i in 1 until todayDay) {
            val banDate = "$minYear-" +
                    (if (minMonth < 10) "0$minMonth" else minMonth.toString()) + "-" +
                    (if (i < 10) "0$i" else i.toString())
            banDateList.add(banDate)
        }
        rootView.calendarView.setBanList(banDateList)

        rootView.calendarView.setOnCalendarSelectListener(this)
        rootView.calendarView.setOnViewChangeListener(this)
        rootView.calendarView.setOnMonthChangeListener(this)
        rootView.calendarView.setOnWeekChangeListener(this)

        rootView.calendarLeftImage.setOnClickListener(this)
        rootView.calendarRightImage.setOnClickListener(this)
        rootView.calendarLeftSecImage.setOnClickListener(this)
        rootView.calendarRightSecImage.setOnClickListener(this)
        rootView.invoiceLayout.setOnClickListener(this)
        rootView.paymentLayout.setOnClickListener(this)
        rootView.nextItemButton.setOnClickListener(this)
        rootView.expandButton.setOnClickListener(this)

        rootView.calendarLeftImage.setAccessibilityDelegate(buttonAccessibilityDelegate)
        rootView.calendarRightImage.setAccessibilityDelegate(buttonAccessibilityDelegate)
        rootView.calendarLeftSecImage.setAccessibilityDelegate(buttonAccessibilityDelegate)
        rootView.calendarRightSecImage.setAccessibilityDelegate(buttonAccessibilityDelegate)
        rootView.invoiceLayout.setAccessibilityDelegate(buttonAccessibilityDelegate)
        rootView.paymentLayout.setAccessibilityDelegate(buttonAccessibilityDelegate)
        rootView.nextItemButton.setAccessibilityDelegate(buttonAccessibilityDelegate)

        rootView.vp_calendar_summary_container.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {

            override fun onPageScrollStateChanged(p0: Int) {
            }

            override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {
            }

            override fun onPageSelected(position: Int) {
                activity?.let {
                    v_home_summary_tip_first.setBackgroundColor(ContextCompat.getColor(it, R.color.light_gray))
                    v_home_summary_tip_second.setBackgroundColor(ContextCompat.getColor(it, R.color.light_gray))
                    v_home_summary_tip_third.setBackgroundColor(ContextCompat.getColor(it, R.color.light_gray))
                    when (position) {
                        0 -> v_home_summary_tip_first.setBackgroundColor(ContextCompat.getColor(it, R.color.primary_red))
                        1 -> v_home_summary_tip_second.setBackgroundColor(ContextCompat.getColor(it, R.color.primary_red))
                        2 -> v_home_summary_tip_third.setBackgroundColor(ContextCompat.getColor(it, R.color.primary_red))
                    }
                }
            }
        })

        rootView.vp_calendar_summary_container.setPageTransformer(true, CubeOutTransformer(60f))
        // Request data
        showLoadingDialogExt()
        mViewModel.calendarLiveData.observe(this, Observer{
            setLoading(false)
            showContentView(it)
        })
        mViewModel.requestLoadingLiveData.observe(this, Observer {
            if (it) {
                showLoadingDialogExt()
            } else {
                hideLoadingDialogExt()
            }
        })
        mViewModel.exceptionLiveData.observe(this, Observer {
            setLoading(false)
            Toast.makeText(activity, it, Toast.LENGTH_SHORT).show()
        })
        mViewModel.doRequest(mSelectedCurrency, mSelectedCountry)
//        presenter.attachView(this)
//        presenter.doRequest(mSelectedCurrency, mSelectedCountry)

        rootView.srl_refresher.setOnRefreshListener {
            setLoading(true)
            mViewModel.doRequest(mSelectedCurrency, mSelectedCountry)
        }

        rootView.nestedScrollView.viewTreeObserver.addOnScrollChangedListener {
            rootView.srl_refresher.isEnabled = rootView.nestedScrollView.scrollY == 0
        }
        return rootView
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK && REQUEST_CODE_CALENDAR_FILTER == requestCode) {
            if (data?.getStringExtra(CalendarFilterActivity.FILTER_CURRENCY) != null) {
                mSelectedCurrency = data.getStringExtra(CalendarFilterActivity.FILTER_CURRENCY)
                mSelectedCountry = data.getStringExtra(CalendarFilterActivity.FILTER_COUNTRY)
                rootView.currencyText.text = String.format(MemoryCache.getLabelText("head_currency") ?: getString(R.string.head_currency), mSelectedCurrency)
            }
            // Request data
            showLoadingDialogExt()
            mViewModel.doRequest(mSelectedCurrency, mSelectedCountry)
//            presenter.doRequest(mSelectedCurrency, mSelectedCountry)
        }
    }

    private fun setLoading(loadingFlag: Boolean) {
        isLoading = loadingFlag
        srl_refresher?.isRefreshing = loadingFlag
    }

    private fun setMarkLayoutHeight(percent: Float) {
        val totalHeight = ConvertUtil.dp2px(activity, 56F)
        val params = markLayout.layoutParams as FrameLayout.LayoutParams?
        if (params != null) {
            params.height = (totalHeight * percent).toInt()
            markLayout.layoutParams = params
        }
    }

    override fun onCalendarSelect(calendar: Calendar?, isClick: Boolean) {
//        Logger.i("calendar selected: ${calendar.toString()}/$isClick")
        mPreSelectedCalendar = mSelectedCalendar
        mSelectedCalendar = calendar
        mNextCalendar = getNextCalendar()
        switchCalendarText()
        mSelectedCalendar?.also {
            val scheme = it.scheme
            when {
                scheme != null && "1".contentEquals(scheme) -> {
                    invoiceLayout.visibility = View.VISIBLE
                    paddingView.visibility = View.GONE
                    paymentLayout.visibility = View.GONE
                    bottomView.visibility = View.VISIBLE

                    noItemsLayout.visibility = View.GONE
                    nextItemsLayout.visibility = View.GONE

                    showInvoiceAndPayment()
                }
                scheme != null && "2".contentEquals(scheme) -> {
                    invoiceLayout.visibility = View.GONE
                    paddingView.visibility = View.GONE
                    paymentLayout.visibility = View.VISIBLE
                    bottomView.visibility = View.VISIBLE

                    noItemsLayout.visibility = View.GONE
                    nextItemsLayout.visibility = View.GONE

                    showInvoiceAndPayment()

                }
                scheme != null && "3".contentEquals(scheme) -> {
                    invoiceLayout.visibility = View.VISIBLE
                    paddingView.visibility = View.VISIBLE
                    paymentLayout.visibility = View.VISIBLE
                    bottomView.visibility = View.GONE

                    noItemsLayout.visibility = View.GONE
                    nextItemsLayout.visibility = View.GONE

                    showInvoiceAndPayment()
                }
                mNextCalendar != null -> {
                    invoiceLayout.visibility = View.GONE
                    paddingView.visibility = View.GONE
                    paymentLayout.visibility = View.GONE
                    bottomView.visibility = View.GONE

                    noItemsLayout.visibility = View.GONE
                    nextItemsLayout.visibility = View.VISIBLE

                    showNextCalendar()
                }
                mNextCalendar == null -> {
                    invoiceLayout.visibility = View.GONE
                    paddingView.visibility = View.GONE
                    paymentLayout.visibility = View.GONE
                    bottomView.visibility = View.GONE

                    noItemsLayout.visibility = View.VISIBLE
                    if (mCalendarGroup.isEmpty()) {
                        noItemsText.visibility = View.GONE
                    } else {
                        noItemsText.visibility = View.VISIBLE
                    }
                    nextItemsLayout.visibility = View.GONE
                }
            }
        }
        mSelectedCalendar?.also { c ->
            val date = java.util.Calendar.getInstance().also { a ->
                a.set(java.util.Calendar.YEAR, c.year)
                a.set(java.util.Calendar.MONTH, c.month - 1)
                a.set(java.util.Calendar.DAY_OF_MONTH, c.day)
            }.time
            val text = SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH).format(date)

            val formatDate = getDateFromCalendar(c)
            val item = mCalendarGroup[formatDate]
            val invoices = item?.dueInvoices
            val payments = item?.expectedPayments

            when {
                invoices != null && invoices.size > 0 && payments != null && payments.size > 0 -> {
                    calendarText.announceForAccessibility(MemoryCache.getLabelText("talkBack_select_date_both") ?: resources.getString(R.string.talkBack_select_date_both, text))
                }
                invoices != null && invoices.size > 0 -> {
                    calendarText.announceForAccessibility(MemoryCache.getLabelText("talkBack_select_date_invoice") ?: resources.getString(R.string.talkBack_select_date_invoice, text))
                }
                payments != null && payments.size > 0 -> {
                    calendarText.announceForAccessibility(MemoryCache.getLabelText("talkBack_select_date_payment") ?: resources.getString(R.string.talkBack_select_date_payment, text))
                }
                else -> {
                    calendarText.announceForAccessibility(MemoryCache.getLabelText("talkBack_select_date_none") ?: resources.getString(R.string.talkBack_select_date_none, text))
                }
            }
        }
    }

    override fun onCalendarOutOfRange(calendar: Calendar?) {
//        Logger.i("calendar range selected: ${calendar.toString()}")
    }

    override fun onViewChange(isMonthView: Boolean) {
        this.isMonthView.set(isMonthView)
//        Logger.i("calendar view changed: $isMonthView")
        context?.let {
            if (isMonthView) {
                expandButton.setImageDrawable(ContextCompat.getDrawable(it, R.drawable.ic_calendar_collapse))
                markLayout.visibility = View.VISIBLE
                setMarkLayoutHeight(1F)
                expandButton.contentDescription = MemoryCache.getLabelText("talkBack_collapse") ?: getString(R.string.talkBack_collapse)
            } else {
                expandButton.setImageDrawable(ContextCompat.getDrawable(it, R.drawable.ic_calendar_expand))
                markLayout.visibility = View.GONE
                setMarkLayoutHeight(0F)
                expandButton.contentDescription = MemoryCache.getLabelText("talkBack_expand") ?: getString(R.string.talkBack_expand)
            }
        }
        switchCalendarText()
    }

    override fun onMonthChange(year: Int, month: Int, itemView: BaseMonthView?) {
//        Logger.i("calendar month changed: $year-$month")
        itemView?.also {
            mCurrentMonthView  = itemView
        }
        mMonthCalendar = Calendar().also {
            it.year = year
            it.month = month
        }
        if (isMonthView.get()) {
            mSelectedCalendar = Calendar().also {
                it.year = year
                it.month = month
                val calendarInstance = java.util.Calendar.getInstance()
                if (isDateChangeDueToMonthChangePre) {
                    calendarInstance.set(java.util.Calendar.YEAR, it.year)
                    calendarInstance.set(java.util.Calendar.MONTH, it.month - 1)
                    it.day = calendarInstance.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
                    isDateChangeDueToMonthChangePre = false
                } else if (isDateChangeDueToMonthChangeNext) {
                    it.day = 1
                    isDateChangeDueToMonthChangeNext = false
                } else {
                    it.day = calendarInstance.get(java.util.Calendar.DAY_OF_MONTH)
                }
            }
            mSelectedCalendar?.also {
                calendarView.scrollToCalendar(it.year, it.month, it.day, false)
            }
        }
        switchCalendarText()
        announceMonthView(year, month)
    }

    private fun announceMonthView(year: Int, month: Int) {
        mCurrentMonthView?.also {
            val selectedMonth = "$year-${DecimalFormat("00").format(month)}"
            val selectedGroup = mCalendarGroup.filter {
                it.key.contains(selectedMonth)
            }
            val text = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(SimpleDateFormat("yyyy-MM").parse(selectedMonth).time)
            val contentDescription = StringBuffer()
            if (selectedGroup.isNotEmpty()) {
                contentDescription.append(MemoryCache.getLabelText("talkBack_scroll_month") ?: resources.getString(R.string.talkBack_scroll_month, text))
                val keys = selectedGroup.keys.sorted()
                keys.forEach { key ->
                    val text =java.util.Calendar.getInstance().let {
                        it.time = SimpleDateFormat("yyyy-MM-dd").parse(key)
                        it
                    }.get(java.util.Calendar.DAY_OF_MONTH).toString()
                    val item = selectedGroup[key]
                    val invoices = item?.dueInvoices
                    val payments = item?.expectedPayments
                    val contentDescriptionItem = when {
                        invoices != null && invoices.size > 0 && payments != null && payments.size > 0 -> {
                            MemoryCache.getLabelText("talkBack_select_day_both") ?: resources.getString(R.string.talkBack_select_day_both, text)
                        }
                        invoices != null && invoices.size > 0 -> {
                            MemoryCache.getLabelText("talkBack_select_day_invoice") ?: resources.getString(R.string.talkBack_select_day_invoice, text)
                        }
                        payments != null && payments.size > 0 -> {
                            MemoryCache.getLabelText("talkBack_select_day_payment") ?: resources.getString(R.string.talkBack_select_day_payment, text)
                        }
                        else -> {
                            null
                        }
                    }
                    contentDescriptionItem?.also {
                        contentDescription.append(", $it")
                    }
                }
            } else {
                contentDescription.append(MemoryCache.getLabelText("talkBack_scroll_month_none") ?: resources.getString(R.string.talkBack_scroll_month_none, text))
            }
            it.setAccessibilityDelegate(object : View.AccessibilityDelegate() {

                override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info?.className = TextView::class.java.name
                    host?.isClickable = false
                    host?.isLongClickable = false
                }
            })
            it.contentDescription = contentDescription.toString()
        }
    }

    override fun onWeekChange(weekCalendars: MutableList<Calendar>?, itemView: BaseWeekView?) {
//        Logger.i("calendar week changed: ${weekCalendars?.size}")
        itemView?.also {
            mCurrentWeekView  = itemView
        }
        weekCalendars?.also {
            mWeekCalendars.clear()
            mWeekCalendars.addAll(it)
        }
        switchCalendarText()
    }

    override fun onClick(v: View?) {
        when (v) {
            calendarLeftImage -> {
                calendarView.scrollToPre(true)
                /*mSelectedCalendar?.also {
                    val year = it.year
                    val month = it.month
                    if (month == 1) {
                        calendarView.scrollToCalendar(year - 1, 12, 1, true)
                    } else {
                        calendarView.scrollToCalendar(year, month - 1, 1, true)
                    }
                }*/
            }
            calendarRightImage -> {
                calendarView.scrollToNext(true)
                /*mSelectedCalendar?.also {
                    val year = it.year
                    val month = it.month
                    if (month == 12) {
                        calendarView.scrollToCalendar(year + 1, 1, 1, true)
                    } else {
                        calendarView.scrollToCalendar(year, month + 1, 1, true)
                    }
                }*/
            }
            calendarLeftSecImage -> {
                val currentYear = mSelectedCalendar?.year
                val currentMonth = mSelectedCalendar?.month
                val currentDay = mSelectedCalendar?.day
                val calendarInstance = java.util.Calendar.getInstance()
                if (calendarInstance.get(java.util.Calendar.YEAR) == currentYear &&
                        calendarInstance.get(java.util.Calendar.MONTH) == ((currentMonth ?: 0) - 1) &&
                        calendarInstance.get(java.util.Calendar.DAY_OF_MONTH) == currentDay) {
                    return
                }
                isDateChangeDueToMonthChangePre = currentDay == calendarInstance.getActualMinimum(java.util.Calendar.DAY_OF_MONTH)
                mSelectedCalendar?.also {
                    val now = java.util.Calendar.getInstance()
                    now.set(java.util.Calendar.YEAR, it.year)
                    now.set(java.util.Calendar.MONTH, it.month - 1)
                    now.set(java.util.Calendar.DAY_OF_MONTH, it.day)
                    now.set(java.util.Calendar.DATE, now.get(java.util.Calendar.DATE) - 1)
                    it.year = now.get(java.util.Calendar.YEAR)
                    it.month = now.get(java.util.Calendar.MONTH) + 1
                    it.day = now.get(java.util.Calendar.DAY_OF_MONTH)
                }
                mSelectedCalendar?.also {
                    calendarView.scrollToCalendar(it.year, it.month, it.day, true)
                }
            }
            calendarRightSecImage -> {
                val currentDay = mSelectedCalendar?.day
                val calendarInstance = java.util.Calendar.getInstance()
                isDateChangeDueToMonthChangeNext = currentDay == calendarInstance.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
                mSelectedCalendar?.also {
                    val now = java.util.Calendar.getInstance()
                    now.set(java.util.Calendar.YEAR, it.year)
                    now.set(java.util.Calendar.MONTH, it.month - 1)
                    now.set(java.util.Calendar.DAY_OF_MONTH, it.day)
                    now.set(java.util.Calendar.DATE, now.get(java.util.Calendar.DATE) + 1)
                    it.year = now.get(java.util.Calendar.YEAR)
                    it.month = now.get(java.util.Calendar.MONTH) + 1
                    it.day = now.get(java.util.Calendar.DAY_OF_MONTH)
                }
                mSelectedCalendar?.also {
                    calendarView.scrollToCalendar(it.year, it.month, it.day, true)
                }
            }
            invoiceLayout -> {
                mSelectedCalendar?.also {
                    val date = getDateFromCalendar(it)
                    val item = mCalendarGroup[date]
                    val list = item?.dueInvoices
                    val array = ArrayList<InvoiceListItem>()
                    list?.also { itemList ->
                        array.addAll(itemList)
                    }
                    InvoiceDueTodayActivity.showActivity(activity, getDateFromCalendar(it), mSelectedCurrency ?: MARKET_CURRENCY, array)
                }
            }
            paymentLayout -> {
                val entity = getExpectedPayments()
                entity?.also {
//                    Logger.i("selected payments: ${it.json}")
                    PlannedPaymentDueDayActivity.showActivity(this, entity, mSelectedCurrency ?: "")
                }
            }
            nextItemButton -> {
                mNextCalendar?.also {
                    TealiumUtil.eventTag("button click", "post logon landing page: go to that day")
                    calendarView.scrollToCalendar(it.year, it.month, it.day, true)
                }
            }
            expandButton -> {
                if (calendarLayout.isExpand) {
                    calendarLayout.shrink()
                } else {
                    calendarLayout.expand()
                }
            }
        }
    }

    private val mFormat = SimpleDateFormat("yyyy-MM-dd")
    private val isMonthView = AtomicBoolean(false)
    private var mPreSelectedCalendar: Calendar? = null
    private var mSelectedCalendar: Calendar? = null
    private var mNextCalendar: Calendar? = null
    private var mMonthCalendar: Calendar? = null
    private val mWeekCalendars = mutableListOf<Calendar>()
    private val mCalendarGroup = mutableMapOf<String, CalendarListItem>()

    override fun getActivityContext(): Activity? {
        return activity
    }

    override fun showContentView(mCalendarGroup: MutableMap<String, CalendarListItem>) {
        hideLoadingDialogExt()
        // Set data
        if (mCalendarGroup.isNotEmpty()) {
            this.mCalendarGroup.clear()
            this.mCalendarGroup.putAll(mCalendarGroup)
        }
        updateCalendarView()
        mSelectedCalendar?.also {
            calendarView.scrollToCalendar(it.year, it.month, it.day, true)
        }
        updateCharts()
        mSelectedCalendar?.also {
            announceMonthView(it.year, it.month)
        }
    }

    private fun updateCalendarView() {
        // Update calendar points
        val schemes = mutableMapOf<String, Calendar>()
        if (mCalendarGroup.isNotEmpty()) {
            mCalendarGroup.forEach {
                val date = it.key
                val item = it.value
                var invoiceFlag = false
                var paymentFlag = false
                item.dueInvoices.also {
                    if (it.isNotEmpty()) {
                        invoiceFlag = true
                    }
                }
                item.expectedPayments.also {
                    if (it.isNotEmpty()) {
                        paymentFlag = true
                    }
                }
                val mark = when {
                    invoiceFlag && !paymentFlag -> "1"
                    !invoiceFlag && paymentFlag -> "2"
                    invoiceFlag && paymentFlag -> "3"
                    else -> null
                }
                mark?.also {
                    val calendar = getCalendarFromDate(date)
                    val scheme = getScheme(calendar.year, calendar.month, calendar.day, mark)
                    schemes[scheme.toString()] = scheme
                }
            }
        }
        calendarView.setSchemeDate(schemes)
    }

    private fun getDateFromCalendar(calendar: Calendar): String {
        val year = calendar.year
        val month = calendar.month
        val day = calendar.day
        return "$year" + "-" +
                (if (month < 10) "0$month" else month) + "-" +
                (if (day < 10) "0$day" else day)
    }

    private fun getCalendarFromDate(string: String): Calendar {
        val arrays = string.split("-")
        val year = arrays[0].toInt()
        val month = arrays[1].toInt()
        val day = arrays[2].toInt()
        return Calendar().let {
            it.year = year
            it.month = month
            it.day = day
            it
        }
    }

    private fun getScheme(year: Int, month: Int, day: Int, scheme: String): Calendar {
        return Calendar().let {
            it.year = year
            it.month = month
            it.day = day
            it.scheme = scheme
            it
        }
    }

    private fun getExpectedPayments(dataList: List<ITPListItem>? = null): PlannedPaymentListPayload? {
        try {
            val newTokens = mutableListOf<String>()
            val newAmounts = mutableListOf<String>()
            val newCreatedAts = mutableListOf<String>()
            val newItps = mutableListOf<ITP>()
            val newStatuses = mutableListOf<String>()
            val newUpdatedAts = mutableListOf<String>()

            val date = getDateFromCalendar(mSelectedCalendar ?: Calendar())
            val item = dataList ?: mCalendarGroup[date]?.expectedPayments
            item?.forEach {
                newTokens.add(it.token ?: "")
                newAmounts.add(it.amount ?: "")
                newCreatedAts.add(it.createdAt ?: "")
                newItps.add(it.itp ?: ITP(null, null, null, null,
                        null, null, null, null, null,
                        null,null, null, null, null))
                newStatuses.add(it.status ?: "")
                newUpdatedAts.add(it.updatedAt ?: "")
            }

            val entity = PlannedPaymentListPayload()
            entity.payload = PlannedPaymentList(id = null,
                    tokens = newTokens,
                    createdAts = newCreatedAts,
                    itps = newItps,
                    updatedAts = newUpdatedAts,
                    statuses = newStatuses,
                    amounts = newAmounts)
            return entity
        } catch (e: Exception) {
            return null
        }
    }

    @Synchronized
    private fun switchCalendarText() {
        mSelectedCalendar?.also { c ->
            val date = java.util.Calendar.getInstance().also { a ->
                a.set(java.util.Calendar.YEAR, c.year)
                a.set(java.util.Calendar.MONTH, c.month - 1)
                a.set(java.util.Calendar.DAY_OF_MONTH, c.day)
            }.time
            calendarText.text = SimpleDateFormat("E, MMMM d, yyyy", Locale.ENGLISH).format(date)
        }
    }

    private fun getNextCalendar(): Calendar? {
        mSelectedCalendar?.also { c ->
            val nowTime = java.util.Calendar.getInstance().also { a ->
                a.set(java.util.Calendar.YEAR, c.year)
                a.set(java.util.Calendar.MONTH, c.month - 1)
                a.set(java.util.Calendar.DAY_OF_MONTH, c.day)
            }.time.time
            val keys = arrayListOf<String>()
            keys.addAll(mCalendarGroup.keys.toSortedSet())
            for ((index, key) in keys.withIndex()) {
                val calendar = java.util.Calendar.getInstance().also {
                    it.time = mFormat.parse(key)
                }
                val time = mFormat.parse(key).time
                if (index == 0) {// 1st item
                    if (nowTime < time) {
                        return Calendar().also {
                            it.year = calendar[java.util.Calendar.YEAR]
                            it.month = calendar[java.util.Calendar.MONTH] + 1
                            it.day = calendar[java.util.Calendar.DAY_OF_MONTH]
                        }
                    }
                } else {// other item
                    val preIndex = index - 1
                    if (preIndex >= 0) {
                        val preKey = keys[preIndex]
                        val preTime = mFormat.parse(preKey).time
                        if (nowTime in (preTime + 1) until time) {
                            return Calendar().also {
                                it.year = calendar[java.util.Calendar.YEAR]
                                it.month = calendar[java.util.Calendar.MONTH] + 1
                                it.day = calendar[java.util.Calendar.DAY_OF_MONTH]
                            }
                        }
                    }
                }
            }
        }
        return null
    }

    private fun showNextCalendar() {
        mNextCalendar?.also { c ->
            val date = java.util.Calendar.getInstance().also { a ->
                a.set(java.util.Calendar.YEAR, c.year)
                a.set(java.util.Calendar.MONTH, c.month - 1)
                a.set(java.util.Calendar.DAY_OF_MONTH, c.day)
            }.time
            nextItemText.text = String.format(MemoryCache.getLabelText("message_calendar_next_items") ?: getString(R.string.message_calendar_next_items), SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH).format(date))
        }
    }

    private fun updateCharts() {
//        val timeFormatter = SimpleDateFormat("yyyy-MM-dd")
//        val summaryData = presenter.calculatePieChartsData(timeFormatter.format(Date()))
        val summaryData = mViewModel.chatLiveData.value
        if (summaryData == null || (summaryData[0] == "0" && summaryData[2] == "0" && summaryData[4] == "0" && summaryData[6] == "0" && summaryData[8] == "0" && summaryData[10] == "0")) {
            vp_calendar_summary_container.visibility = View.GONE
            ll_calendar_summary_indicator_container.visibility = View.GONE
            return
        } else {
            vp_calendar_summary_container.visibility = View.VISIBLE
        }
        summaryData.also { summaryItem ->
            val pageViews = mutableListOf<View>()
            val jsonLabelArray = if (MemoryCache.getLabelText("s_array_due_today").isNullOrBlank()) null else mutableListOf(MemoryCache.getLabelText("s_array_due_today"),
                    MemoryCache.getLabelText("s_array_due_next_one_month"),
                    MemoryCache.getLabelText("s_array_due_next_three_month"))
            val labelArray = if (jsonLabelArray.isNullOrEmpty()) resources.getStringArray(R.array.s_a_calendar_chart_label) else jsonLabelArray.toTypedArray()
            activity?.let {
                for (i in 0..2) {
                    val view = LayoutInflater.from(it).inflate(R.layout.item_calendar_summary, null)
                    val ringList = mutableListOf<RingData>()
                    val invoiceList = summaryItem[4 * i] as ArrayList<InvoiceListItem>
                    val paymentList = summaryItem[4 * i + 2] as ArrayList<ITPListItem>
                    val totalCount = invoiceList.size + paymentList.size
                    if (totalCount > 0) {
                        ringList.add(RingData(paymentList.size.toDouble() / totalCount.toDouble(), ContextCompat.getColor(it, R.color.c_ring_payment_closed), null))
                        ringList.add(RingData(invoiceList.size.toDouble() / totalCount.toDouble(), ContextCompat.getColor(it, R.color.colorInvoicePartialPaid), null))
                    }
                    view.rv_calendar_summary_pie.setData(ringList.filter { data ->
                        data.gravity > 0
                    })
                    view.tv_calendar_summary_pie_label.text = labelArray[i]
                    view.tv_calendar_summary_pie_invoice_num.text = invoiceList.size.toString()
                    view.tv_calendar_summary_pie_payment_num.text = paymentList.size.toString()
                    view.sv_calendar_summary_invoice_info_pointer.setColor(ContextCompat.getColor(it, R.color.colorInvoicePartialPaid))
                    view.tv_calendar_summary_invoice_info_num.text = String.format(MemoryCache.getLabelText("s_num_invoices") ?: getString(R.string.s_num_invoices), invoiceList.size.toString())
                    view.tv_calendar_summary_invoice_info_amount.text = summaryItem[4 * i + 1].toString()
                    view.sv_calendar_summary_payment_info_pointer.setColor(ContextCompat.getColor(it, R.color.c_ring_payment_closed))
                    view.tv_calendar_summary_payment_info_num.text = String.format(MemoryCache.getLabelText("s_num_payments") ?: getString(R.string.s_num_payments), paymentList.size.toString())
                    view.tv_calendar_summary_payment_info_amount.text = summaryItem[4 * i + 3].toString()

                    view.rl_calendar_summary_invoice_container.setOnClickListener {
                        InvoiceDueTodayActivity.showActivity(activity, getDateFromCalendar(mSelectedCalendar ?: Calendar()),
                                mSelectedCurrency ?: MARKET_CURRENCY, invoiceList)
                    }
                    view.rl_calendar_summary_payment_container.setOnClickListener {
                        val entity = getExpectedPayments(paymentList)
                        entity?.also {
                            PlannedPaymentDueDayActivity.showActivity(this, entity, mSelectedCurrency ?: "")
                        }
                    }
                    pageViews.add(view)
                }
            }

            val pagerAdapter = object : PagerAdapter() {
                override fun isViewFromObject(p0: View, p1: Any): Boolean {
                    return p0 === p1
                }

                override fun getCount(): Int {
                    return pageViews.size
                }

                override fun instantiateItem(container: ViewGroup, position: Int): Any {
                    container.addView(pageViews[position])
                    return pageViews[position]
                }

                override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
                    container.removeView(pageViews[position])
                }
            }

            vp_calendar_summary_container.adapter = pagerAdapter
        }

        ll_calendar_summary_indicator_container.visibility = View.VISIBLE
        activity?.let {
            v_home_summary_tip_second.setBackgroundColor(ContextCompat.getColor(it, R.color.light_gray))
            v_home_summary_tip_third.setBackgroundColor(ContextCompat.getColor(it, R.color.light_gray))
            v_home_summary_tip_first.setBackgroundColor(ContextCompat.getColor(it, R.color.primary_red))
        }
    }

    private fun showInvoiceAndPayment() {
        mSelectedCalendar?.also {
            val date = getDateFromCalendar(it)
            val item = mCalendarGroup[date]
            val invoices = item?.dueInvoices
            val payments = item?.expectedPayments
            if (invoices != null && invoices.size > 0) {
                invoiceNumberText.text = invoices.size.toString()
                val tmpText = "${item.invoiceCurrency}\t${IndiaNumberUtil.formatNumByDecimal(item.invoiceAmount ?: "", item.invoiceCurrency ?: MARKET_CURRENCY)}"
                invoiceAmountText.text = tmpText
            } else {
                invoiceNumberText.text = "0"
                invoiceAmountText.text = "0${if (mSelectedCurrency == "IDR") "," else "."}00"
            }
            if (payments != null && payments.size > 0) {
                paymentNumberText.text = payments.size.toString()
                val tmpText = "${item.itpCurrency}\t${IndiaNumberUtil.formatNumByDecimal(item.itpAmount ?: "", item.itpCurrency ?: MARKET_CURRENCY)}"
                paymentAmountText.text = tmpText
            } else {
                paymentNumberText.text = "0"
                paymentAmountText.text = "0${if (mSelectedCurrency == "IDR") "," else "."}00"
            }

            val timeFormatter = SimpleDateFormat("yyyy-MM-dd")
            val selectDate = if (mSelectedCalendar == null) {
                timeFormatter.format(Date())
            } else {
                timeFormatter.format(mSelectedCalendar?.timeInMillis)
            }
            if (TimeZoneTransformsUtil.calDaysBetween(selectDate, timeFormatter.format(Date())).toInt() > 0) {
                tv_invoice_calendar_more_detail_title.text = MemoryCache.getLabelText("head_calendar_invoice_overdue") ?: getString(R.string.head_calendar_invoice_overdue)
                tv_payment_calendar_more_detail_title.text = MemoryCache.getLabelText("head_calendar_payment_overdue") ?: getString(R.string.head_calendar_payment_overdue)
            } else {
                tv_invoice_calendar_more_detail_title.text = MemoryCache.getLabelText("head_calendar_invoice") ?: getString(R.string.head_calendar_invoice)
                tv_payment_calendar_more_detail_title.text = MemoryCache.getLabelText("head_calendar_payment") ?: getString(R.string.head_calendar_payment)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart:buyer portal:home:post logon landing page",
                "/dart/buyer-portal/home/post-logon-landing-page",
                "landing",
                "buyer portal",
                "home",
                "mobile",
                "en",
                "buyer portal - login",
                "2",
                "buyer portal - login - completed",
                "logon",
                "verification",
                "OpenAM"
        )
    }
}

