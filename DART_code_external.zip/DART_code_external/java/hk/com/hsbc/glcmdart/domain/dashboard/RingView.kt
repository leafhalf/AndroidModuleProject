/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dashboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import java.io.Serializable
import kotlin.math.min

class RingView : View {

    val data = mutableListOf<RingData>()
    private val mColorfulPaint = Paint()
    private val mWhitePaint = Paint()
    private val mWhiteStrokePaint = Paint()
    private var mRadius = 0
    private var mRingModulus = 0.65F
    private val oval = RectF()

    constructor(context: Context?) : super(context)

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs)

    init {
        mColorfulPaint.isAntiAlias = true
        mColorfulPaint.style = Paint.Style.FILL
        mColorfulPaint.textAlign = Paint.Align.CENTER

        mWhitePaint.isAntiAlias = true
        mWhitePaint.style = Paint.Style.FILL
        mWhitePaint.textAlign = Paint.Align.CENTER
        mWhitePaint.color = Color.WHITE

        mWhiteStrokePaint.isAntiAlias = true
        mWhiteStrokePaint.style = Paint.Style.STROKE
        mWhiteStrokePaint.strokeWidth = dipToPx(context, 4F).toFloat()
        mWhiteStrokePaint.textAlign = Paint.Align.CENTER
        mWhiteStrokePaint.color = Color.WHITE
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val wideSize = MeasureSpec.getSize(widthMeasureSpec)
        val wideMode = MeasureSpec.getMode(widthMeasureSpec)
        val heightSize = MeasureSpec.getSize(heightMeasureSpec)
        val heightMode = MeasureSpec.getMode(heightMeasureSpec)
        var width: Int?
        var height: Int?
        if (wideMode == MeasureSpec.EXACTLY) {
            width = wideSize
        } else {
            width = mRadius * 2 + paddingLeft + paddingRight
            if (wideMode == MeasureSpec.AT_MOST) {
                width = min(width, wideSize)
            }
        }
        if (heightMode == MeasureSpec.EXACTLY) {
            height = heightSize
        } else {
            height = mRadius * 2 + paddingTop + paddingBottom
            if (heightMode == MeasureSpec.AT_MOST) {
                height = min(height, heightSize)
            }
        }
        setMeasuredDimension(width, height)
        mRadius = (min(width - paddingLeft - paddingRight, height - paddingTop - paddingBottom) * 1.0f / 2).toInt()
    }

    override fun onDraw(canvas: Canvas?) {
        canvas?.apply {
            if (mRadius > 0) {
                val centerX = (width - paddingLeft - paddingRight)/2F + paddingLeft
                val centerY = (height - paddingTop - paddingBottom)/2F + paddingTop
                if (data.isNotEmpty()) {
                    oval.set(centerX - mRadius.toFloat(),
                            centerY - mRadius.toFloat(),
                            centerX + mRadius.toFloat(),
                            centerY + mRadius.toFloat())
                    val minAngle = 1F
                    val totalAngle = 360.toDouble()
                    val paddingSweepAngle = 3.toDouble() * totalAngle/360.toDouble()
                    val size = data.size
                    var startAngle = (-90).toDouble()
                    for (it in data) {
                        mColorfulPaint.color = it.color
                        val sweepAngle = it.gravity * (totalAngle - size.toDouble() * paddingSweepAngle)
                        val paddingStartAngle = startAngle + sweepAngle
                        drawArc(oval, startAngle.toFloat(), if (sweepAngle > minAngle) sweepAngle.toFloat() else minAngle, true, mColorfulPaint)
                        startAngle = paddingStartAngle + paddingSweepAngle
                    }

                    drawCircle(centerX, centerY, mRadius * mRingModulus, mWhitePaint)
                } else {
                    mColorfulPaint.color = Color.parseColor("#efefef")
                    drawCircle(centerX, centerY, mRadius.toFloat(), mColorfulPaint)

                    drawCircle(centerX, centerY, mRadius * mRingModulus, mWhitePaint)
                }
            }
        }
    }

    fun setData(d: List<RingData>) {
        data.clear()
        data.addAll(d)
        invalidate()
    }

    private fun dipToPx(context: Context, dpValue: Float): Int {
        val scale = context.resources.displayMetrics.density
        return (dpValue * scale + 0.5f).toInt()
    }
}

data class RingData(
        var gravity: Double = 0.toDouble(),
        val color: Int,
        var tag: Any? = null
) : Serializable