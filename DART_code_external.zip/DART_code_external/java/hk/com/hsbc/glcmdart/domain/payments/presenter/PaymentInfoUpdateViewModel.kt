package hk.com.hsbc.glcmdart.domain.payments.presenter

import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import hk.com.hsbc.glcmdart.client.MARKET_COUNTRY
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.domain.dart.ErrorBody
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentDetailEntityPayload
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.util.MemoryCache
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class PaymentInfoUpdateViewModel: PaymentBaseViewModel() {

    val paymentUpdateResultLiveData = MutableLiveData<PaymentDetailEntityPayload>()
    val deductionLiveData = MutableLiveData<MutableMap<String, List<TaxDeductionInfo>?>>()

    fun requestValidateItp(token: String?, itp: Map<String, Any>?) {
        requestLoadingLiveData.postValue(true)
        val disposable = paymentsModel.validateItp(itp ?: mutableMapOf())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    requestLoadingLiveData.postValue(false)
                        if (it.payload.Success)
                            requestUpdateItp(token, itp)
                }, {
                    requestLoadingLiveData.postValue(false)
                    try {
                        val errorBody = Gson().fromJson((it as HttpException).response().errorBody()?.string(), ErrorBody::class.java)
                        paymentErrorLiveData.postValue(errorBody.errorText)
                    } catch (e: Exception) {
                        paymentErrorLiveData.postValue(e.toString())
                    }
                })
    }

    fun requestUpdateItp(token: String?, itp: Map<String, Any>?) {
        requestLoadingLiveData.postValue(true)
        val disposable = paymentsModel.requestUpdateItp(token ?: "", itp ?: mutableMapOf())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    requestLoadingLiveData.postValue(false)
                    paymentUpdateResultLiveData.postValue(it)
                }, {
                    Toast.makeText(DartApplication.instance, "Update fail", Toast.LENGTH_SHORT).show()
                    requestLoadingLiveData.postValue(false)
                })
    }

    fun requestDeductions(payeeReference: String?, countryCode: String?, accountReference: String?) {
        val disposable = paymentsModel.requestDeductionList(payeeReference ?: "", countryCode ?: MARKET_COUNTRY, accountReference ?: "")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    requestLoadingLiveData.postValue(false)
                    val deductionMapHandled = mutableMapOf<String, List<TaxDeductionInfo>?>()
                    val deductionKeys = it.payload?.keys
                    deductionKeys?.forEach { key ->
                        deductionMapHandled[key] = it.payload?.get(key)
                    }
                    if (!deductionMapHandled.isNullOrEmpty() && MemoryCache.deductionsActive == true) {
                        deductionLiveData.postValue(deductionMapHandled)
                    } else {
                        deductionLiveData.postValue(mutableMapOf())
                    }
                }, {
                    requestLoadingLiveData.postValue(false)
                    deductionLiveData.postValue(mutableMapOf())
                })
    }
}