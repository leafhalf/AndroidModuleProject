package hk.com.hsbc.glcmdart.domain.payments.presenter

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.util.MemoryCache

class SupplierOrCustomerViewModel: ViewModel() {

    val organizationLiveData = MutableLiveData<List<Payee>>()

    fun requestData(isGetCustomerData: Boolean) {
        MemoryCache.getOrganisations()?.also { entity ->
                if (isGetCustomerData) {
                    entity.payload.payors
                } else {
                    entity.payload.payees
                }?.let { list ->
                    list.forEach {
                        it.isChecked = false
                    }
                    organizationLiveData.postValue(list)
                }
        }
    }
}