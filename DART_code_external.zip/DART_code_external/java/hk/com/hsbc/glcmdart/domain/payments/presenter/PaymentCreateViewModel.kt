package hk.com.hsbc.glcmdart.domain.payments.presenter

import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import hk.com.hsbc.glcmdart.domain.dart.BankCalendarDate
import hk.com.hsbc.glcmdart.domain.dart.ErrorBody
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentPayload
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class PaymentCreateViewModel : CreditNoteAndPaymentMethodViewModel() {

    val bankHolidayLiveData = MutableLiveData<List<BankCalendarDate>>()
    val paymentCreationLiveData = MutableLiveData<PlannedPaymentPayload>()

    fun requestBankCalendar(countryCode: String?) {
        val disposable = paymentsModel.getBankCalendar(countryCode)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    bankHolidayLiveData.postValue(it.payload.entries!!)
                }, {
                    bankHolidayLiveData.postValue(mutableListOf())
                })
    }

    fun requestValidateItp(itp: Map<String, Any>?) {
        val disposable = paymentsModel.validateItp(itp ?: mutableMapOf())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    if (it.payload.Success)
                        requestCreateItp(itp)
                }, {
                    try {
                        val errorBody = Gson().fromJson((it as HttpException).response().errorBody()?.string(), ErrorBody::class.java)
                        paymentErrorLiveData.postValue(errorBody.errorText)
                    } catch (e: Exception) {
                        paymentErrorLiveData.postValue(e.toString())
                    }
                })
    }

    fun requestCreateItp(itp: Map<String, Any>?) {
        val disposable = paymentsModel.createItp(itp ?: mutableMapOf())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    paymentCreationLiveData.postValue(it)
                }, {
                    paymentErrorLiveData.postValue(it.message)
                })
    }
}