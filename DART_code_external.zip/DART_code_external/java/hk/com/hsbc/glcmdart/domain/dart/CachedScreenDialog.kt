/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dart

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.WindowManager
import hk.com.hsbc.glcmdart.R

class CachedScreenDialog constructor(context: Context): Dialog(context, R.style.FullScreenDialogTheme) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window?.decorView?.setPadding(0, 0, 0, 0)
        window.setWindowAnimations(R.style.Animation)
        val lp = window?.attributes
        lp?.width = WindowManager.LayoutParams.MATCH_PARENT
        lp?.height = WindowManager.LayoutParams.MATCH_PARENT
        window?.attributes = lp

        setContentView(R.layout.view_cachedscreen)
        setCanceledOnTouchOutside(false)
        setCancelable(false)
    }
}
