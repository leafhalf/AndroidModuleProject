/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.model

import com.google.gson.Gson
import hk.com.hsbc.glcmdart.client.HOST_URL
import hk.com.hsbc.glcmdart.domain.dart.BankCalendarPayload
import hk.com.hsbc.glcmdart.domain.dart.CreditnotesEntity
import hk.com.hsbc.glcmdart.domain.dart.PaymentMethodPayload
import hk.com.hsbc.glcmdart.domain.dart.ResponseResultPayload
import hk.com.hsbc.glcmdart.domain.payments.model.bean.*
import hk.com.hsbc.glcmdart.util.NetworkManager
import io.reactivex.Observable
import okhttp3.MediaType
import okhttp3.RequestBody
import retrofit2.http.Path

class PaymentsModel {

    fun getPlannedPaymentList(uploadParameter: Any): Observable<PlannedPaymentListPayload> {
        val parameterStr = Gson().toJson(uploadParameter)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).getPlannedPaymentList(requestBody)
    }

    fun getPlannedPaymentListByFilter(filter: String): Observable<PaymentDetailEntityPayload> {
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).getPlannedPaymentListByFilter(filter)
    }

    fun searchPlannedPayment(uploadParameter: Map<String, Any>): Observable<PlannedPaymentListPayload> {
        val parameterStr = Gson().toJson(uploadParameter)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).getPlannedPaymentList(requestBody)
    }

    fun getPaymentMethods(payee: String?, country: String?, currency: String?): Observable<PaymentMethodPayload> {
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).getPaymentMethods(payee, country, currency)
    }

    fun getBankCalendar(countryCode: String?): Observable<BankCalendarPayload> {
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).getBankCalendar(countryCode)
    }

    fun validateItp(uploadParameter: Map<String, Any>): Observable<ResponseResultPayload> {
        val parameterStr = Gson().toJson(uploadParameter)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).validateItp(requestBody)
    }

    fun createItp(uploadParameter: Map<String, Any>): Observable<PlannedPaymentPayload> {
        val parameterStr = Gson().toJson(uploadParameter)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).createItp(requestBody)
    }

    fun requestCreditNotes(uploadParameter: String): Observable<CreditnotesEntity> {
        val requestBody = RequestBody.create(MediaType.parse("application/json"), uploadParameter)
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).creditnotes(requestBody)
    }

    fun requestItpRevoke(token: String, uploadParameter: Map<String, Any>): Observable<RevokePayload> {
        val parameterStr = Gson().toJson(uploadParameter)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).itpRevoke(token, requestBody)
    }

    fun requestUpdateItp(token: String, uploadParameter: Map<String, Any>): Observable<PaymentDetailEntityPayload> {
        val parameterStr = Gson().toJson(uploadParameter)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), parameterStr)
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).updateItp(token, requestBody)
    }

    fun requestPaymentGatewayHtml(token: String): Observable<PaymentPayInfo> {
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).getGatewayHtml(token)
    }

    fun requestPaymentTracking(token: String): Observable<PaymentTrackPayload> {
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).trackPayment(token)
    }

    fun requestDeductionList(payeeRef: String, countryCode: String, payeeAccountRef: String): Observable<TaxDeductionPayload> {
        return NetworkManager.getNormalService(PaymentsService::class.java, HOST_URL).getDeductions(payeeRef, countryCode, payeeAccountRef)
    }
}