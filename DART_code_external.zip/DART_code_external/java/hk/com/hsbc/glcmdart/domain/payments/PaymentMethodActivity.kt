/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.dart.PaymentMethod
import hk.com.hsbc.glcmdart.domain.payments.adapter.PaymentMethodAdapter
import hk.com.hsbc.glcmdart.domain.payments.view.ProvidePaymentInfoView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import hk.com.hsbc.glcmdart.widget.SpacesItemDecoration
import kotlinx.android.synthetic.main.activity_planned_payment_creation.*
import kotlinx.android.synthetic.main.fragment_my_payments.*

class PaymentMethodActivity : BaseActivity(), RecyclerExtras.OnItemClickListener {

    private val itemList = ArrayList<String>()
    private val mAdapter by lazy { PaymentMethodAdapter(this, itemList) }
    private var isUpdate: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_method)
        initEventAndData()
    }

    @SuppressLint("ResourceAsColor")
    private fun initEventAndData() {
        tl_head.title = MemoryCache.getLabelText("s_payment_method_title") ?: getString(R.string.s_payment_method_title)
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            finish()
        }
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        mAdapter.setOnItemClickListener(this)
        rv_invoice_add_or_edit.adapter = mAdapter
        rv_invoice_add_or_edit.itemAnimator = DefaultItemAnimator()
        rv_invoice_add_or_edit.addItemDecoration(SpacesItemDecoration(this, 2))

        isUpdate = intent.getBooleanExtra("isUpdate", false)
        if (intent.getSerializableExtra("paymentMethods") != null) {
            val paymentMethods = intent.getSerializableExtra("paymentMethods") as PaymentMethod
            val selectPosition = intent.getIntExtra("selectPosition", -1)
            val paymentMethodList = arrayListOf<String>()
            if (paymentMethods.cheque != null) {
                paymentMethods.cheque?.active?.let {
                    if (it) {
                        paymentMethodList.add(ProvidePaymentInfoView.cheque)
                    }
                }
            }
            if (paymentMethods.rtgs != null) {
                paymentMethods.rtgs?.active?.let {
                    if (it) {
                        paymentMethodList.add(ProvidePaymentInfoView.rtgs)
                    }
                }
            }
            if (paymentMethods.ach != null) {
                paymentMethods.ach?.active?.let {
                    if (it) {
                        paymentMethodList.add(ProvidePaymentInfoView.ach)
                    }
                }
            }
            if (paymentMethods.bank_transfer != null) {
                paymentMethods.bank_transfer?.active?.let {
                    if (it) {
                        paymentMethodList.add(ProvidePaymentInfoView.bank_transfer)
                    }
                }
            }

            if (paymentMethods.dcms != null) {
                paymentMethods.dcms?.active?.let {
                    if (it) {
                        paymentMethodList.add(ProvidePaymentInfoView.dcms)
                    }
                }
            }

            mAdapter.addData(paymentMethodList)
            if (selectPosition != -1) {
                mAdapter.setSelector(selectPosition)
            }
        }
    }

    override fun onItemClick(view: View, position: Int) {
        val methodStr = itemList[position]
        if (this.isUpdate)
            TealiumUtil.eventTag("button click", "planned payments - update payment info: payment method list: $methodStr selected")
        else
            TealiumUtil.eventTag("button click", "choose payment method: $methodStr")
        val intent = Intent()
        intent.putExtra(REQUEST_RESULT_PAYMENT_METHOD, methodStr)
        intent.putExtra(REQUEST_RESULT_PAYMENT_METHOD_SELECT, position)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    companion object {
        const val REQUEST_RESULT_PAYMENT_METHOD: String = "paymentMethod"
        const val REQUEST_RESULT_PAYMENT_METHOD_SELECT: String = "paymentMethod_select"
        fun showActivity(activity: Activity, paymentMethods: PaymentMethod?, selectPosition: Int?, isUpdate: Boolean?, requestCode: Int) {
            val intent = Intent(activity, PaymentMethodActivity::class.java)
            intent.putExtra("paymentMethods", paymentMethods)
            intent.putExtra("selectPosition", selectPosition)
            intent.putExtra("isUpdate", false)
            activity.startActivityForResult(intent, requestCode)
        }
    }

    override fun onRestart() {
        super.onRestart()
        TealiumUtil.pageTag(
                "dart : buyer portal : payments : choose payment method",
                "/dart/buyer portal/payments/choose payment method",
                "accounts",
                "buyer portal",
                "payments"
        )
    }
}
