package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R

class PaymentCurrencyAdapter(context: Context, private var mData: Map<String, MutableList<String>>) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), CompoundButton.OnCheckedChangeListener {
    val inflater: LayoutInflater = LayoutInflater.from(context)

    private val keyList = mutableListOf<String>()
    private var itemSelect: String? = null

    fun addData(dataList: Map<String, MutableList<String>>) {
        this.keyList.clear()
        this.mData = dataList
        for (item in dataList) {
            keyList.addAll(item.value)
        }
        notifyDataSetChanged()
    }

    fun setSelectState(selectItem: String?) {
        itemSelect = selectItem
        notifyDataSetChanged()
    }

    fun getSelectItem(): String? {
        return itemSelect
    }

    override fun getItemCount(): Int = keyList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_creditnotes_radio, parent, false)
        return ItemHolder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        vh.tvCurrency.text = keyList[position]
        vh.cbCurrency.setOnClickListener {
            if (vh.cbCurrency.isChecked) {
                itemSelect = keyList[position]
            } else {
                itemSelect = null
            }
            notifyDataSetChanged()
        }
        vh.cbCurrency.tag = position
        vh.cbCurrency.isChecked = itemSelect == keyList[position]
    }

    override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {

        Handler().post {
            notifyDataSetChanged()
        }
    }


    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvCurrency: TextView = view.findViewById(R.id.tv_currency)
        val cbCurrency: RadioButton = view.findViewById(R.id.cb_currency)
    }
}
