package hk.com.hsbc.glcmdart.domain.payments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_PAYU_ERROR
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.activity_pg_already_sent.*

class PaymentGatewaySentTipActivity: BaseActivity() {

    companion object{
        fun showActivity(c: Context?, isPayUError: Boolean = false) {
            c?.startActivity(Intent(c, PaymentGatewaySentTipActivity::class.java).apply {
                putExtra(TAG_PAYU_ERROR, isPayUError)
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pg_already_sent)
        initViews()
    }

    private fun initViews() {
        val isPayUError = intent.getBooleanExtra(TAG_PAYU_ERROR, false)
        var title = ""
        var tip = ""
        if (!isPayUError) {
            title = MemoryCache.getLabelText("s_payment_already_sent") ?: getString(R.string.s_payment_already_sent)
            tip = MemoryCache.getLabelText("s_payment_already_sent_tip") ?: getString(R.string.s_payment_already_sent_tip)
        } else {
            title = MemoryCache.getLabelText("s_online_payment_error_title") ?: getString(R.string.s_online_payment_error_title)
            tip = MemoryCache.getLabelText("s_online_payment_error_tip") ?: getString(R.string.s_online_payment_error_tip)
        }

        quitButton.text = MemoryCache.getLabelText("s_talkback_close_button") ?: getString(R.string.s_talkback_close_button)
        tv_pg_sent_tip_title.text = title
        tv_success_title.text = tip
        deleteButton.setOnClickListener { finish() }
        quitButton.setOnClickListener { finish() }
    }
}