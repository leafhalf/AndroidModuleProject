/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.fragment_register_successfully.*
import kotlinx.android.synthetic.main.fragment_register_successfully.view.*

private const val ARG_RECOVERY_FLAG = "param1"
private const val ARG_USERNAME = "param2"
private const val ARG_REGISTER_TYPE = "param3"

class RegisterSuccessfullyFragment : Fragment(),
        RegisterCreateNewUserProfileContract.FragmentCallback,
        View.OnClickListener{

    companion object {
        @JvmStatic
        fun newInstance(isRecoveryFlag: Boolean, userName: String, registerType: String = "") =
                RegisterSuccessfullyFragment().apply {
                    arguments = Bundle().apply {
                        putBoolean(ARG_RECOVERY_FLAG, isRecoveryFlag)
                        putString(ARG_USERNAME, userName)
                        putString(ARG_REGISTER_TYPE, registerType)
                    }
                }
    }

    private var isRecovery = false
    private var userName: String? = null
    private var registerType = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.also {
            isRecovery = it.getBoolean(ARG_RECOVERY_FLAG, false)
            userName = it.getString(ARG_USERNAME)
            registerType = it.getString(ARG_REGISTER_TYPE) ?: ""
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.fragment_register_successfully, container, false)
        if (isRecovery) {
            MemoryCache.getLabelText("s_forget_username_success_message")?.let {
                if (!it.isBlank()) {
                    rootView.tv_success_tip.text = String.format(it, userName)
                }
            }
            MemoryCache.getLabelText("s_forget_username_success_title")?.let {
                if (!it.isBlank()) {
                    rootView.tv_success_title.text = it
                }
            }
        } else {
            if ("S" == registerType) {
                MemoryCache.getLabelText("message_registerSuccessfully_supplier")?.let {
                    if (!it.isBlank()) {
                        rootView.tv_success_tip.text = it
                    }
                }
            } else {
                MemoryCache.getLabelText("message_registerSuccessfully_buyer")?.let {
                    if (!it.isBlank()) {
                        rootView.tv_success_tip.text = it
                    }
                }
            }
            MemoryCache.getLabelText("head_registerSuccessfully")?.let {
                if (!it.isBlank()) {
                    rootView.tv_success_title.text = it
                }
            }
        }

        MemoryCache.getLabelText("s_talkback_close_button")?.let {
            if (!it.isBlank()) {
                rootView.deleteButton.contentDescription = it
            }
        }

        MemoryCache.getLabelText("button_registerSuccessfully_logon")?.let {
            if (!it.isBlank()) {
                rootView.logonButton.text = it
            }
        }
        return rootView
    }

    override fun onStart() {
        super.onStart()

        deleteButton.setOnClickListener(activity as View.OnClickListener)
        logonButton.setOnClickListener(activity as View.OnClickListener)
    }

    override fun onResume() {
        super.onResume()
        updateContentView()
        if (!isRecovery) {
            TealiumUtil.pageTag(
                    "dart : buyer portal : registration : registration successful",
                    "/dart/buyer portal/registration/registration successful",
                    "verification",
                    "buyer portal",
                    "registration",
                    "mobile",
                    "en",
                    "registration",
                    "10",
                    "registration - completed",
                    "registration",
                    "verification"
            )
        } else {
            TealiumUtil.pageTag(
                    "dart : buyer portal : recover username : recovery successful",
                    "/dart/buyer portal/recover username/revovery successful",
                    "verification",
                    "buyer portal",
                    "recover username",
                    "mobile",
                    "en",
                    "recover username",
                    "4",
                    "recover username - completed")
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.deleteButton -> {
                if (!isRecovery) {
                    TealiumUtil.eventTag("button click", "registration: registration successful: close")
                } else {
                    TealiumUtil.eventTag("button click", "recover username: recover successful: close")
                }
                v.also {
                    (activity as View.OnClickListener).onClick(v)
                }
            }
            R.id.logonButton -> {
                if (!isRecovery) {
                    TealiumUtil.eventTag("button click", "registration: registration successful: log on")
                } else {
                    TealiumUtil.eventTag("button click", "recover username: recover successful: log on")
                }
                v.also {
                    (activity as View.OnClickListener).onClick(v)
                }
            }
        }
    }

    override fun updateContentView() {

    }
}

