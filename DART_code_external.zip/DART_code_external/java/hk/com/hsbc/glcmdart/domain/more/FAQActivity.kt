/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.more.adapter.FAQAdapter
import hk.com.hsbc.glcmdart.domain.more.entity.HelpEntity
import hk.com.hsbc.glcmdart.domain.more.entity.Section
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import kotlinx.android.synthetic.main.activity_faq.*

class FAQActivity : BaseActivity(), FAQContract.View, RecyclerExtras.OnItemClickListener {

    private lateinit var mViewModel: FAQViewModel
    private val itemList = ArrayList<Section>()
    private val mAdapter by lazy { FAQAdapter(this, itemList) }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_faq)
        initViewAndEvent()
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart:buyer portal:more:faq - landing",
                "/dart/buyer-portal/more/faq/landing",
                "landing",
                "buyer portal",
                "more")
    }

    @SuppressLint("ResourceAsColor")
    private fun initViewAndEvent() {
        tl_head.title = getString(R.string.s_FAQ)
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            TealiumUtil.eventTag("button click", "FAQ: back")
            finish()
        }
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        mAdapter.setOnItemClickListener(this)
        rv_invoice_add_or_edit.adapter = mAdapter
        mViewModel = ViewModelProviders.of(this).get(FAQViewModel::class.java)
        mViewModel.helpLiveData.observe(this, Observer {
            if (it != null) {
                setRequestDataResult(it)
            }
        })

        mViewModel.requestLoadingLiveData.observe(this, Observer {
            if (it) { showLoadingDialogExt() } else { hideLoadingDialogExt() }
        })
        showLoadingDialogExt()
        mViewModel.requestData()
    }

    override fun setRequestDataResult(help: HelpEntity?) {
        hideLoadingDialogExt()
        val sections = mutableListOf<Section>()
        if (help != null) {
            for(item in help.sections){
                if(item.roles?.contains("i8.invoicing.buyer") == true)
                    sections.add(item)
            }
        }
        mAdapter.addData(sections as ArrayList<Section>)
    }

    override fun onItemClick(view: View, position: Int) {
        TealiumUtil.eventTag(
                "button click",
                "more faq landing: ${mAdapter.getData()[position].title}")
        FAQDetailActivity.showActivity(this, itemList[position])
    }

    companion object {
        fun showActivity(activity: Activity?) {
            activity?.startActivity(Intent(activity, FAQActivity::class.java))
        }
    }
}
