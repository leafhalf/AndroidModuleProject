package hk.com.hsbc.glcmdart.domain.payments

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.fragment_register_successfully.*

class PaymentSentSuccessActivity: BaseActivity(), View.OnClickListener {

    companion object{
        fun showActivity(c: Context?) {
            c?.startActivity(Intent(c, PaymentSentSuccessActivity::class.java))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_register_successfully)

        var titleStr = MemoryCache.getLabelText("s_payment_sent_success_title")
        if (titleStr.isNullOrEmpty()) {
            titleStr = getString(R.string.s_payment_sent_success_title)
        }
        tv_success_title.text = titleStr
        var tipStr = MemoryCache.getLabelText("s_payment_sent_tip")
        if (tipStr.isNullOrEmpty()) {
            tipStr = getString(R.string.s_payment_sent_tip)
        }
        tv_success_tip.text = tipStr
        var btnStr = MemoryCache.getLabelText("s_payment_sent_button")
        if (btnStr.isNullOrEmpty()) {
            btnStr = getString(R.string.s_payment_sent_button)
        }
        logonButton.text = btnStr
        deleteButton.setOnClickListener(this)
        logonButton.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.deleteButton -> {
                TealiumUtil.eventTag("button click", "payment sent: back to detail page")
                setResult(Activity.RESULT_OK)
                finish()
            }
            R.id.logonButton -> {
                TealiumUtil.eventTag("button click", "payment sent: back to detail page")
                setResult(Activity.RESULT_OK)
                finish()
            }
        }
    }
}