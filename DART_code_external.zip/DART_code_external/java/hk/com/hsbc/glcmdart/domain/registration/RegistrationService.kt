/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import hk.com.hsbc.glcmdart.client.*
import io.reactivex.Observable
import okhttp3.RequestBody
import retrofit2.http.*

/**
 * Created by Donut on 2018/11/14.
 */
interface RegistrationService {

    @Headers(
            "Content-Type: application/json",
            "Accept: */*")
    @POST(URL_REGISTRATIOM_SUPPLIER_DETAIL)
    fun uploadInvitationCode(@Path("invitation") invitation: String): Observable<RegistrationInvitationEntity>

    @Headers(
            "Content-Type: application/json",
            "Accept: */*")
    @POST(URL_REGISTRATIOM_SECURE_QUESTIONS)
    fun answerSecurityQuestion(@Path("invitation") invitation: String,
                               @Body body: RequestBody): Observable<RegistrationChallengeEntity>

    @Headers(
            "Content-Type: application/json",
            "Accept: */*")
    @POST(URL_REGISTRATIOM_RECOVERY_QUESTIONS)
    fun requestRecoveryQuestions(): Observable<RecoveryQuestionsEntity>

    @Headers(
            "Content-Type: application/json",
            "Accept: */*")
    @POST(URL_REGISTRATIOM_CHECK_USER_NAME)
    fun requestUsernameValidation(@Path("invitation") invitation: String,
                                  @Header("Authorization") token: String,
                                  @Body jsonBody: UsernameValidationBean): Observable<UsernameValidationEntity>

    @Headers(
            "Content-Type: application/json",
            "Accept: */*")
    @POST(URL_REGISTRATIOM_CREATE_PROFILE)
    fun requestProfileCreation(@Path("invitation") invitation: String,
                               @Header("Authorization") token: String,
                               @Body jsonBody: ProfileCreationBean): Observable<ProfileCreationEntity>

    @Headers(
            "Content-Type: application/json",
            "Accept: */*")
    @POST(URL_FORGET_USERNAME_SECURE_QUESTIONS)
    fun recoverUsername(@Path("invitation") invitation: String,
                        @Body body: RequestBody): Observable<RegistrationChallengeEntity>

    @Headers(
            "Content-Type: application/json",
            "Accept: */*")
    @POST(URL_REGISTRATION_EXPIRED_CODE_RECOVER)
    fun recoverExpiredInvitationCode(@Path("invitation") invitation: String,
                                     @Body body: RequestBody): Observable<ExpiredInvitationEntity>
}