/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.registration

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.dialog_password.view.*
import kotlinx.android.synthetic.main.dialog_username.view.*

object RegistrationDialog {

    fun showUsernameDialog(context: Context) {
        val mDialog = Dialog(context, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(context).inflate(R.layout.dialog_username, null)
        val gitItButton = mContentView.findViewById<TextView>(R.id.gotItButton).also {
            it.setOnClickListener {
                TealiumUtil.eventTag("button click", "registration: security advice overlay: got it")
                mDialog.dismiss()
            }
        }
        val mToolbar = mContentView.findViewById<Toolbar>(R.id.mToolbar).also {
            MemoryCache.getLabelText("title_registration_username")?.let { label ->
                if (!label.isBlank()) {
                    it.title = label
                } else {
                    it.title = context.getString(R.string.title_registration_username)
                }
            }
            it.setTitleTextColor(Color.BLACK)
            it.setBackgroundColor(Color.WHITE)
            it.setNavigationIcon(R.drawable.ic_close_on_light)
            it.setNavigationOnClickListener {
                TealiumUtil.eventTag("button click", "registration: security advice overlay: close")
                mDialog.dismiss()
            }
        }

        MemoryCache.getLabelText("description_registration_username")?.let {
            if (!it.isBlank()) {
                mContentView.tv_username_tip_dialog_tip.text = it
            }
        }
        MemoryCache.getLabelText("button_got_it")?.let {
            if (!it.isBlank()) {
                gitItButton.text = it
            }
        }
        mDialog.setContentView(mContentView)
        mDialog.setCanceledOnTouchOutside(false)
        mDialog.setCancelable(false)
        mDialog.show()
        TealiumUtil.pageTag(
                "dart : buyer portal : registration : security advice overlay",
                "/dart/buyer portal/registration/security advice overlay",
                "verification",
                "buyer portal",
                "registration"
        )
        mDialog.window?.also {
            it.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
    }

    fun showPasswordDialog(context: Context) {
        val mDialog = Dialog(context, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(context).inflate(R.layout.dialog_password, null)
        val okayButton = mContentView.findViewById<TextView>(R.id.okayButton).also {
            it.setOnClickListener {
                mDialog.dismiss()
            }
        }
        MemoryCache.getLabelText("title_registration_password")?.let {
            if (!it.isBlank()) {
                mContentView.tv_password_tip_dialog_title.text = it
            }
        }
        MemoryCache.getLabelText("description_registration_password")?.let {
            if (!it.isBlank()) {
                mContentView.tv_password_tip_dialog_tip.text = it
            }
        }
        MemoryCache.getLabelText("button_okay")?.let {
            if (!it.isBlank()) {
                okayButton.text = it
            }
        }
        mDialog.setContentView(mContentView)
        mDialog.setCanceledOnTouchOutside(true)
        mDialog.setCancelable(true)
        mDialog.show()
    }
}