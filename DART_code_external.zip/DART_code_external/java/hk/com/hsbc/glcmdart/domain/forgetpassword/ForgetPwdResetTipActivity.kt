/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.forgetpassword

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_RESET_PWD_QUESTIONS
import hk.com.hsbc.glcmdart.client.TAG_FORGET_RECOVERY_QUESTIONS
import hk.com.hsbc.glcmdart.client.TAG_FORGET_RESET_SUCCESS_FLAG
import hk.com.hsbc.glcmdart.client.TAG_FORGET_RESET_USERNAME
import hk.com.hsbc.glcmdart.domain.login.LoginActivity
import hk.com.hsbc.glcmdart.domain.registration.Question
import hk.com.hsbc.glcmdart.domain.welcome.WelcomeActivity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.fragment_register_successfully.*

class ForgetPwdResetTipActivity : BaseActivity(), View.OnClickListener {

    companion object {
        fun showActivity(activity: Activity, isResetSuccess: Boolean, username: String = "", questions: ArrayList<Question> = ArrayList()) {
            activity.startActivity(Intent(activity, ForgetPwdResetTipActivity::class.java).apply {
                putExtra(TAG_FORGET_RESET_SUCCESS_FLAG, isResetSuccess)
                putExtra(TAG_FORGET_RECOVERY_QUESTIONS, questions)
                putExtra(TAG_FORGET_RESET_USERNAME, username)
            })
        }
    }

    private var isSuccessFlag = false
    private var resetUsername = ""
    private lateinit var questions: ArrayList<Question>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_register_successfully)
        MemoryCache.getLabelText("s_talkback_close_button")?.let {
            if (!it.isBlank()) {
                deleteButton.contentDescription = it
            }
        }
0
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        deleteButton.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 24, 24)
        isSuccessFlag = intent.getBooleanExtra(TAG_FORGET_RESET_SUCCESS_FLAG, true)
        questions = intent.getSerializableExtra(TAG_FORGET_RECOVERY_QUESTIONS) as ArrayList<Question>
        resetUsername = intent.getStringExtra(TAG_FORGET_RESET_USERNAME)
        for (item in questions) {
            item.answer = null
        }
        deleteButton.setOnClickListener(this)
        logonButton.setOnClickListener(this)
        if (isSuccessFlag) {
            logonButton.text = MemoryCache.getLabelText("button_registerSuccessfully_logon") ?: getString(R.string.button_registerSuccessfully_logon)
            tv_success_title.text = MemoryCache.getLabelText("s_password_updated") ?: getString(R.string.s_password_updated)
            tv_success_tip.text = MemoryCache.getLabelText("s_password_updated_tip") ?: getString(R.string.s_password_updated_tip)
        } else {
            icon.setImageResource(R.drawable.login_and_register_account_locked)
            logonButton.text = MemoryCache.getLabelText("s_answer_questions") ?: getString(R.string.s_answer_questions)
            tv_success_title.text = MemoryCache.getLabelText("s_incorrect_answer") ?: getString(R.string.s_incorrect_answer)
            tv_success_tip.text = MemoryCache.getLabelText("s_incorrect_answer_tip") ?: getString(R.string.s_incorrect_answer_tip)
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.deleteButton -> {
                ApplicationManager.finishOtherActivities(ForgetPwdResetTipActivity::class.java)
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            }
            R.id.logonButton -> {
                if (isSuccessFlag) {
                    ApplicationManager.finishOtherActivities(ForgetPwdResetTipActivity::class.java)
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                } else {
                    ApplicationManager.finishActivity(ForgetPwdResetActivity::class.java)
                    ForgetPwdRecoveryQuestionActivity.showActivity(this, REQUEST_CODE_RESET_PWD_QUESTIONS, questions, resetUsername, isResetFail = true)
                    finish()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (isSuccessFlag) {
            TealiumUtil.pageTag("dart : buyer portal : recover password : reset successful",
                    "/dart/buyer portal/recover password/reset successful",
                    "verification",
                    "buyer portal",
                    "recover password",
                    "mobile",
                    "en",
                    "recover password",
                    "5",
                    "recover password - completed")
        }
    }
}