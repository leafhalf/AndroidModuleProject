/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.forgetpassword

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_FORGET_ANSWERS
import hk.com.hsbc.glcmdart.client.TAG_FORGET_RESET_TOKEN
import hk.com.hsbc.glcmdart.client.TAG_FORGET_RESET_USERNAME
import hk.com.hsbc.glcmdart.domain.registration.Question
import hk.com.hsbc.glcmdart.domain.registration.RegistrationDialog
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.util.ValidationUtil
import kotlinx.android.synthetic.main.fragment_register_userinformation.*

class ForgetPwdResetActivity: BaseActivity(), ForgetPwdResetContract.View, View.OnClickListener,
        View.OnFocusChangeListener, TextWatcher {

    private lateinit var mViewModel: ForgetPwdResetViewModel
    //    private val mPresenter = ForgetPwdResetPresenter()
    private lateinit var questions: ArrayList<Question>
    private lateinit var resetToken: String
    private var isTealiumPasswordEnter = false
    private var isTealiumConfirmPasswordEnter = false
    private var resetUsername = ""

    companion object {
        fun showActivity(activity: Activity, recoveryAnswers: ArrayList<Question>, token: String, username: String) {
            val intent = Intent(activity, ForgetPwdResetActivity::class.java).apply {
                putExtra(TAG_FORGET_ANSWERS, recoveryAnswers)
                putExtra(TAG_FORGET_RESET_TOKEN, token)
                putExtra(TAG_FORGET_RESET_USERNAME, username)
            }
            activity.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_register_userinformation)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        mContainerLayout.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)

        questions = intent.getSerializableExtra(TAG_FORGET_ANSWERS) as ArrayList<Question>
        resetToken = intent.getStringExtra(TAG_FORGET_RESET_TOKEN)
        resetUsername = intent.getStringExtra(TAG_FORGET_RESET_USERNAME)
        mViewModel = ViewModelProviders.of(this).get(ForgetPwdResetViewModel::class.java)
        mViewModel.resetResultLiveData.observe(this, Observer {
            resetPasswordSuccess(it)
        })
        initViewAndData()
    }

    private fun initViewAndData() {
        MemoryCache.getLabelText("s_talkback_back_button")?.let {
            if (!it.isBlank()) {
                backButton1st.contentDescription = it
            }
        }
        MemoryCache.getLabelText("text_userInformation_username")?.let {
            if (!it.isBlank()) {
                usernameHeadText.text = it
            }
        }
        MemoryCache.getLabelText("toast_userInformation_username")?.let {
            if (!it.isBlank()) {
                usernameErrorText.text = it
            }
        }
        MemoryCache.getLabelText("hint_userInformation_username")?.let {
            if (!it.isBlank()) {
                usernameHelpTextTip.text = it
            }
        }
        MemoryCache.getLabelText("text_userInformation_password")?.let {
            if (!it.isBlank()) {
                passwordHeadText.text = it
            }
        }
        MemoryCache.getLabelText("hint_userInformation_password")?.let {
            if (!it.isBlank()) {
                passwordHelpTextTip.text = it
            }
        }
        MemoryCache.getLabelText("text_userInformation_secPassword")?.let {
            if (!it.isBlank()) {
                tv_confirm_password_tag.text = it
            }
        }
        MemoryCache.getLabelText("hint_userInformation_secPassword")?.let {
            if (!it.isBlank()) {
                secPasswordHelpText.text = it
            }
        }
        MemoryCache.getLabelText("button_userInformation_continue")?.let {
            if (!it.isBlank()) {
                continueButton1st.text = it
            }
        }

        backButton1st.setOnClickListener(this)
        continueButton1st.setOnClickListener(this)
        passwordText.onFocusChangeListener = this
        secPasswordText.onFocusChangeListener = this
        passwordText.addTextChangedListener(this)
        secPasswordText.addTextChangedListener(this)
        passwordImage.setOnClickListener(this)
        passwordHeadText.text = MemoryCache.getLabelText("s_forget_password_new_password") ?: getString(R.string.s_forget_password_new_password)
        usernameHeadText.visibility = View.GONE
        usernameText.visibility = View.GONE
        usernameImage.visibility = View.VISIBLE
        usernameImage.setOnClickListener(this)
        continueButton1st.text = MemoryCache.getLabelText("s_submit") ?: getString(R.string.s_submit)
    }

    private fun validateInformation(): Boolean {
        passwordHelpText.visibility = View.GONE
        secPasswordHelpText.visibility = View.GONE
        val password = passwordText.text.toString()
        val secPassword = secPasswordText.text.toString()
        if (password.isEmpty() || password.length < 8) {
            passwordHelpText.visibility = View.VISIBLE
            return false
        }
        if (!password.contentEquals(secPassword)) {
            TealiumUtil.eventTag("error", "recover password: enter new password: password confirmation does not match")
            secPasswordHelpText.visibility = View.VISIBLE
            return false
        }
        passwordHelpText.visibility = View.GONE
        secPasswordHelpText.visibility = View.GONE
        passwordText.clearFocus()
        secPasswordText.clearFocus()
        return true
    }

    override fun resetPasswordSuccess(isSuccess: Boolean) {
        if (isSuccess) {
            ForgetPwdResetTipActivity.showActivity(this, true)
        } else {
            ForgetPwdResetTipActivity.showActivity(this, false, resetUsername, questions)
        }
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.backButton1st -> {
                TealiumUtil.eventTag("button click", "recover password: enter new password: back")
                finish()
            }
            R.id.continueButton1st -> {
                TealiumUtil.eventTag("button click", "recover password: enter new password: next")
                if (validateInformation()) {
                    v.also {
                        val password = passwordText.text.toString()
                        val answers = ArrayList<Answer>(questions.size)
                        for (item in questions) {
                            val answer = Answer(item.id, item.answer ?: "")
                            answers.add(answer)
                        }
                        val requestEntity = RequestResetPasswordEntity(password, answers)
                        mViewModel.resetPassword(requestEntity, resetToken)
                    }
                }
            }
            R.id.passwordImage -> {
                TealiumUtil.eventTag("button click", "recover password: enter new password: password tooltip")
                RegistrationDialog.showPasswordDialog(this)
            }
            R.id.usernameImage -> {
//                TealiumUtil.eventTag("button click", "recover password: enter new password: password tooltip")
                RegistrationDialog.showUsernameDialog(this)
            }
        }
    }

    override fun onFocusChange(v: View?, hasFocus: Boolean) {
        when (v) {
            passwordText -> {
                if (hasFocus) {
                    passwordHelpText.visibility = View.VISIBLE
                } else {
                    passwordHelpText.visibility = View.GONE
                    val password = passwordText.text.toString()
                    if (password.isNotEmpty() && !ValidationUtil.validatePassword(password)) {
                        TealiumUtil.eventTag("error", "recover password: enter new password: your password does not meet the requirements")
                        passwordHelpText.visibility = View.VISIBLE
                    } else {
                        passwordHelpText.visibility = View.GONE
                    }
                }
            }
            secPasswordText -> {
                if (hasFocus) {
                    secPasswordHelpText.visibility = View.VISIBLE
                } else {
                    secPasswordHelpText.visibility = View.GONE
                }
            }
        }
    }

    override fun afterTextChanged(s: Editable?) {
        if (!isTealiumPasswordEnter && passwordText.text.toString().isNotEmpty()) {
            TealiumUtil.eventTag("text entry", "recover password: enter new password: new password entered")
            isTealiumPasswordEnter = true
        }

        if (!isTealiumConfirmPasswordEnter && secPasswordText.text.toString().isNotEmpty()) {
            TealiumUtil.eventTag("text entry", "recover password: confirm password: confirm password entered")
            isTealiumPasswordEnter = true
        }

        if (!passwordText.text.isNullOrEmpty() && !secPasswordText.text.isNullOrEmpty()) {
            continueButton1st.isEnabled = true
            continueButton1st.isClickable = true
            continueButton1st.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        } else {
            continueButton1st.isEnabled = false
            continueButton1st.isClickable = false
            continueButton1st.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        }

        val password = passwordText.text.toString()
        val secPassword = secPasswordText.text.toString()
        if (password.isNotEmpty() && password.length >= 8) {
            passwordHelpText.visibility = View.GONE
        }
        if (password.contentEquals(secPassword)) {
            secPasswordHelpText.visibility = View.GONE
        }
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart : buyer portal : recover password : enter new password",
                "/dart/buyer portal/recover password/enter new password",
                "verification",
                "buyer portal",
                "recover password",
                "mobile",
                "en",
                "recover password",
                "4",
                "recover password - enter new password")
    }
}