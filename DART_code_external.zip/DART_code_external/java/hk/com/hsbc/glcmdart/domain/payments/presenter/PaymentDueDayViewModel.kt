package hk.com.hsbc.glcmdart.domain.payments.presenter

import android.text.TextUtils
import android.util.SparseArray
import androidx.lifecycle.MutableLiveData
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentDueDayLocalEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.util.DateUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class PaymentDueDayViewModel: PaymentBaseViewModel() {

    val paymentDueDayLiveData = MutableLiveData<List<PlannedPaymentDueDayLocalEntity>>()
    val paymentDueDaySummaryLiveData = MutableLiveData<SparseArray<Long>>()

    fun requestData(payorOrPayee: String?, searchKey: String?, currency: String?, isInitRequest: Boolean = false) {
        if (isInitRequest) {
            if (MemoryCache.initITPList != null) {
                paymentDueDayLiveData.postValue(dataProcessing(MemoryCache.initITPList!!, true))
                    return
            }
        }

        val dataMap = mutableMapOf<String, Any>()
        if (TextUtils.isEmpty(payorOrPayee).not()) if ("S" == MemoryCache.getSessionEntity()?.type) {
            if ("All" == payorOrPayee) {
                dataMap["payorReference"] = ""
            } else {
                dataMap["payorReference"] = payorOrPayee ?: ""
            }
        } else {
            if ("All" == payorOrPayee) {
                dataMap["payeeReference"] = ""
            } else {
                dataMap["payeeReference"] = payorOrPayee ?: ""
            }
        }
        if (!searchKey.isNullOrEmpty())
            dataMap["search"] = searchKey
        if (!currency.isNullOrEmpty())
            dataMap["currencies"] = listOf(currency)
        val disposable = paymentsModel.getPlannedPaymentList(dataMap)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    paymentDueDayLiveData.postValue(dataProcessing(it, true))
                }, {
                    paymentErrorLiveData.postValue(it.message)
                })
    }

    fun dealWithData(data: PlannedPaymentListPayload?) {
        val disposable = io.reactivex.Observable.create<List<PlannedPaymentDueDayLocalEntity>> {
            it.onNext(dataProcessing(data!!, false))
            it.onComplete()
        }.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    paymentDueDayLiveData.postValue(it)
                }, {
                     paymentErrorLiveData.postValue(it.message)
                })
    }


    private fun dataProcessing(it: PlannedPaymentListPayload, compare
    : Boolean): List<PlannedPaymentDueDayLocalEntity> {
        var mOverDueNumber: Long = 0
        var mOverDueAmount: Long = 0
        val datas = mutableListOf<PlannedPaymentDueDayLocalEntity>()
        if (it.payload != null && !it.payload!!.itps.isNullOrEmpty()) {
            val organizationsMap = MemoryCache.getOrganisationsMap()
            val dueDayDatas = mutableListOf<PlannedPaymentDueDayLocalEntity>()
            val todayDayDatas = mutableListOf<PlannedPaymentDueDayLocalEntity>()
            val todayDate = DateUtil.getLocalTodayDate()
            for (i in it.payload?.itps?.indices!!) {
                val plannedPaymentDueDayLocalEntity = PlannedPaymentDueDayLocalEntity("",
                        it.payload?.amounts?.get(i), it.payload?.createdAts?.get(i),
                        it.payload?.itps?.get(i), it.payload?.statuses?.get(i),
                        it.payload?.tokens?.get(i), it.payload?.updatedAts?.get(i), "", false, "", false, 0, 0
                )
                if (compare) {
                    val expectedDate = it.payload?.itps?.get(i)?.expectedDate
                    if (DateUtil.compareCurrentDate(expectedDate) && plannedPaymentDueDayLocalEntity.statuse == "created") {
                        if (todayDate == expectedDate) {
                            todayDayDatas.add(plannedPaymentDueDayLocalEntity)
                        } else {
                            dueDayDatas.add(plannedPaymentDueDayLocalEntity)
                        }
                        mOverDueNumber++
                    }
                } else {
                    dueDayDatas.add(plannedPaymentDueDayLocalEntity)
                    mOverDueNumber++
                }
            }
            dueDayDatas.reverse()
            if (todayDayDatas.size > 0) {
                dueDayDatas.addAll(0, todayDayDatas)
            }
            //sorting by expectedDate
            val expectedDataMap = mutableMapOf<String, MutableList<PlannedPaymentDueDayLocalEntity>>()
            for (item in dueDayDatas) {
                val expectedDate = item.itp?.expectedDate
                if (expectedDataMap.containsKey(expectedDate)) {
                    val datas = expectedDataMap[expectedDate]
                    datas!!.add(item)
                    expectedDataMap[expectedDate!!] = datas
                } else {
                    val datas = mutableListOf<PlannedPaymentDueDayLocalEntity>()
                    datas.add(item)
                    expectedDataMap[expectedDate!!] = datas
                }
            }
            //sorting by payee
            val expectedPayeeDataMap = mutableMapOf<String, MutableMap<String, MutableList<PlannedPaymentDueDayLocalEntity>>>()
            for (map in expectedDataMap) {
                val payeeDataMap = mutableMapOf<String, MutableList<PlannedPaymentDueDayLocalEntity>>()
                val payeeReference = map.key
                val datas = map.value
                for (data in datas) {
                    val payeeReference = if ("S" == MemoryCache.getSessionEntity()?.type) {
                        if (organizationsMap.containsKey(data.itp!!.payorReference))
                            (organizationsMap[data.itp!!.payorReference] as Payee).name
                        else
                            ""
                    } else {
                        if (organizationsMap.containsKey(data.itp!!.payeeReference))
                            (organizationsMap[data.itp!!.payeeReference] as Payee).name
                        else
                            ""
                    }
                    if (payeeDataMap.containsKey(payeeReference)) {
                        val entities = payeeDataMap[payeeReference]
                        entities?.add(data)
                        entities?.sortByDescending { it.itp?.lines?.get(0)?.amount?.amount?.toLong() }
                        payeeDataMap[payeeReference!!] = entities!!
                    } else {
                        val entities = mutableListOf<PlannedPaymentDueDayLocalEntity>()
                        entities.add(data)
                        payeeDataMap[payeeReference!!] = entities
                    }
                }
                expectedPayeeDataMap[payeeReference] = payeeDataMap
            }
            for (expectedMap in expectedPayeeDataMap) {
                val expectedDate = expectedMap.key
                val header = PlannedPaymentDueDayLocalEntity("",
                        "", null,
                        null, null,
                        null, null, expectedDate, true, "", false, DateUtil.countDaysWithToday(expectedDate), 0
                )
                datas.add(header)
                for (payeeMap in expectedMap.value) {
                    val payeeAccountDisplay = payeeMap.key
                    var dueDayAmount: Long = 0
                    var currency = ""
                    for (item in payeeMap.value) {
                        currency = item.itp?.payorAccount?.currency ?: ""
                        if (item.statuse == "created") {
                            for (line in item.itp!!.lines!!) if (line.type == "invoice")
                                dueDayAmount += line.amount!!.amount!!.toLong()
                        }
                    }
                    val secondHeader = PlannedPaymentDueDayLocalEntity(currency,
                            "", null,
                            null, null,
                            null, null, "", false, payeeAccountDisplay + "(" + payeeMap.value.size + ")", true, 0, null
                    )
                    datas.add(secondHeader)
                    datas.addAll(payeeMap.value)
                    val footer = PlannedPaymentDueDayLocalEntity(currency,
                            "", null,
                            null, null,
                            null, null, "", false, "", true, 0, dueDayAmount
                    )
                    datas.add(footer)
                    mOverDueAmount += dueDayAmount
                }
            }
        }

        val summaryArray = SparseArray<Long>()
        summaryArray.put(0, mOverDueNumber)
        summaryArray.put(1, mOverDueAmount)
        paymentDueDaySummaryLiveData.postValue(summaryArray)
//            setHeaderViewData(mOverDueNumber, mOverDueAmount)
        return datas
    }
}