/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.dart

import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.urbanairship.AirshipConfigOptions
import com.urbanairship.Autopilot
import com.urbanairship.UAirship
import com.urbanairship.push.PushMessage
import com.urbanairship.push.notifications.*
import com.urbanairship.util.NotificationIdGenerator
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.R


/**
 * Autopilot that enables user notifications on first run.
 */
class NotificationAutopilot : Autopilot() {

    override fun onAirshipReady(airship: UAirship?) {
        val preferences = UAirship.getApplicationContext().getSharedPreferences(NO_BACKUP_PREFERENCES, Context.MODE_PRIVATE)

        val isFirstRun = preferences.getBoolean(FIRST_RUN_KEY, true)
        if (isFirstRun) {
            preferences.edit().putBoolean(FIRST_RUN_KEY, false).apply()

            // Enable user notifications on first run
            airship?.pushManager?.userNotificationsEnabled = true
        }

//        airship?.pushManager?.notificationFactory?.titleId = R.string.s_notification_title
        airship?.pushManager?.notificationFactory = DartNotificationFactory(UAirship.getApplicationContext())
    }

    override fun createAirshipConfigOptions(context: Context): AirshipConfigOptions? {
        // Optionally, customize your config at runtime:
        if (BuildConfig.DEBUG) {
            val appkey = if (BuildConfig.FLAVOR_env == "dev") "2hrNnf5aTeOrXBf9r6_v-w" else if (BuildConfig.FLAVOR_env == "uat") "Pyr7ufkORA-1SzHwVHFmSA" else if (BuildConfig.FLAVOR_env == "pet") "pyQ_UUi8RN6L8DaNPWg90g" else "33edjC2NQ9mBPO18QJl-vA"
            val appsecret = if (BuildConfig.FLAVOR_env == "dev") "Ndorf6qET0usg47GQBRa1A" else if (BuildConfig.FLAVOR_env == "uat") "jGovS7vUSquG_ef-RjzI6A" else if (BuildConfig.FLAVOR_env == "pet") "PplkY-rrQcapHgZdGNVDw" else "jzbTGBaYRWmlQdZ-dUYV3w"
            val senderId = if (BuildConfig.FLAVOR_env == "dev") "452018804323" else if (BuildConfig.FLAVOR_env == "uat") "270000092895" else if (BuildConfig.FLAVOR_env == "pet") "1009859036043" else "219814830951"
            Log.e("test", "appKey: $appkey")
            Log.e("test", "appSecret: $appsecret")
            Log.e("test", "senderId: $senderId")
            Log.e("test", "appID: ${BuildConfig.APPLICATION_ID}")
        }

        return AirshipConfigOptions.Builder()
                    .setInProduction(!BuildConfig.DEBUG)
                    .setDevelopmentAppKey(if (BuildConfig.FLAVOR_env == "dev")"2hrNnf5aTeOrXBf9r6_v-w" else if (BuildConfig.FLAVOR_env == "uat") "Pyr7ufkORA-1SzHwVHFmSA" else if (BuildConfig.FLAVOR_env == "pet") "pyQ_UUi8RN6L8DaNPWg90g" else "33edjC2NQ9mBPO18QJl-vA")
                    .setDevelopmentAppSecret(if (BuildConfig.FLAVOR_env == "dev")"Ndorf6qET0usg47GQBRa1A" else if (BuildConfig.FLAVOR_env == "uat") "jGovS7vUSquG_ef-RjzI6A" else if (BuildConfig.FLAVOR_env == "pet") "PplkY-rrQcapPHgZdGNVDw" else "jzbTGBaYRWmlQdZ-dUYV3w")
                    .setProductionAppKey(if (BuildConfig.FLAVOR_env == "dev")"2hrNnf5aTeOrXBf9r6_v-w" else if (BuildConfig.FLAVOR_env == "uat") "Pyr7ufkORA-1SzHwVHFmSA" else if (BuildConfig.FLAVOR_env == "pet") "pyQ_UUi8RN6L8DaNPWg90g" else "33edjC2NQ9mBPO18QJl-vA")
                    .setProductionAppSecret(if (BuildConfig.FLAVOR_env == "dev")"Ndorf6qET0usg47GQBRa1A" else if (BuildConfig.FLAVOR_env == "uat") "jGovS7vUSquG_ef-RjzI6A" else if (BuildConfig.FLAVOR_env == "pet") "PplkY-rrQcapPHgZdGNVDw" else "jzbTGBaYRWmlQdZ-dUYV3w")
                    .setGcmSender(if (BuildConfig.FLAVOR_env == "dev")"452018804323" else if (BuildConfig.FLAVOR_env == "uat") "270000092895" else if (BuildConfig.FLAVOR_env == "pet") "1009859036043" else "219814830951")
                    .setNotificationIcon(R.drawable.ic_no_invoices)
                    .build()
        // defaults to loading config from airshipconfig.properties file
        // return super.createAirshipConfigOptions(context)
    }

    companion object {

        private const val NO_BACKUP_PREFERENCES = "com.urbanairship.sample.no_backup"

        private const val FIRST_RUN_KEY = "first_run"
    }

    inner class DartNotificationFactory(mContext: Context): NotificationFactory(mContext) {

        override fun createNotificationBuilder(message: PushMessage, notificationId: Int, defaultStyle: NotificationCompat.Style?): NotificationCompat.Builder {
            val builder = NotificationCompat.Builder(this.context).setContentTitle(null).setContentText(message.alert).setAutoCancel(true).setLocalOnly(message.isLocalOnly).setColor(message.getIconColor(this.color)).setSmallIcon(R.drawable.ic_no_invoices).setPriority(message.priority).setCategory(message.category).setVisibility(message.visibility)
            if (Build.VERSION.SDK_INT < 26) {
                var defaults = this.notificationDefaultOptions
                if (message.getSound(this.context) != null) {
                    builder.setSound(message.getSound(this.context))
                    defaults = defaults and -2
                } else if (this.sound != null) {
                    builder.setSound(this.sound)
                    defaults = defaults and -2
                }

                builder.setDefaults(defaults)
            }

            if (this.largeIcon != 0) {
                builder.setLargeIcon(BitmapFactory.decodeResource(this.context.resources, this.largeIcon))
            }

            if (message.summary != null) {
                builder.setSubText(message.summary)
            }

            builder.extend(PublicNotificationExtender(this.context, message).setAccentColor(this.color).setLargeIcon(this.largeIcon).setSmallIcon(this.smallIconId))
            builder.extend(WearableNotificationExtender(this.context, message, notificationId))
            builder.extend(ActionsNotificationExtender(this.context, message, notificationId))
            builder.extend(StyleNotificationExtender(this.context, message).setDefaultStyle(defaultStyle))
            if (Build.VERSION.SDK_INT >= 26) {
                builder.setChannelId(getActiveNotificationChannel(message))
            }

            return builder
        }

        @RequiresApi(api = 26)
        internal fun getActiveNotificationChannel(message: PushMessage): String {
            val notificationManager = this.context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            var channel: String?
            if (message.notificationChannel != null) {
                channel = message.notificationChannel
                if (notificationManager.getNotificationChannel(channel) != null) {
                    return channel ?: ""
                }

            }

            if (this.notificationChannel != null) {
                channel = this.notificationChannel
                if (notificationManager.getNotificationChannel(channel) != null) {
                    return channel
                }

            }

            val notificationChannel = NotificationChannel("com.urbanairship.default", "Notifications", NotificationManager.IMPORTANCE_DEFAULT)
            notificationChannel.description = "General app updates"
            notificationManager.createNotificationChannel(notificationChannel)
            return "com.urbanairship.default"
        }

        override fun getNextId(pushMessage: PushMessage): Int {
            return NotificationIdGenerator.nextID()
        }

        /**
         * Checks if the push message requires a long running task. If `true`, the push message
         * will be scheduled to process at a later time when the app has more background time. If `false`,
         * the app has approximately 10 seconds total for [.createNotification]
         * and [.getNextId].
         *
         *
         * Apps that return `false` are highly encouraged to add `RECEIVE_BOOT_COMPLETED` so
         * the push message will persist between device reboots.
         *
         * @param message The push message.
         * @return `true` to require long running task, otherwise `false`.
         */
        override fun requiresLongRunningTask(message: PushMessage?): Boolean {
            return false
        }

        private fun isAppRunning(context: Context, packageName: String): Boolean {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val list = am.getRunningTasks(100)
            if (list.size <= 0) {
                return false
            }
            for (info in list) {
                if (info.baseActivity.packageName == packageName) {
                    return true
                }
            }
            return false
        }
    }
}
