/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicedetail

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.ITPListItem
import hk.com.hsbc.glcmdart.domain.dart.InvoiceDeductionItem
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.InvoiceListNativeEntity
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentCreationActivity
import hk.com.hsbc.glcmdart.domain.payments.PlannedPaymentDetailActivity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import kotlinx.android.synthetic.main.activity_invoice_detail.*
import kotlinx.android.synthetic.main.item_invoice_detail_deduction.view.*
import kotlinx.android.synthetic.main.item_invoice_detail_time_line.view.*
import kotlinx.android.synthetic.main.item_invoice_list_plan_payment_info.view.*
import kotlinx.android.synthetic.main.view_payment_detail_header.*
import java.util.*


/**
 * Created by Donut
 *
 * invoice detail page
 */
class InvoiceDetailActivity : BaseActivity(), InvoiceDetailContract.View, View.OnClickListener {

    private lateinit var mViewModel: InvoiceDetailViewModel
    private val TIMELINE_TYPE_HEAD = 1
    private val TIMELINE_TYPE_NORMAL = 0
    private val TIMELINE_TYPE_FOOT = 2

    private var isOtherInfoShowing = true
    private var isPlannedPaymentShowing = true
    private var isTimelineShowing = true
    private var mInfo: InvoiceDetailEntity? = null
    private var mToken: String = ""

//    private val mPresenter = InvoiceDetailPresenter()

    companion object {

        fun showActivity(activity: Activity?, preEntity: InvoiceListNativeEntity?, fromPaymentCreationFlag: Boolean = false) {
            activity?.startActivity(Intent(activity, InvoiceDetailActivity::class.java).let {
                it.putExtra(TAG_INVOICE_TOKEN, preEntity)
                it.putExtra(TAG_INVOICE_FROM_PLANNED_PAYMENT_CREATION, fromPaymentCreationFlag)
                it
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invoice_detail)
        mViewModel = ViewModelProviders.of(this).get(InvoiceDetailViewModel::class.java)

//        /**
//         * 1、设置相同的TransitionName
//         */
//        ViewCompat.setTransitionName(tv_invoice_id, "invoice_id:" + mInfo?.payload?.invoice?.invoice?.reference)
//        ViewCompat.setTransitionName(tv_invoice_supplier_name, "supplier_name:" + mInfo?.payload?.invoice?.invoice?.payee?.name)
//        ViewCompat.setTransitionName(tv_invoice_pay_status, "pay_state:" +
//                mInfo?.payload?.invoice?.invoice?.reference +
//                mInfo?.payload?.invoice?.invoice?.status)
//        /**
//         * 2、设置WindowTransition,除指定的ShareElement外，其它所有View都会执行这个Transition动画
//         */
//        window.enterTransition = Fade()
//        window.exitTransition = Fade()
//        /**
//         * 3、设置ShareElementTransition,指定的ShareElement会执行这个Transiton动画
//         */
//        val transitionSet = TransitionSet()
//        transitionSet.addTransition(ChangeBounds())
//        transitionSet.addTransition(ChangeTransform())
//        transitionSet.addTarget(tv_invoice_id)
//        transitionSet.addTarget(tv_invoice_supplier_name)
//        transitionSet.addTarget(tv_invoice_pay_status)
//        window.sharedElementEnterTransition = transitionSet
//        window.sharedElementExitTransition = transitionSet

        initEventAndData()
    }

    private fun initEventAndData() {
        //maybe it should be replaced by token, 
        val invoiceItem = intent?.getSerializableExtra(TAG_INVOICE_TOKEN) as InvoiceListNativeEntity?
        if (invoiceItem == null) {
            Toast.makeText(this, MemoryCache.getLabelText("s_data_error")
                    ?: getString(R.string.s_data_error), Toast.LENGTH_SHORT).show()
        } else {
            mToken = invoiceItem.token ?: ""
//            mPresenter.attachView(this)
            tv_invoice_id.text = invoiceItem.invoice?.reference
            val organizationsMap = MemoryCache.getOrganisationsMap()
            val payeeReferenceName = if ("S" == MemoryCache.getSessionEntity()?.type) {
                if (organizationsMap.containsKey(invoiceItem.invoice?.payor?.reference))
                    (organizationsMap[invoiceItem.invoice?.payor?.reference] as Payee).name
                else
                    invoiceItem.invoice?.payor?.name
            } else {
                if (organizationsMap.containsKey(invoiceItem.invoice?.payee?.reference))
                    (organizationsMap[invoiceItem.invoice?.payee?.reference] as Payee).name
                else
                    invoiceItem.invoice?.payee?.name
            }
            tv_supplier_name?.text = payeeReferenceName
            tv_pay_status?.text = MemoryCache.getLabelText("s_invoice_status_" + invoiceItem.invoice?.status)
            val isFromPlannedPaymentCreation = intent.getBooleanExtra(TAG_INVOICE_FROM_PLANNED_PAYMENT_CREATION, false)
            btn_invoice_detail_add_plan_payment.visibility = if (isFromPlannedPaymentCreation) {
                View.GONE
            } else {
                View.VISIBLE
            }
            tv_due_date.text = String.format(MemoryCache.getLabelText("s_due_on")
                    ?: getString(R.string.s_due_on), if (invoiceItem.invoice?.dueDate != null) {
                TimeZoneTransformsUtil.formatTime(invoiceItem.invoice.dueDate)
            } else {
                TimeZoneTransformsUtil.formatTime(Date())
            }
            )
            val outstandingStr = invoiceItem.invoice?.summation?.outstanding?.amount
            if (outstandingStr != null) {
                val outstandingTxt = invoiceItem.invoice.summation.outstanding.currency + " " +
                        IndiaNumberUtil.formatNumByDecimal(outstandingStr, invoiceItem.invoice.summation.outstanding.currency
                                ?: "")
                if (outstandingStr.toLong() >= 0) {
                    tv_amount?.text = String.format(MemoryCache.getLabelText("s_outstanding")
                            ?: getString(R.string.s_outstanding), outstandingTxt)
                }
            }
            if (invoiceItem.token != null) {
//                mPresenter.getInvoiceDetail(token.token)
                mViewModel.invoiceDetailLiveData.observe(this, androidx.lifecycle.Observer {
                    updateDetailInfo(it)
                })
                mViewModel.timelineLiveData.observe(this, androidx.lifecycle.Observer {
                    updateDetailTimeline(it)
                })
                mViewModel.requestLoadingLiveData.observe(this, androidx.lifecycle.Observer {
                    if (it) {
                        showLoadingDialog()
                    } else {
                        hideLoadingDialog()
                    }
                })
                mViewModel.exceptionLiveData.observe(this, androidx.lifecycle.Observer {
                    Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
                })
                mViewModel.doRequest(invoiceItem.token)
            } else {
                Toast.makeText(this, MemoryCache.getLabelText("s_data_error")
                        ?: getString(R.string.s_data_error), Toast.LENGTH_SHORT).show()
            }

            if ("S" == MemoryCache.getSessionEntity()?.type) {
                btn_invoice_detail_add_plan_payment.visibility = View.GONE
            }
        }

        MemoryCache.getLabelText("s_talkback_button_back")?.let {
            if (!it.isBlank()) {
                btn_common_back.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_invoice_detail")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_title.text = it
            }
        }
        MemoryCache.getLabelText("s_beneficiary_info")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_beneficiary_info_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_bank_name")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_beneficiary_bank_name_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_bank_name_value")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_beneficiary_bank_name.text = it
            }
        }
        MemoryCache.getLabelText("s_invoice_number")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_invoice_number_tag.text = it
            }
        }

        MemoryCache.getLabelText("s_bank_code_label")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_beneficiary_ifsc_code_tag.text = it
            }
        }
        tv_invoice_detail_beneficiary_ifsc_code.text = MemoryCache.bankCode
        MemoryCache.getLabelText("s_account_number")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_beneficiary_account_number_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_other_info")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_other_info_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_bill_amount")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_other_info_bill_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_issue_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_other_info_issue_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_due_date")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_other_info_due_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_time_line")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_timeline_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_plan_payment_info")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_planned_payment_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_more_information")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_more_info.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_invoice_detail_more_information")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_more_info.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_advise_payment")?.let {
            if (!it.isBlank()) {
                btn_invoice_detail_add_plan_payment.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_advise_payment")?.let {
            if (!it.isBlank()) {
                btn_invoice_detail_add_plan_payment.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_hide")?.let {
            if (!it.isBlank()) {
                tv_timeline_collapse.text = it
            }
        }
        MemoryCache.getLabelText("s_account_name")?.let {
            if (!it.isBlank()) {
                tv_invoice_detail_beneficiary_account_name_tag.text = it
            }
        }
    }

    override fun getActivity(): Activity {
        return this
    }

    /**
     * show the invoice detail info
     */
    override fun updateDetailInfo(info: InvoiceDetailEntity?) {
        mInfo = info
        tv_invoice_id?.text = info?.payload?.invoice?.invoice?.reference
        val organizationsMap = MemoryCache.getOrganisationsMap()
        val payeeReferenceName = if ("S" == MemoryCache.getSessionEntity()?.type) {
            if (organizationsMap.containsKey(info?.payload?.invoice?.invoice?.payor?.reference))
                (organizationsMap[info?.payload?.invoice?.invoice?.payor?.reference] as Payee).name
            else
                info?.payload?.invoice?.invoice?.payor?.name
        } else {
            if (organizationsMap.containsKey(info?.payload?.invoice?.invoice?.payee?.reference))
                (organizationsMap[info?.payload?.invoice?.invoice?.payee?.reference] as Payee).name
            else
                info?.payload?.invoice?.invoice?.payee?.name
        }
        tv_supplier_name?.text = payeeReferenceName
        tv_pay_status?.text = MemoryCache.getLabelText("s_invoice_status_" + info?.payload?.invoice?.invoice?.status)
        tv_due_date.text = String.format(MemoryCache.getLabelText("s_due_on")
                ?: getString(R.string.s_due_on), if (info?.payload?.invoice?.invoice?.dueDate != null) {
            TimeZoneTransformsUtil.formatTime(info.payload.invoice.invoice.dueDate)
        } else {
            TimeZoneTransformsUtil.formatTime(Date())
        }
        )
        val outstandingStr = info?.payload?.invoice?.invoice?.summation?.outstanding?.amount
        if (outstandingStr != null) {
            val outstandingTxt = info.payload.invoice.invoice.summation.outstanding.currency + " " +
                    IndiaNumberUtil.formatNumByDecimal(outstandingStr, info.payload.invoice.invoice.summation.outstanding.currency
                            ?: "")
            tv_amount?.text = String.format(MemoryCache.getLabelText("s_outstanding")
                    ?: getString(R.string.s_outstanding), outstandingTxt)
        }
        val billStr = info?.payload?.invoice?.invoice?.summation?.total?.amount
        if (billStr != null) {
            val billTxt = info.payload.invoice.invoice.summation.total.currency + " " +
                    IndiaNumberUtil.formatNumByDecimal(billStr, info.payload.invoice.invoice.summation.total.currency
                            ?: "")
            tv_invoice_detail_other_info_bill?.text = billTxt
        }
        tv_invoice_detail_other_info_due_date?.text = if (info?.payload?.invoice?.invoice?.dueDate != null) {
            TimeZoneTransformsUtil.formatTime(info.payload.invoice.invoice.dueDate)
        } else {
            TimeZoneTransformsUtil.formatTime(Date())
        }
        tv_invoice_detail_other_info_issue_date?.text = if (info?.payload?.invoice?.invoice?.issueDate != null) {
            TimeZoneTransformsUtil.formatTime(info.payload.invoice.invoice.issueDate)
        } else {
            TimeZoneTransformsUtil.formatTime(Date())
        }

        if ("R" == info?.payload?.invoice?.invoice?.status) {
            btn_invoice_detail_add_plan_payment.visibility = View.GONE
        }

        if (info != null) {
            if (info.payload.itps != null) {
                var isHasProcessingPayment = false
                ll_invoice_detail_planned_payment_container.removeAllViews()
                for (item in info.payload.itps) {
                    ll_invoice_detail_planned_payment_container.addView(providePlannedPayment(item))
//                    if (!isHasProcessingPayment) {
//                        if ("processing" == item.status && "dcms" == item.itp?.paymentMethod) {
//                            isHasProcessingPayment = true
//                        }
//                    }
                }

//                if (isHasProcessingPayment) {
//                    if (mInfo?.payload?.invoice?.invoice?.status == "U" || mInfo?.payload?.invoice?.invoice?.status == "P") {
//                        tv_invoice_detail_processing_tip.visibility = View.VISIBLE
//                    }
//                } else {
//                    tv_invoice_detail_processing_tip.visibility = View.GONE
//                }
            }

            ll_invoice_detail_deductions_container.removeAllViews()

            if (!info.payload.deductions.isNullOrEmpty()) {
                v_invoice_deduction_separate_top.visibility = View.VISIBLE
                tv_invoice_detail_deductions_tag.visibility = View.VISIBLE
                v_invoice_deduction_separate_middle.visibility = View.VISIBLE
                ll_invoice_detail_deductions_container.visibility = View.VISIBLE
                info.payload.deductions[info.payload.invoice?.token]?.forEach {
                    ll_invoice_detail_deductions_container.addView(provideInvoiceDeductionItem(it))
                }
            } else {
                v_invoice_deduction_separate_top.visibility = View.GONE
                tv_invoice_detail_deductions_tag.visibility = View.GONE
                v_invoice_deduction_separate_middle.visibility = View.GONE
                ll_invoice_detail_deductions_container.visibility = View.GONE
            }
        }

        tv_invoice_detail_more_info.setAccessibilityDelegate(object : View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        })

        btn_invoice_detail_add_plan_payment.setOnClickListener(this)
//        tv_invoice_detail_other_info_tag.setOnClickListener(this)
        tv_timeline_collapse.setOnClickListener(this)
//        tv_invoice_detail_planned_payment_tag.setOnClickListener(this)
        btn_common_back.setOnClickListener(this)
        tv_invoice_detail_more_info.setOnClickListener(this)
//        tv_invoice_detail_beneficiary_account_number.text = if ("S" == MemoryCache.getSessionEntity()?.type) {
//            info?.payload?.invoice?.invoice?.payor?.account?.display
//        } else {
        tv_invoice_detail_beneficiary_account_number.text = info?.payload?.invoice?.invoice?.payee?.account?.display
//        }
//        tv_invoice_detail_beneficiary_account_name.text = if ("S" == MemoryCache.getSessionEntity()?.type) {
//            info?.payload?.invoice?.invoice?.payor?.name
//        } else {
        tv_invoice_detail_beneficiary_account_name.text = info?.payload?.invoice?.invoice?.payee?.name
//        }

        if (info?.payload?.invoice?.invoice?.status == "O" || info?.payload?.invoice?.invoice?.status == "F") {
            btn_invoice_detail_add_plan_payment.setBackgroundColor(ContextCompat.getColor(this, R.color.secondary_gray))
            btn_invoice_detail_add_plan_payment.isEnabled = false
        } else {
            btn_invoice_detail_add_plan_payment.setBackgroundColor(ContextCompat.getColor(this, R.color.primary_red))
            btn_invoice_detail_add_plan_payment.isEnabled = true
        }
    }

    /**
     * add timeline item to page, no using list view or recycler view to show the items, i think the count of items may not too much
     * if the num become large, here will change to use list view or recycler view
     */
    override fun updateDetailTimeline(timeline: InvoiceDetailTimeLineEntity?) {
        if (timeline != null) {
            if (timeline.payload.notifications != null) {
                ll_invoice_detail_timeline_container.removeAllViews()
                for (i in timeline.payload.notifications.indices) {
                    var type = TIMELINE_TYPE_NORMAL
                    if (i == 0) {
                        type = type or TIMELINE_TYPE_HEAD
                    }

                    if (i == timeline.payload.notifications.size - 1) {
                        type = type or TIMELINE_TYPE_FOOT
                    }
                    ll_invoice_detail_timeline_container.addView(provideTimeLineItem(timeline.payload.notifications[i], type))
                }
            }
        }
    }

    /**
     *  onClick listener
     */
    override fun onClick(v: View?) {
        when (v?.id) {
            //hide or show other info
            R.id.tv_invoice_detail_other_info_tag -> {
                cl_invoice_detail_other_info_container.visibility = if (isOtherInfoShowing) View.GONE else View.VISIBLE
                isOtherInfoShowing = !isOtherInfoShowing
            }
            //hide or show timeline info
            R.id.tv_timeline_collapse -> {
                ll_invoice_detail_timeline_container.visibility = if (isTimelineShowing) {
                    tv_timeline_collapse.text = MemoryCache.getLabelText("s_view") ?: getString(R.string.s_view)
                    tv_timeline_collapse.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null,
                            ContextCompat.getDrawable(this, R.drawable.ic_arrow_down_black), null)
                    View.GONE
                } else {
                    tv_timeline_collapse.text = MemoryCache.getLabelText("s_hide") ?: getString(R.string.s_hide)
                    tv_timeline_collapse.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null,
                            ContextCompat.getDrawable(this, R.drawable.ic_arrow_up_black), null)
                    View.VISIBLE
                }
                isTimelineShowing = !isTimelineShowing
            }
            //hide or show planned payment info
            R.id.tv_invoice_detail_planned_payment_tag -> {
                ll_invoice_detail_planned_payment_container.visibility = if (isPlannedPaymentShowing) View.GONE else View.VISIBLE
                isPlannedPaymentShowing = !isPlannedPaymentShowing
            }
            //back
            R.id.btn_common_back -> {
                TealiumUtil.eventTag("button click", "invoices invoice detail: back")
                finish()
            }
            //go to create plan payment
            R.id.btn_invoice_detail_add_plan_payment -> {
                TealiumUtil.eventTag("button click", "invoices invoice detail: pay now")
                val tmpCode = 404
                val invoices: ArrayList<InvoiceListItem?> = arrayListOf(mInfo?.payload?.invoice)
                PlannedPaymentCreationActivity.showActivity(this, invoices, tmpCode)
            }
            //invoice detail more info
            R.id.tv_invoice_detail_more_info -> {
                InvoiceDetailMoreActivity.showActivity(this, mInfo)
            }
        }
    }

    /**
     * build timeline item
     */
    private fun provideTimeLineItem(timeline: Notification, type: Int): View {
        val timelineItem = LayoutInflater.from(this).inflate(R.layout.item_invoice_detail_time_line, null).apply {
            //depart date and time
            val timeDepart = if (timeline.createdAt != null) {
                val dateStr = TimeZoneTransformsUtil.transforms(timeline.createdAt)
                dateStr?.split(" ")
            } else {
                listOf(TimeZoneTransformsUtil.formatParameterTime(Date()))
            }

            //show date and time
            if (timeDepart?.size == 2) {
                this.tv_invoice_detail_timeline_item_date.text = TimeZoneTransformsUtil.formatTime(timeDepart[0])
                this.tv_invoice_detail_timeline_item_time.text = timeDepart[1]
            } else {
                this.tv_invoice_detail_timeline_item_date.text = MemoryCache.getLabelText("s_illegal_time")
                        ?: getString(R.string.s_illegal_time)
            }

            //build timeline message and title
            this.tv_invoice_detail_timeline_item_date.setTextColor(ContextCompat.getColor(this@InvoiceDetailActivity, R.color.primary_gray))
            this.tv_invoice_detail_timeline_item_title.text = getTimelineType(timeline.type)
            val timelineMessage = when (timeline.type) {
                null -> {
                    MemoryCache.getLabelText("s_unknown_event")
                            ?: getString(R.string.s_unknown_event)
                }
                INVOICE -> {
                    var payeeName: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    var reference: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "payeeName" -> payeeName = it.value
                                "currency" -> currency = it.value
                                "amount" -> amount = it.value
                                "reference" -> reference = it.value
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_invoice_new")
                            ?: getString(R.string.s_timeline_invoice_new), payeeName,
                            currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            },
                            reference
                    )
                }
                "invoice.update" -> {
                    var payeeName: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            if (it.key == "payeeName") {
                                payeeName = it.value
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_invoice_update")
                            ?: getString(R.string.s_timeline_invoice_update), payeeName)
                }
                "itp.create" -> {
                    var expectedDate: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "currency" -> currency = it.value
                                "amount" -> amount = it.value
                                "expectedDate" -> expectedDate = if (it.value != null) (TimeZoneTransformsUtil.formatTime(it.value)) else MemoryCache.getLabelText("s_illegal_time")
                                        ?: getString(R.string.s_illegal_time)
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_planned_payment_create")
                            ?: getString(R.string.s_timeline_planned_payment_create), currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            },
                            expectedDate)
                }
                "itp.update.amount" -> {
                    var expectedDate: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "currency" -> currency = it.value
                                "amount" -> amount = it.value
                                "expectedDate" -> expectedDate = if (it.value != null) (TimeZoneTransformsUtil.formatTime(it.value)) else MemoryCache.getLabelText("s_illegal_time")
                                        ?: getString(R.string.s_illegal_time)
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_planned_payment_update")
                            ?: getString(R.string.s_timeline_planned_payment_update), currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            },
                            expectedDate)
                }
                "creditNote.applied" -> {
                    var payeeCreditNoteReference: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "currency" -> currency = it.value
                                "amount" -> amount = it.value
                                "payeeCreditNoteReference" -> payeeCreditNoteReference = it.value
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_credit_note_applied")
                            ?: getString(R.string.s_timeline_credit_note_applied), payeeCreditNoteReference,
                            currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            })
                }
                "itp.status.creditnote" -> {
                    var payeeCreditNoteReference: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "currency" -> currency = it.value
                                "amount" -> amount = it.value
                                "payeeCreditNoteReference" -> payeeCreditNoteReference = it.value
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_credit_note_create")
                            ?: getString(R.string.s_timeline_credit_note_create), payeeCreditNoteReference,
                            currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            })
                }
                "itp.status.invoice" -> {
                    var currency: String? = ""
                    var amount: String? = ""
                    var throughDCMSFlag = false
                    var providerName: String? = ""
                    var paymentMethod: String? = ""
                    var paymentReference: String? = ""
                    var status: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "currency" -> currency = it.value
                                "amount" -> amount = it.value
                                "paymentMethod" -> {
                                    throughDCMSFlag = (it.value == "dcms" || it.value == "virtual_account")
                                    paymentMethod = it.value
                                }
                                "dcms-provider" -> providerName = it.value
                                "paymentReference" -> paymentReference = it.value
                                "status" -> status = it.value
                            }
                        }
                    }
                    if (throughDCMSFlag) {
                        if (status == "closed") {
                            String.format(MemoryCache.getLabelText("s_timeline_payment")
                                ?: getString(R.string.s_timeline_payment),
                                currency,
                                if (amount.isNullOrEmpty()) {
                                    getString(R.string.s_zero_number)
                                } else {
                                    IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                                })
                        } else {
                            String.format(MemoryCache.getLabelText("s_timeline_payment_with_dcms")
                                    ?: getString(R.string.s_timeline_payment_with_dcms),
                                    currency,
                                    if (amount.isNullOrEmpty()) {
                                        getString(R.string.s_zero_number)
                                    } else {
                                        IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency
                                                ?: "")
                                    },
                                    if (paymentMethod == "dcms") providerName else "VA payment code",
                                    paymentReference
                            )
                        }
                    } else {
                        String.format(MemoryCache.getLabelText("s_timeline_payment")
                                ?: getString(R.string.s_timeline_payment),
                                currency,
                                if (amount.isNullOrEmpty()) {
                                    getString(R.string.s_zero_number)
                                } else {
                                    IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                                })
                    }
                }
                "itp.line.removed" -> {
                    var paymentRef: String? = ""
                    var date: String? = ""
                    timeline.properties?.forEach {
                        when (it.key) {
                            "expectedDate" -> date = it.value
                            "paymentReference" -> paymentRef = it.value
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_remove_invoice") ?: getString(R.string.s_timeline_remove_invoice),
                    paymentRef, TimeZoneTransformsUtil.formatTime(date))
//                            TimeZoneTransformsUtil.formatTimeInSimple(date))
                }
                "openItem" -> {
                    var status: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "currency" -> currency = it.value
                                "outstanding" -> amount = it.value
                                "status" -> status = MemoryCache.getLabelText("s_invoice_status_" + it.value)
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_update")
                            ?: getString(R.string.s_timeline_update),
                            status,
                            currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            })
                }
                "itp.revoke.payor" -> {
                    var expectedDate: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "currency" -> currency = it.value
                                "amount" -> amount = it.value
                                "expectedDate" -> expectedDate = if (it.value != null) (TimeZoneTransformsUtil.formatTime(it.value)) else MemoryCache.getLabelText("s_illegal_time")
                                        ?: getString(R.string.s_illegal_time)
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_revoke")
                            ?: getString(R.string.s_timeline_revoke), currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            },
                            expectedDate)
                }
                "preallocatedcreditnote" -> {
                    var payeeCreditNoteReference: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "currency" -> currency = it.value
                                "amount" -> amount = it.value
                                "payeeCreditNoteReference" -> payeeCreditNoteReference = it.value
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_creditnote")
                            ?: getString(R.string.s_timeline_creditnote), payeeCreditNoteReference, currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            })
                }
                "deduction.applied" -> {
                    var deductionName: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    var percentage: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "deductionMaxPercentage" -> percentage = "${it.value}%"
                                "currency" -> currency = it.value
                                "amount" -> amount = "-${it.value}"
                                "deductionName" -> deductionName = it.value
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_time_line_deduction")
                            ?: getString(R.string.s_time_line_deduction), percentage, deductionName, currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            })
                }
                "invoice.delete" -> {
                    /* payeeReference, payorReference, expectedDate, currency, status */
                    var payeeName: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            if (it.key == "payeeName") {
                                payeeName = it.value
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_timeline_invoice_delete")
                            ?: getString(R.string.s_timeline_invoice_delete), payeeName)
                }
                //mock up
                "deduction.confirmed" -> {
                    var deductionName: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    var percentage: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "deductionMaxPercentage" -> percentage = "${it.value}%"
                                "currency" -> currency = it.value
                                "amount" -> amount = "-${it.value}"
                                "deductionName" -> deductionName = it.value
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_time_line_deduction_confirmed")
                            ?: getString(R.string.s_time_line_deduction_confirmed), deductionName, currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            })
                }
                // mock up
                "deduction.rejected" -> {
                    var deductionName: String? = ""
                    var currency: String? = ""
                    var amount: String? = ""
                    var percentage: String? = ""
                    var rejectReason: String? = ""
                    if (timeline.properties != null) {
                        timeline.properties.forEach {
                            when (it.key) {
                                "deductionMaxPercentage" -> percentage = "${it.value}%"
                                "currency" -> currency = it.value
                                "amount" -> amount = "-${it.value}"
                                "deductionName" -> deductionName = it.value
                                "reason" -> rejectReason = it.value
                            }
                        }
                    }
                    String.format(MemoryCache.getLabelText("s_time_line_deduction_rejected")
                            ?: getString(R.string.s_time_line_deduction_rejected), deductionName, currency,
                            if (amount.isNullOrEmpty()) {
                                getString(R.string.s_zero_number)
                            } else {
                                IndiaNumberUtil.formatNumByDecimal(amount ?: "", currency ?: "")
                            }, rejectReason)
                }
                else -> {
                    MemoryCache.getLabelText("s_timeline_default_event")
                            ?: getString(R.string.s_timeline_default_event)
                }
            }
            this.tv_invoice_detail_timeline_item_message.text = timelineMessage
        }
        return timelineItem.apply {
            if ((type and TIMELINE_TYPE_HEAD) > 0) {
                this.v_invoice_detail_timeline_top_line.visibility = View.INVISIBLE
            }

            if ((type and TIMELINE_TYPE_FOOT) > 0) {
                this.v_invoice_detail_timeline_bottom_line.visibility = View.GONE
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
//            mPresenter.getInvoiceDetail(mToken)
            mViewModel.doRequest(mToken)
        }
    }

    /**
     * provide timeline type
     */
    private fun getTimelineType(originType: String?): String {
        return if (originType == null) {
            MemoryCache.getLabelText("s_new") ?: getString(R.string.s_new)
        } else {
            when(VALUE_TIMELINE_TYPE[originType] ?: MemoryCache.getLabelText("s_new")
            ?: getString(R.string.s_new)) {
                "New" -> MemoryCache.getLabelText("s_new") ?: getString(R.string.s_new)
                "Update" -> MemoryCache.getLabelText("s_update") ?: getString(R.string.s_update)
                "Planned payment" -> MemoryCache.getLabelText("s_planned_payment") ?: getString(R.string.s_planned_payment)
                "Credit note" -> MemoryCache.getLabelText("s_credit_note") ?: getString(R.string.s_credit_note)
                "Payment" -> MemoryCache.getLabelText("s_payment") ?: getString(R.string.s_payment)
                "Deduction" -> MemoryCache.getLabelText("s_deduction") ?: getString(R.string.s_deduction)
                "Delete" -> MemoryCache.getLabelText("s_delete") ?: getString(R.string.s_delete)
                // mock up
                "Deduction confirmed" -> MemoryCache.getLabelText("s_deduction") ?: getString(R.string.s_deduction)
                "Deduction rejected" -> MemoryCache.getLabelText("s_deduction") ?: getString(R.string.s_deduction)
                else -> MemoryCache.getLabelText("s_new") ?: getString(R.string.s_new)
            }
        }
    }

    /**
     * build planned payment item
     * the same as timeline, no using list view or recycler view here
     */
    private fun providePlannedPayment(planPayment: ITPListItem): View {
        return LayoutInflater.from(this).inflate(R.layout.item_invoice_list_plan_payment_info, null).apply {
            setAccessibilityDelegate(object : View.AccessibilityDelegate() {

                override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info?.className = Button::class.java.name
                }
            })

            this.tv_invoice_list_plan_payment_item_id_tag.text = String.format(MemoryCache.getLabelText("s_payment_ref")
                    ?: getString(R.string.s_payment_ref), planPayment.itp?.paymentReference)
            if (planPayment.itp?.lines == null) {
                this.tv_invoice_list_plan_payment_amount.text = "${MemoryCache.defaultCurrency} 0.00"
            } else {
                val relatedInvoiceLine = planPayment.itp.lines.filter {
                    it.token == mInfo?.payload?.invoice?.token && it.amount?.currency == mInfo?.payload?.invoice?.invoice?.summation?.total?.currency
                }

                var relateAmount = 0L
                relatedInvoiceLine.forEach {
                    relateAmount += (it.amount?.amount?.toLong() ?: 0)
                }
                val amountText = planPayment.itp.lines[0].amount?.currency + " " +
                        IndiaNumberUtil.formatNumByDecimal(relateAmount.toString()
                                ?: "", planPayment.itp.lines[0].amount?.currency ?: "")
                this.tv_invoice_list_plan_payment_amount.text = amountText
            }
            this.tv_invoice_list_plan_payment_date.text = if (planPayment.itp?.expectedDate != null) {
                TimeZoneTransformsUtil.formatTime(planPayment.itp.expectedDate)
            } else {
                TimeZoneTransformsUtil.formatParameterTime(Date())
            }
            var statusText = MemoryCache.getLabelText("s_payment_status_" + planPayment.status)
            if (statusText == "Processed") {
                if (MemoryCache.defaultCountry == "IN") {
                    statusText = "Processing"
                }
            }
            this.tv_invoice_list_plan_payment_status.text = statusText
            this.tv_invoice_list_plan_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_" + planPayment.itp?.paymentMethod)

            setOnClickListener {
                TealiumUtil.eventTag("button click", "invoices invoice detail: planned payment information")
                PlannedPaymentDetailActivity.showActivity(this@InvoiceDetailActivity, planPayment.token!!, 404, false)
            }
        }
    }

    /**
     * build deduction item in this invoice
     */
    private fun provideInvoiceDeductionItem(deduction: TaxDeductionInfo): View {
        return LayoutInflater.from(this).inflate(R.layout.item_invoice_detail_deduction, null).apply {
            this.tv_invoice_detail_deduction_name.text = deduction.name
            this.tv_invoice_detail_deduction_amount.text = deduction.currency + " " +
                    IndiaNumberUtil.formatNumByDecimal(deduction.maxAmount ?: "",
                    deduction.currency ?: MARKET_CURRENCY ?: "")
            this.tv_invoice_detail_deduction_date.text = TimeZoneTransformsUtil.formatTime(deduction.createdAt)
            this.tv_invoice_detail_deduction_type.text = deduction.type
            this.tv_invoice_detail_deduction_status.text = deduction.status
            deduction.rejectReason?.let {
                this.tv_invoice_detail_deduction_reason.visibility = View.VISIBLE
                this.tv_invoice_detail_deduction_reason.text = it
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag("dart:buyer portal:invoices:invoice detail",
                "/dart/buyer-portal/invoices/invoice-detail", "payment", "buyer portal",
                "invoices")
    }
}