/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_CALENDAR_CURRENCY
import hk.com.hsbc.glcmdart.client.TAG_REQUEST_INTENT_DATA_DUEDAY_PLANNED_PAYMENT
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PlannedPaymentListPayload
import hk.com.hsbc.glcmdart.util.MemoryCache

import kotlinx.android.synthetic.main.activity_planned_payment_due_day.*

class PlannedPaymentDueDayActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planned_payment_due_day)
        initView()
    }

    @SuppressLint("ResourceAsColor")
    private fun initView() {
        tl_head.title = MemoryCache.getLabelText("s_payments") ?: getString(R.string.s_payments)
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener { finish() }

        val data=intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_DUEDAY_PLANNED_PAYMENT)
        val fragment = PaymentsDueDayFragment.newInstance(false, data as PlannedPaymentListPayload)
        fragment.currency = intent.getStringExtra(TAG_CALENDAR_CURRENCY)
        val transaction = supportFragmentManager.beginTransaction()
        transaction.add(R.id.fl_container, fragment)
        transaction.show(fragment).commitAllowingStateLoss()

    }


    companion object {
        fun showActivity(fragment: Fragment, data: PlannedPaymentListPayload, currency: String) {
            val intent = Intent(fragment.activity, PlannedPaymentDueDayActivity::class.java)
            intent.putExtra(TAG_REQUEST_INTENT_DATA_DUEDAY_PLANNED_PAYMENT,data)
            intent.putExtra(TAG_CALENDAR_CURRENCY, currency)
            fragment.startActivity(intent)
        }
    }

}
