package hk.com.hsbc.glcmdart.domain.more

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_PAYEE_DETAIL
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import kotlinx.android.synthetic.main.activity_suppliers_or_buyers_detail.*

class SuppliersOrBuyersDetailActivity: BaseActivity() {

    companion object {
        fun showActivity(activity: Activity?, detail: Payee) {
            val intent = Intent(activity, SuppliersOrBuyersDetailActivity::class.java).apply {
                putExtra(TAG_PAYEE_DETAIL, detail)
            }
            activity?.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_suppliers_or_buyers_detail)

        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        removeStatusView(this)

        val detail = intent?.extras?.get(TAG_PAYEE_DETAIL) as Payee?
        detail?.let {
            tv_suppliers_or_buyers_detail_name.text = it.name
            tv_suppliers_or_buyers_detail_email.text = if (it.organizationDetail?.email.isNullOrEmpty()) "-" else it.organizationDetail?.email
            tv_suppliers_or_buyers_detail_contact.text = if (it.organizationDetail?.contact.isNullOrEmpty()) "-" else it.organizationDetail?.contact
            tv_suppliers_or_buyers_detail_phone.text = if (it.organizationDetail?.phone.isNullOrEmpty()) "-" else it.organizationDetail?.phone
            tv_suppliers_or_buyers_detail_address.text = if (it.organizationDetail?.address.isNullOrEmpty()) "-" else it.organizationDetail?.address
        }

        ib_suppliers_or_buyers_detail_back.setOnClickListener { finish() }

        MemoryCache.getLabelText("s_talkback_detail_back")?.let {
            if (!it.isBlank()) {
                ib_suppliers_or_buyers_detail_back.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_email")?.let {
            if (!it.isBlank()) {
                tv_suppliers_or_buyers_email_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_contact")?.let {
            if (!it.isBlank()) {
                tv_suppliers_or_buyers_contact_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_telephone")?.let {
            if (!it.isBlank()) {
                tv_suppliers_or_buyers_phone_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_address")?.let {
            if (!it.isBlank()) {
                tv_suppliers_or_buyers_address_tag.text = it
            }
        }
    }
}