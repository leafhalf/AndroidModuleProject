/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.dashboard

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.*
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.viewpager.widget.PagerAdapter
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.Account
import hk.com.hsbc.glcmdart.domain.dart.Payee
import hk.com.hsbc.glcmdart.domain.payments.SuppliersOrCustomersSelectActivity
import hk.com.hsbc.glcmdart.domain.payments.view.PaymentSummaryView.Companion.SUMMARY_FILTER_TYPE_METHOD
import hk.com.hsbc.glcmdart.domain.payments.view.PaymentSummaryView.Companion.SUMMARY_FILTER_TYPE_STATUS
import hk.com.hsbc.glcmdart.extension.hideLoadingDialogExt
import hk.com.hsbc.glcmdart.extension.showLoadingDialogExt
import hk.com.hsbc.glcmdart.util.ConvertUtil
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TimeZoneTransformsUtil
import hk.com.hsbc.glcmdart.widget.CubeOutTransformer
import hk.com.hsbc.glcmdart.widget.ObservableHorizontalScrollView
import hk.com.hsbc.glcmdart.widget.ViewOnScrollListener
import kotlinx.android.synthetic.main.fragment_chart.*
import kotlinx.android.synthetic.main.fragment_chart.view.*
import kotlinx.android.synthetic.main.view_payment_summary.view.*
import kotlinx.android.synthetic.main.view_supplier_dashboard_payment_popup.view.*
import java.util.*

class ChartFragment : Fragment(), ChartContract.View, View.OnClickListener, ViewOnScrollListener {

    companion object {
        fun newInstance(): ChartFragment {
            return ChartFragment()
        }

        private const val REQUEST_CODE_CUSTOMERS = 2000
        private const val REQUEST_CODE_FILTER = 2001
    }

//    private val mPresenter = ChartPresenter()
    private lateinit var mViewModel: ChartViewModel
    private lateinit var requestParameter: HashMap<String, Any>
    private lateinit var rootView: View
    private lateinit var mFilterText: TextView
    private lateinit var tvCustomerFilter: TextView
    private val invoiceSummaryXY = intArrayOf(0, 0)
    private val paymentSummaryXY = intArrayOf(0, 0)
    private val accountsList = mutableListOf<Account>()
    private val inflater by lazy { LayoutInflater.from(activity) }
    private var mCurrentPage = 1
    private var mInvoiceList = mutableListOf<HomeInvoiceStatusInfo>()
    private var mPaymentList = mutableListOf<HomePaymentChannelInfo>()
    private var lastBuyerName = "All"
    private var mPaymentChannel: HomePaymentChannelEntity? = null
    private var isNoData = false
    private val paymentPopupTextXY = intArrayOf(0,0)
    private val chartFilterByPopup by lazy {
        PopupWindow(ConvertUtil.dp2px(activity, 138f).toInt(), ConvertUtil.dp2px(activity, 111f).toInt()).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(ColorDrawable(0xffffff))
        }
    }
    private val popupItemClickListener = { v: View ->
        chartFilterByPopup.dismiss()
        val itemText = (v as TextView).text.toString()
        if (mFilterText.text.toString() != itemText) {
            activity?.let {
                if (itemText == MemoryCache.getLabelText("s_by_method") ?: getString(R.string.s_by_method)) {
                    popupView.tv_dashboard_popup_first_item.setBackgroundColor(ContextCompat.getColor(it, R.color.secondary_light_gray))
                    popupView.tv_dashboard_popup_second_item.setBackgroundColor(Color.WHITE)
                } else {
                    popupView.tv_dashboard_popup_first_item.setBackgroundColor(Color.WHITE)
                    popupView.tv_dashboard_popup_second_item.setBackgroundColor(ContextCompat.getColor(it, R.color.secondary_light_gray))
                }
            }
            mFilterText.text = itemText
            updateChartEntity()
            setPaymentSummaryByFilter(itemText)
        }
    }
    private val popupView by lazy {
        val view = inflater.inflate(R.layout.view_supplier_dashboard_payment_popup, null)
        view.tv_dashboard_popup_first_item.text = MemoryCache.getLabelText("s_by_method") ?: getString(R.string.s_by_method)
        view.tv_dashboard_popup_second_item.text = MemoryCache.getLabelText("s_by_status") ?: getString(R.string.s_by_status)
        view
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        mPresenter.attachView(this)
        mViewModel = ViewModelProviders.of(this).get(ChartViewModel::class.java)
        mViewModel.doInvoiceRequest()
        mViewModel.accountsLiveData.observe(this, androidx.lifecycle.Observer {
            saveAccounts(it)
        })

        mViewModel.channelLiveData.observe(this, androidx.lifecycle.Observer {
            updateChannelsData(it)
        })

        mViewModel.metricsLiveData.observe(this, androidx.lifecycle.Observer {
            if (it != null) {
                updateFragmentMetricsData(it)
            }
        })

        mViewModel.statusLiveData.observe(this, androidx.lifecycle.Observer {
            updateInvoiceStatusData(it)
        })

        mViewModel.summaryLiveData.observe(this, androidx.lifecycle.Observer {
            if (it != null) {
                updateInvoiceSummaryData(it)
            }
        })

        mViewModel.requestLoadingLiveData.observe(this, androidx.lifecycle.Observer {
            if (it) { showLoadingDialogExt() } else { hideLoadingDialogExt() }
        })

        mViewModel.exceptionLiveData.observe(this, androidx.lifecycle.Observer {
            Toast.makeText(activity, it, Toast.LENGTH_SHORT).show()
        })
        requestParameter = HashMap()
        requestParameter["currency"] = MemoryCache.defaultCurrency ?: MARKET_CURRENCY
        requestParameter["accounts"] = mutableListOf<String>()
        requestParameter["buyers"] = mutableListOf<String>()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootView = inflater.inflate(R.layout.fragment_chart, container, false)
        initViewAndData()
        return rootView
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initViewAndData() {
        val buttonAccessibilityDelegate = object: View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        }
        rootView.tv_home_customer_selector.text = String.format(MemoryCache.getLabelText("s_apply_filter") ?: getString(R.string.s_home_customer_selection), MemoryCache.getLabelText("s_apply_filter") ?: getString(R.string.s_all))
        rootView.tv_home_payment_summary_invoice_num.text = String.format(MemoryCache.getLabelText("s_apply_filter") ?: getString(R.string.s_home_summary_payment_invoices_num), "0")
        rootView.tv_home_invoice_summary_total_amount_tag.text = String.format(MemoryCache.getLabelText("s_apply_filter") ?: getString(R.string.s_total_invoices), "0")
        rootView.tv_home_invoice_summary_today_amount_tag.text = String.format(MemoryCache.getLabelText("s_apply_filter") ?: getString(R.string.s_due_today_invoices), "0")
        rootView.tv_home_invoice_summary_today_overdue_amount_tag.text = String.format(MemoryCache.getLabelText("s_apply_filter") ?: getString(R.string.s_invoices_overdue), "0")
        mFilterText = rootView.filterText
        tvCustomerFilter = rootView.tv_home_customer_selector
        rootView.hsv_home_summary_container.isSmoothScrollingEnabled = true

        mFilterText.text = MemoryCache.getLabelText("s_by_method") ?: getString(R.string.s_by_method)
        MemoryCache.getLabelText("s_talkback_dashboard_filter")?.let {
            if (!it.isBlank()) {
                rootView.iv_home_filter.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_no_amount_due")?.let {
            if (!it.isBlank()) {
                rootView.tv_home_invoice_summary_today_overdue_amount.text = it
            }
        }
        MemoryCache.getLabelText("s_planned_payments_paid_today")?.let {
            if (!it.isBlank()) {
                rootView.tv_home_payment_summary_title.text = it
            }
        }
        MemoryCache.getLabelText("s_invoices_summary")?.let {
            if (!it.isBlank()) {
                rootView.subTitleText.text = it
            }
        }
        MemoryCache.getLabelText("s_no_invoices_to_display")?.let {
            if (!it.isBlank()) {
                rootView.tv_home_invoice_summary_no_data.text = it
            }
        }
        MemoryCache.getLabelText("s_no_payments_to_display")?.let {
            if (!it.isBlank()) {
                rootView.tv_home_payment_summary_no_data.text = it
            }
        }

        rootView.hsv_home_summary_container.ll_home_payment_summary_container.viewTreeObserver.addOnGlobalLayoutListener {
            val invoiceHeight = rootView.hsv_home_summary_container.ll_home_invoice_summary_container.height
            val param = rootView.hsv_home_summary_container.ll_home_payment_summary_container.layoutParams
            param.height = invoiceHeight
            rootView.hsv_home_summary_container.ll_home_payment_summary_container.layoutParams = param
        }

        rootView.hsv_home_summary_container.ll_home_invoice_summary_container.setAccessibilityDelegate(buttonAccessibilityDelegate)
        rootView.hsv_home_summary_container.ll_home_payment_summary_container.setAccessibilityDelegate(buttonAccessibilityDelegate)
        rootView.hsv_home_summary_container.setScrollChangeListener(this)
        rootView.hsv_home_summary_container.ll_home_invoice_summary_container.setOnClickListener(this)
        rootView.hsv_home_summary_container.ll_home_payment_summary_container.setOnClickListener(this)
        mFilterText.setOnClickListener(this)
        tvCustomerFilter.setOnClickListener(this)
        rootView.iv_home_filter.setOnClickListener(this)
        rootView.hsv_home_summary_container.viewTreeObserver.addOnGlobalLayoutListener(
                object : ViewTreeObserver.OnGlobalLayoutListener {
                    override fun onGlobalLayout() {
                        rootView.hsv_home_summary_container.ll_home_invoice_summary_container.getLocationOnScreen(invoiceSummaryXY)
                        rootView.hsv_home_summary_container.ll_home_payment_summary_container.getLocationOnScreen(paymentSummaryXY)
                        rootView.hsv_home_summary_container.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    }
                })

        rootView.hsv_home_summary_container.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                if (mCurrentPage == 2) {
                    if (rootView.hsv_home_summary_container.scrollX < rootView.hsv_home_summary_container.ll_home_invoice_summary_container.right / 8 * 7) {
                        showInvoiceSummary()
                    } else {
                        showPaymentSummary()
                    }
                } else {
                    if (rootView.hsv_home_summary_container.scrollX > rootView.hsv_home_summary_container.ll_home_payment_summary_container.left / 8) {
                        showPaymentSummary()
                    } else {
                        showInvoiceSummary()
                    }
                }
                return@setOnTouchListener true
            }
            return@setOnTouchListener false
        }

        Calendar.getInstance().let {
            it.time = Date(System.currentTimeMillis())
            it
        }.also {
            when (it.get(Calendar.HOUR_OF_DAY)) {
                in 1..11 -> {
                    rootView.tv_home_title.text = MemoryCache.getLabelText("head_day_morning") ?: resources.getText(R.string.head_day_morning)
                }
                in 12..(12 + 5) -> {
                    rootView.tv_home_title.text = MemoryCache.getLabelText("head_day_afternoon") ?: resources.getText(R.string.head_day_afternoon)
                }
                in (12 + 6)..(12 + 11) -> {
                    rootView.tv_home_title.text = MemoryCache.getLabelText("head_day_evening") ?: resources.getText(R.string.head_day_evening)
                }
                else -> {
                    rootView.tv_home_title.text = MemoryCache.getLabelText("head_day_morning") ?: resources.getText(R.string.head_day_morning)
                }
            }
        }

        showLoadingDialogExt()
        requestParameter["minDate"] = TimeZoneTransformsUtil.formatParameterTime(Date(Date().time - 15552000000))
        requestParameter["maxDate"] = TimeZoneTransformsUtil.formatParameterTime(Date())
        mViewModel.getProfileDetail(requestParameter)
    }

    private fun updateChartEntity() {
        when (mCurrentPage) {
            1 -> {
                val map = mutableMapOf<String, RingData>().also { m ->
                    INVOICE_STATUS.forEach { key ->
                        m[key] = RingData(0.toDouble(), getInvoiceColor(key), null)
                    }
                }
                var totalValue = 0.toDouble()
                mInvoiceList.forEach { entity ->
                    entity.totalValue?.also {
                        totalValue += it.toDouble()
                    }
                    map[entity.status]?.also {
                        it.tag = entity
                    }
                }
                map.forEach {
                    val value = it.value
                    val entity = value.tag as HomeInvoiceStatusInfo?
                    val itemValue = if (entity?.totalValue != null) entity.totalValue.toDouble() else 0.toDouble()
                    value.gravity = itemValue / totalValue
                }
                updateInvoiceView(map)
            }
            2 -> {
                val existingMethod = mutableSetOf<String?>()
                mPaymentChannel?.payload?.items?.forEach {
                    if (it.channel != "full_deduction" && it.channel != "credit_note")
                        existingMethod.add(it.channel)
                }
                val map = mutableMapOf<String, MutableMap<String, RingData>>().also { m ->
                    if (mFilterText.text.toString() == MemoryCache.getLabelText("s_by_status") ?: getString(R.string.s_by_status)) {
                        PAYMENT_STATUS.forEach { key ->
                            m[key] = mutableMapOf()
                        }
                    } else {
                        existingMethod.forEach { key ->
                            m[key ?: ""] = mutableMapOf()
                        }
                    }
                }
                map.values.forEach { item ->
                    if (mFilterText.text.toString() == MemoryCache.getLabelText("s_by_status") ?: getString(R.string.s_by_status)) {
                        existingMethod.forEach { key ->
                            item[key ?: ""] = RingData(0.toDouble(), getPaymentMethodColor(key ?: ""), 0.toDouble())
                        }
                    } else {
                        PAYMENT_STATUS.forEach { key ->
                            item[key] = RingData(0.toDouble(), getPaymentStatusColor(key), 0.toDouble())
                        }
                    }
                }
                mPaymentList.forEach { entity ->
                    if (mFilterText.text.toString() == MemoryCache.getLabelText("s_by_status") ?: getString(R.string.s_by_status)) {
                        val value = map[entity.paidStatus]?.get(entity.channel)
                        val l = if (value?.tag is Double) value.tag as Double else 0.toDouble()
                        val t = if (entity.totalValue != null) entity.totalValue.toDouble() else 0.toDouble()
                        value?.tag = l + t
                    } else {
                        val value = map[entity.channel]?.get(entity.paidStatus)
                        val l = if (value?.tag is Double) value.tag as Double else 0.toDouble()
                        val t = if (entity.totalValue != null) entity.totalValue.toDouble() else 0.toDouble()
                        value?.tag = l + t
                    }
                }
                map.values.forEach {
                    var totalValue = 0.toDouble()
                    val values = it.values
                    values.forEach { entity ->
                        totalValue += entity.tag as Double
                    }
                    values.forEach { entity ->
                        val itemValue = if (entity.tag is Double) entity.tag as Double else 0.toDouble()
                        entity.gravity = itemValue / totalValue
                    }
                }
                mPaymentList.forEach { entity ->
                    if (mFilterText.text.toString() == MemoryCache.getLabelText("s_by_status") ?: getString(R.string.s_by_status)) {
                        val value = map[entity.paidStatus]?.get(entity.channel)
                        value?.tag = entity
                    } else {
                        val value = map[entity.channel]?.get(entity.paidStatus)
                        value?.tag = entity
                    }
                }
                updatePaymentView(map)
            }
        }
    }

    private val INVOICE_STATUS = mutableListOf("U", "P", "F", "O")
    private val PAYMENT_STATUS = mutableListOf("paid", "planned", "due")

    private fun getInvoiceColor(s: String): Int {
        return context?.let {
            when (s) {
                "U" -> ContextCompat.getColor(it, R.color.colorInvoiceUnpaid)
                "P" -> ContextCompat.getColor(it, R.color.colorInvoicePartialPaid)
                "F" -> ContextCompat.getColor(it, R.color.colorInvoicePaid)
                "O" -> ContextCompat.getColor(it, R.color.colorInvoiceOverPaid)
                else -> 0x00FFFFFF
            }
        } ?: 0x00FFFFFF
    }

    private fun getPaymentStatusColor(s: String): Int {
        return context?.let {
            when (s) {
                "paid" -> ContextCompat.getColor(it, R.color.colorPaymentPaid)
                "planned" -> ContextCompat.getColor(it, R.color.colorPaymentPlanned)
                "due" -> ContextCompat.getColor(it, R.color.colorPaymentDue)
                else -> 0x00FFFFFF
            }
        } ?: 0x00FFFFFF
    }

    private fun getPaymentMethodColor(s: String): Int {
        return context?.let {
            when (s) {
                "ach" -> ContextCompat.getColor(it, R.color.colorPaymentAch)
                "bank_transfer" -> ContextCompat.getColor(it, R.color.colorPaymentBankTransfer)
                "cheque" -> ContextCompat.getColor(it, R.color.colorPaymentCheque)
                "rtgs" -> ContextCompat.getColor(it, R.color.colorPaymentRtgs)
                "dcms" -> ContextCompat.getColor(it, R.color.colorPaymentDcms)
                "virtual_account" -> ContextCompat.getColor(it, R.color.colorPaymentVA)
                else -> 0x00FFFFFF
            }
        } ?: 0x00FFFFFF
    }

    private fun getInvoiceString(s: String): String {
        return when (s) {
            "U" -> MemoryCache.getLabelText("text_invoice_unpaid") ?: context?.resources?.getText(R.string.text_invoice_unpaid).toString()
            "P" -> MemoryCache.getLabelText("text_invoice_partial_paid") ?: context?.resources?.getText(R.string.text_invoice_partial_paid).toString()
            "F" -> MemoryCache.getLabelText("text_invoice_paid") ?: context?.resources?.getText(R.string.text_invoice_paid).toString()
            "O" -> MemoryCache.getLabelText("text_invoice_over_paid") ?: context?.resources?.getText(R.string.text_invoice_over_paid).toString()
            else -> ""
        }
    }

    private fun getPaymentStatusString(s: String): String {
        return MemoryCache.getLabelText("s_payment_method_label_$s") ?: ""
    }

    private fun getPaymentMethodString(s: String): String {
        return MemoryCache.getLabelText("s_payment_method_label_$s") ?: ""
    }

    private fun updateInvoiceView(map: MutableMap<String, RingData>) {
        // Left view of invoice
        val list = mutableListOf<RingData>()
        map.values.forEach {
            if (it.gravity > 0) {
                list.add(it)
            }
        }
        mRingView.setData(list)
        // Right view of invoice
        mInvoiceListView.removeAllViews()
        inflater.inflate(R.layout.item_chart_padding, null, false).also {
            mInvoiceListView.addView(it)
        }
        for (key in map.keys) {
            val value = map[key]
            val entity = value?.tag as HomeInvoiceStatusInfo?
            val view = inflater.inflate(R.layout.item_chart_invoice, null, false)
            val pointView = view.findViewById<ImageView>(R.id.pointView)
            val countText = view.findViewById<TextView>(R.id.countText)
            val currencyText = view.findViewById<TextView>(R.id.currencyText)
            val totalCount = if (entity?.totalCount == null) "0" else entity.totalCount
            val totalValue = if (entity?.totalValue == null) "0" else entity.totalValue
            pointView.setBackgroundColor(getInvoiceColor(key))
            countText.text = String.format(getInvoiceString(key), totalCount)
            val currencyTmpText = requestParameter["currency"].toString() + " " + IndiaNumberUtil.formatNumByDecimal(totalValue,
                    requestParameter["currency"].toString())
            currencyText.text = currencyTmpText
            mInvoiceListView.addView(view)
        }
        inflater.inflate(R.layout.item_chart_padding, null, false).also {
            mInvoiceListView.addView(it)
        }
    }

    private fun updatePaymentView(map: MutableMap<String, MutableMap<String, RingData>>) {
        // Top view of payment
        mDescriptionListView.removeAllViews()
        inflater.inflate(R.layout.item_chart_padding, null, false)
        mDescriptionListView.visibility = View.GONE
        // Bottom view of payment
        mPaymentListView.removeAllViews()
        val vpPaymentRingChartContainer = rootView.summaryView.vp_supplier_payment
        val pageViews = mutableListOf<View>()
        for (key in map.keys) {
            val value = map[key]
            val nullDataView = inflater.inflate(R.layout.view_null_data, null, false)
            val view = inflater.inflate(R.layout.item_supplier_dashboard_payment, null, false)
            val ringChart = view.findViewById<RingView>(R.id.rv_supplier_payment_ring)
            val tvPaymentChartLabel = view.findViewById<TextView>(R.id.tv_supplier_payment_ring_label)
            val llPaymentChartPointers = view.findViewById<LinearLayout>(R.id.ll_supplier_payment_ring_desc)
            tvPaymentChartLabel.text = if (mFilterText.text.toString() == MemoryCache.getLabelText("s_by_status") ?: getString(R.string.s_by_status)) {
                getPaymentStatusString(key).replace(" ", "\n")
            } else {
                getPaymentMethodString(key)
            }
            ringChart.setData(value?.values?.toList()?.filter {
                it.gravity > 0
            } ?: emptyList())
            llPaymentChartPointers.removeAllViews()
            if (value != null) {
                for (item in value) {
                    var entity: HomePaymentChannelInfo?
                    if (item.value.tag is HomePaymentChannelInfo) {
                        entity = item.value.tag as HomePaymentChannelInfo
                    } else {
                        continue
                    }
                    val viewPointer = inflater.inflate(R.layout.item_chart_invoice, null, false)
                    val pointView = viewPointer.findViewById<ImageView>(R.id.pointView)
                    val titleText = viewPointer.findViewById<TextView>(R.id.countText)
                    val currencyText = viewPointer.findViewById<TextView>(R.id.currencyText)
                    val totalValue = entity.totalValue ?: "0"
                    pointView.setBackgroundColor(if (mFilterText.text.toString() == MemoryCache.getLabelText("s_by_status") ?: getString(R.string.s_by_status)) getPaymentMethodColor(entity.channel ?: "") else getPaymentStatusColor(entity.paidStatus ?: ""))
                    titleText.text = if (mFilterText.text.toString() == MemoryCache.getLabelText("s_by_status") ?: getString(R.string.s_by_status)) getPaymentMethodString(entity.channel ?: "") else getPaymentStatusString(entity.paidStatus ?: "")
                    val currencyTmpText = requestParameter["currency"].toString() + " " + IndiaNumberUtil.formatNumByDecimal(totalValue, requestParameter["currency"].toString())
                    currencyText.text = currencyTmpText
                    llPaymentChartPointers.addView(viewPointer)
                }
            }
            if (ringChart.data.isNullOrEmpty())
                pageViews.add(nullDataView)
            else
                pageViews.add(view)
        }

        val pagerAdapter = object : PagerAdapter() {
            override fun isViewFromObject(p0: View, p1: Any): Boolean {
                return p0 === p1
            }

            override fun getCount(): Int {
                return pageViews.size
            }

            override fun instantiateItem(container: ViewGroup, position: Int): Any {
                container.addView(pageViews[position])
                return pageViews[position]
            }

            override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
                container.removeView(pageViews[position])
            }

        }

        vpPaymentRingChartContainer.adapter = pagerAdapter
        vpPaymentRingChartContainer.setPageTransformer(true, CubeOutTransformer(60f))
        rootView.summaryView.alignChartAndTabCurrentItem()
//        inflater.inflate(R.layout.item_chart_payment_graduate, null, false).also {
//            mPaymentListView.addView(it)
//        }
//        mPaymentListView.addView(vpPaymentRingChartContainer)
    }

    private fun showInvoiceSummary() {
        mCurrentPage = 1
        rootView.hsv_home_summary_container.smoothScrollTo(0, invoiceSummaryXY[1])
        rootView.subTitleText.text = MemoryCache.getLabelText("s_invoices_summary") ?: getString(R.string.s_invoices_summary)
        rootView.filterText.visibility = View.INVISIBLE
        activity?.also {
            rootView.v_home_summary_tip_first.setBackgroundColor(ContextCompat.getColor(it, R.color.primary_red))
            rootView.v_home_summary_tip_second.setBackgroundColor(ContextCompat.getColor(it, R.color.light_gray))
        }
        rootView.mInvoiceLayout.visibility = View.VISIBLE
        rootView.mPaymentLayout.visibility = View.GONE
        rootView.summaryView.visibility = View.GONE
        if (isNoData) {
            rootView.tv_home_payment_summary_no_data.visibility = View.GONE
            rootView.tv_home_invoice_summary_no_data.visibility = View.VISIBLE
        }

        updateChartEntity()
        rootView.mMiddleLayout.visibility = View.VISIBLE
    }

    private fun showPaymentSummary() {
        mCurrentPage = 2
        rootView.hsv_home_summary_container.smoothScrollTo(paymentSummaryXY[0], paymentSummaryXY[1])
        rootView.subTitleText.text = MemoryCache.getLabelText("s_planned_payment_summary") ?: getString(R.string.s_planned_payment_summary)
        rootView.filterText.visibility = View.VISIBLE
        activity?.let {
            rootView.v_home_summary_tip_first.setBackgroundColor(ContextCompat.getColor(it, R.color.light_gray))
            rootView.v_home_summary_tip_second.setBackgroundColor(ContextCompat.getColor(it, R.color.primary_red))
        }
        rootView.mInvoiceLayout.visibility = View.GONE
        rootView.mPaymentLayout.visibility = View.VISIBLE
        if (isNoData) {
            rootView.tv_home_payment_summary_no_data.visibility = View.VISIBLE
            rootView.tv_home_invoice_summary_no_data.visibility = View.GONE
        } else {
            rootView.summaryView.visibility = View.VISIBLE
        }
        updateChartEntity()
        rootView.mMiddleLayout.visibility = View.GONE
    }

    override fun updateInvoiceStatusData(entity: HomeInvoiceStatusEntity?) {
        entity?.also {
            var totalCount = 0
            var totalAmount = 0L
            mInvoiceList.clear()
            it.payload?.items?.also { list ->
                mInvoiceList.addAll(list)
                for (item in list) {
                    if (item.status != "C") {
                        totalCount += if (item.totalCount == null) 0 else item.totalCount.toInt()
                        totalAmount += if (item.totalValue == null) 0L else item.totalValue.toLong()
                    }
                }
                rootView.tv_home_invoice_summary_total_amount_tag.text = String.format(MemoryCache.getLabelText("s_total_invoices") ?: getString(R.string.s_total_invoices), totalCount)
                val totalValueStr = requestParameter["currency"].toString() + " " + IndiaNumberUtil.formatNumByDecimal(totalAmount.toString(), requestParameter["currency"].toString())
                rootView.tv_home_invoice_summary_total_amount.text = totalValueStr
            }

            if (it.payload?.items.isNullOrEmpty()) {
                rootView.tv_home_invoice_summary_total_amount_tag.text = String.format(MemoryCache.getLabelText("s_total_invoices") ?: getString(R.string.s_total_invoices), 0)
                val tmpText = "${requestParameter["currency"].toString()} 0.00"
                rootView.tv_home_invoice_summary_total_amount.text = tmpText
            }

            if (mInvoiceList.isEmpty()) {
                isNoData = true
                rootView.tv_home_invoice_summary_no_data.visibility = View.VISIBLE
            } else {
                isNoData = false
                rootView.tv_home_invoice_summary_no_data.visibility = View.GONE
                updateChartEntity()
            }
        }
        hideLoadingDialogExt()
    }

    override fun updateChannelsData(entity: HomePaymentChannelEntity?) {
        entity?.also {
            mPaymentList.clear()
            it.payload?.items?.forEach {
                if (it.channel != "full_deduction" && it.channel != "credit_note") {
                    mPaymentList.add(it)
                }
            }
            this.mPaymentChannel = it
            rootView.summaryView.setPaymentSummaryView(SUMMARY_FILTER_TYPE_METHOD, it, requestParameter["currency"].toString())
            if (mPaymentList.isNullOrEmpty()) {
                isNoData = true
                if (mCurrentPage == 2) {
                    rootView.tv_home_payment_summary_no_data.visibility = View.VISIBLE
                    rootView.summaryView.visibility = View.GONE
                }
            } else {
                isNoData = false
                rootView.tv_home_payment_summary_no_data.visibility = View.GONE
                updateChartEntity()
            }
        }
        hideLoadingDialogExt()
    }

    override fun updateInvoiceSummaryData(entity: HomeInvoiceSummaryEntity) {
        rootView.tv_home_invoice_summary_today_overdue_amount_tag.text = String.format(MemoryCache.getLabelText("s_invoices_overdue") ?: getString(R.string.s_invoices_overdue), entity.payload?.invoiceOverdueCount)
        val overDueValueStr = requestParameter["currency"].toString() + " " + IndiaNumberUtil.formatNumByDecimal(entity.payload?.invoiceOverdueValue ?: "0", requestParameter["currency"].toString())
        rootView.tv_home_invoice_summary_today_overdue_amount.text = overDueValueStr
    }

    override fun updateFragmentMetricsData(entity: HomeInvoiceMetricsEntity) {
        rootView.tv_home_payment_summary_invoice_num.text = String.format(MemoryCache.getLabelText("s_home_summary_payment_invoices_num") ?: getString(R.string.s_home_summary_payment_invoices_num), entity.payload?.invoiceDueTodayCount)
        rootView.tv_home_invoice_summary_today_amount_tag.text = String.format(MemoryCache.getLabelText("s_due_today_invoices") ?: getString(R.string.s_due_today_invoices), entity.payload?.invoiceDueTodayCount)
        val todayValueStr = requestParameter["currency"].toString() + " " +
                IndiaNumberUtil.formatNumByDecimal(entity.payload?.invoiceDueTodayValue ?: "", requestParameter["currency"].toString())
        rootView.tv_home_invoice_summary_today_amount.text = todayValueStr
        val todayITPValueStr = requestParameter["currency"].toString() + " " +
                IndiaNumberUtil.formatNumByDecimal(entity.payload?.itpPaidTodayValue ?: "", requestParameter["currency"].toString())
        rootView.tv_home_payment_summary_amount.text = todayITPValueStr
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.ll_home_invoice_summary_container -> {
                showInvoiceSummary()
            }
            R.id.ll_home_payment_summary_container -> {
                showPaymentSummary()
            }
            R.id.tv_home_customer_selector -> {
//                SuppliersOrCustomersSelectActivity.showActivity(activity, originBuyer, REQUEST_CODE_CUSTOMERS, isFromInvoiceFilter = false, isSelectCustomers = true)
                val intent = Intent(activity, SuppliersOrCustomersSelectActivity::class.java).apply {
                    var lastBuyerParameter = ""
                    if ((requestParameter["buyers"] as List<String>).isNotEmpty()) {
                        lastBuyerParameter = (requestParameter["buyers"] as List<String>)[0]
                    }
                    putExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN, lastBuyerParameter)
                    putExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_ORIGIN_CURRENCY, requestParameter["currency"].toString())
                    putExtra(TAG_FILTER_SUPPLIER_OR_CUSTOMERS_FROM_FLAG, false)
                    putExtra(TAG_FILTER_SELECT_SUPPLIER_OR_CUSTOMERS_FLAG, true)
                }

                startActivityForResult(intent, REQUEST_CODE_CUSTOMERS)

            }
            R.id.iv_home_filter -> {
                ChartFilterActivity.showActivity(this@ChartFragment, accountsList, requestParameter, REQUEST_CODE_FILTER)
            }
            R.id.filterText -> {
                if (paymentPopupTextXY[0] == 0 && paymentPopupTextXY[1] == 0) {
                    rootView.filterText.getLocationInWindow(paymentPopupTextXY)
                }

                popupView.tv_dashboard_popup_first_item.setOnClickListener(popupItemClickListener)
                popupView.tv_dashboard_popup_second_item.setOnClickListener(popupItemClickListener)
                chartFilterByPopup.contentView = popupView
                chartFilterByPopup.showAsDropDown(rootView.filterText, ConvertUtil.dp2px(activity, -30f).toInt(),
                        ConvertUtil.dp2px(activity, -44f).toInt())
            }
        }
    }

    private fun setPaymentSummaryByFilter(text: String) {
        when (text) {
            (MemoryCache.getLabelText("s_by_method") ?: getString(R.string.s_by_method)) -> {
                rootView.summaryView.setPaymentSummaryView(SUMMARY_FILTER_TYPE_METHOD, mPaymentChannel,requestParameter["currency"] as String?)
            }
            (MemoryCache.getLabelText("s_by_status") ?: getString(R.string.s_by_status)) -> {
                rootView.summaryView.setPaymentSummaryView(SUMMARY_FILTER_TYPE_STATUS, mPaymentChannel,requestParameter["currency"] as String?)
            }
        }
    }

    override fun saveAccounts(accounts: List<Account>?) {
        accountsList.clear()
        accounts?.let {
            accountsList.addAll(it)
        }
    }

    /**
     * if need to do something when scrolling, please add code here
     */
    override fun onScroll(view: ObservableHorizontalScrollView, x: Int, y: Int, oldX: Int, oldY: Int) {
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CODE_CUSTOMERS -> {
                    data?.let {
                        val customer = it.getSerializableExtra(TAG_SELECT_SUPPLIER_RESULT) as Payee
                        if (customer.reference == MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all)) {
                            requestParameter["buyers"] = mutableListOf<String>()
                        } else {
                            requestParameter["buyers"] = mutableListOf(customer.reference)
                        }
                        lastBuyerName = customer.name ?: ""
                        tvCustomerFilter.text = String.format(MemoryCache.getLabelText("s_home_customer_selection") ?: getString(R.string.s_home_customer_selection), customer.name)
                        showLoadingDialogExt()
                        mViewModel.getHomeFragmentChannelsData(requestParameter)
                        mViewModel.getHomeFragmentMetricsData(requestParameter)
                        mViewModel.getHomeInvoiceStatusData(requestParameter)
                        mViewModel.getHomeInvoiceSummaryData(requestParameter)
                    }
                }
                REQUEST_CODE_FILTER -> {
                    data?.let {
                        requestParameter = it.getSerializableExtra(TAG_HOME_FILTER_RESULT) as HashMap<String, Any>
                        tvCustomerFilter.text = String.format(MemoryCache.getLabelText("s_home_customer_selection") ?: getString(R.string.s_home_customer_selection), MemoryCache.getLabelText("s_all") ?: getString(R.string.s_all))
                        requestParameter["buyers"] = mutableListOf<String>()
                        lastBuyerName = ""
                        showLoadingDialogExt()
                        mViewModel.getHomeFragmentChannelsData(requestParameter)
                        mViewModel.getHomeFragmentMetricsData(requestParameter)
                        mViewModel.getHomeInvoiceStatusData(requestParameter)
                        mViewModel.getHomeInvoiceSummaryData(requestParameter)
                    }
                }
            }
        }
    }
}