/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.util.ValidationUtil
import kotlinx.android.synthetic.main.fragment_register_userinformation.*
import kotlinx.android.synthetic.main.fragment_register_userinformation.view.*

class RegisterUserInformationFragment : Fragment(),
        RegisterCreateNewUserProfileContract.FragmentCallback,
        View.OnFocusChangeListener,
        View.OnClickListener,
        TextWatcher {

    companion object {
        @JvmStatic
        fun newInstance() =
                RegisterUserInformationFragment()
    }

    private lateinit var mActivity: RegisterCreateNewUserProfileActivity
    private var isTealiumNameEnter = false
    private var isTealiumPasswordEnter = false
    private var isTealiumPasswordConfirmEnter = false

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mActivity = context as RegisterCreateNewUserProfileActivity
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val rootView =  inflater.inflate(R.layout.fragment_register_userinformation, container, false)
        MemoryCache.getLabelText("s_talkback_back_button")?.let {
            if (!it.isBlank()) {
                rootView.backButton1st.contentDescription = it
            }
        }
        MemoryCache.getLabelText("text_userInformation_username")?.let {
            if (!it.isBlank()) {
                rootView.usernameHeadText.text = it
            }
        }
        MemoryCache.getLabelText("toast_userInformation_username")?.let {
            if (!it.isBlank()) {
                rootView.usernameErrorText.text = it
            }
        }
        MemoryCache.getLabelText("hint_userInformation_username")?.let {
            if (!it.isBlank()) {
                rootView.usernameHelpTextTip.text = it
            }
        }
        MemoryCache.getLabelText("text_userInformation_password")?.let {
            if (!it.isBlank()) {
                rootView.passwordHeadText.text = it
            }
        }
        MemoryCache.getLabelText("hint_userInformation_password")?.let {
            if (!it.isBlank()) {
                rootView.passwordHelpTextTip.text = it
            }
        }
        MemoryCache.getLabelText("text_userInformation_secPassword")?.let {
            if (!it.isBlank()) {
                rootView.tv_confirm_password_tag.text = it
            }
        }
        MemoryCache.getLabelText("hint_userInformation_secPassword")?.let {
            if (!it.isBlank()) {
                rootView.secPasswordHelpText.text = it
            }
        }
        MemoryCache.getLabelText("button_userInformation_continue")?.let {
            if (!it.isBlank()) {
                rootView.continueButton1st.text = it
            }
        }
        return rootView
    }

    override fun onStart() {
        super.onStart()

        backButton1st.setOnClickListener(this)
        continueButton1st.setOnClickListener(this)
        usernameText.onFocusChangeListener = this
        passwordText.onFocusChangeListener = this
        secPasswordText.onFocusChangeListener = this
        usernameText.addTextChangedListener(this)
        passwordText.addTextChangedListener(this)
        secPasswordText.addTextChangedListener(this)

        usernameImage.setOnClickListener(this)
        passwordImage.setOnClickListener(this)

        usernameText.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart : buyer portal : registration : user information",
                "/dart/buyer portal/registration/user information",
                "verification",
                "buyer portal",
                "registration",
                "mobile",
                "en",
                "registration",
                "6",
                "registration - user info")
    }

    override fun updateContentView() {

    }

    fun updateErrorView() {
        TealiumUtil.eventTag("error", "registration: user information: this username is used")
        usernameErrorText.visibility = View.VISIBLE
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.backButton1st -> {
                TealiumUtil.eventTag("button click", "registration: user information: back")
                v.also {
                    (activity as View.OnClickListener).onClick(v)
                }
            }
            R.id.continueButton1st -> {
                TealiumUtil.eventTag("button click", "registration: user information: continue")
                if (validateInformation()) {
                    v.also {
                        val username = usernameText.text?.toString()
                        val password = passwordText.text?.toString()
                        it.tag = UsernameValidationBean(username = username, password = password)
                        (activity as View.OnClickListener).onClick(v)
                    }
                }
            }
            R.id.usernameImage -> {
                TealiumUtil.eventTag("button click", "registration: user information: username tooltip")
                activity?.also {
                    RegistrationDialog.showUsernameDialog(it)
                }
            }
            R.id.passwordImage -> {
                TealiumUtil.eventTag("button click", "registration: user information: password tooltip")
                activity?.also {
                    RegistrationDialog.showPasswordDialog(it)
                }
            }
        }
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

    }

    override fun afterTextChanged(s: Editable?) {
        if (!isTealiumNameEnter && usernameText.text.isNotEmpty()) {
            TealiumUtil.eventTag("text entry", "registration: user information: enter username")
            isTealiumNameEnter = true
        }

        if (!isTealiumPasswordEnter && passwordText.text.isNotEmpty()) {
            TealiumUtil.eventTag("text entry", "registration: user information: create a password")
            isTealiumPasswordEnter = true
        }

        if (!isTealiumPasswordConfirmEnter && usernameText.text.isNotEmpty()) {
            TealiumUtil.eventTag("text entry", "registration: user information: confirm password")
            isTealiumPasswordConfirmEnter = true
        }

        if (!usernameText.text.isNullOrEmpty() &&
                !passwordText.text.isNullOrEmpty()) {
            continueButton1st.isEnabled = true
            continueButton1st.isClickable = true
            context?.let {
                continueButton1st.setBackgroundColor(ContextCompat.getColor(it, R.color.primary_red))
            }
        } else {
            continueButton1st.isEnabled = false
            continueButton1st.isClickable = false
            context?.let {
                continueButton1st.setBackgroundColor(ContextCompat.getColor(it, R.color.light_gray))
            }
        }

        val username = usernameText.text.toString()
        val password = passwordText.text.toString()
        val secPassword = secPasswordText.text.toString()
        when {
            usernameText.isFocused -> {
                if (username.isEmpty() || username.length < 6) {
                    usernameHelpText.visibility = View.VISIBLE
                } else {
                    usernameHelpText.visibility = View.GONE
                }
            }
            passwordText.isFocused -> {
                if (password.isEmpty() || !ValidationUtil.validatePassword(password)) {
                    passwordHelpText.visibility = View.VISIBLE
                } else {
                    passwordHelpText.visibility = View.GONE
                }
            }
            secPasswordText.isFocused -> {
                if (!password.contentEquals(secPassword)) {
                    secPasswordHelpText.visibility = View.VISIBLE
                } else {
                    secPasswordHelpText.visibility = View.GONE
                }
            }
        }
    }

    override fun onFocusChange(v: View?, hasFocus: Boolean) {
        val username = usernameText.text.toString()
        val password = passwordText.text.toString()
        val secPassword = secPasswordText.text.toString()
        when (v) {
            usernameText -> {
                if (hasFocus) {
                    if (username.isEmpty() || username.length < 6) {
                        usernameHelpText.visibility = View.VISIBLE
                    } else {
                        usernameHelpText.visibility = View.GONE
                    }
                } else {
                    usernameHelpText.visibility = View.GONE
                    if (username.isNotEmpty() && username.length < 6) {
                        TealiumUtil.eventTag("error", "registration: user information: your username does not meet the requirements")
                        usernameHelpText.visibility = View.VISIBLE
                    } else {
                        usernameHelpText.visibility = View.GONE
                    }
                }
            }
            passwordText -> {
                if (hasFocus) {
                    if (password.isEmpty() || !ValidationUtil.validatePassword(password)) {
                        passwordHelpText.visibility = View.VISIBLE
                    } else {
                        passwordHelpText.visibility = View.GONE
                    }
                } else {
                    passwordHelpText.visibility = View.GONE
                    if (password.isNotEmpty() && !ValidationUtil.validatePassword(password)) {
                        TealiumUtil.eventTag("error", "registration: user information: your password does not meet the requirements")
                        passwordHelpText.visibility = View.VISIBLE
                    } else {
                        passwordHelpText.visibility = View.GONE
                    }
                }
            }
            secPasswordText -> {
                if (hasFocus) {
                    if (!password.contentEquals(secPassword)) {
                        secPasswordHelpText.visibility = View.VISIBLE
                    } else {
                        secPasswordHelpText.visibility = View.GONE
                    }
                } else {
                    secPasswordHelpText.visibility = View.GONE
                }
            }
        }
    }

    private fun validateInformation(): Boolean {
        usernameHelpText.visibility = View.GONE
        passwordHelpText.visibility = View.GONE
        secPasswordHelpText.visibility = View.GONE
        usernameErrorText.visibility = View.GONE

        val username = usernameText.text.toString()
        val password = passwordText.text.toString()
        val secPassword = secPasswordText.text.toString()

        if (username.isEmpty() || username.length < 6) {
            usernameHelpText.visibility = View.VISIBLE
            return false
        }
        if (password.isEmpty() || !ValidationUtil.validatePassword(password)) {
            passwordHelpText.visibility = View.VISIBLE
            return false
        }
        if (!password.contentEquals(secPassword)) {
            TealiumUtil.eventTag("error", "registration: user information: password confirmation does not match")
            secPasswordHelpText.visibility = View.VISIBLE
            return false
        }

        usernameHelpText.visibility = View.GONE
        usernameErrorText.visibility = View.GONE
        passwordHelpText.visibility = View.GONE
        secPasswordHelpText.visibility = View.GONE
        return true
    }
}
