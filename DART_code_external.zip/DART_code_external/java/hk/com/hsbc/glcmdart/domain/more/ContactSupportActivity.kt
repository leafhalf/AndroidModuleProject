/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.more

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_contact_support.*

class ContactSupportActivity : BaseActivity() {

    companion object {
        fun showActivity(context: Context?) {
            context?.startActivity(Intent(context, ContactSupportActivity::class.java))
        }
    }

    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_support)
        tl_head.title = MemoryCache.getLabelText("s_contact_support_title") ?: getString(R.string.s_contact_support_title)
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            TealiumUtil.eventTag("button click", "Contact Support: back")
            finish()
        }
        if ("S" == MemoryCache.getSessionEntity()?.type) {
            tv_contact_support_content.text = MemoryCache.getLabelText("s_contact_support_supplier_tip") ?: getString(R.string.s_contact_support_supplier_tip)
            tv_contact_support_title.text = MemoryCache.getLabelText("s_contact_support_supplier_title") ?: getString(R.string.s_contact_support_supplier_title)
        } else {
            tv_contact_support_content.text = MemoryCache.getLabelText("s_contact_support_buyer_tip") ?: getString(R.string.s_contact_support_buyer_tip)
            tv_contact_support_title.text = MemoryCache.getLabelText("s_contact_support_buyer_title") ?: getString(R.string.s_contact_support_buyer_title)
        }
    }

    override fun onResume() {
        super.onResume()
        if ("B" == MemoryCache.getSessionEntity()?.type) {
            TealiumUtil.pageTag(
                    "dart:buyer portal:more:contact dart",
                    "/dart/buyer-portal/more/contact-dart",
                    "other",
                    "buyer portal",
                    "more")
        }
    }
}