/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.view

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_CHOOSE_VA_BANK_LIST
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_GET_PAYMENT_METHOD
import hk.com.hsbc.glcmdart.domain.dart.*
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog.Companion.TYPE_CHEQUE_DATE
import hk.com.hsbc.glcmdart.domain.invoices.invoicelist.FilterDateDialog.Companion.TYPE_PAYMENT_DATE
import hk.com.hsbc.glcmdart.domain.payments.ChooseVABankActivity
import hk.com.hsbc.glcmdart.domain.payments.PaymentMethodActivity
import hk.com.hsbc.glcmdart.domain.payments.PaymentMethodActivity.Companion.REQUEST_RESULT_PAYMENT_METHOD
import hk.com.hsbc.glcmdart.domain.payments.PaymentMethodActivity.Companion.REQUEST_RESULT_PAYMENT_METHOD_SELECT
import hk.com.hsbc.glcmdart.domain.payments.dialog.PaymentMethodDialog
import hk.com.hsbc.glcmdart.domain.payments.dialog.PaymentMethodSelectCallback
import hk.com.hsbc.glcmdart.domain.payments.model.bean.PaymentDetailEntity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.*
import kotlinx.android.synthetic.main.view_ach_mandate.view.*
import kotlinx.android.synthetic.main.view_bank_transfer_details.view.*
import kotlinx.android.synthetic.main.view_cheque_details.view.*
import kotlinx.android.synthetic.main.view_provide_payment_info.view.*
import kotlinx.android.synthetic.main.view_va_payment_code.view.*
import org.w3c.dom.Text
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.abs

@SuppressLint("ViewConstructor")
class ProvidePaymentInfoView(context: Context?, type: Int? = -1) : LinearLayout(context), TextWatcher {

    companion object {
        const val TYPE_PAYMENT_UPDATE = 1
        const val TYPE_PAYMENT_CHANGE = 2
        const val cheque = "cheque"
        const val ach = "ach"
        const val bank_transfer = "bank_transfer"
        const val rtgs = "rtgs"
        const val credit_note = "credit_note"
        const val dcms = "dcms"
        const val deduction = "full_deduction"
        const val va = "virtual_account"
    }

    private var isUpdate = false
    private var selectPostion: Int? = -1
    private var selectMethod: String? = null
    private var llPaymentViewMiddle: View? = null
    private var llPaymentState: View? = null
    private var btnStep: Button? = null
    private var tvPaymentDate: TextView? = null
    private var deductionAmountText: TextView? = null
    private var expectedDate: String? = null
    private var chequeDate: String? = null
    private var amountText: TextView? = null
    private var amountTextMiddle: TextView? = null
    private var payeeName: String? = ""
    private var isTealiumReferenceInput = false
    private var vaCodeList: List<String?>? = null
    var chequeAmount: String? = ""

    @SuppressLint("SimpleDateFormat")
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd")
    private var paymentMethods: PaymentMethod? = null
    private var currency: String? = MemoryCache.defaultCurrency
    private val banDateList = mutableListOf<String>()

    init {
        val mInflater = LayoutInflater.from(context)
        val view = mInflater.inflate(R.layout.view_provide_payment_info, this, false)
        addView(view)
        if (type == TYPE_PAYMENT_UPDATE) {
            tv_title.visibility = View.GONE
            iv_right.visibility = View.GONE
            context?.also {
                tv_payment_method_title.setTextColor(ContextCompat.getColor(it, R.color.colorPaymentMehodDisable))
                tv_payment_method.setTextColor(ContextCompat.getColor(it, R.color.colorPaymentMehodDisable))
            }
        } else {
            tv_title.visibility = View.VISIBLE
            iv_right.visibility = View.VISIBLE
        }
        initEventAndData()
    }

    private fun initEventAndData() {
        val buttonAccessibilityDelegate = object : View.AccessibilityDelegate() {

            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        }

        tv_payment_date.addTextChangedListener(this)
        tv_cheque_date.addTextChangedListener(this)
        et_cheque_number.addTextChangedListener(this)
        et_cheque_amount.addTextChangedListener(InputTextWatcher(et_cheque_amount))
        et_cheque_amount.onFocusChangeListener = FocuseChangeListener()
        et_paymentReference.addTextChangedListener(this)
        ll_payment_date.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_cheque_date.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_payment_method.setAccessibilityDelegate(buttonAccessibilityDelegate)
        ll_payment_date.setOnClickListener {
            val methodStr = when (selectMethod) {
                cheque -> {
                    "info cheque"
                }
                bank_transfer -> {
                    "info bank"
                }
                ach -> {
                    "info ach"
                }
                rtgs -> {
                    "info rtgs"
                }
                dcms -> {
                    "info dcms"
                }
                deduction -> {
                    "info full deduction"
                }
                va -> {
                    "info virtual account"
                }
                else -> {
                    "info"
                }
            }
            if (isUpdate)
                TealiumUtil.eventTag("button click", "planned payments - update payment info |planned payments - update payment info:$methodStr: payment date")
            else
                TealiumUtil.eventTag("button click", "confirm planned payment - payment $methodStr: payment date")
            showDatePickerDialog(TYPE_PAYMENT_DATE)
        }
        ll_cheque_date.setOnClickListener {
            if (isUpdate)
                TealiumUtil.eventTag("button click", "confirm planned payment - payment info: cheque date")
            else
                TealiumUtil.eventTag("button click", "planned payments -update payment info: cheque date")
            showDatePickerDialog(TYPE_CHEQUE_DATE, paymentMethods?.cheque?.issue_date_not_older_than_days)
        }
        rb_generate.setOnCheckedChangeListener { _, isChecked ->
            val methodStr = when (selectMethod) {
                cheque -> {
                    "info cheque"
                }
                bank_transfer -> {
                    "info bank"
                }
                ach -> {
                    "info ach"
                }
                rtgs -> {
                    "info rtgs"
                }
                dcms -> {
                    "info dcms"
                }
                deduction -> {
                    "info full deduction"
                }
                va -> {
                    "info virtual account"
                }
                else -> {
                    "info"
                }
            }
            if (isChecked) {
                if (isUpdate) {
                    TealiumUtil.eventTag("onsite", "planned payments - update planned payment info: $methodStr: payment reference generate for me")
                } else {
                    TealiumUtil.eventTag("radio", "confirm planned payment - payment $methodStr: payment reference generate for me")
                }
                rb_not_generate.isChecked = false
                ll_own_reference.visibility = View.GONE
                setNextButtonState()
            }
        }
        rb_not_generate.setOnCheckedChangeListener { _, isChecked ->
            val methodStr = when (selectMethod) {
                cheque -> {
                    "info cheque"
                }
                bank_transfer -> {
                    "info bank"
                }
                ach -> {
                    "info ach"
                }
                rtgs -> {
                    "info rtgs"
                }
                dcms -> {
                    "info dcms"
                }
                deduction -> {
                    "info full deduction"
                }
                va -> {
                    "info virtual account"
                }
                else -> {
                    "info"
                }
            }

            if (isChecked) {
                if (isUpdate) {
                    TealiumUtil.eventTag("onsite", "planned payments - update planned payment info: $methodStr: payment reference use my own")
                } else {
                    TealiumUtil.eventTag("radio", "confirm planned payment - payment $methodStr: payment reference use my own")
                }
                rb_generate.isChecked = false
                ll_own_reference.visibility = View.VISIBLE
                setNextButtonState()
            }
        }
        ll_payment_method.setOnClickListener {
            val methodStr = when (selectMethod) {
                cheque -> {
                    "info cheque"
                }
                bank_transfer -> {
                    "info bank"
                }
                ach -> {
                    "info ach"
                }
                rtgs -> {
                    "info rtgs"
                }
                dcms -> {
                    "info dcms"
                }
                deduction -> {
                    "info full deduction"
                }
                va -> {
                    "info virtual account"
                }
                else -> {
                    "info"
                }
            }
            TealiumUtil.eventTag("button click", "confirm planned payment - payment $methodStr: payment method")

            PaymentMethodDialog.showDialog(context as BaseActivity?, paymentMethods, currency, object : PaymentMethodSelectCallback {
                override fun onMethodSelected(position: Int, methodStr: String?) {
                    val intent = Intent()
                    intent.putExtra(REQUEST_RESULT_PAYMENT_METHOD, methodStr)
                    intent.putExtra(REQUEST_RESULT_PAYMENT_METHOD_SELECT, position)
                    onActivityResult(REQUEST_CODE_GET_PAYMENT_METHOD, intent)
                }
            }, preSelectPosition = selectPostion ?: -1)
//            PaymentMethodActivity.showActivity(context as Activity, paymentMethods, selectPostion, isUpdate, REQUEST_CODE_GET_PAYMENT_METHOD)
        }
        val announceText = MemoryCache.getLabelText("s_my_own_reference_announce")
                ?: context.getString(R.string.s_my_own_reference_announce)
        et_paymentReference.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (!isTealiumReferenceInput) {
                    val methodStr = when (selectMethod) {
                        cheque -> {
                            "info cheque"
                        }
                        bank_transfer -> {
                            "info bank"
                        }
                        ach -> {
                            "info ach"
                        }
                        rtgs -> {
                            "info rtgs"
                        }
                        dcms -> {
                            "info dcms"
                        }
                        deduction -> {
                            "info full deduction"
                        }
                        va -> {
                            "info virtual account"
                        }
                        else -> {
                            "info"
                        }
                    }
                    TealiumUtil.eventTag("text entry", "confirm planned payment - payment $methodStr: my own reference: text entered")
                    isTealiumReferenceInput
                }
                val size = 64 - et_paymentReference.text.length
                tv_own_reference.announceForAccessibility(size.toString() + announceText)
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

        })

        et_cheque_number.setOnEditorActionListener { _, _, _ ->
            if (isUpdate)
                TealiumUtil.eventTag("text entry", "planned payments - update payment info: cheque payment: cheque number: text entered")
            else
                TealiumUtil.eventTag("text entry", "confirm planned payment - payment info cheque: cheque amount: text entered")
            false
        }

        et_cheque_amount.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (cheque == (selectMethod ?: "")) {
                    if (s.isNullOrBlank()) {
                        tv_cheque_number_tip.visibility = View.VISIBLE
                    } else {
                        tv_cheque_number_tip.visibility = View.GONE
                    }
                }
            }

        })

        et_cheque_amount.setOnEditorActionListener { _, _, _ ->
            if (isUpdate)
                TealiumUtil.eventTag("text entry", "planned payments - update payment info: cheque payment: cheque amount: text entered")
            else
                TealiumUtil.eventTag("text entry", "confirm planned payment - payment info cheque: cheque amount: text entered")

            false
        }

        MemoryCache.getLabelText("s_payment_info")?.let {
            if (!it.isBlank()) {
                tv_title.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_method")?.let {
            if (!it.isBlank()) {
                tv_payment_method_title.text = it
            }
        }
        MemoryCache.getLabelText("s_select_a_method")?.let {
            if (!it.isBlank()) {
                tv_payment_method.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_date")?.let {
            if (!it.isBlank()) {
                tv_payment_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_select_date")?.let {
            if (!it.isBlank()) {
                tv_payment_date.hint = it
            }
        }
        MemoryCache.getLabelText("s_additional_payment_info")?.let {
            if (!it.isBlank()) {
                tv_additional_info.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_reference")?.let {
            if (!it.isBlank()) {
                tv_payment_reference_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_generate_for_me")?.let {
            if (!it.isBlank()) {
                tv_generate_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_use_my_own_reference")?.let {
            if (!it.isBlank()) {
                tv_not_generate_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_my_own_reference")?.let {
            if (!it.isBlank()) {
                tv_own_reference.text = it
            }
        }
        MemoryCache.getLabelText("s_enter_here")?.let {
            if (!it.isBlank()) {
                et_paymentReference.hint = it
            }
        }
        MemoryCache.getLabelText("s_cheque_date")?.let {
            if (!it.isBlank()) {
                tv_cheque_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_cheque_number")?.let {
            if (!it.isBlank()) {
                tv_cheque_number_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_cheque_amount")?.let {
            if (!it.isBlank()) {
                tv_cheque_amount_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_enter_data")?.let {
            if (!it.isBlank()) {
                et_cheque_number.hint = it
            }
        }

        et_cheque_amount.hint = "$currency ${if (currency == "IDR") "0,00" else "0.00"}"
        MemoryCache.getLabelText("s_urn_number")?.let {
            if (!it.isBlank()) {
                tv_URN_number_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_expiration_date")?.let {
            if (!it.isBlank()) {
                tv_expiration_date_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_maximum_amount")?.let {
            if (!it.isBlank()) {
                tv_maximum_amount_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_cheque_number_input_tip")?.let {
            if (!it.isBlank()) {
                tv_cheque_number_tip.text = it
            }
        }
        MemoryCache.getLabelText("s_select_date")?.let {
            if (!it.isBlank()) {
                tv_cheque_date.hint = it
            }
        }

        MemoryCache.getLabelText("s_payment_bank_name_tag")?.let {
            if (!it.isBlank()) {
                tv_va_bank_name_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_code_tag")?.let {
            if (!it.isBlank()) {
                tv_va_payment_code_tag.text = it
            }
        }
        MemoryCache.getLabelText("s_payment_code_tip")?.let {
            if (!it.isBlank()) {
                tv_payment_code_tip.text = it
            }
        }
    }

    fun disablePaymentMethodClick() {
        ll_payment_method.isEnabled = false
    }

    private fun showDatePickerDialog(type: Int, chequeLimitDays: Int? = null) {
        val minDate: String
        val title: String
        when (type) {
            TYPE_CHEQUE_DATE -> {
                val c = Calendar.getInstance()
                c.time = Date()
                var limitDays = -91
                if (chequeLimitDays != null && chequeLimitDays != 0) {
                    limitDays = try {
                        -abs(chequeLimitDays.toInt())
                    } catch (e: Exception) {
                        -91
                    }
                }
                c.add(Calendar.DATE, limitDays)
                minDate = DateUtil.getDateStrBySimpleDateFormate(c.time)
                title = MemoryCache.getLabelText("s_cheque_date")
                        ?: context.getString(R.string.s_cheque_date)
            }
            else -> {
                minDate = DateUtil.getDateStrBySimpleDateFormate(Date())
                title = MemoryCache.getLabelText("s_payment_date")
                        ?: context.getString(R.string.s_payment_date)
            }
        }
        FilterDateDialog.showDateDialog(context, title, minDate, null, banDateList, object : FilterDateDialog.DateConfirmCallback {

            @SuppressLint("SetTextI18n")
            override fun getDate(date: String) {
//                if (banDateList.isNotEmpty() && banDateList.contains(date)) {
//                    Toast.makeText(context, "The date is invalid! Please choose another date", Toast.LENGTH_SHORT).show()
//                    return
//                }
                when (type) {
                    TYPE_PAYMENT_DATE -> {
                        expectedDate = date
                        tv_payment_date.text = TimeZoneTransformsUtil.formatTime(date)
                        if (tvPaymentDate != null)
                            MemoryCache.getLabelText("s_expiration_date")?.let {
                                if (!it.isBlank()) {
                                    tvPaymentDate?.text = "$it: " + TimeZoneTransformsUtil.formatTime(date)
                                } else {
                                    tvPaymentDate?.text = "${context.getString(R.string.s_date)}: " + TimeZoneTransformsUtil.formatTime(date)
                                }
                            }
                        chequeDate = null
                        tv_cheque_date.text = ""
                        setNextButtonState()
                    }
                    TYPE_CHEQUE_DATE -> {
                        chequeDate = date
                        tv_cheque_date.text = TimeZoneTransformsUtil.formatTime(date)
                        setNextButtonState()
                    }
                }
            }
        })
    }

    fun setMainPageWidget(llPaymentView: View?, llPaymentViewMiddle: View?, amountText: TextView?,
                          amountTextMiddle: TextView?, deductionAmount: TextView?, btnStep: Button?,
                          tvPaymentDate: TextView?, payeeName: String? = "", currency: String?) {
        this.llPaymentViewMiddle = llPaymentViewMiddle
        this.llPaymentState = llPaymentView
        this.btnStep = btnStep
        this.tvPaymentDate = tvPaymentDate
        this.amountText = amountText
        this.amountTextMiddle = amountTextMiddle
        this.deductionAmountText = deductionAmount
        this.payeeName = payeeName
        this.currency = currency
        et_cheque_amount.hint = "$currency ${if (currency == "IDR") "0,00" else "0.00"}"
    }

    @SuppressLint("SetTextI18n")
    fun updateMainPageWidgetState() {
        llPaymentViewMiddle?.visibility = View.VISIBLE
        llPaymentState?.visibility = View.GONE
        tvPaymentDate?.visibility = View.GONE
        ll_credit_note_tip_container.visibility = View.GONE
        if (amountText != null) {
            if (amountText?.text?.toString()?.contains("$currency ${if (currency == "IDR") "0,00" else "0.00"}") == true) {
                iv_right.visibility = View.GONE
                val creditNoteTextView = llPaymentViewMiddle?.findViewById<TextView>(R.id.creditnoteAmountMiddle)
                val creditNoteAmount = creditNoteTextView?.text?.toString()
                        ?.replace(MemoryCache.getLabelText("s_cr_note_amount") ?: context.getString(R.string.s_cr_note_amount), "")
                        ?.replace(":", "")
                        ?.replace(currency ?: MARKET_CURRENCY, "")
                        ?.replace(",","")
                        ?.replace(".","")
                        ?.replace(" ", "")
                if ((creditNoteAmount?.toLong() ?: 0L) == 0L) {
                    selectMethod = deduction
                    tv_credit_note_tip.text = MemoryCache.getLabelText("s_deduction_only_tip") ?: context.getString(R.string.s_deduction_only_tip)
                    ll_credit_note_tip_container.visibility = View.VISIBLE
                    selectPaymentMethod(deduction, null)
                } else {
                    selectMethod = credit_note
                    tv_credit_note_tip.text = MemoryCache.getLabelText("s_creditnote_method_tip")
                            ?: context.getString(R.string.s_creditnote_method_tip)
                    ll_credit_note_tip_container.visibility = View.VISIBLE
                    ll_payment_method.isEnabled = false
                    ll_payment_date.isEnabled = false
                    val currentDate = dateFormat.format(Date())
                    expectedDate = currentDate
                    tv_payment_date.text = TimeZoneTransformsUtil.formatTime(currentDate)
                    if (tvPaymentDate != null)
                        MemoryCache.getLabelText("s_date")?.let {
                            if (it.isNotBlank()) {
                                tvPaymentDate?.text = "$it: " + TimeZoneTransformsUtil.formatTime(currentDate)
                            } else {
                                tvPaymentDate?.text = "${context.getString(R.string.s_date)}: " + TimeZoneTransformsUtil.formatTime(currentDate)
                            }
                        }
                    selectPaymentMethod(credit_note, null)
                }
            } else {
                if (selectMethod == deduction) {
                    selectPaymentMethod(null, null)
                    setNextButtonState()
                    tv_payment_method.text = ""
                    iv_right.visibility = View.VISIBLE
                } else if (selectMethod == credit_note) {
                    iv_right.visibility = View.VISIBLE
                    ll_payment_method.isEnabled = true
                    ll_payment_date.isEnabled = false
                    selectMethod = ""
                    expectedDate = ""
                    tv_payment_date.text = ""
                    tv_payment_method.text = ""
                    tvPaymentDate?.text = ""
                }
            }
        }
    }

    fun checkInputData(): Boolean {
        if (selectMethod == deduction) {
            return true
        }
        if (selectMethod == null) {
            return false
        }
        if (TextUtils.isEmpty(tv_payment_date.text.toString())) {
            return false
        }
        if (!rb_generate.isChecked && !rb_not_generate.isChecked) {
            return false
        }
        if (rb_not_generate.isChecked && TextUtils.isEmpty(et_paymentReference.text.toString())) {
            return false
        }
        //extra
        when (selectMethod) {
            cheque -> {
                if (TextUtils.isEmpty(tv_cheque_date.text.toString())) {
                    return false
                }
                if (TextUtils.isEmpty(et_cheque_number.text.toString())) {
                    return false
                }
                if (TextUtils.isEmpty(et_cheque_amount.text.toString())) {
                    return false
                }
            }
            bank_transfer -> {

            }
            ach -> {
                if (tv_maximum_amount.text.isNullOrEmpty())
                    return false
            }
            rtgs -> {

            }
            dcms -> {

            }
            va -> {
                if (tv_va_payment_code.text.toString().isBlank()) {
                    return false
                }
            }
        }
        return true
    }

    fun setPaymentMethods(paymentMethods: PaymentMethod) {
        this.paymentMethods = paymentMethods
        this.vaCodeList = paymentMethods.virtual_account?.virtual_accounts
    }

    @SuppressLint("SetTextI18n")
    private fun backfillAchData() {
        if (this.paymentMethods != null && this.paymentMethods?.ach != null) {
            if (this.paymentMethods?.ach?.extra == null) {
                ll_ach_detail.visibility = View.GONE
                tv_ach_invalid.visibility = View.VISIBLE
                val invalidText = (MemoryCache.getLabelText("s_ach_mandate_invalid")
                        ?: context.getString(R.string.s_ach_mandate_invalid)).replace("ACH", MemoryCache.getLabelText("s_payment_method_label_" + "ach")
                        ?: "ACH")
                tv_ach_invalid.text = String.format(invalidText, payeeName)
            } else {
                ll_ach_detail.visibility = View.VISIBLE
                tv_ach_invalid.visibility = View.GONE
            }

            this.paymentMethods?.ach?.extra?.let {
                tv_URN_number.text = it.ACH_mandate_urn
                tv_expiration_date.text = TimeZoneTransformsUtil.formatTime(it.ACH_mandate_date!!)
                tv_maximum_amount.text = "$currency " + IndiaNumberUtil.formatNumByDecimal(it.ACH_mandate_amount
                        ?: "0.00", currency ?: MARKET_CURRENCY)
            }
        } else {
            ll_ach_detail.visibility = View.GONE
//            tv_ach_invalid.visibility = View.VISIBLE
//            val invalidText = MemoryCache.getLabelText("s_ach_mandate_invalid") ?: context.getString(R.string.s_ach_mandate_invalid )
//            tv_ach_invalid.text = String.format(invalidText, payeeName)
        }
    }

    fun setBankCalendar(bankCalendar: List<BankCalendarDate>) {
        bankCalendar.forEach {
            if (it.workingDay == null) {
                banDateList.add(it.date ?: "")
            } else {
                if (!it.workingDay) {
                    banDateList.add(it.date ?: "")
                }
            }
        }
    }

    fun getCurrentViewData(): Map<String, Any> {
        val dataMap = mutableMapOf<String, Any>()
        val extraMap = mutableMapOf<String, String>()
        if (rb_not_generate.isChecked) {
            extraMap["use_generated_token"] = "false"
            dataMap["paymentReference"] = et_paymentReference.text.toString()
        } else {
            extraMap["use_generated_token"] = "true"
            dataMap["paymentReference"] = ""
        }
        //expectedDate
        dataMap["expectedDate"] = this.expectedDate ?: SimpleDateFormat("yyyy-MM-dd").format(Date())
        //extra
        when (selectMethod) {
            cheque -> {
                dataMap["paymentMethod"] = cheque
                val decimalSymbol = if (currency == "IDR") "," else "."
                extraMap["payment_cheque_amount"] = ((chequeAmount?.replace(decimalSymbol, ".")?.toDouble()
                        ?: 0.00) * 100).toLong().toString()
                extraMap["payment_cheque_currency"] = "$currency"
                extraMap["payment_cheque_date"] = chequeDate ?: ""
                extraMap["payment_cheque_number"] = et_cheque_number.text.toString()
            }
            ach -> {
                dataMap["paymentMethod"] = ach
            }
            bank_transfer -> {
                dataMap["paymentMethod"] = bank_transfer
            }
            rtgs -> {
                dataMap["paymentMethod"] = rtgs
            }
            dcms -> {
                dataMap["paymentMethod"] = dcms
                if (MemoryCache.defaultCountry == "IN") {
                    extraMap["payment_method_provider"] = "PayU"
                } else {
                    extraMap["payment_method_provider"] = "DOKU"
                }
            }
            credit_note -> {
                dataMap["paymentMethod"] = credit_note
            }
            deduction -> {
                dataMap["paymentMethod"] = deduction
            }
            va -> {
                dataMap["paymentMethod"] = va
                extraMap["dcms_va_payment_code"] = tv_va_payment_code.text.toString().replace("-", "").replace(" ", "")
                if (MemoryCache.defaultCountry == "IN") {
                    extraMap["payment_method_provider"] = "PayU"
                } else {
                    extraMap["payment_method_provider"] = "DOKU"
                }
                dataMap["va_name"] = tv_va_bank_name.text.toString()
                dataMap["va_code"] = tv_va_payment_code.text.toString()
            }
        }
        dataMap["extra"] = extraMap
        return dataMap
    }

    fun backfillCurrentViewData(paymentDetail: PaymentDetailEntity?) {
        isUpdate = true
        //payment date
        expectedDate = paymentDetail?.itp?.expectedDate
        tv_payment_date.text = TimeZoneTransformsUtil.formatTime(expectedDate)
        //payment reference
        if (paymentDetail?.itp?.extra != null) {
            if (paymentDetail.itp.extra.use_generated_token!!.toBoolean()) {
                rb_generate.isChecked = true
                rb_not_generate.isChecked = false
                ll_own_reference.visibility = View.GONE
            } else {
                rb_generate.isChecked = false
                rb_not_generate.isChecked = true
                ll_own_reference.visibility = View.VISIBLE
                et_paymentReference.setText(paymentDetail.itp.paymentReference)
            }
        }
        selectPaymentMethod(paymentDetail?.itp!!.paymentMethod, paymentDetail)
        //update button
        setNextButtonState()
    }

    @SuppressLint("SetTextI18n")
    private fun selectPaymentMethod(paymentMethod: String?, paymentDetail: PaymentDetailEntity? = null) {
        ll_payment_date.isEnabled = true
        tv_title.visibility = View.VISIBLE
        rl_payment_method_container.visibility = View.VISIBLE
        ll_payment_date.visibility = View.VISIBLE
        tv_payment_date_tag.setTextColor(ContextCompat.getColor(context, R.color.primary_gray))
        tv_payment_date.setTextColor(ContextCompat.getColor(context, R.color.primary_gray))
        when (paymentMethod) {
            cheque -> {
                TealiumUtil.pageTag(
                        "dart : buyer portal : payments : confirm planned payment - payment info cheque",
                        "/dart/buyer portal/payments/confirm planned payment-payment info cheque",
                        "transaction",
                        "buyer portal",
                        "payments",
                        "mobile",
                        "en",
                        "create planned payment",
                        "3",
                        "create planned payment - payment info cheque"
                )
                tv_additional_info.visibility = View.VISIBLE
                tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_$cheque")
                views_cheque.visibility = View.VISIBLE
                view_ach.visibility = View.GONE
                view_bank_transfer.visibility = View.GONE
                view_va.visibility = View.GONE
                if (paymentDetail?.itp?.extra != null) {
                    chequeDate = paymentDetail.itp.extra.payment_cheque_date
                    tv_cheque_date.text = TimeZoneTransformsUtil.formatTime(chequeDate)
                    et_cheque_number.setText(paymentDetail.itp.extra.payment_cheque_number)
                    chequeAmount = paymentDetail.itp.extra.payment_cheque_amount
                    et_cheque_amount.setText("$currency " + IndiaNumberUtil.formatNum(MemoryCache.globalDecimal.format((paymentDetail.itp.extra.payment_cheque_amount?.toDouble()
                            ?: 0.00) / 100.0).toString(), currency ?: ""))
                }
            }
            ach -> {
                TealiumUtil.pageTag(
                        "dart : buyer portal : payments : confirm planned payment - payment info ach",
                        "/dart/buyer portal/payments/confirm planned payment-payment info ach",
                        "transaction",
                        "buyer portal",
                        "payments",
                        "mobile",
                        "en",
                        "create planned payment",
                        "3",
                        "create planned payment - payment info ach"
                )
                tv_additional_info.visibility = View.VISIBLE
                tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_$ach")
                views_cheque.visibility = View.GONE
                view_ach.visibility = View.VISIBLE
                view_bank_transfer.visibility = View.GONE
                view_va.visibility = View.GONE
                backfillAchData()
            }
            bank_transfer -> {
                TealiumUtil.pageTag(
                        "dart : buyer portal : payments : confirm planned payment - payment info bank",
                        "/dart/buyer portal/payments/confirm planned payment-payment info bank",
                        "transaction",
                        "buyer portal",
                        "payments",
                        "mobile",
                        "en",
                        "create planned payment",
                        "3",
                        "create planned payment - payment info bank"
                )
                tv_additional_info.visibility = View.GONE
                tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_$bank_transfer")
                views_cheque.visibility = View.GONE
                view_ach.visibility = View.GONE
                view_bank_transfer.visibility = View.VISIBLE
            }
            rtgs -> {
                TealiumUtil.pageTag(
                        "dart : buyer portal : payments : confirm planned payment - payment info rtgs",
                        "/dart/buyer portal/payments/confirm planned payment-payment info rtgs",
                        "transaction",
                        "buyer portal",
                        "payments",
                        "mobile",
                        "en",
                        "create planned payment",
                        "3",
                        "create planned payment - payment info rtgs"
                )
                tv_additional_info.visibility = View.GONE
                tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_$rtgs")
                views_cheque.visibility = View.GONE
                view_ach.visibility = View.GONE
                view_bank_transfer.visibility = View.GONE
                view_va.visibility = View.GONE
            }
            dcms -> {
                TealiumUtil.pageTag(
                        "dart : buyer portal : payments : confirm planned payment - payment info dcms",
                        "/dart/buyer portal/payments/confirm planned payment-payment info dcms",
                        "transaction",
                        "buyer portal",
                        "payments",
                        "mobile",
                        "en",
                        "create planned payment",
                        "3",
                        "create planned payment - payment info dcms"
                )
                tv_additional_info.visibility = View.GONE
                tv_payment_method.text = MemoryCache.getLabelText("s_online_payment")
                        ?: context.getString(R.string.s_online_payment)
                tv_payment_date.text = TimeZoneTransformsUtil.formatTime(Date())
                tv_payment_date_tag.setTextColor(ContextCompat.getColor(context, R.color.secondary_gray))
                tv_payment_date.setTextColor(ContextCompat.getColor(context, R.color.secondary_gray))
                expectedDate = SimpleDateFormat("yyyy-MM-dd").format(Date())
                ll_payment_date.isEnabled = false
                views_cheque.visibility = View.GONE
                view_ach.visibility = View.GONE
                view_bank_transfer.visibility = View.GONE
                view_va.visibility = View.GONE
            }
            credit_note -> {
                tv_additional_info.visibility = View.GONE
                ll_payment_date.isEnabled = false
                tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_$credit_note")
                views_cheque.visibility = View.GONE
                view_ach.visibility = View.GONE
                view_bank_transfer.visibility = View.GONE
                view_va.visibility = View.GONE
            }
            deduction -> {
                rl_payment_method_container.visibility = View.GONE
                ll_payment_date.visibility = View.GONE
                tv_additional_info.visibility = View.GONE
                tv_payment_method.text = "Deduction"
                views_cheque.visibility = View.GONE
                view_ach.visibility = View.GONE
                view_bank_transfer.visibility = View.GONE
                view_va.visibility = View.GONE
                tv_title.visibility = View.GONE
                setNextButtonState()
            }
            va -> {
                views_cheque.visibility = View.GONE
                view_ach.visibility = View.GONE
                view_bank_transfer.visibility = View.GONE
                view_va.visibility = View.VISIBLE
                tv_payment_method.text = MemoryCache.getLabelText("s_payment_method_label_$va")
                if (paymentDetail != null) {
                    if (paymentDetail.itp?.extra?.dcms_va_payment_code != null) {
                        tv_va_bank_name.text = MemoryCache.getVABankNameMap(context, paymentDetail.itp.extra.dcms_va_payment_code.substring(0, 5)) ?: "Unmatched bank name"
                        val prefix = paymentDetail.itp.extra.dcms_va_payment_code.substring(0, 5)
                        val postfix = paymentDetail.itp.extra.dcms_va_payment_code.substring(5)
                        tv_va_payment_code.text = "$prefix-$postfix"
                    }
                }
                view_va.setOnClickListener {
                    ChooseVABankActivity.showActivityForResult(context as BaseActivity,
                            REQUEST_CODE_CHOOSE_VA_BANK_LIST,
                            if (vaCodeList.isNullOrEmpty()) ArrayList() else (vaCodeList?.filter { !it.isNullOrBlank() }) as ArrayList<String>,
                            if (tv_va_bank_name.text.toString().isBlank())
                                ""
                            else
                                tv_va_bank_name.text.toString() + "  " + tv_va_payment_code.text.toString())
                }
            }
        }
        selectMethod = paymentMethod
    }

    fun onActivityResult(requestCode: Int, data: Intent?) {
        if (requestCode == REQUEST_CODE_GET_PAYMENT_METHOD) {
            val paymentMethod = data?.getStringExtra(REQUEST_RESULT_PAYMENT_METHOD)
            if (paymentMethod == ach && paymentMethods != null) {
                var message: String? = ""
                paymentMethods?.ach?.extra?.let {
                    if (it.ACH_mandate_amount != null) {
                        message = (((MemoryCache.getLabelText("s_ach_payment_method_tip1")?.replace("INR", currency
                                ?: MARKET_CURRENCY)?.replace("ACH", MemoryCache.getLabelText("s_payment_method_label_" + "ach") ?: "")
                                ?: context.getString(R.string.s_ach_payment_method_tip1))).replace("ACH", MemoryCache.getLabelText("s_payment_method_label_" + "ach") ?: "")
                                .replace("INR", currency
                                ?: MARKET_CURRENCY) +
                                "\t${IndiaNumberUtil.formatNumByDecimal(it.ACH_mandate_amount ?: "0.00", currency ?: MARKET_CURRENCY)}" +
                                context.getString(R.string.s_ach_payment_method_tip2)).replace("INR", currency
                                ?: MARKET_CURRENCY)
                    }
                }

                val title = MemoryCache.getLabelText("s_select_another_method_title")
                        ?: context.getString(R.string.s_select_another_method_title)
                CommonDialog.showAlertDialog(context, title, message,
                        MemoryCache.getLabelText("s_select")
                                ?: context.getString(R.string.s_select), object : CommonDialogExtras.OnButtonListener {
                    override fun positiveButtonListener() {
                        TealiumUtil.eventTag("button click", "add invoice - select another payment method overlay: cancel")
                        PaymentMethodDialog.showDialog(context as BaseActivity?, paymentMethods, currency,
                                object : PaymentMethodSelectCallback {
                                    override fun onMethodSelected(position: Int, methodStr: String?) {
                                        val intent = Intent()
                                        intent.putExtra(REQUEST_RESULT_PAYMENT_METHOD, methodStr)
                                        intent.putExtra(REQUEST_RESULT_PAYMENT_METHOD_SELECT, position)
                                        onActivityResult(REQUEST_CODE_GET_PAYMENT_METHOD, intent)
                                    }
                                }, preSelectPosition = data.getIntExtra(REQUEST_RESULT_PAYMENT_METHOD_SELECT, -1))
//                    PaymentMethodActivity.showActivity(context as Activity, paymentMethods, selectPostion, isUpdate, REQUEST_CODE_GET_PAYMENT_METHOD)
                    }

                    override fun negativeButtonListener() {
                        TealiumUtil.eventTag("button click", "add invoice - select another payment method overlay: select")
                        selectPostion = data.getIntExtra(REQUEST_RESULT_PAYMENT_METHOD_SELECT, -1)
                        selectPaymentMethod(paymentMethod)
                        setNextButtonState()
                    }
                }, (MemoryCache.getLabelText("s_cancel")
                        ?: context.getString(R.string.s_cancel)).replace("ACH", MemoryCache.getLabelText("s_payment_method_label_" + "ach") ?: ""))
                TealiumUtil.pageTag(
                        "dart : buyer portal : invoices : select another payment method",
                        "/dart/buyer portal/invoices/select another payment method",
                        "accounts",
                        "buyer portal",
                        "invoices"
                )
            } else {
                selectPostion = data?.getIntExtra(REQUEST_RESULT_PAYMENT_METHOD_SELECT, -1)
                selectPaymentMethod(paymentMethod)
                setNextButtonState()
            }
        } else {
            val bankNameAndCode = data?.getStringExtra(ChooseVABankActivity.INTENT_TAG_RESULT_VA_BANK_NAME)
            val bankNameAndCodeSub = bankNameAndCode?.split("  ")
            bankNameAndCode?.also {
                tv_va_bank_name.text = bankNameAndCodeSub?.get(0)
                tv_va_payment_code.text = bankNameAndCodeSub?.get(1)
            }
            setNextButtonState()
        }
    }

    fun setNextButtonState() {
        if (btnStep != null) {
            btnStep?.isEnabled = checkInputData()
        }
    }

    override fun afterTextChanged(s: Editable?) {}

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        setNextButtonState()
    }

    inner class InputTextWatcher(val et_cheque_amount: EditText?) : TextWatcher {

        override fun afterTextChanged(s: Editable) {
//            if (!chequeAmount.isNullOrBlank()) {
//                val tmpTag = chequeAmount?.replace(",", ".")
//                et_cheque_amount?.tag = (tmpTag?.toDouble() ?: 0.00) / 100.00
//            }
            val decimalSymbol = if (currency == "IDR") {
                ","
            } else {
                "."
            }

            val banDecimalSymbol = if (currency == "IDR") {
                "."
            } else {
                ","
            }

            if (s.toString().contains(banDecimalSymbol)) {
                et_cheque_amount?.setText(s.toString().replace(banDecimalSymbol, ""))
                et_cheque_amount?.setSelection(et_cheque_amount.text.toString().length)
            }

            if (s.toString().contains(decimalSymbol)) {
                if (et_cheque_amount?.text.toString().indexOf(decimalSymbol) >= 0) {
                    if (et_cheque_amount?.text.toString().indexOf(decimalSymbol, et_cheque_amount?.text.toString().indexOf(decimalSymbol) + 1) > 0) {
                        et_cheque_amount?.setText(et_cheque_amount.text.toString().substring(0, et_cheque_amount.text.toString().length - 1))
                        et_cheque_amount?.setSelection(et_cheque_amount.text.toString().length)
                    }

                }
            }

            //这部分是处理如果用户输入以.开头，在前面加上0
            if (s.toString().trim().substring(0) == decimalSymbol) {
                et_cheque_amount?.setText("0$s")
                et_cheque_amount?.setSelection(2)
            }
            //这里处理用户 多次输入.的处理 比如输入 1..6的形式，是不可以的
            if (s.toString().startsWith("0") && s.toString().trim().length > 1) {
                if (s.toString().substring(1, 2) != decimalSymbol) {
                    et_cheque_amount?.setText(s.subSequence(0, 1))
                    et_cheque_amount?.setSelection(1)
                    return
                }
            }
            val input = s.toString()
            chequeAmount = if (input.isNotEmpty()) {
                val amount = input.replace("$currency", "").replace(banDecimalSymbol, "").trim()
                amount
            } else {
                ""
            }
            setNextButtonState()
        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    inner class FocuseChangeListener : OnFocusChangeListener {
        override fun onFocusChange(v: View?, hasFocus: Boolean) {
            val inputEditText = v as EditText
            var inputShow: String? = ""
            var inputNoFocuse: String? = ""
            val decimalSymbol = if (currency == "IDR") "," else "."
            if (!TextUtils.isEmpty(chequeAmount)) {
                val amount = MemoryCache.globalDecimal.format(chequeAmount?.replace(decimalSymbol, ".")?.toDouble()
                        ?: 0.00).toString()
                inputShow = "$currency " + IndiaNumberUtil.formatNum(amount, currency ?: "")
                inputNoFocuse = if (amount.contains(".00"))
                    amount.replace(".00", "")
                else
                    amount
                chequeAmount = amount
            }
            if (!hasFocus) {
                inputEditText.setText(inputShow)
            } else {
                inputEditText.setText("")
            }
        }
    }
}