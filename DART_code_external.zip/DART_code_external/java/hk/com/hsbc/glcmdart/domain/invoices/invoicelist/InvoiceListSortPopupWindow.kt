/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.invoices.invoicelist

import android.app.Activity
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import android.widget.TextView
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.util.MemoryCache
import kotlinx.android.synthetic.main.view_invoice_list_sort_popup.view.*

/**
 * Created by Donut
 *
 * sort window for all invoice
 */
class InvoiceListSortPopupWindow(private val mContext: Activity, private val mChooseCallback: InvoiceSortPopupChoose) {

    companion object {
        //sort type
        const val SORT_TYPE_DEFAULT = 0
        const val SORT_TYPE_NEW_TO_OLD = 1
        const val SORT_TYPE_OLD_TO_NEW = 2
        const val SORT_TYPE_HIGH_TO_LOW = 3
        const val SORT_TYPE_LOW_TO_HIGH = 4
    }

    //save the last choice
    private lateinit var lastSelection: TextView

    fun showUpPopupWindow(originSortType: Int): PopupWindow {
        val contentView = LayoutInflater.from(mContext).inflate(R.layout.view_invoice_list_sort_popup, null)
        val defaultItem = contentView.tv_invoice_list_sort_default
        val new2OldItem = contentView.tv_invoice_list_sort_new_to_old
        val old2NewItem = contentView.tv_invoice_list_sort_old_to_new
        val high2LowItem = contentView.tv_invoice_list_sort_high_to_low
        val low2HighItem = contentView.tv_invoice_list_sort_low_to_high

        MemoryCache.getLabelText("tv_invoice_list_sort_default")?.let {
            if (!it.isBlank()) {
                defaultItem.text = it
            }
        }
        MemoryCache.getLabelText("s_new_to_old")?.let {
            if (!it.isBlank()) {
                new2OldItem.text = it
            }
        }
        MemoryCache.getLabelText("s_old_to_new")?.let {
            if (!it.isBlank()) {
                old2NewItem.text = it
            }
        }
        MemoryCache.getLabelText("s_high_to_low")?.let {
            if (!it.isBlank()) {
                high2LowItem.text = it
            }
        }
        MemoryCache.getLabelText("s_low_to_high")?.let {
            if (!it.isBlank()) {
                low2HighItem.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_unchecked")?.let {
            if (!it.isBlank()) {
                new2OldItem.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_talkback_unchecked")?.let {
            if (!it.isBlank()) {
                old2NewItem.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_talkback_unchecked")?.let {
            if (!it.isBlank()) {
                high2LowItem.contentDescription = it
            }
        }
        MemoryCache.getLabelText("s_talkback_unchecked")?.let {
            if (!it.isBlank()) {
                low2HighItem.contentDescription = it
            }
        }

        when(originSortType) {
            SORT_TYPE_DEFAULT -> {
                lastSelection = defaultItem
                defaultItem.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(mContext, R.drawable.ic_done), null)
            }
            SORT_TYPE_NEW_TO_OLD -> {
                lastSelection = new2OldItem
                new2OldItem.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(mContext, R.drawable.ic_done), null)
            }
            SORT_TYPE_OLD_TO_NEW -> {
                lastSelection = old2NewItem
                old2NewItem.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(mContext, R.drawable.ic_done), null)
            }
            SORT_TYPE_HIGH_TO_LOW -> {
                lastSelection = high2LowItem
                high2LowItem.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(mContext, R.drawable.ic_done), null)
            }
            SORT_TYPE_LOW_TO_HIGH -> {
                lastSelection = low2HighItem
                low2HighItem.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(mContext, R.drawable.ic_done), null)
            }
        }

        lastSelection.contentDescription = lastSelection.text.toString() + " " + (MemoryCache.getLabelText("s_talkback_checked") ?: mContext.getString(R.string.s_talkback_checked))

        val mPopup = PopupWindow(contentView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, true).apply {
            setBackgroundDrawable(ColorDrawable())
            isOutsideTouchable = true
            isTouchable = true
        }
        contentView.ll_popup_container.setOnClickListener {
            mPopup.dismiss()
        }

        val onClickListener = View.OnClickListener { v ->
            if (lastSelection != v) {
                select(v as TextView)
            }
            mPopup.dismiss()
        }
        defaultItem.setOnClickListener(onClickListener)
        new2OldItem.setOnClickListener(onClickListener)
        old2NewItem.setOnClickListener(onClickListener)
        high2LowItem.setOnClickListener(onClickListener)
        low2HighItem.setOnClickListener(onClickListener)

        return mPopup
    }

    private fun select(view: TextView) {
        view.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, ContextCompat.getDrawable(mContext, R.drawable.ic_done), null)
        lastSelection.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, null, null)
        lastSelection = view
        mChooseCallback.onChoose(view.text.toString())
    }
}

/**
 * choose sort item callback
 */
interface InvoiceSortPopupChoose {
    fun onChoose(item: String)
}

