/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.login

import android.app.Activity
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.dart.BasicResponse
import hk.com.hsbc.glcmdart.domain.home.HomeActivity
import hk.com.hsbc.glcmdart.extension.hideInputDelayed
import hk.com.hsbc.glcmdart.extension.removeStatusView
import hk.com.hsbc.glcmdart.extension.showLongToast
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.RASPUtil
import hk.com.hsbc.glcmdart.util.StatusBarUtil
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.widget.LoadingCompletedCallback
import kotlinx.android.synthetic.main.activity_login.*
import java.util.*

/**
 * when change country package, please change #areaText as well
 */
class LoginActivity : BaseActivity(),
        LoginContract.View,
        View.OnClickListener, SelectLanguageCallback{

    private lateinit var mViewModel: LoginViewModel
    //    private val mPresenter by lazy { LoginPresenter() }
    private var mFlag1st = false
    private var mFlag2nd = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        StatusBarUtil.setTransparentStatusBar(this, false)
        StatusBarUtil.setStatusTextColor(false, this)
        removeStatusView(this)
        contentLayout.setPadding(0, StatusBarUtil.getStatusBarHeight(this), 0, 0)

        mViewModel = ViewModelProviders.of(this).get(LoginViewModel::class.java)
        mViewModel.loginResponse.observe(this, Observer<BasicResponse> {
            if (it.code != 200) {
                hideLoginView(it.code, it.msg)
            } else {
                showLoginView(it.code, it.msg)
            }
        })

//        registerPresenter(mPresenter as IPresenter<*>)
        areaText.setAccessibilityDelegate(object: View.AccessibilityDelegate() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        })
        when(MemoryCache.defaultLanguageFull) {
            "en-in" -> {
                areaText.text = getString(R.string.s_language_tip1)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.login_and_register_india_flag, 0, 0, 0)
            }
            "en-id" -> {
                areaText.text = getString(R.string.s_language_tip2)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_indonezia_flag, 0, 0, 0)
            }
            "id-id" -> {
                areaText.text = getString(R.string.s_language_tip3)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_indonezia_flag, 0, 0, 0)
            }
            "en-au" -> {
                areaText.text = getString(R.string.s_language_tip4)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_australia_flag, 0, 0, 0)
            }
            "en-sg" -> {
                areaText.text = getString(R.string.s_language_tip5)
                areaText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_singapore_flag, 0, 0, 0)
            }
        }

        usernameText.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable?) {
                if (mFlag1st) {
                    TealiumUtil.eventTag(
                            "text entry",
                            "dart - enter username and password: username: text entered"
                    )
                }
                updateTextChange()
                mFlag1st = true
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        passwordText.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable?) {
                if (mFlag2nd) {
                    TealiumUtil.eventTag(
                            "text entry",
                            "dart - enter username and password: password: text entered"
                    )
                }
                updateTextChange()
                mFlag2nd = true
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        passwordText.setOnEditorActionListener { _, _, _ ->
            submitData()
            true
        }
        logonButton.setOnButtonClickListener(this)
        logonButton.setButtonText(MemoryCache.getLabelText("button_logon") ?: getString(R.string.button_logon))
        logonButton.enableButton(false)
        moreButton.setOnClickListener(this)
        areaText.setOnClickListener(this)

        Calendar.getInstance().let {
            it.time = Date(System.currentTimeMillis())
            it
        }.also {
            when (it.get(Calendar.HOUR_OF_DAY)) {
                in 1..11 -> {
                    dayText.text = MemoryCache.getLabelText("head_day_morning") ?: resources.getText(R.string.head_day_morning)
                }
                in 12..(12 + 5) -> {
                    dayText.text = MemoryCache.getLabelText("head_day_afternoon") ?: resources.getText(R.string.head_day_afternoon)
                }
                in (12 + 6)..(12 + 11) -> {
                    dayText.text = MemoryCache.getLabelText("head_day_evening") ?: resources.getText(R.string.head_day_evening)
                }
                else -> {
                    dayText.text = MemoryCache.getLabelText("head_day_morning") ?: resources.getText(R.string.head_day_morning)
                }
            }
        }

        mHandler.postDelayed({
            RASPUtil.handleKeyboard()
        }, 1200)

        addLayoutListener(logonButton)

        MemoryCache.getLabelText("s_talkback_hamburger_button")?.let {
            if (!it.isBlank()) {
                moreButton.contentDescription = it
            }
        }
        MemoryCache.getLabelText("message_username")?.let {
            if (!it.isBlank()) {
                tv_enter_username_tag.text = it
            }
        }
        MemoryCache.getLabelText("message_password")?.let {
            if (!it.isBlank()) {
                tv_enter_password_tag.text = it
            }
        }
        MemoryCache.getLabelText("message_username_and_password_incorrect")?.let {
            if (!it.isBlank()) {
                usernameAndPasswordErrorText.text = it
            }
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tv_submit -> {
                submitData()
            }
            R.id.moreButton -> {
                AboutDialog.showAboutDialog(this)
                TealiumUtil.eventTag(
                        "button click",
                        "dart - enter username and password: about"
                )
            }
            R.id.areaText -> {
                LanguageDialog.showLanguageDialog(this, this)
            }
        }
    }

    private fun submitData() {
        val username = usernameText.text.toString()
        val password = passwordText.text.toString()
        val bean = LoginBean(username, password)
        hideInputDelayed(400)
        logonButton.startLoadingAnimation()
        mViewModel.doRequest(bean)


//        mPresenter.doRequest(bean)
        TealiumUtil.eventTag(
                "button click",
                "dart - enter username and password: log on"
        )
    }

    private fun updateTextChange() {
        if (!usernameText.text.isNullOrEmpty() &&
                !passwordText.text.isNullOrEmpty()) {
            logonButton.enableButton(true)
        } else {
            logonButton.enableButton(false)
        }
    }

    override fun showLoginView(code: Int?, msg: String?) {
        when (code) {
            200 -> {
                updateUsernameAndPasswordView(false)
                logonButton.animationEndCallback = object: LoadingCompletedCallback{
                    override fun onAnimationCompleted() {
                        startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                        finish()
                    }
                }
                logonButton.endLoadingAnimation(true)
            }
        }
    }

    override fun hideLoginView(code: Int?, msg: String?) {
        logonButton.endLoadingAnimation(false)
        logonButton.setButtonText(MemoryCache.getLabelText("button_logon") ?: getString(R.string.button_logon))
        when (code) {
            400, 401 -> {// incorrect username or password
                updateUsernameAndPasswordView(true)
            }
            408, 504 -> {// timeout
                updateUsernameAndPasswordView(false)
                showLongToast(R.string.toast_timeout_network)
            }
            else -> {
                updateUsernameAndPasswordView(false)
                msg?.also {
                    showLongToast(it)
                }
            }
        }
    }

    private fun updateUsernameAndPasswordView(flag: Boolean) {
        when (flag) {
            true -> {
                TealiumUtil.eventTag(
                        "error",
                        "dart - enter username and password: incorrect username or password {1|2} attempts remaining"
                )
                usernameAndPasswordErrorText.visibility = View.VISIBLE
                usernameAndPasswordErrorText.text = MemoryCache.getLabelText("message_username_and_password_incorrect") ?: resources.getString(R.string.message_username_and_password_incorrect)
            }
            else -> {
                usernameAndPasswordErrorText.visibility = View.INVISIBLE
            }
        }
    }

    override fun getActivity(): Activity {
        return this
    }

    override fun onLanguageChange(language: String) {
        areaText.text = language
        recreate()
    }

    private var rootViewVisionHeight = 0
    private fun addLayoutListener(bottomView: View) {
        window.decorView.viewTreeObserver.addOnGlobalLayoutListener {
            val rect = Rect()
            window.decorView.getWindowVisibleDisplayFrame(rect)
            val visionHeight = rect.height()
            if (rootViewVisionHeight == 0) {
                rootViewVisionHeight = visionHeight
                return@addOnGlobalLayoutListener
            }

            if (rootViewVisionHeight == visionHeight) {
                return@addOnGlobalLayoutListener
            }

            val invisibleHeight = rootViewVisionHeight - visionHeight
            val leftSpace = window.decorView.height - passwordText.bottom - invisibleHeight - bottomView.height
            if (leftSpace > 0) {
                if (invisibleHeight > 150) {
                    bottomView.animate().translationY(-invisibleHeight.toFloat()).setDuration(0).start()
                } else {
                    bottomView.animate().translationY(0F).start()
                }
                rootViewVisionHeight = visionHeight
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        startActivity(Intent(this, HomeActivity::class.java).also {
            finish()
        })
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart:buyer portal:logon:username and password",
                "/dart/buyer-portal/logon/username-and-password",
                "authentication",
                "buyer portal",
                "logon",
                "mobile",
                "en",
                "buyer portal - login",
                "1",
                "buyer portal - login - start"
        )
    }
}

