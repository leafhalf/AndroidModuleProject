/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.calendar

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import androidx.core.content.ContextCompat
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.calendar.Calendar
import hk.com.hsbc.glcmdart.calendar.MonthView
import kotlin.math.min

class CalendarMonthView(context: Context) : MonthView(context) {

    private var mRadius: Int = 0// The radius of selected

    private val mLeftPointPaint = Paint()// The paint of point
    private val mRightPointPaint = Paint()// The paint of point
    private val mPointRadius: Float// The radius of point
    private val mPointPadding: Int// The padding of point

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, mSelectedPaint)
        mSelectedPaint.maskFilter = BlurMaskFilter(1f, BlurMaskFilter.Blur.SOLID)

        mLeftPointPaint.isAntiAlias = true
        mLeftPointPaint.style = Paint.Style.FILL
        mLeftPointPaint.textAlign = Paint.Align.CENTER
        mLeftPointPaint.color = ContextCompat.getColor(context, R.color.colorCalendarInvoice)

        mRightPointPaint.isAntiAlias = true
        mRightPointPaint.style = Paint.Style.FILL
        mRightPointPaint.textAlign = Paint.Align.CENTER
        mRightPointPaint.color = ContextCompat.getColor(context, R.color.colorCalendarPayment)

        mPointPadding = dipToPx(context, 3f)
        mPointRadius = dipToPx(context, 2f).toFloat()
    }

    override fun onPreviewHook() {
//        Logger.d("---------->: onPreviewHook")
        mRadius = min(mItemWidth, mItemHeight) / 5 * 2
        mSchemePaint.style = Paint.Style.STROKE
    }

    override fun onLoopStart(x: Int, y: Int) {

    }

    override fun onDrawSelected(canvas: Canvas, calendar: Calendar, x: Int, y: Int, hasScheme: Boolean): Boolean {
//        Logger.d("---------->: onDrawSelected")
        val cx = x + mItemWidth / 2
        val cy = y + mItemHeight / 2
        canvas.drawCircle(cx.toFloat(), cy.toFloat(), mRadius.toFloat(), mSelectedPaint)
        return false
    }

    override fun onDrawScheme(canvas: Canvas, calendar: Calendar, x: Int, y: Int) {
//        Logger.d("---------->: onDrawScheme")
        if (!isSelected(calendar)) {
            val cx = x + mItemWidth / 2
            val cy = y + mItemHeight - 3 * mPointPadding
            when (calendar.scheme) {
                "1" -> {
                    val p = if (calendar.scheme == "1") mLeftPointPaint else mRightPointPaint
                    canvas.drawRect(cx - mPointRadius, cy - mPointRadius, cx + mPointRadius, cy + mPointRadius, p)
                }
                "2" -> {
                    val p = if (calendar.scheme == "1") mLeftPointPaint else mRightPointPaint
                    canvas.drawCircle(cx.toFloat(), cy.toFloat(), mPointRadius, p)
                }
                "3" -> {
                    val lx = cx - (mPointRadius * 1.5).toInt()
                    val rx = cx + (mPointRadius * 1.5).toInt()
                    canvas.drawRect(lx - mPointRadius, cy - mPointRadius, lx + mPointRadius, cy + mPointRadius, mLeftPointPaint)
                    canvas.drawCircle(rx.toFloat(), cy.toFloat(), mPointRadius, mRightPointPaint)
                }
            }
        }
    }

    override fun onDrawText(canvas: Canvas, calendar: Calendar, x: Int, y: Int, hasScheme: Boolean, isSelected: Boolean) {
//        Logger.d("---------->: onDrawText")
        val baselineY = mTextBaseLine + y
        val cx = x + mItemWidth / 2
        val currentDate = "${calendar.year}-${(if (calendar.month < 10) "0" else "") + calendar.month}-${(if (calendar.day < 10) "0" else "") + calendar.day}"
        val isInBanList = mBanList != null && mBanList.contains(currentDate)

        when {
            isInBanList -> {
                canvas.drawText(calendar.day.toString(),
                        cx.toFloat(),
                        baselineY,
                        mBanTextPaint)
            }
            isSelected -> canvas.drawText(calendar.day.toString(),
                    cx.toFloat(),
                    baselineY,
                    mSelectTextPaint)
            hasScheme -> canvas.drawText(calendar.day.toString(),
                    cx.toFloat(),
                    baselineY,
                    if (calendar.isCurrentDay)
                        mCurDayTextPaint
                    else if (calendar.isCurrentMonth) mSchemeTextPaint else mOtherMonthTextPaint)
            else -> canvas.drawText(calendar.day.toString(),
                    cx.toFloat(),
                    baselineY,
                    when {
                        calendar.isCurrentDay -> mCurDayTextPaint
                        calendar.isCurrentMonth -> mCurMonthTextPaint
                        else -> mOtherMonthTextPaint
                    })
        }
    }

    private fun dipToPx(context: Context, dpValue: Float): Int {
        val scale = context.resources.displayMetrics.density
        return (dpValue * scale + 0.5f).toInt()
    }
}
