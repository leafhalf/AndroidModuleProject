/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 */

package hk.com.hsbc.glcmdart.domain.login

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.forgetpassword.ForgetIndexActivity
import hk.com.hsbc.glcmdart.domain.more.LegalPageActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil

object AboutDialog {

    fun showAboutDialog(c: Context) {
        val mDialog = Dialog(c, R.style.AlertDialog)
        val mContentView = LayoutInflater.from(c).inflate(R.layout.dialog_about, null)

        val onClickListener = View.OnClickListener {
            mDialog.cancel()
            when(it.id) {
                R.id.tv_about_user_name -> {
                    TealiumUtil.eventTag(
                            "onsite",
                            "dart - enter username and password: about username"
                    )
                    ForgetIndexActivity.showActivity(c as Activity, true)
                }
                R.id.tv_about_password -> {
                    TealiumUtil.eventTag(
                            "onsite",
                            "dart - enter username and password: about password"
                    )
                    ForgetIndexActivity.showActivity(c as Activity)
                }
                R.id.tv_about_eula -> {
                    TealiumUtil.eventTag(
                            "onsite",
                            "dart - enter username and password: about end user license agreement"
                    )
                    mDialog.cancel()
//                    EULASelectDialog.showDialog(c as BaseActivity)
                    var url = EULA_STATIC_URL
                    url = url.replace("{country}", MemoryCache.defaultCountry ?: MARKET_COUNTRY)
                    url = url.replace("{language}", MemoryCache.defaultLanguageFull ?: "en-in")
                    url = url.replace("EULA.html", "EULA-${MemoryCache.defaultLanguageFull}.html")
                    LegalPageActivity.showActivity(c as Activity, MemoryCache.getLabelText("s_about_EULA")
                            ?: c.getString(R.string.s_about_EULA), url, true)
//                    LegalPageActivity.showActivity(c as Activity, MemoryCache.getLabelText("s_about_EULA") ?: c.getString(R.string.s_about_EULA), EULA_STATIC_URL, true)
                    TealiumUtil.pageTag(
                            "dart:buyer portal:logon:about end user license agreement",
                            "/dart/buyer-portal/logon/about-end-user-license-agreement",
                            "authentication",
                            "buyer portal",
                            "logon")
                }
                R.id.tv_about_cookie_policy -> {
                    TealiumUtil.eventTag(
                            "onsite",
                            "dart - enter username and password: cookie policy"
                    )
                    TealiumUtil.eventTag(
                            "onsite",
                            "dart - enter username and password: about cookie policy"
                    )
                    LegalPageActivity.showActivity(c as Activity, MemoryCache.getLabelText("s_about_cookie_policy") ?: c.getString(R.string.s_about_cookie_policy), COOKIE_POLICY_STATIC_URL, true)
                }
                R.id.tv_about_acknowledgment -> {
                    TealiumUtil.eventTag(
                            "onsite",
                            "dart - enter username and password: acknowledgment"
                    )
                    LegalPageActivity.showActivity(c as Activity, MemoryCache.getLabelText("s_about_acknowledgment") ?: c.getString(R.string.s_about_acknowledgment), ACKNOWLEDGEMENT_STATIC_URL, true)
                    TealiumUtil.pageTag(
                            "dart:buyer portal:logon:about acknowledgement",
                            "/dart/buyer-portal/logon/about-acknowledgement",
                            "authentication",
                            "buyer portal",
                            "logon")
                }
                R.id.tv_about_pdps -> {
                    TealiumUtil.eventTag(
                            "onsite",
                            "dart - enter username and password: about privacy and data"
                    )
                    LegalPageActivity.showActivity(c as Activity, MemoryCache.getLabelText("s_about_PDPS") ?: c.getString(R.string.s_about_PDPS), PRIVACY_AND_DATA_STATIC_URL, true)
                }
                R.id.tv_terms_conditions -> {
                    TealiumUtil.eventTag(
                            "onsite",
                            "dart - enter username and password: about terms and conditions"
                    )
                    LegalPageActivity.showActivity(c as Activity, MemoryCache.getLabelText("s_terms_conditions") ?: c.getString(R.string.s_terms_conditions), TERMS_AND_CONDITIONS_STATIC_URL, true)
                }
            }
        }

        mContentView.findViewById<TextView>(R.id.tv_about_user_name).setOnClickListener(onClickListener)
        mContentView.findViewById<TextView>(R.id.tv_about_password).setOnClickListener(onClickListener)
        mContentView.findViewById<TextView>(R.id.tv_about_eula).setOnClickListener(onClickListener)
        mContentView.findViewById<TextView>(R.id.tv_about_cookie_policy).setOnClickListener(onClickListener)
        mContentView.findViewById<TextView>(R.id.tv_about_acknowledgment).setOnClickListener(onClickListener)
        mContentView.findViewById<TextView>(R.id.tv_about_pdps).setOnClickListener(onClickListener)
        mContentView.findViewById<TextView>(R.id.tv_terms_conditions).setOnClickListener(onClickListener)

        MemoryCache.getLabelText("s_about")?.let {
            if (!it.isBlank()) {
                mContentView.findViewById<TextView>(R.id.tv_about_dialog_title).text = it
            }
        }
        MemoryCache.getLabelText("s_about_username")?.let {
            if (!it.isBlank()) {
                mContentView.findViewById<TextView>(R.id.tv_about_user_name).text = it
            }
        }
        MemoryCache.getLabelText("s_about_password")?.let {
            if (!it.isBlank()) {
                mContentView.findViewById<TextView>(R.id.tv_about_password).text = it
            }
        }
        MemoryCache.getLabelText("s_about_EULA")?.let {
            if (!it.isBlank()) {
                mContentView.findViewById<TextView>(R.id.tv_about_eula).text = it
            }
        }
        MemoryCache.getLabelText("s_about_cookie_policy")?.let {
            if (!it.isBlank()) {
                mContentView.findViewById<TextView>(R.id.tv_about_cookie_policy).text = it
            }
        }
        MemoryCache.getLabelText("s_about_acknowledgment")?.let {
            if (!it.isBlank()) {
                mContentView.findViewById<TextView>(R.id.tv_about_acknowledgment).text = it
            }
        }
        MemoryCache.getLabelText("s_about_PDPS")?.let {
            if (!it.isBlank()) {
                mContentView.findViewById<TextView>(R.id.tv_about_pdps).text = it
            }
        }
        MemoryCache.getLabelText("s_terms_conditions")?.let {
            if (!it.isBlank()) {
                mContentView.findViewById<TextView>(R.id.tv_terms_conditions).text = it
            }
        }

        mDialog.setContentView(mContentView)
        val layoutParams = mContentView.layoutParams
        layoutParams.width = c.resources.displayMetrics.widthPixels
        mContentView.layoutParams = layoutParams
        mDialog.window?.setGravity(Gravity.BOTTOM)
        mDialog.setCanceledOnTouchOutside(true)
        mDialog.setCancelable(true)
        mDialog.window?.setWindowAnimations(R.style.Animation_Bottom)
        mDialog.show()
    }
}



