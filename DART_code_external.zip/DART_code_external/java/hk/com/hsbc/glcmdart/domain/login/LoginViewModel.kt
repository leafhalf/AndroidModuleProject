package hk.com.hsbc.glcmdart.domain.login

import android.annotation.SuppressLint
import android.content.Context
import android.util.SparseArray
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.urbanairship.UAirship
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.client.MARKET_COUNTRY
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.client.TAG_COUNTRY_CONFIGURATION
import hk.com.hsbc.glcmdart.client.TAG_IS_NOTIFICATION_ON_FLAG
import hk.com.hsbc.glcmdart.domain.dart.BasicResponse
import hk.com.hsbc.glcmdart.domain.dart.DartApplication
import hk.com.hsbc.glcmdart.domain.dart.PayeeEntity
import hk.com.hsbc.glcmdart.domain.dart.SchedulerTransformer
import hk.com.hsbc.glcmdart.domain.dashboard.ProfileDetailEntity
import hk.com.hsbc.glcmdart.domain.welcome.ConfigViewModel
import hk.com.hsbc.glcmdart.framework.BaseViewModel
import hk.com.hsbc.glcmdart.util.DynamicJsonUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.NetworkManager
import io.reactivex.Observable
import io.reactivex.functions.Function3
import io.reactivex.schedulers.Schedulers
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Response
import java.net.HttpCookie
import java.net.URI

class LoginViewModel : BaseViewModel() {

    private var needChangeLanguage: Boolean = false
    var loginResponse: LiveData<BasicResponse> = MutableLiveData<BasicResponse>()
    private val configViewModel = ConfigViewModel()
    private val mModel by lazy { LoginModel() }

    @SuppressLint("CheckResult")
    fun doRequest(bean: LoginBean) {
        mModel.requestLogin(bean)
                .compose(SchedulerTransformer())
                .subscribe({
                    val request = it.raw().request()
                    val loginCode = it.code()
                    val loginEntity = it?.body()
                    val AMToken = loginEntity?.payload?.AMToken
                    val I8Token = loginEntity?.payload?.I8Token
                    when (loginCode) {
                        200 -> {
                            // Save login entity in memory
                            loginEntity?.also {
                                MemoryCache.saveLoginEntity(it)
                            }
                            // Save tokens in memory
                            AMToken?.also {
                                MemoryCache.saveAMToken(it)
                                val uri = URI(request.url().host())
                                val cookie = HttpCookie("AMToken", it)
                                NetworkManager.addCookie(uri, cookie)
                            }
                            I8Token?.also {
                                MemoryCache.saveI8Token(it)
                            }

                            Observable.zip(mModel.requestProfile().subscribeOn(Schedulers.io()),
                                    mModel.requestProfileDetail(loginEntity?.payload?.SessionInfo?.type).subscribeOn(Schedulers.io()),
                                    mModel.requestOrganisations(it.body()?.payload?.SessionInfo?.type).subscribeOn(Schedulers.io()),
                                    Function3<Response<ProfileEntity>, Response<ProfileDetailEntity>, Response<PayeeEntity>, SparseArray<Any>> { t1, t2, t3 ->
                                        val result = SparseArray<Any>()
                                        result.put(0, t1)
                                        result.put(1, t2)
                                        result.put(2, t3)
                                        result
                                    })
                                    .subscribe({
                                        val profileResponse = it[0] as Response<ProfileEntity>
                                        val profileCode = profileResponse.code()
                                        val profileEntity = profileResponse.body()
                                        when (profileCode) {
                                            200 -> {
                                                // Save session entity in memory
                                                profileEntity?.also {
                                                    if (it.payload?.user?.type == "S" &&
                                                            it.payload.user.name?.contains("(") == true) {
                                                        val subNames = it.payload.user.name.split("(")
                                                        val departmentName = subNames[1].replace(")", "").replace(" ", "")
                                                        val departmentNameList = when {
                                                            departmentName.contains(",") -> {
                                                                departmentName.split(",")
                                                            }
                                                            departmentName.contains("，") -> {
                                                                departmentName.split("，")
                                                            }
                                                            else -> {
                                                                if (departmentName.isNotBlank()) {
                                                                    val singleList= mutableListOf<String>()
                                                                    singleList.add(departmentName)
                                                                    singleList as ArrayList<String>
                                                                } else {
                                                                    null
                                                                }
                                                            }
                                                        }
                                                        if (!departmentNameList.isNullOrEmpty()) {
                                                            for (item in departmentNameList) {
                                                                MemoryCache.departmentName.add(item)
                                                            }
                                                        }
                                                    }
                                                    MemoryCache.saveProfile(profileEntity)
                                                }
                                            }
                                        }
                                        val sharePre = DartApplication.instance?.getSharedPreferences(DartApplication.instance?.applicationInfo?.packageName, Context.MODE_PRIVATE)
                                        val savedConfiguration = sharePre?.getString(TAG_COUNTRY_CONFIGURATION, null)
                                        if (MemoryCache.defaultCountry != profileEntity?.payload?.user?.countryCode) {
                                            MemoryCache.defaultCountry = profileEntity?.payload?.user?.countryCode
                                                    ?: MARKET_COUNTRY
                                            val configMap = mutableMapOf<String, Any?>()
                                            DynamicJsonUtil.deformatJsonOnce(savedConfiguration
                                                    ?: "", configMap)
                                            val countryInfoMap = mutableMapOf<String, Any?>()
                                            DynamicJsonUtil.deformatJsonOnce((configMap[MemoryCache.defaultCountry?.toLowerCase()] as JSONObject).toString(), countryInfoMap)
                                            val languageMap = mutableMapOf<String, Any?>()
                                            DynamicJsonUtil.deformatJsonOnce((countryInfoMap["language"] as JSONObject).toString(), languageMap)
                                            val languageList = languageMap["available"] as JSONArray
                                            var hasItem = false
                                            for (i in 0 until languageList.length()) {
                                                if (languageList.getString(i) == MemoryCache.defaultLanguageFull) {
                                                    hasItem = true
                                                }
                                            }
                                            if (!hasItem) {
                                                needChangeLanguage = true
                                            }
                                        }
                                        val currentLanguage = MemoryCache.defaultLanguageFull
                                        MemoryCache.updateCountryInfo(savedConfiguration
                                                ?: "", null)
                                        if (!needChangeLanguage) {
                                            MemoryCache.defaultLanguageFull = currentLanguage
                                        }

                                        val profileDetailResponse = it[1] as Response<ProfileDetailEntity>
                                        val profileDetailCode = profileDetailResponse.code()
                                        val profileDetailEntity = profileDetailResponse.body()
                                        when (profileDetailCode) {
                                            200 -> {
                                                // Save defaultCurrency to memory
                                                if ("S" == loginEntity?.payload?.SessionInfo?.type) {
                                                    profileDetailEntity?.also { detail ->
                                                        val currencyMap = mutableMapOf<String, MutableList<String>?>()
                                                        detail.payload?.accounts?.let { accounts ->
                                                            accounts.forEach { account ->
                                                                account.countryCode?.let { countryCode ->
                                                                    if (!currencyMap.containsKey(countryCode)) {
                                                                        currencyMap[countryCode] = mutableListOf(account.currency
                                                                                ?: MARKET_CURRENCY)
                                                                    } else {
                                                                        if (currencyMap[countryCode]?.contains(account.currency) == false) {
                                                                            currencyMap[countryCode]?.add(account.currency
                                                                                    ?: MARKET_CURRENCY)
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        MemoryCache.saveCurrencyMap(currencyMap)
                                                    }
                                                }

                                                UAirship.shared().namedUser.id = bean.username
                                                if ("B" == loginEntity?.payload?.SessionInfo?.type) {
                                                    if (DartApplication.instance?.getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE)
                                                                    ?.getBoolean(TAG_IS_NOTIFICATION_ON_FLAG, true) == true) {
                                                        mModel.uploadUrbanAirshipInfo(RequestUrbanAirship(UAirship.shared().pushManager.channelId, loginEntity.payload.SessionInfo.user_id))
                                                                .compose(SchedulerTransformer()).subscribe({}, {})
                                                    } else {
                                                        mModel.detachUrbanAirship(loginEntity.payload.SessionInfo.user_id).compose(SchedulerTransformer()).subscribe({}, {})
                                                    }
                                                } else {
                                                    UAirship.shared().pushManager.userNotificationsEnabled = false
                                                }
                                            }
                                        }

                                        val organizationResponse = it[2] as Response<PayeeEntity>
                                        val organizationCode = organizationResponse.code()
                                        val organizationEntity = organizationResponse.body()
                                        when (organizationCode) {
                                            200 -> {
                                                // Save session entity in memory
                                                organizationEntity?.also { payeeEntity ->
                                                    MemoryCache.saveOrganisations(payeeEntity)
                                                    if ("S" == loginEntity?.payload?.SessionInfo?.type) {
                                                        if (payeeEntity.payload.payors.isNullOrEmpty()) {
                                                            mModel.getBuyers()
                                                        }
                                                    }
                                                    if ("B" == loginEntity?.payload?.SessionInfo?.type) {
                                                        val currencyMap = mutableMapOf<String, MutableList<String>?>()
                                                        payeeEntity.payload.payees?.let { payees ->
                                                            payees.forEach { account ->
                                                                account.account?.countryCode?.let { countryCode ->
                                                                    if (!currencyMap.containsKey(countryCode)) {
                                                                        currencyMap[countryCode] = mutableListOf(account.account.currency
                                                                                ?: MARKET_CURRENCY)
                                                                    } else {
                                                                        if (currencyMap[countryCode]?.contains(account.account.currency) == false) {
                                                                            currencyMap[countryCode]?.add(account.account.currency
                                                                                    ?: MARKET_CURRENCY)
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        MemoryCache.saveCurrencyMap(currencyMap)
                                                    }
                                                }
                                            }
                                        }

                                        if (needChangeLanguage) {
                                            configViewModel.getLanguageStringsFile(MemoryCache.defaultLanguageFull!!) {
                                                (loginResponse as MutableLiveData<BasicResponse>).postValue(BasicResponse(200, null))
                                            }
                                        } else {
                                            (loginResponse as MutableLiveData<BasicResponse>).postValue(BasicResponse(200, null))
                                        }
                                    }, {
                                        val t = it?.message ?: "Login failed!"
                                        (loginResponse as MutableLiveData<BasicResponse>).postValue(BasicResponse(-1, t))
                                    })
                        }
                        400, 401 -> {
                            (loginResponse as MutableLiveData<BasicResponse>).value = BasicResponse(loginCode, null)
                        }
                        else -> {
                            val message = it.message()
                            val errorText = loginEntity?.errorText
                            val msg = when {
                                !errorText.isNullOrEmpty() -> errorText
                                !message.isNullOrEmpty() -> message
                                else -> "Login failed!"
                            }
                            (loginResponse as MutableLiveData<BasicResponse>).postValue(BasicResponse(loginCode, msg))
                        }
                    }
                }, {
                    val t = it?.message ?: "Login failed!"
                    (loginResponse as MutableLiveData<BasicResponse>).postValue(BasicResponse(-1, t))
                })
    }

}