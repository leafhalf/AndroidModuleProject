/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */

package hk.com.hsbc.glcmdart.domain.more

import hk.com.hsbc.glcmdart.client.URL_MORE_BUYER
import hk.com.hsbc.glcmdart.client.URL_MORE_HELP
import hk.com.hsbc.glcmdart.domain.more.entity.BuyerListEntity
import hk.com.hsbc.glcmdart.domain.more.entity.HelpEntity
import io.reactivex.Observable
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Created by Donut on 2018/11/12.
 */
interface MoreServer {

    @GET(URL_MORE_HELP)
    fun getHelpInfo(): Observable<HelpEntity>

    @GET(URL_MORE_BUYER)
    fun getBuyers(@Query("type")type: String = "B"): Observable<BuyerListEntity>
}