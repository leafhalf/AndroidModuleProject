/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.*
import hk.com.hsbc.glcmdart.domain.dart.CommonDialog
import hk.com.hsbc.glcmdart.domain.dart.CommonDialogExtras
import hk.com.hsbc.glcmdart.domain.dart.CreditNoteLocal
import hk.com.hsbc.glcmdart.domain.dart.InvoiceListItem
import hk.com.hsbc.glcmdart.domain.payments.adapter.AddNewInvoiceAdapter
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import hk.com.hsbc.glcmdart.view.RecyclerExtras
import kotlinx.android.synthetic.main.activity_add_new_invoice.*
import kotlin.math.abs

class AddNewInvoiceActivity : BaseActivity(), RecyclerExtras.OnItemDeleteClickListener, RecyclerExtras.OnItemClickListener {

    private val itemList = ArrayList<InvoiceAddEntity>()
    private val mAdapter by lazy { AddNewInvoiceAdapter(this, itemList) }

    // available credit note list
    private var creditNotes: List<CreditNoteLocal> = mutableListOf()
    private var taxDeductions: HashMap<String, ArrayList<TaxDeductionInfo>?>? = null

    // initiated selected credit note
    private var originSelectedCreditNotes = HashMap<String?, ArrayList<CreditNoteLocal>?>()
    private var invoicesAdded: ArrayList<InvoiceAddEntity>? = null
    private var invoicesSelected: ArrayList<InvoiceAddEntity>? = null
    private var selectedPosition: Int = -1
    private val originalAmountMap = mutableMapOf<String, Long>()
    private var type = -1
    private var currency: String? = null
    private var updateCreditNoteAmount = false
    private var isCreditNoteMethod = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_new_invoice)
        initView()
        initData()
    }

    @SuppressLint("ResourceAsColor")
    private fun initView() {
        tl_head.title = ""
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)
        setSupportActionBar(tl_head)
        tl_head.setNavigationOnClickListener {
            returnBackLastPage()
        }

        btn_save.setOnClickListener {
            for (item in itemList) {
                if (item.amount.isNullOrEmpty() && item.creditNotesSelected == null)
                    return@setOnClickListener
                if (item.amount.isNullOrEmpty())
                    item.amount = "0"
            }
            val intent = Intent().apply {
                putExtra(TAG_REQUEST_RESULT_INVOICE, itemList)
            }
            setResult(Activity.RESULT_OK, intent)
            finish()
        }

        tv_remove_invoice.setOnClickListener {
            CommonDialog.showAlertDialog(this, MemoryCache.getLabelText("s_remove_invoice_title")
                    ?: getString(R.string.s_remove_invoice_title),
                    MemoryCache.getLabelText("s_remove_invoice")
                            ?: getString(R.string.s_remove_invoice),
                    MemoryCache.getLabelText("s_remove")
                            ?: getString(R.string.s_remove), object : CommonDialogExtras.OnButtonListener {
                override fun positiveButtonListener() {
                    TealiumUtil.eventTag("button click", "invoice delete confirmation overlay: delete")
                    val intent = Intent().apply {
                        putExtra(TAG_REQUEST_RESULT_INVOICE, itemList)
                        putExtra(TAG_DELETE_INVOICE, true)
                    }

                    setResult(Activity.RESULT_OK, intent)
                    finish()
                }

                override fun negativeButtonListener() {
                    TealiumUtil.eventTag("button click", "invoice delete confirmation overlay: cancel")
                }
            }, MemoryCache.getLabelText("s_cancel") ?: getString(R.string.s_cancel))
        }

        btn_enter.setOnClickListener {
            if (itemList.size > 0) {
                TealiumUtil.eventTag("button click", "planned payment - update invoice info: add invoice details: add")
                val overpayInvoiceList = mutableListOf<String>()
                val overpaidTips = StringBuffer()
                overpaidTips.append(MemoryCache.getLabelText("s_overpay_invoices_warnming")
                        ?: getString(R.string.s_overpay_invoices_warnming)).append(" ")
                for (item in itemList) {
                    if (item.overPaid == true) {
                        overpayInvoiceList.add(item.invoice?.reference ?: "")
                    }
                }
                if (overpayInvoiceList.size > 0) {
                    when (overpayInvoiceList.size) {
                        1 -> overpaidTips.append(overpayInvoiceList[0])
                        2 -> overpaidTips.append(overpayInvoiceList[0]).append(" and ").append(overpayInvoiceList[1])
                        else -> {
                            for (i in overpayInvoiceList.indices) {
                                when {
                                    i < overpayInvoiceList.size - 2 -> overpaidTips.append(overpayInvoiceList[i]).append(", ")
                                    i == overpayInvoiceList.size - 2 -> overpaidTips.append(overpayInvoiceList[i]).append(" and ")
                                    i == overpayInvoiceList.size - 1 -> overpaidTips.append(overpayInvoiceList[i])
                                }
                            }
                        }
                    }
                    CommonDialog.showAlertDialog(this, MemoryCache.getLabelText("s_overpay_invoices")
                            ?: getString(R.string.s_overpay_invoices), overpaidTips.toString(),
                            MemoryCache.getLabelText("s_amend") ?: getString(R.string.s_amend),
                            object : CommonDialogExtras.OnButtonListener {
                                override fun positiveButtonListener() {

                                }

                                override fun negativeButtonListener() {
                                    for (item in itemList) {
                                        if (item.amount.isNullOrEmpty())
                                            item.amount = "0"
                                    }
                                    val intent = Intent().apply {
                                        putExtra(TAG_REQUEST_RESULT_INVOICE, itemList)
                                    }
                                    setResult(Activity.RESULT_OK, intent)
                                    finish()
                                }
                            }, MemoryCache.getLabelText("s_overpay")
                            ?: getString(R.string.s_overpay))
                } else {
                    for (item in itemList) {
                        if (item.amount.isNullOrEmpty() && item.creditNotesSelected == null)
                            return@setOnClickListener
                        if (isCreditNoteMethod) {
                            item.amount = "0"
                        }
                        if (item.amount.isNullOrEmpty())
                            item.amount = "0"
                    }
                    val intent = Intent().apply {
                        putExtra(TAG_REQUEST_RESULT_INVOICE, itemList)
                    }
                    setResult(Activity.RESULT_OK, intent)
                    finish()
                }
            }
        }
        rv_invoice_add_or_edit.layoutManager = LinearLayoutManager(this)
        mAdapter.setOnItemClickListener(this)
        mAdapter.setOnItemDeleteClickListener(this)
        mAdapter.setButton(btn_enter)
        mAdapter.setSaveButton(btn_save)
        rv_invoice_add_or_edit.adapter = mAdapter
    }

    private fun initData() {
        currency = intent.getStringExtra(TAG_INVOICE_CURRENCY)
        isCreditNoteMethod = intent.getBooleanExtra(TAG_IS_CREDIT_NOTE_METHOD, false)
        mAdapter.setCurrency(currency)
        mAdapter.isCreditNoteMethod = isCreditNoteMethod
        type = intent.getIntExtra(TAG_INVOICE_TYPE_EDIT, -1)
        if (type == 1) {
            tl_head.title = MemoryCache.getLabelText("s_edit_invoice_detail_title")
                    ?: getString(R.string.s_edit_invoice_detail_title)
            tv_remove_invoice.text = MemoryCache.getLabelText("s_remove_this_invoice")
                    ?: getString(R.string.s_remove_this_invoice)
            btn_save.text = MemoryCache.getLabelText("s_save") ?: getString(R.string.s_save)
            btn_enter.visibility = View.GONE
            btn_save.visibility = View.VISIBLE
            tv_remove_invoice.visibility = View.VISIBLE
        } else {
            tl_head.title = MemoryCache.getLabelText("s_add_new_invoice")
                    ?: getString(R.string.s_add_new_invoice)
            btn_enter.text = MemoryCache.getLabelText("s_add") ?: getString(R.string.s_add)
            btn_enter.visibility = View.VISIBLE
            btn_save.visibility = View.GONE
            tv_remove_invoice.visibility = View.GONE
        }
        mAdapter.setType(type)
        val creditNotesResidueMap = mutableMapOf<String, CreditNoteLocal>()
        taxDeductions = MemoryCache.getCachedDeduction()
        if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE) != null) {
            val mCreditNotes = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE) as ArrayList<CreditNoteLocal>?
            if (mCreditNotes != null) {
                creditNotes = mutableListOf()
                for (item in mCreditNotes) {
                    if (currency == item.creditNote?.payeeAccount?.currency) {
                        item.outstanding = ""
                        (creditNotes as ArrayList<CreditNoteLocal>).add(item)
                        creditNotesResidueMap[item.token!!] = item
                    }
                }
            }
        }
        if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_INVOICE_ADDED) != null)
            invoicesAdded = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_INVOICE_ADDED) as ArrayList<InvoiceAddEntity>?
        if (intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_INVOICE_SELECTED) != null)
            invoicesSelected = intent.getSerializableExtra(TAG_REQUEST_INTENT_DATA_INVOICE_SELECTED) as ArrayList<InvoiceAddEntity>?

        invoicesSelected?.forEach {
            it.creditNotes = creditNotes
            it.taxDeductions = taxDeductions?.get(it.token)
        }
        invoicesSelected?.let {
            mAdapter.isCreditNoteMethod = isCreditNoteMethod
            mAdapter.addData(it)
            it.forEach { invoice ->
                if (!invoice.creditNotesSelected.isNullOrEmpty()) {
                    originSelectedCreditNotes.put(invoice.token, invoice.creditNotesSelected as ArrayList?)
                }
            }
            if (isCreditNoteMethod) {
                btn_enter.isEnabled = true
                for (item in it) {
                    if (item.creditNotesSelected.isNullOrEmpty()) {
                        btn_enter.isEnabled = false
                        break
                    }
                }
            }
        }
    }

    override fun onItemClick(view: View, position: Int) {
        if (view.id == R.id.ll_credit_note) {
            if (type == 1) {
                TealiumUtil.eventTag("onsite", "edit invoice - detail with credit note: credit note")
            } else {
                TealiumUtil.eventTag("onsite", "planned payment - update invoice info:add invoice details: credit note")
            }
            if (creditNotes != null) {
                selectedPosition = position
                ChooseCreditNoteActivity.showActivity(this,
                        this.creditNotes!!,
                        itemList[position].creditNotesSelected, currency, REQUEST_CODE_CHOOSE_CREDIT_NOTE_LIST)
            }
        } else {
            if (taxDeductions != null) {
                selectedPosition = position
                itemList[position].taxDeductionSelected?.forEach {
                    it.selected = true
                }
                ChooseTaxDeductionActivity.showActivity(this, taxDeductions?.get(itemList[position].token)!!, currency,
                        itemList[position].invoice!!, itemList[position].taxDeductionSelected,
                        REQUEST_CODE_CHOOSE_TAX_DEDUCTION_LIST)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_CHOOSE_CREDIT_NOTE_LIST) {
                if (data?.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE) != null) {
                    val mCreditNotes = data.getSerializableExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE) as List<CreditNoteLocal>
                    if (selectedPosition > -1) {
                        updateCreditNoteAmount = true
                        updateInvoicesStateWithCreditNotes(selectedPosition, mCreditNotes)
                        selectedPosition = -1
                    }

                    if (isCreditNoteMethod) {
                        if (itemList.size > 0) {
                            btn_enter.isEnabled = true
                            for (item in itemList) {
                                if (item.creditNotesSelected.isNullOrEmpty()) {
                                    btn_enter.isEnabled = false
                                    break
                                }
                            }
                        }
                    }
                }
            }

            if (requestCode == REQUEST_CODE_CHOOSE_TAX_DEDUCTION_LIST) {
                if (selectedPosition > -1) {
                    itemList[selectedPosition].taxDeductionSelected =
                            data?.getSerializableExtra(TAG_REQUEST_INTENT_DATA_TAX_DEDUCTION) as ArrayList<TaxDeductionInfo>?
                    mAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    private fun updateInvoicesStateWithCreditNotes(mSelectedPostion: Int, mCreditNotes: List<CreditNoteLocal>) {
        val mapCreditNotesUsed = mutableMapOf<String, List<CreditNoteLocal>>()
        val mapCreditNotesAmountUsed = mutableMapOf<String, Long>()
        val deletedCNList = mutableListOf<CreditNoteLocal>()
        val sb = StringBuilder()
        for (item in mCreditNotes) {
            sb.append(item.token).append(",")
        }
        if (!itemList[mSelectedPostion].creditNotesSelected.isNullOrEmpty()) {
            val tokenSetStrings = sb.toString()
            itemList[mSelectedPostion].creditNotesSelected?.forEach {
                if (!tokenSetStrings.contains(it.token ?: "")) {
                    deletedCNList.add(it)
                }
            }
        }
        itemList[mSelectedPostion].creditNotesSelected = mCreditNotes as ArrayList<CreditNoteLocal>?
        if (itemList[mSelectedPostion].creditNotesSelected.isNullOrEmpty()) {
            itemList[mSelectedPostion].creditNotesSelected = mCreditNotes as ArrayList<CreditNoteLocal>
        } else {
            for (item in mCreditNotes) {
                var itemInList = false
                itemList[mSelectedPostion].creditNotesSelected?.forEach { originCN ->
                    if (item.token == originCN.token) {
                        itemInList = true
                        originCN.outstanding = item.outstanding
                    }
                }

                if (!itemInList) {
                    itemList[mSelectedPostion].creditNotesSelected?.add(item)
                }
            }

            for (item in deletedCNList) {
                for (originItem in itemList[mSelectedPostion].creditNotesSelected!!) {
                    if (originItem.token == item.token) {
                        itemList[mSelectedPostion].creditNotesSelected?.remove(originItem)
                        break
                    }
                }
            }
        }

        if (mCreditNotes.isNotEmpty()) {
            for (item in mCreditNotes) {
                item.token?.also {
                    if (mapCreditNotesUsed.contains(it)) {
                        val usedList = mapCreditNotesUsed[it] as ArrayList<CreditNoteLocal>
                        usedList.add(item)
                        mapCreditNotesUsed[it] = usedList
                        var amountUsed = mapCreditNotesAmountUsed[it]
                        amountUsed = (amountUsed ?: 0L) + (item.outstanding?.toLong() ?: 0L)
                        mapCreditNotesAmountUsed[it] = amountUsed
                    } else {
                        val usedList = mutableListOf<CreditNoteLocal>()
                        usedList.add(item)
                        mapCreditNotesUsed[it] = usedList
                        mapCreditNotesAmountUsed[it] = item.outstanding?.toLong() ?: 0L
                    }
                }
            }
        }
        for (i in itemList.indices) {
            if (i != mSelectedPostion) {
                itemList[i].creditNotesSelected?.forEach {
                    it.token?.also { token ->
                        if (mapCreditNotesUsed.contains(token)) {
                            val usedList = mapCreditNotesUsed[token] as ArrayList<CreditNoteLocal>
                            usedList.add(it)
                            mapCreditNotesUsed[token] = usedList
                            var amountUsed = mapCreditNotesAmountUsed[token] ?: 0L
                            amountUsed += (it.outstanding?.toLong() ?: 0L)
                            mapCreditNotesAmountUsed[token] = amountUsed
                        } else {
                            val usedList = mutableListOf<CreditNoteLocal>()
                            usedList.add(it)
                            mapCreditNotesUsed[token] = usedList
                            mapCreditNotesAmountUsed[token] = it.outstanding?.toLong() ?: 0L
                        }
                    }
                }
            }
        }
        val mapCreditNotesAvailable = mutableMapOf<String, CreditNoteLocal>()
        creditNotes?.forEach {
            val itemCopy = CreditNoteLocal(it.creditNote?.copy(), it.token, it.outstanding)
            if (mapCreditNotesAmountUsed.contains(itemCopy.token)) {
                val creditNoteAmountAvailable = originalAmountMap[itemCopy.token]
                        ?: 0L + (mapCreditNotesAmountUsed[itemCopy.token]?.toLong() ?: 0L)
                if (creditNoteAmountAvailable < 0) {
                    val creditNoteAvailable = CreditNoteLocal(itemCopy.creditNote, itemCopy.token, "")
                    creditNoteAvailable.creditNote?.outstanding = creditNoteAmountAvailable.toString()
                    mapCreditNotesAvailable[itemCopy.token!!] = creditNoteAvailable
                }
            } else {
                mapCreditNotesAvailable[itemCopy.token!!] = itemCopy
            }
        }

        var updateFlag = true
        for (position in itemList.indices) {

            for (globalCr in creditNotes) {
                globalCr.creditNote?.outstanding = globalCr.creditNote?.originOutstanding ?: "0"
            }

            if (itemList.size > 0) {
                // scan all invoice items
                for (invoiceItem in itemList) {
                    // exclude current item
                    if (invoiceItem.token == itemList[position].token) continue
                    invoiceItem.creditNotesSelected?.forEach { selectedCr ->
                        // use origin outstanding amount minus selected credit notes
                        for (globalCr in creditNotes) {
                            if (globalCr.token == selectedCr.token) {
                                if (globalCr.creditNote?.originOutstanding == globalCr.creditNote?.outstanding) {
                                    val amountText = (-(abs(globalCr.creditNote?.originOutstanding?.toLong()
                                            ?: 0L) - abs(if (selectedCr.outstanding.isNullOrBlank()) 0L else selectedCr.outstanding?.toLong()!!)
                                            )).toString()
                                    globalCr.creditNote?.outstanding = amountText
                                } else {
                                    val amountText = (-(abs(globalCr.creditNote?.outstanding?.toLong()
                                            ?: 0L) - abs(if (selectedCr.outstanding.isNullOrBlank()) 0L else selectedCr.outstanding?.toLong()!!)
                                            )).toString()
                                    globalCr.creditNote?.outstanding = amountText
                                }
                            }
                        }
                    }
                }
            }

            val currentCanSelected = mutableListOf<CreditNoteLocal>()
            for (globalCr in creditNotes) {
                if (((globalCr.creditNote?.outstanding?.toLong()) ?: 0L) < 0) {
                    currentCanSelected.add(CreditNoteLocal(globalCr.creditNote?.copy(), globalCr.token, globalCr.outstanding).copy())
                }
            }
            itemList[position].creditNotes = currentCanSelected

//            val currentCanSelected = mutableListOf<CreditNoteLocal>()
//            if (item.creditNotesSelected != null) {
//                val commonUsedMap = mutableMapOf<CreditNoteLocal, CreditNoteLocal>()
//                item.creditNotesSelected?.forEach {
//                    if (mapCreditNotesAvailable.contains(it.token)) {
//                        mapCreditNotesAvailable[it.token]?.let { local ->
//                            commonUsedMap[it] = local
//                        }
//                    }
//                }
//                if (commonUsedMap.isNotEmpty()) {
//                    for (subItem in commonUsedMap) {
//                        val lastAmountUsed = 0 - (subItem.value.creditNote?.outstanding?.toLong()
//                                ?: 0L)
//                        val creditNote = CreditNoteLocal(subItem.value.creditNote?.copy(), subItem.value.token, subItem.key.outstanding).copy()
//                        creditNote.creditNote?.outstanding = lastAmountUsed.toString()
//                        currentCanSelected.add(creditNote)
//                    }
//                    for (subItem in mapCreditNotesAvailable) {
//                        if (!commonUsedMap.containsValue(subItem.value)) {
//                            currentCanSelected.add(subItem.value)
//                        }
//                    }
//
//                    item.creditNotesSelected?.forEach {
//                        if (!mapCreditNotesAvailable.containsKey(it.token)) {
//                            currentCanSelected.add(it)
//                        }
//                    }
//                } else {
//                    item.creditNotesSelected?.forEach {
//                        if (mapCreditNotesAmountUsed.contains(it.token)) {
//                            val availableAmount = originalAmountMap[it.token] ?: 0L +
//                            (mapCreditNotesAmountUsed[it.token]?.toLong() ?: 0L) -
//                            (it.outstanding?.toLong() ?: 0L)
//                            it.creditNote?.outstanding = availableAmount.toString()
//                            currentCanSelected.add(it)
//                        } else {
//                            currentCanSelected.add(it)
//                        }
//                    }
//                    for (subItem in mapCreditNotesAvailable) {
//                        currentCanSelected.add(subItem.value)
//                    }
//                }
//            } else {
//                for (subItem in mapCreditNotesAvailable) {
//                    currentCanSelected.add(subItem.value)
//                }
//            }
//            item.creditNotes = currentCanSelected
//
            var amountInput = 0L
            if (!itemList[position].amount.isNullOrEmpty()) {
                amountInput = itemList[position].amount?.toLong() ?: 0L
            }
            if (amountInput == 0L && itemList[position].creditNotesSelected.isNullOrEmpty()) {
                updateFlag = false
            }
        }
        btn_enter.isEnabled = updateFlag
        mAdapter.needUpdateCreditNoteAmount = updateCreditNoteAmount
        mAdapter.notifyDataSetChanged()
    }

    override fun onItemDeleteClick(view: View, position: Int) {
        TealiumUtil.eventTag("button click", "planned payment - update invoice info:add invoice details:remove invoice")
        CommonDialog.showAlertDialog(this, MemoryCache.getLabelText("s_remove_invoice_title")
                ?: getString(R.string.s_remove_invoice_title),
                MemoryCache.getLabelText("s_remove_invoice")
                        ?: getString(R.string.s_remove_invoice),
                MemoryCache.getLabelText("s_remove")
                        ?: getString(R.string.s_remove), object : CommonDialogExtras.OnButtonListener {
            override fun positiveButtonListener() {
                TealiumUtil.eventTag("button click", "invoice delete confirmation overlay: delete")
                itemList.removeAt(position)
                mAdapter.notifyDataSetChanged()
                if (itemList.size == 0) {
                    returnBackLastPage()
                }
            }

            override fun negativeButtonListener() {
                TealiumUtil.eventTag("button click", "invoice delete confirmation overlay: cancel")
            }
        }, MemoryCache.getLabelText("s_cancel") ?: getString(R.string.s_cancel))

    }

    override fun onBackPressed() {
        returnBackLastPage()
    }

    private fun returnBackLastPage() {
        if (type == 1) {
            if (btn_save.isEnabled) {
                CommonDialog.showAlertDialog(this, MemoryCache.getLabelText("s_save_changes")
                        ?: getString(R.string.s_save_changes),
                        MemoryCache.getLabelText("s_save_changes_tips")
                                ?: getString(R.string.s_save_changes_tips),
                        MemoryCache.getLabelText("s_save") ?: getString(R.string.s_save),
                        object : CommonDialogExtras.OnButtonListener {
                            override fun positiveButtonListener() {
                                TealiumUtil.eventTag("button", "edit invoice - save changes overlay: save")
                                for (item in itemList) {
                                    if (item.amount.isNullOrEmpty())
                                        item.amount = "0"
                                }
                                val intent = Intent().apply {
                                    putExtra(TAG_REQUEST_RESULT_INVOICE, itemList)
                                }
                                setResult(Activity.RESULT_OK, intent)
                                finish()
                            }

                            override fun negativeButtonListener() {
                                finish()
                                TealiumUtil.eventTag("button", "edit invoice - save changes overlay: cancel")
                            }
                        }, MemoryCache.getLabelText("s_cancel") ?: getString(R.string.s_cancel))
                if (!itemList[0].creditNotesSelected.isNullOrEmpty())
                    TealiumUtil.eventTag("button click", "edit invoice - detail with credit note: save")
                else
                    TealiumUtil.eventTag("button click", "edit invoice - detail: save")
                    TealiumUtil.pageTag(
                        "dart : buyer portal : invoices : edit invoice - save changes overlay",
                        "/dart/buyer portal/invoices/edit invoice-save changes overlay",
                        "accounts",
                        "buyer portal",
                        "invoices"
                )
            } else {
                return
            }
        } else {
            val invoices = mutableListOf<InvoiceListItem>()
            for (item in itemList) {
                invoices.add(InvoiceListItem(item.token, item.invoice, true))
            }
            val intent = Intent()
            intent.putExtra(TAG_REQUEST_RESULT_INVOICE, invoices as ArrayList<InvoiceListItem>)
            setResult(Activity.RESULT_CANCELED, intent)
            finish()
        }
    }

    companion object {
        const val TAG_INVOICE_TYPE_EDIT = "type_invoice_edit"
        const val TAG_INVOICE_CURRENCY = "type_invoice_currency"
        const val TAG_IS_CREDIT_NOTE_METHOD = "is_credit_note"
        fun showActivity(activity: Activity, entities: List<InvoiceListItem>, creditNotes: ArrayList<CreditNoteLocal>,
                         invoicesAdded: ArrayList<InvoiceAddEntity>,
                         currency: String?, requestCode: Int, isCreditNote: Boolean = false) {
            val intent = Intent(activity, AddNewInvoiceActivity::class.java).apply {
                putExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE, creditNotes)
                val invoicesSelected = mutableListOf<InvoiceAddEntity>()
                for (item in entities) {
                    invoicesSelected.add(InvoiceAddEntity(item.token, item.invoice, item.invoice?.summation?.outstanding?.amount.toString(),
                            "", null, null, null, null, active = item.active))
                }
                putExtra(TAG_REQUEST_INTENT_DATA_INVOICE_SELECTED, invoicesSelected as ArrayList<InvoiceAddEntity>)
                putExtra(TAG_REQUEST_INTENT_DATA_INVOICE_ADDED, invoicesAdded)
                putExtra(TAG_INVOICE_CURRENCY, currency)
                putExtra(TAG_IS_CREDIT_NOTE_METHOD, isCreditNote)
            }
            activity.startActivityForResult(intent, requestCode)
        }

        fun showActivity2(activity: Activity, entities: List<InvoiceAddEntity>, creditNotes: List<CreditNoteLocal>,
                          invoicesAdded: ArrayList<InvoiceAddEntity>, currency: String?,
                          requestCode: Int, isCreditNote: Boolean = false) {
            val intent = Intent(activity, AddNewInvoiceActivity::class.java).apply {
                putExtra(TAG_INVOICE_TYPE_EDIT, 1)
                putExtra(TAG_REQUEST_INTENT_DATA_CREDIT_NOTE, creditNotes as ArrayList<CreditNoteLocal>)
                putExtra(TAG_IS_CREDIT_NOTE_METHOD, isCreditNote)
                val invoicesSelected = mutableListOf<InvoiceAddEntity>()
                val invoicesTokenSelected = mutableListOf<String>()
                if (invoicesAdded.isNotEmpty()) {
                    for (item in entities) {
                        for (subItem in invoicesAdded) {
                            if (item.token.equals(subItem.token)) {
                                invoicesSelected.add(subItem)
                                invoicesTokenSelected.add(item.token!!)
                                break
                            }
                        }
                    }
                    for (item in entities) {
                        if (!invoicesTokenSelected.contains(item.token)) {
                            invoicesSelected.add(item)
                        }
                    }
                } else {
                    for (item in entities) {
                        invoicesSelected.add(item)
                    }
                }
                putExtra(TAG_REQUEST_INTENT_DATA_INVOICE, invoicesSelected as ArrayList<InvoiceAddEntity>)
                putExtra(TAG_REQUEST_INTENT_DATA_INVOICE_SELECTED, invoicesAdded)
                putExtra(TAG_INVOICE_CURRENCY, currency)
            }
            activity.startActivityForResult(intent, requestCode)
        }
    }

    override fun onResume() {
        super.onResume()
        if (!invoicesSelected.isNullOrEmpty()) {
            TealiumUtil.pageTag(
                    "dart : buyer portal : invoices : edit invoice - detail",
                    "/dart/buyer portal/invoices/edit invoice-detail",
                    "accounts",
                    "buyer portal",
                    "invoices"
            )
        } else {
            TealiumUtil.pageTag(
                    "dart : buyer portal : invoices : edit invoice - detail with credit note",
                    "/dart/buyer portal/invoices/edit invoice-detail with credit note",
                    "accounts",
                    "buyer portal",
                    "invoices"
            )
        }
    }
}
