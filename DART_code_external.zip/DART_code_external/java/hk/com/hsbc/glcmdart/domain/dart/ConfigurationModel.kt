/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.dart

import com.google.gson.JsonObject
import hk.com.hsbc.glcmdart.client.HOST_URL_CONSENT_
import hk.com.hsbc.glcmdart.util.NetworkManager
import io.reactivex.Observable
import retrofit2.Response

class ConfigurationModel {

    fun requestVersionUpdate(): Response<VersionUpdateEntity> {
        return NetworkManager.getNormalService(ConfigurationService::class.java, HOST_URL_CONSENT_)
                .requestVersionUpdate()
                .execute()
    }

    fun requestCountryConfiguration(): Observable<JsonObject> {
        return NetworkManager.getNormalService(ConfigurationService::class.java, HOST_URL_CONSENT_)
                .requestCountryConfiguration()
    }

    //only strings file use "ID" statically , if more countries and areas, add parameters
    fun requestLanguageStringFile(path: String, countryCode: String): Observable<JsonObject> {
        return NetworkManager.getNormalService(ConfigurationService::class.java, HOST_URL_CONSENT_)
                .requestLanguageStringsFile(path, countryCode)
    }
}