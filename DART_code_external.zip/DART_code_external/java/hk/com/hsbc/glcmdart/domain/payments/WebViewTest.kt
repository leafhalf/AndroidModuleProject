package hk.com.hsbc.glcmdart.domain.payments

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.framework.BaseActivity
import kotlinx.android.synthetic.main.activity_webview_test.*

class WebViewTest: BaseActivity() {

    companion object {
        fun showActivity(c: Context?, content: String) {
            c?.startActivity(Intent(c, WebViewTest::class.java).apply {
                putExtra("test", content)
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_webview_test)
        val str = intent.getStringExtra("test")
        web_test.settings?.javaScriptEnabled = true
        web_test.webViewClient = object: WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                Log.e("test", "current url = $url")
//                view?.loadUrl("javascript:window.payu_obj.checkContent(document.getElementsByTagName('html')[0].innerHTML)")
//                pb_webview.visibility = View.GONE
                super.onPageFinished(view, url)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
//                pb_webview.visibility = View.VISIBLE
//                pb_webview.progress = 0
                super.onPageStarted(view, url, favicon)
            }
        }
        web_test.loadData(str, "text/html", "utf-8")
    }
}