/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.more

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.CompoundButton
import androidx.lifecycle.ViewModelProviders
import com.urbanairship.UAirship
import hk.com.hsbc.glcmdart.BuildConfig
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_NOTIFICATION_NEGATIVE
import hk.com.hsbc.glcmdart.client.REQUEST_CODE_NOTIFICATION_POSITIVE
import hk.com.hsbc.glcmdart.client.TAG_IS_NOTIFICATION_ON_FLAG
import hk.com.hsbc.glcmdart.domain.dart.CommonDialog
import hk.com.hsbc.glcmdart.extension.isNotificationEnabled
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_notification.*

class NotificationActivity : BaseActivity(), CompoundButton.OnCheckedChangeListener {

    private lateinit var mViewModel: NotificationViewModel

    companion object {
        fun showActivity(activity: Activity?) {
            activity?.startActivity(Intent(activity, NotificationActivity::class.java))
        }
    }

//    private val mPresenter by lazy { NotificationPresenter() }

    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)
        tl_head.title = MemoryCache.getLabelText("s_notification") ?: getString(R.string.s_notification)
        tl_head.setTitleTextColor(Color.WHITE)
        tl_head.setNavigationIcon(R.drawable.ic_arrow_back_white)

        tl_head.setNavigationOnClickListener {
            finish()
        }

        mViewModel = ViewModelProviders.of(this).get(NotificationViewModel::class.java)
        sw_notification.isChecked = getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).getBoolean(TAG_IS_NOTIFICATION_ON_FLAG, true)

        sw_notification.setOnCheckedChangeListener(this)

        MemoryCache.getLabelText("s_notification_tag")?.let {
            if (!it.isBlank()) {
                tv_notification_tag.text = it
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart:buyer portal:more:notifications - landing",
                "/dart/buyer-portal/more/notifications/landing",
                "other",
                "buyer portal",
                "more")
    }

    private fun openSetting(isAllow: Boolean) {
        val pkg = applicationContext.packageName
        val uid = applicationInfo.uid
        try {
            val intent = Intent().apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    action = Settings.ACTION_APP_NOTIFICATION_SETTINGS
                    putExtra(Settings.EXTRA_APP_PACKAGE, pkg)
                    putExtra(Settings.EXTRA_CHANNEL_ID, uid)
                }

                putExtra("app_package", pkg)
                putExtra("app_uid", uid)
            }

            startActivityForResult(intent, if (isAllow) REQUEST_CODE_NOTIFICATION_POSITIVE else REQUEST_CODE_NOTIFICATION_NEGATIVE)
        } catch (e: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS)
            startActivityForResult(intent, if (isAllow) REQUEST_CODE_NOTIFICATION_POSITIVE else REQUEST_CODE_NOTIFICATION_NEGATIVE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        sw_notification.setOnCheckedChangeListener(null)
        sw_notification.isChecked = if (!isNotificationEnabled(this)) {
            false
        } else {
            mViewModel.doUploadUrbanAirship()
            UAirship.shared().pushManager.userNotificationsEnabled = true
            getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).edit().putBoolean(TAG_IS_NOTIFICATION_ON_FLAG, true).apply()
            true
        }

        UAirship.shared().pushManager.userNotificationsEnabled = sw_notification.isChecked
        sw_notification.setOnCheckedChangeListener(this)
    }

    override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
        if (isChecked) {
            TealiumUtil.eventTag("button click", "more notifications landing: enabled")
            if (!isNotificationEnabled(this@NotificationActivity)) {
                TealiumUtil.pageTag("dart:buyer portal:more:notification - allow overlay", "/dart/buyer-portal/more/notifications/allow-overlay",
                        "other","buyer portal", "more")
                CommonDialog.showDialog(this@NotificationActivity, getString(R.string.s_notification_dialog_title),
                        getString(R.string.s_notification_dialog_message_positive), getString(R.string.s_notification_dialog_confirm), null,
                        View.OnClickListener {
                            TealiumUtil.eventTag("button click", "more notifications allow overlay: go to setting")
                            openSetting(isChecked)
                        }, View.OnClickListener {
                            TealiumUtil.eventTag("button click", "more notifications allow overlay: cancel")
                        })
            } else {
                mViewModel.doUploadUrbanAirship()
                UAirship.shared().pushManager.userNotificationsEnabled = true
                getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).edit().putBoolean(TAG_IS_NOTIFICATION_ON_FLAG, true).apply()
            }
        } else {
            TealiumUtil.eventTag("button click", "more notifications landing: disabled")
            mViewModel.doDetachUrbanAirship()
            UAirship.shared().pushManager.userNotificationsEnabled = false
            getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE).edit().putBoolean(TAG_IS_NOTIFICATION_ON_FLAG, false).apply()
        }
    }
}