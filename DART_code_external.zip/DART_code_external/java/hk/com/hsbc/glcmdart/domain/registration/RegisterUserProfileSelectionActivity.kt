/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.registration

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.TAG_ANSWER_SECURITY_QUESTION_INFO
import hk.com.hsbc.glcmdart.client.TAG_INVITATION_CODE
import hk.com.hsbc.glcmdart.domain.login.LoginActivity
import hk.com.hsbc.glcmdart.framework.BaseActivity
import hk.com.hsbc.glcmdart.util.ApplicationManager
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.util.TealiumUtil
import kotlinx.android.synthetic.main.activity_register_userprofileselection.*

class RegisterUserProfileSelectionActivity : BaseActivity(), View.OnClickListener {

    private var mInvitationCode: String? = null
    private var mRegistrationChallengeEntity: RegistrationChallengeEntity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_userprofileselection)

        intent?.also {
            mInvitationCode = it.getStringExtra(TAG_INVITATION_CODE)
            mRegistrationChallengeEntity = it.getSerializableExtra(TAG_ANSWER_SECURITY_QUESTION_INFO) as RegistrationChallengeEntity
        }

        registerProfileLayout.setAccessibilityDelegate(object: View.AccessibilityDelegate() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        })

        linkProfileLayout.setAccessibilityDelegate(object: View.AccessibilityDelegate() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.className = Button::class.java.name
            }
        })

        backButton.setOnClickListener(this)
        linkProfileLayout.setOnClickListener(this)
        registerProfileLayout.setOnClickListener(this)

        MemoryCache.getLabelText("s_talkback_back_button")?.let {
            if (!it.isBlank()) {
                backButton.contentDescription = it
            }
        }
        MemoryCache.getLabelText("head_userProfileSelection")?.let {
            if (!it.isBlank()) {
                tv_user_profile_select_title.text = it
            }
        }
        MemoryCache.getLabelText("description_userProfileSelection")?.let {
            if (!it.isBlank()) {
                tv_user_profile_select_create.text = it
            }
        }
        MemoryCache.getLabelText("s_talkback_button_create_profile")?.let {
            if (!it.isBlank()) {
                registerProfileLayout.contentDescription = it
            }
        }
        MemoryCache.getLabelText("text_userProfileSelection_register")?.let {
            if (!it.isBlank()) {
                tv_user_profile_select_register.text = it
            }
        }
        MemoryCache.getLabelText("text_userProfileSelection_link")?.let {
            if (!it.isBlank()) {
                tv_user_profile_select_link.text = it
            }
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.backButton -> {
                TealiumUtil.eventTag("button click", "registration: account setup: back")
                finish()
            }
            R.id.linkProfileLayout -> {
                TealiumUtil.eventTag("button click", "registration: account setup: link my existing profile")
                val intent = Intent(this, LoginActivity::class.java).apply {
                    putExtra(TAG_INVITATION_CODE, mInvitationCode)
                    putExtra(TAG_ANSWER_SECURITY_QUESTION_INFO, mRegistrationChallengeEntity)
                }
                startActivity(intent)
                ApplicationManager.finishActivity(RegisterMainActivity::class.java)
                finish()
            }
            R.id.registerProfileLayout -> {
                TealiumUtil.eventTag("button click", "registration: account setup: register a new profile")
                val intent = Intent(this, RegisterCreateNewUserProfileActivity::class.java).apply {
                    putExtra(TAG_INVITATION_CODE, mInvitationCode)
                    putExtra(TAG_ANSWER_SECURITY_QUESTION_INFO, mRegistrationChallengeEntity)
                }
                startActivity(intent)
                finish()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        TealiumUtil.pageTag(
                "dart : buyer portal : registration : account setup",
                "/dart/buyer portal/registration/account setup",
                "verification",
                "buyer portal",
                "registration",
                "mobile",
                "en",
                "registration",
                "5",
                "registration - setup")
    }
}
