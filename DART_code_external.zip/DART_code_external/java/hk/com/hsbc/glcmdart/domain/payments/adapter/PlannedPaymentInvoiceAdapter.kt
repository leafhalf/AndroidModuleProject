/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.content.Context
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.client.MARKET_CURRENCY
import hk.com.hsbc.glcmdart.domain.dart.CreditNoteLocal
import hk.com.hsbc.glcmdart.domain.payments.model.bean.InvoiceAddEntity
import hk.com.hsbc.glcmdart.domain.payments.model.bean.TaxDeductionInfo
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil
import hk.com.hsbc.glcmdart.util.MemoryCache
import hk.com.hsbc.glcmdart.view.RecyclerExtras

class PlannedPaymentInvoiceAdapter(private val context: Context, private val mData: ArrayList<InvoiceAddEntity>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val inflater: LayoutInflater = LayoutInflater.from(context)

    companion object {
        const val ITEM_INVOICE_DETAIL = 0
        const val ITEM_INVOICE_ADD = 1
    }

    private var currency: String? = null

    fun setCurrency(currency: String?) {
        this.currency = currency
    }

    fun addData(dataList: ArrayList<InvoiceAddEntity>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        notifyDataSetChanged()
    }

    fun getItemByPosition(position: Int): InvoiceAddEntity {
        return this.mData[position]
    }

    override fun getItemCount(): Int{
        return mData.size + 1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
            if (viewType == ITEM_INVOICE_ADD) {
                val view: View = inflater.inflate(R.layout.item_planned_payment_add_invoice, parent, false)
                AddItemHolder(view)
            } else {
                val view: View = inflater.inflate(R.layout.item_planned_payment_invoice, parent, false)
                ItemHolder(view)
            }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == ITEM_INVOICE_ADD) {
            val vh: AddItemHolder = holder as AddItemHolder
            MemoryCache.getLabelText("s_add_other_invoice")?.let {
                if (!it.isBlank()) {
                    vh.tvAddOtherInvoice.text = it
                }
            }
            vh.llAdd.setAccessibilityDelegate(object : View.AccessibilityDelegate() {
                override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info?.className = Button::class.java.name
                }
            })
            vh.llAdd.setOnClickListener { v ->
                itemAddClickListener?.onItemAddClick(v, position)
            }
        } else {
            val vh: ItemHolder = holder as ItemHolder
            MemoryCache.getLabelText("s_note")?.let {
                if (!it.isBlank()) {
                    vh.tvNoteTag.text = it
                }
            }
            vh.tvInvoiceNumber.text = mData[position].invoice?.reference
            MemoryCache.getLabelText("s_talkback_button_create_payment_invoice_detail")?.let {
                if (!it.isBlank()) {
                    vh.itemView.contentDescription = String.format(it, mData[position].invoice?.reference)
                } else {
                    vh.itemView.contentDescription = String.format(context.getString(R.string.s_talkback_button_create_payment_invoice_detail), mData[position].invoice?.reference)
                }
            }

            val amountText: String = if (mData[position].amount.isNullOrEmpty()) {
                "$currency " + IndiaNumberUtil.formatNumByDecimal(mData[position].invoice?.summation?.outstanding?.amount ?: "0.00", currency ?: MARKET_CURRENCY)
            } else {
                "$currency " + IndiaNumberUtil.formatNumByDecimal(mData[position].amount ?: "0.00", currency ?: MARKET_CURRENCY)
            }

            vh.tvAmount.text = amountText
            if (mData[position].active != true) {
                vh.ivDelete.visibility = View.VISIBLE
                vh.tvRemovedTag.visibility = View.VISIBLE
            } else {
                vh.ivDelete.visibility = View.GONE
                vh.tvRemovedTag.visibility = View.GONE
            }

            if (!TextUtils.isEmpty(mData[position].comment)) {
                vh.llNote.visibility = View.VISIBLE
                vh.tvNote.text = mData[position].comment
            } else {
                vh.llNote.visibility = View.GONE
            }
            vh.llItem.setAccessibilityDelegate(object : View.AccessibilityDelegate() {
                override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info?.className = Button::class.java.name
                }
            })
            vh.llItem.setOnClickListener { v ->
                itemClickListener?.onItemClick(v, position)
            }
            MemoryCache.getLabelText("s_talkback_delete_invoice_button")?.let {
                if (!it.isBlank()) {
                    vh.ivDelete.contentDescription = String.format(it, mData[position].invoice?.reference)
                } else {
                    vh.ivDelete.contentDescription = String.format(context.getString(R.string.s_talkback_delete_invoice_button), mData[position].invoice?.reference)
                }
            }
            vh.ivDelete.setOnClickListener { v ->
                itemDeleteClickListener?.onItemDeleteClick(v, position)
            }
            if (!mData[position].creditNotes.isNullOrEmpty()) {
                vh.llCreditNote.visibility = View.VISIBLE
                val creditnoteText = if (MemoryCache.getLabelText("s_credit_note").isNullOrBlank()) {
                    "${context.getString(R.string.s_credit_note)} (" + mData[position].creditNotes?.size +
                            " ${MemoryCache.getLabelText("s_available") ?: context.getString(R.string.s_available)})"
                } else {
                    "${MemoryCache.getLabelText("s_credit_note")} (" + mData[position].creditNotes?.size +
                            " ${MemoryCache.getLabelText("s_available") ?: context.getString(R.string.s_available)})"
                }
                vh.tvCreditNote.text = creditnoteText
            } else {
                vh.llCreditNote.visibility = View.GONE
            }
            if (!mData[position].taxDeductions.isNullOrEmpty()) {
                vh.llTaxDeduction.visibility = View.VISIBLE
                val taxDeductionText = if (MemoryCache.getLabelText("s_deduction").isNullOrBlank()) {
                    "${context.getString(R.string.s_deduction)} (" + mData[position].taxDeductions?.size +
                            " ${MemoryCache.getLabelText("s_available") ?: context.getString(R.string.s_available)})"
                } else {
                    "${MemoryCache.getLabelText("s_deduction")} (" + mData[position].taxDeductions?.size +
                            " ${MemoryCache.getLabelText("s_available") ?: context.getString(R.string.s_available)})"
                }
                vh.tvTaxDeduction.text = taxDeductionText
            } else {
                vh.llTaxDeduction.visibility = View.GONE
            }

            if (mData[position].creditNotesSelected != null) {
                vh.mRecyclerView.adapter = CreditNoteAdapter(context, mData[position].creditNotesSelected as ArrayList<CreditNoteLocal>, this.currency!!)
            } else {
                vh.mRecyclerView.adapter = null
            }

            if (!mData[position].taxDeductionSelected.isNullOrEmpty()) {
                vh.mTaxRecyclerView.adapter = TaxDeductionAdapter(context,
                        mData[position].taxDeductionSelected as ArrayList<TaxDeductionInfo>, this.currency!!, position)
            } else {
                vh.mTaxRecyclerView.adapter = null
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (position == mData.size) {
            ITEM_INVOICE_ADD
        } else {
            ITEM_INVOICE_DETAIL
        }
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val llItem: LinearLayout = view.findViewById(R.id.ll_item)
        val tvInvoiceNumber: TextView = view.findViewById(R.id.tv_invoice_number)
        val tvAmount: TextView = view.findViewById(R.id.tv_amount)
        val llCreditNote: LinearLayout = view.findViewById(R.id.ll_credit_note)
        val llTaxDeduction: LinearLayout = view.findViewById(R.id.ll_tax_deduction)
        val tvCreditNote: TextView = view.findViewById(R.id.tv_credit_note)
        val tvTaxDeduction: TextView = view.findViewById(R.id.tv_tax_deduction)
        val mRecyclerView: RecyclerView = view.findViewById(R.id.rv_invoice_add_or_edit)
        val mTaxRecyclerView: RecyclerView = view.findViewById(R.id.rv_deduction)
        val llNote: LinearLayout = view.findViewById(R.id.ll_note)
        val tvNote: TextView = view.findViewById(R.id.tv_note)
        val ivDelete: ImageView = view.findViewById(R.id.iv_delete)
        val tvNoteTag: TextView = view.findViewById(R.id.tv_note_tag)
        val tvRemovedTag: TextView = view.findViewById(R.id.tv_removed_label)

        init {
            mRecyclerView.layoutManager = LinearLayoutManager(context)
            mTaxRecyclerView.layoutManager = LinearLayoutManager(context)
            ivDelete.visibility = View.GONE
        }
    }

    inner class AddItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val llAdd: LinearLayout = view.findViewById(R.id.rl_add)
        val tvAddOtherInvoice: TextView = view.findViewById(R.id.tv_add_other_invoice)
    }

    private var itemClickListener: RecyclerExtras.OnItemClickListener? = null

    fun setOnItemClickListener(listener: RecyclerExtras.OnItemClickListener) {
        this.itemClickListener = listener
    }

    private var itemAddClickListener: RecyclerExtras.OnItemAddClickListener? = null

    fun setOnItemAddClickListener(listener: RecyclerExtras.OnItemAddClickListener) {
        this.itemAddClickListener = listener
    }

    private var itemDeleteClickListener: RecyclerExtras.OnItemDeleteClickListener? = null

    fun setOnItemDeleteClickListener(listener: RecyclerExtras.OnItemDeleteClickListener) {
        this.itemDeleteClickListener = listener
    }
}
