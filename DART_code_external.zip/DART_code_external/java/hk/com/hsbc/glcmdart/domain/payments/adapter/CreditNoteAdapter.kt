/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.domain.payments.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.dart.CreditNoteLocal
import hk.com.hsbc.glcmdart.util.IndiaNumberUtil

class CreditNoteAdapter(context: Context, private val mData: ArrayList<CreditNoteLocal>,private val currency:String) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val inflater: LayoutInflater = LayoutInflater.from(context)
    var needUpdateAmount = false

    fun addData(dataList: ArrayList<CreditNoteLocal>) {
        this.mData.clear()
        this.mData.addAll(dataList)
        notifyDataSetChanged()
    }

    fun clearData(){
        this.mData.clear()
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = mData.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View = inflater.inflate(R.layout.item_credit_note, parent, false)
        return ItemHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: ItemHolder = holder as ItemHolder
        vh.tvTitle.text = mData[position].creditNote?.payorCreditNoteReference ?: ""
        val tmpText = IndiaNumberUtil.formatNumByDecimal(mData[position].outstanding ?: "", currency)
        val tmpAmountText = "$currency -"+ tmpText.replace("-","")
        vh.tvContent.text =  tmpAmountText
    }

    override fun getItemViewType(position: Int): Int {
        return PlannedPaymentInvoiceAdapter.ITEM_INVOICE_DETAIL
    }

    inner class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tv_title)
        val tvContent: TextView = view.findViewById(R.id.tv_content)
    }

}
