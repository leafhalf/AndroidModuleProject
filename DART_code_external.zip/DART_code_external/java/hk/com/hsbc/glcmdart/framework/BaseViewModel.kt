package hk.com.hsbc.glcmdart.framework

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

abstract class BaseViewModel: ViewModel() {

    val requestLoadingLiveData = MutableLiveData<Boolean>()
    val exceptionLiveData = MutableLiveData<String>()
}