/*
 * COPYRIGHT. HSBC HOLDING PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the
 * prior written consent of HSBC Holdings plc.
 *
 */
package hk.com.hsbc.glcmdart.framework

import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import hk.com.hsbc.glcmdart.R
import hk.com.hsbc.glcmdart.domain.dart.CachedScreenDialog
import hk.com.hsbc.glcmdart.domain.dart.SessionExpiredDialog
import hk.com.hsbc.glcmdart.util.Logger
import hk.com.hsbc.glcmdart.util.TealiumUtil


abstract class BaseActivity : AppCompatActivity() {

    internal val mHandler by lazy { Handler(Looper.getMainLooper()) }
    private val mInflater by lazy { LayoutInflater.from(applicationContext) }
//    private val mPresenters = mutableListOf<IPresenter<*>>()
    private var createdTime: Long = 0L

//    internal fun registerPresenter(iPresenter: IPresenter<*>) {
//        mPresenters.add(iPresenter)
//        mPresenters.forEach {
//            val activity = this@BaseActivity
//            if (activity is IView) {
//                if (it is IPresenter) {
//                    (it as IPresenter<IView>).attachView(activity)
//                }
//            }
//        }
//    }
//
//    internal fun unregisterPresenter(iPresenter: IPresenter<*>) {
//        mPresenters.remove(iPresenter)
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        createdTime = System.currentTimeMillis()
        super.onCreate(savedInstanceState)
    }

    override fun onDestroy() {
//        mPresenters.forEach {
//            it.detachView()
//        }
//        mPresenters.clear()
        hideLoadingDialog()
        hideSessionExpiredDialog()
        super.onDestroy()
        mHandler.removeCallbacksAndMessages(null)
    }

    private var mLoadingDialog: Dialog? = null
    private var mCachedScreenDialog: Dialog? = null
    private var mSessionExpiredDialog: Dialog? = null

    internal fun showLoadingDialog() {
        if (mLoadingDialog != null && mLoadingDialog!!.isShowing) {
            return
        }
        mLoadingDialog = Dialog(this, R.style.AlertDialog).also {
            it.setCancelable(true)
            it.setCanceledOnTouchOutside(false)
            it.window?.also { window ->
                val layoutParams = window.attributes
                layoutParams?.width = WindowManager.LayoutParams.MATCH_PARENT
                layoutParams?.height = WindowManager.LayoutParams.WRAP_CONTENT
                window.decorView.setPadding(0, 0, 0, 0)
                window.attributes = layoutParams
            }
            val view = mInflater.inflate(R.layout.view_loading_whole_page, null)
            it.setContentView(view)
            if (!isFinishing) {
                it.show()
                view.announceForAccessibility(getString(R.string.s_loading))
            }
        }

        val windowParameter = mLoadingDialog?.window?.attributes
        windowParameter?.dimAmount = 0f
        mLoadingDialog?.window?.attributes = windowParameter
    }

    internal fun hideLoadingDialog() {
        mLoadingDialog?.also {
            if (it.isShowing) {
                val view = it.window?.decorView
                view?.announceForAccessibility(getString(R.string.talkBack_loading_complete))
                it.dismiss()
            }
        }
    }

    fun handleCachedScreen(flag: Boolean) {
        runOnUiThread {
            if (flag) {
                if (mCachedScreenDialog == null || !mCachedScreenDialog!!.isShowing) {
                    mCachedScreenDialog = CachedScreenDialog(this).also {
                        it.show()
                    }
                }
//                Logger.i("mask cached screen")
            } else {
                mCachedScreenDialog?.also {
                    if (it.isShowing) {
                        it.dismiss()
                    }
                }
            }
        }
    }

    fun isScreenCaptureAbility(): Boolean {
        val nowTime = System.currentTimeMillis()
        val diffTime = nowTime - createdTime
        return diffTime > 1 * 1000
    }

    fun showSessionExpiredDialog() {
        runOnUiThread {
            if (mSessionExpiredDialog?.isShowing == true) {
                return@runOnUiThread
            }

            mSessionExpiredDialog?.also {
                if (it.isShowing) {
                    it.dismiss()
                }
            }
            mSessionExpiredDialog = SessionExpiredDialog(this).also {
                if (!isFinishing) {
                    it.show()
                }
            }
            TealiumUtil.pageTag("dart : buyer portal : other : time out overlay",
                    "/dart/buyer portal/other/time out overlay",
                    "transaction",
                    "buyer portal",
                    "other")
        }
    }

    private fun hideSessionExpiredDialog() {
        runOnUiThread {
            mSessionExpiredDialog?.also {
                if (it.isShowing) {
                    it.dismiss()
                }
            }
        }
    }
}
