import os
import yaml

id_prefix = 'com.hsbc.gbm.dart'

env_build_type_debug = 'debug'
env_build_type_release = 'release'
env_flavour_dev = 'dev'
env_flavour_uat = 'uat'
env_flavour_pet = 'pet'
env_flavour_prod = ''
env_security_type_review = 'review'
env_security_type_secure = 'secure'

current_env_flavour: str = env_flavour_dev
current_env_build_type = env_build_type_debug
current_env_security = env_security_type_review

idsfs = open(os.path.join(os.getcwd(), 'ids.yaml'), encoding="UTF-8")
ids_data = yaml.load(idsfs, Loader=yaml.FullLoader)


def init_env(env: str = env_flavour_dev, build_type: str = env_build_type_debug,
             security: str = env_security_type_review):
    global current_env_flavour
    current_env_flavour = env
    global current_env_build_type
    current_env_build_type = build_type
    global current_env_security
    current_env_security = security
