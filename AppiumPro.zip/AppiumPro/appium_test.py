from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import unittest

server = 'http://localhost:4723/wd/hub'

config_options = dict(
    platformName='Android',
    platformVersion='11',
    deviceName='emulator-5554',
    app='F:\\Android\\DART\\pcmrms_dart\\app\\build\\outputs\\apk\\devReview\\debug\\app-dev-review-debug.apk',
    noReset=True
)

driver = webdriver.Remote(server, config_options)
driver_wait = WebDriverWait(driver, timeout=30)
btn_en_in = driver_wait.until(EC.presence_of_element_located((By.ID, "com.hsbc.gbm.dart.dev:id/btn_in_english")))
btn_en_in.click()

