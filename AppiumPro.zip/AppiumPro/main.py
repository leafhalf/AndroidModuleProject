# This is a sample Python script.

# Press Alt+Shift+X to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
from Common.common_definition import MONTHDAY_LOC28
from DataSet.EnvData import init_env
from Page.advise_payment_step1 import AdvisePayment1
from Page.advise_payment_step2 import AdvisePayment2
from Page.advise_payment_step3 import AdvisePayment3
from Page.advise_payment_step4 import AdvisePayment4
from Page.home_page import HomePage
from Page.init_page import InitPage
from Page.invoice_detail_page import InvoiceDetailPage
from Page.invoices_page import InvoicesPage
from Page.login_page import LoginPage
from Page.welcome_page import WelcomePage


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+Shift+B to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    init_env()
    init_page = InitPage()
    welcome_page = WelcomePage()
    welcome_page.go_login_click()
    login_page = LoginPage()
    login_page.login_click(username='Buyer_IN', password='16da65')
    home_page = HomePage()
    home_page.change_page_invoices()
    invoice_page = InvoicesPage()
    invoice_page.all_invoice_click()
    invoice_page.item_click(reference='TDS-INV092812')
    invoice_detail_page = InvoiceDetailPage()
    invoice_detail_page.advice_click()
    advise_page1 = AdvisePayment1()
    advise_page1.next_click()
    advise_page2 = AdvisePayment2()
    advise_page2.next_click()
    advise_page3 = AdvisePayment3()
    advise_page3.payment_method_confirm(method='bank_transfer')
    advise_page3.payment_date_ok(day_location=MONTHDAY_LOC28)
    advise_page3.next_click()
    advise_page4 = AdvisePayment4()
    advise_page4.final_step_click()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
