import os
from time import sleep
from typing import Optional
from appium import webdriver
from Framework.driver_provider import DriverProvider
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class BasePage:
    driver: webdriver
    driver_wait: WebDriverWait

    def open(self, driver, options: Optional[dict] = (), server: str = ''):
        self.driver = DriverProvider.provide_driver(driver, options, server)
        self.driver_wait = WebDriverWait(self.driver, timeout=30)

    def find_element(self, *loc):
        return self.driver_wait.until(EC.presence_of_element_located(*loc))

    def find_elements(self, *loc):
        return self.driver_wait.until(EC.presence_of_all_elements_located(*loc))

    def find_element_without_waiting(self, by, value):
        return self.driver.find_element(by, value)

    def find_elements_without_waiting(self, by, value):
        return self.driver.find_elements(by, value)

    def input(self, *loc, txt):
        self.find_element(*loc).send_keys(txt)

    def click(self, *loc):
        self.find_element(*loc).click()

    def tab(self, *loc):
        adb_command = 'adb shell input tap %d %d' % (loc[0][0], loc[0][1])
        os.system(adb_command)

    def drag_over(self, start_x, start_y, end_x, end_y, duration: int = 500):
        self.driver.swipe(start_x, start_y, end_x, end_y, duration)

    def wait_loading(self, timeout):
        self.driver.implicitly_wait(1)

        total_time = 0
        while total_time < timeout:
            try:
                sleep(1)
                self.find_loading()
                total_time += 1
            except:
                break

        self.driver.implicitly_wait(10)

    @property
    def find_loading(self):
        return self.driver.find_element_by_xpath('/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout'
                                                 '/android.widget.FrameLayout/android.widget.RelativeLayout/android'
                                                 '.widget.ProgressBar')

    def wait(self, wait_time):
        sleep(wait_time)

    def quit(self):
        self.driver.close()

    def back(self):
        self.driver.back()
