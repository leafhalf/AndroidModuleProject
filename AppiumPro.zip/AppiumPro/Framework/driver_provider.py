from typing import Optional

from appium import webdriver


class DriverProvider:
    server = 'http://localhost:4723/wd/hub'
    config_options = dict(
        platformName='Android',
        platformVersion='11',
        automationName='UiAutomator2',
        deviceName='emulator-5554',
        app='F:\\Android\\DART\\pcmrms_dart\\app\\build\\outputs\\apk\\devReview\\debug\\app-dev-review-debug.apk',
        noReset=True
    )

    global_driver = None

    @classmethod
    def provide_global_driver(cls):
        if cls.global_driver is None:
            cls.global_driver = webdriver.Remote(cls.server, cls.config_options)
        return cls.global_driver

    @classmethod
    def provide_driver(cls, driver, options: Optional[dict] = (), server: str = ''):
        if driver is None:
            if len(server) == 0:
                return cls.provide_global_driver()
            else:
                if len(options) == 0:
                    return cls.provide_global_driver()
                else:
                    return webdriver.Remote(server, options)
        else:
            return driver
