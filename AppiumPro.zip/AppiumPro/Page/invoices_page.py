from appium.webdriver import webdriver

from Common.common_definition import SORT_BY_DEFAULT, SORT_BY_NEW_TO_OLD, SORT_BY_OLD_TO_NEW, SORT_BY_HIGH_TO_LOW, \
    SORT_BY_LOW_TO_HIGH, INVOICE_ITEM_HIGH
from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class InvoicesPage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)
        self.is_searching = False

    def refresh(self):
        self.drag_over(538, 475, 538, 1128)

    def drag_page(self):
        self.drag_over(947, 1137, 60, 1137, 1000)

    def invoice_due_today_click(self):
        self.wait_loading(10)
        self.click((By.XPATH, '//androidx.appcompat.app.ActionBar.Tab[@content-desc="Invoices due today"]'))
        self.wait(wait_time=1)

    def all_invoice_click(self):
        self.wait_loading(10)
        self.click((By.XPATH, '//androidx.appcompat.app.ActionBar.Tab[@content-desc="All invoices"]'))
        self.wait(wait_time=1)

    def search(self, txt):
        if not self.is_searching:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_search'])))
            self.is_searching = True

        self.input((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_search_input'])), txt=txt)
        self.driver.keyevent(66)

    def close_search(self):
        if self.is_searching:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_search'])))
            self.is_searching = False

    def open_sort(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_invoice_sort'])))

    def sort(self, sort_by):
        self.open_sort()
        switch = {
            SORT_BY_DEFAULT: 'id_invoice_sort_default',
            SORT_BY_NEW_TO_OLD: 'id_invoice_sort_new_to_old',
            SORT_BY_OLD_TO_NEW: 'id_invoice_sort_old_to_new',
            SORT_BY_HIGH_TO_LOW: 'id_invoice_sort_high_to_low',
            SORT_BY_LOW_TO_HIGH: 'id_invoice_sort_low_to_high'
        }
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data[switch[sort_by]])))

    def filter_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_invoice_filter'])))

    def show_outstanding_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_show_outstanding'])))

    def item_click(self, reference):
        is_found_element = False
        found_element = None
        last_element = self.find_element((By.XPATH, '//android.widget.Button[last()]'))
        current_last_element = None
        while last_element != current_last_element and not is_found_element:
            elements = self.find_elements_without_waiting(By.XPATH, '//android.widget.Button')
            for item in elements:
                if reference in item.get_attribute('content-desc'):
                    is_found_element = True
                    found_element = item
                    break

            if not is_found_element:
                self.driver.swipe(538, 1923, 538, 1923 - INVOICE_ITEM_HIGH * 3)
                self.wait_loading(10)

            current_last_element = last_element
            last_element = self.find_element((By.XPATH, '//android.widget.Button[last()]'))

        if not is_found_element:
            raise Exception('Item not found')
        else:
            found_element.click()

    def reset_item_list(self):
        current_first_element = None
        first_element = self.find_element((By.XPATH, '//android.widget.Button[first()]'))
        while first_element != current_first_element:
            self.driver.swipe(538, 1923 - INVOICE_ITEM_HIGH * 5, 538, 1923)
            self.wait_loading(10)
            current_first_element = first_element
            first_element = self.find_element((By.XPATH, '//android.widget.Button[first()]'))
