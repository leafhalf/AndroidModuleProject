from appium.webdriver import webdriver

from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class TutorialPage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def next_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_tutorial_next'])))

    def skip_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_tutorial_skip'])))

    def gotit_click(self):
        try:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_tutorial_gotit'])))
        finally:
            return
