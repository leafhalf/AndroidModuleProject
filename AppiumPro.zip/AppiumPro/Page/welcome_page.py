from appium.webdriver import webdriver

from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from Framework.base_page import BasePage
from appium.webdriver.common.mobileby import By


class WelcomePage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def select_language_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['areaText'])))

    def en_in_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_en_in'])))

    def en_id_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_en_id'])))

    def id_id_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_id_id'])))

    def en_au_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_en_au'])))

    def en_sg_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_en_sg'])))

    def cancel_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_cancel'])))

    def go_login_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_login'])))

    def go_register_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_signup'])))
