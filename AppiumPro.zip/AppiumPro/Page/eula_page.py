from appium.webdriver import webdriver

from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from Framework.base_page import BasePage
from appium.webdriver.common.mobileby import By


class EULAPage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def en_in_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_agree'])))
