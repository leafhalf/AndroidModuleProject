from appium.webdriver import webdriver

from Common.common_definition import WEEKDAY_SUNDAY, WEEKDAY_MONDAY, WEEKDAY_TUESDAY, WEEKDAY_WEDNESDAY, \
    WEEKDAY_THURSDAY, WEEKDAY_FRIDAY, WEEKDAY_SATURDAY, MONTHDAY_LOC1, MONTHDAY_LOC2, MONTHDAY_LOC3, MONTHDAY_LOC4, \
    MONTHDAY_LOC5, MONTHDAY_LOC6, MONTHDAY_LOC7, MONTHDAY_LOC8, MONTHDAY_LOC9, MONTHDAY_LOC10, MONTHDAY_LOC11, \
    MONTHDAY_LOC12, MONTHDAY_LOC13, MONTHDAY_LOC14, MONTHDAY_LOC20, MONTHDAY_LOC21, MONTHDAY_LOC19, MONTHDAY_LOC18, \
    MONTHDAY_LOC17, MONTHDAY_LOC16, MONTHDAY_LOC15, MONTHDAY_LOC22, MONTHDAY_LOC23, MONTHDAY_LOC24, MONTHDAY_LOC25, \
    MONTHDAY_LOC26, MONTHDAY_LOC27, MONTHDAY_LOC28, MONTHDAY_LOC34, MONTHDAY_LOC35, MONTHDAY_LOC33, MONTHDAY_LOC32, \
    MONTHDAY_LOC31, MONTHDAY_LOC30, MONTHDAY_LOC29
from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class CalendarPage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)
        self.isExpanding = False

    def previous_month_or_week_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_left_btn'])))

    def previous_day_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_sec_left_btn'])))

    def next_month_or_week_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_right_btn'])))

    def next_day_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_sec_right_btn'])))

    def invoices_item_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_invoice'])))

    def payments_item_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_payment'])))

    def next_item_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_next_item'])))

    def expand_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_expand'])))
        self.isExpanding = bool(1 - self.isExpanding)

    def currency_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_currency'])))

    def week_day_click(self, week_day):
        if self.isExpanding:
            self.expand_click()
            self.isExpanding = False

        switch = {
            WEEKDAY_SUNDAY: (105, 614),
            WEEKDAY_MONDAY: (247, 614),
            WEEKDAY_TUESDAY: (396, 614),
            WEEKDAY_WEDNESDAY: (535, 614),
            WEEKDAY_THURSDAY: (681, 614),
            WEEKDAY_FRIDAY: (823, 614),
            WEEKDAY_SATURDAY: (966, 614)
        }

        self.tab(switch.get(week_day))

    def month_day_click(self, day_location):
        if not self.isExpanding:
            self.expand_click()
            self.isExpanding = True

        switch = {
            MONTHDAY_LOC1: (105, 614),
            MONTHDAY_LOC2: (247, 614),
            MONTHDAY_LOC3: (396, 614),
            MONTHDAY_LOC4: (535, 614),
            MONTHDAY_LOC5: (681, 614),
            MONTHDAY_LOC6: (823, 614),
            MONTHDAY_LOC7: (966, 614),
            MONTHDAY_LOC8: (105, 725),
            MONTHDAY_LOC9: (247, 725),
            MONTHDAY_LOC10: (396, 725),
            MONTHDAY_LOC11: (535, 725),
            MONTHDAY_LOC12: (681, 725),
            MONTHDAY_LOC13: (823, 725),
            MONTHDAY_LOC14: (966, 725),
            MONTHDAY_LOC15: (105, 846),
            MONTHDAY_LOC16: (247, 846),
            MONTHDAY_LOC17: (396, 846),
            MONTHDAY_LOC18: (535, 846),
            MONTHDAY_LOC19: (681, 846),
            MONTHDAY_LOC20: (823, 846),
            MONTHDAY_LOC21: (966, 846),
            MONTHDAY_LOC22: (105, 953),
            MONTHDAY_LOC23: (247, 953),
            MONTHDAY_LOC24: (396, 953),
            MONTHDAY_LOC25: (535, 953),
            MONTHDAY_LOC26: (681, 953),
            MONTHDAY_LOC27: (823, 953),
            MONTHDAY_LOC28: (966, 953),
            MONTHDAY_LOC29: (105, 1074),
            MONTHDAY_LOC30: (247, 1074),
            MONTHDAY_LOC31: (396, 1074),
            MONTHDAY_LOC32: (535, 1074),
            MONTHDAY_LOC33: (681, 1074),
            MONTHDAY_LOC34: (823, 1074),
            MONTHDAY_LOC35: (966, 1074)
        }

        self.tab(switch.get(day_location))

    def refresh(self):
        self.drag_over(538, 475, 538, 1128)

    def drag_page(self, is_previous):
        if is_previous:
            self.drag_over(60, 1137, 947, 1137, 1000)
        else:
            self.drag_over(947, 1137, 60, 1137, 1000)
