from appium.webdriver import webdriver

from Common.common_definition import PAYMENT_ITEM_HIGH
from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class PaymentPage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)
        self.is_searching = False

    def refresh(self):
        self.drag_over(538, 475, 538, 1128)

    def drag_page(self):
        self.drag_over(947, 1137, 60, 1137, 1000)

    def search(self, txt):
        if not self.is_searching:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_search'])))
            self.is_searching = True

        self.input((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_search_input'])), txt=txt)
        self.driver.keyevent(66)

    def close_search(self):
        if self.is_searching:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_search'])))
            self.is_searching = False

    def payment_due_today_click(self):
        self.click((By.XPATH, '//androidx.appcompat.app.ActionBar.Tab[@content-desc="Payments due today"]'))

    def all_payment_click(self):
        self.click((By.XPATH, '//androidx.appcompat.app.ActionBar.Tab[@content-desc="All advices"]'))

    def filter_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_payment_filter'])))

    def item_click(self, reference):
        element = self.find_element((By.XPATH, '//android.widget.Button[@content-desc="Item %s"]' % reference))
        last_element = self.find_element((By.XPATH, '//android.widget.Button[last()]' % reference))
        current_last_element = None
        if element is not None:
            self.click((By.XPATH, '//android.widget.Button[@content-desc="Item %s"]'))
        else:
            while last_element != current_last_element and element is None:
                self.driver.swipe(538, 1923, 538, 1923 - PAYMENT_ITEM_HIGH * 4)
                element = self.find_element((By.XPATH, '//android.widget.Button[@content-desc="Item %s"]' % reference))
                current_last_element = last_element
                last_element = self.find_element((By.XPATH, '//android.widget.Button[last()]' % reference))

        if element is None:
            raise Exception("Item not found")
        else:
            element.click()

    def reset_item_list(self):
        current_first_element = None
        first_element = self.find_element((By.XPATH, '//android.widget.Button[first()]'))
        while first_element != current_first_element:
            self.driver.swipe(538, 1923 - PAYMENT_ITEM_HIGH * 5, 538, 1923)
            current_first_element = first_element
            first_element = self.find_element((By.XPATH, '//android.widget.Button[first()]'))
