from appium.webdriver import webdriver

from Common.common_definition import MONTHDAY_LOC1, MONTHDAY_LOC2, MONTHDAY_LOC3, MONTHDAY_LOC4, \
    MONTHDAY_LOC5, MONTHDAY_LOC6, MONTHDAY_LOC7, MONTHDAY_LOC8, MONTHDAY_LOC9, MONTHDAY_LOC10, MONTHDAY_LOC11, \
    MONTHDAY_LOC12, MONTHDAY_LOC13, MONTHDAY_LOC14, MONTHDAY_LOC20, MONTHDAY_LOC21, MONTHDAY_LOC19, MONTHDAY_LOC18, \
    MONTHDAY_LOC17, MONTHDAY_LOC16, MONTHDAY_LOC15, MONTHDAY_LOC22, MONTHDAY_LOC23, MONTHDAY_LOC24, MONTHDAY_LOC25, \
    MONTHDAY_LOC26, MONTHDAY_LOC27, MONTHDAY_LOC28, MONTHDAY_LOC34, MONTHDAY_LOC35, MONTHDAY_LOC33, MONTHDAY_LOC32, \
    MONTHDAY_LOC31, MONTHDAY_LOC30, MONTHDAY_LOC29
from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class AdvisePayment3(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def back_click(self):
        self.click((By.XPATH, '//android.widget.ImageButton[@content-desc="Navigate up"]'))

    def next_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_next_step'])))

    def payment_method_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_select_payment_method'])))

    def payment_method_select(self, method):
        self.payment_method_click()
        self.click((By.XPATH, '//android.widget.RadioButton[@content-desc="%s"]' % method))

    def payment_method_confirm(self, method):
        self.payment_method_select(method)
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_payment_method_confirm'])))

    def payment_method_cancel(self):
        try:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_payment_method_cancel'])))
        finally:
            return

    def payment_date_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_select_payment_date'])))

    def previous_month_or_week_click(self):
        self.payment_date_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_left_btn'])))

    def next_month_or_week_click(self):
        self.payment_date_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_calendar_right_btn'])))

    def month_day_click(self, day_location, is_cheque_date: bool = False):
        if not is_cheque_date:
            self.payment_date_click()
        else:
            self.cheque_date_click()

        switch = {
            MONTHDAY_LOC1: (228, 1115),
            MONTHDAY_LOC2: (326, 1115),
            MONTHDAY_LOC3: (431, 1115),
            MONTHDAY_LOC4: (535, 1115),
            MONTHDAY_LOC5: (637, 1115),
            MONTHDAY_LOC6: (741, 1115),
            MONTHDAY_LOC7: (846, 1115),
            MONTHDAY_LOC8: (228, 1226),
            MONTHDAY_LOC9: (326, 1226),
            MONTHDAY_LOC10: (431, 1226),
            MONTHDAY_LOC11: (535, 1226),
            MONTHDAY_LOC12: (637, 1226),
            MONTHDAY_LOC13: (741, 1226),
            MONTHDAY_LOC14: (846, 1226),
            MONTHDAY_LOC15: (228, 1343),
            MONTHDAY_LOC16: (326, 1343),
            MONTHDAY_LOC17: (431, 1343),
            MONTHDAY_LOC18: (535, 1343),
            MONTHDAY_LOC19: (637, 1343),
            MONTHDAY_LOC20: (741, 1343),
            MONTHDAY_LOC21: (846, 1343),
            MONTHDAY_LOC22: (228, 1457),
            MONTHDAY_LOC23: (326, 1457),
            MONTHDAY_LOC24: (431, 1457),
            MONTHDAY_LOC25: (535, 1457),
            MONTHDAY_LOC26: (637, 1457),
            MONTHDAY_LOC27: (741, 1457),
            MONTHDAY_LOC28: (846, 1457),
            MONTHDAY_LOC29: (228, 1574),
            MONTHDAY_LOC30: (326, 1574),
            MONTHDAY_LOC31: (431, 1574),
            MONTHDAY_LOC32: (535, 1574),
            MONTHDAY_LOC33: (637, 1574),
            MONTHDAY_LOC34: (741, 1574),
            MONTHDAY_LOC35: (846, 1574)
        }

        self.tab(switch.get(day_location))

    def payment_date_ok(self, day_location, is_cheque_date: bool = False):
        self.month_day_click(day_location, is_cheque_date)
        self.click((By.ID, ids_data['id_system_dialog_button1']))

    def payment_date_cancel(self):
        try:
            self.click((By.ID, ids_data['id_system_dialog_button2']))
        finally:
            return

    def choose_reference_auto_gen(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_reference_auto_gen'])))

    def choose_reference_use_own(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_reference_use_own'])))

    def input_own_reference(self, txt):
        self.choose_reference_use_own()
        self.input((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_reference_input'])), txt=txt)

    def cheque_date_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_cheque_date'])))

    def cheque_number_input(self, txt):
        self.input((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_cheque_number_input'])),
                   txt=txt)

    def cheque_amount_input(self, txt):
        self.input((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_cheque_amount'])), txt=txt)
