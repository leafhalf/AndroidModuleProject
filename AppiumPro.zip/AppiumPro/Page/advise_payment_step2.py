from appium.webdriver import webdriver

from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class AdvisePayment2(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def back_click(self):
        self.click((By.XPATH, '//android.widget.ImageButton[@content-desc="Navigate up"]'))

    def next_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_next_step'])))

    def item_click(self, reference):
        self.click((By.XPATH, '//android.widget.Button[@content-desc="Button, invoice %s detail"]' % reference))

    def add_item_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_item_add'])))
