from appium.webdriver import webdriver

from Common.common_definition import PAYMENT_DETAIL_INVOICE_ITEM_HIGH
from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class AdvisePayment4(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def back_click(self):
        self.click((By.XPATH, '//android.widget.ImageButton[@content-desc="Navigate up"]'))

    def final_step_click(self):
        final_step_button = None
        while final_step_button is None:
            try:
                final_step_button = self.find_element_without_waiting(By.ID, "%s.%s:id/%s" % (id_prefix,
                                                                                              current_env_flavour,
                                                                                              ids_data['id_last_step']))
            except:
                self.driver.swipe(538, 1923, 538, 1923 - 600)
                self.wait_loading(10)
        final_step_button.click()

    def cancel_click(self):
        cancel_button = None
        while cancel_button is None:
            try:
                cancel_button = self.find_element_without_waiting(By.ID, "%s.%s:id/%s" % (id_prefix,
                                                                                              current_env_flavour,
                                                                                              ids_data['id_cancel_step']))
            except:
                self.driver.swipe(538, 1923, 538, 1923 - 600)
                self.wait_loading(10)
        cancel_button.click()

    def invoice_item_click(self, reference):
        is_found_element = False
        found_element = None
        cancel_button = None

        while cancel_button is None and not is_found_element:
            elements = self.find_elements_without_waiting(By.XPATH, '//android.widget.Button')
            for item in elements:
                if reference in item.get_attribute('content-desc'):
                    is_found_element = True
                    found_element = item
                    break

            if not is_found_element:
                self.driver.swipe(538, 1923, 538, 1923 - PAYMENT_DETAIL_INVOICE_ITEM_HIGH * 3)
                self.wait_loading(10)

            try:
                cancel_button = self.find_element_without_waiting(By.ID, "%s.%s:id/%s" % (id_prefix,
                                                                                  current_env_flavour,
                                                                                  ids_data['id_cancel_step']))
            except:
                cancel_button = None

        if not is_found_element:
            raise Exception('Item not found')
        else:
            found_element.click()
