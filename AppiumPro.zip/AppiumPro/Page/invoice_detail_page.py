from appium.webdriver import webdriver

from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class InvoiceDetailPage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def back_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_more_my_profile'])))

    def advice_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_advice_payment'])))

    def timeline_collapse_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_timeline_collapse'])))

    def more_info_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_more_invoice_info'])))

    def payment_item_click(self, reference):
        self.click((By.XPATH, '//android.widget.Button[@content-desc="Payment item %s"]' % reference))
