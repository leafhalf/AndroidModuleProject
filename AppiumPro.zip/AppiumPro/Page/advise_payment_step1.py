from appium.webdriver import webdriver

from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class AdvisePayment1(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def back_click(self):
        self.wait_loading(10)
        self.click((By.XPATH, '//android.widget.ImageButton[@content-desc="Navigate up"]'))

    def next_click(self):
        self.wait_loading(10)
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_next_step'])))

