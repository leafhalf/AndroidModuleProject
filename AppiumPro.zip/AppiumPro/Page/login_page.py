from appium.webdriver import webdriver

from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class LoginPage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def select_language_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['areaText'])))

    def select_more_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['areaText'])))

    def en_in_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_en_in'])))

    def en_id_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_en_id'])))

    def id_id_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_id_id'])))

    def en_au_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_en_au'])))

    def en_sg_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_en_sg'])))

    def cancel_click(self):
        self.select_language_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_cancel'])))

    def reset_username_click(self):
        self.select_more_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_about_reset_username'])))

    def reset_pwd_click(self):
        self.select_more_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_about_reset_pwd'])))

    def about_eula_click(self):
        self.select_more_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_about_eula'])))

    def about_cookie_policy_click(self):
        self.select_more_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_about_cookie_policy'])))

    def about_acknowledgement_click(self):
        self.select_more_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_about_acknowledgement'])))

    def about_pdps_click(self):
        self.select_more_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_about_pdps'])))

    def about_tandc_click(self):
        self.select_more_click()
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_about_tandc'])))

    def login_click(self, username, password):
        self.input((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_input_username'])), txt=username)
        self.input((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_input_password'])), txt=password)
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_login'])))

