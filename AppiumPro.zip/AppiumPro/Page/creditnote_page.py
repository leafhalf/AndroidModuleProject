from appium.webdriver import webdriver

from Common.common_definition import PAYMENT_ITEM_HIGH
from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class CreditNotePage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)
        self.is_searching = False

    def refresh(self):
        self.drag_over(538, 475, 538, 1128)

    def drag_page(self):
        self.drag_over(947, 1137, 60, 1137, 1000)

    def search(self, txt):
        if not self.is_searching:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_search'])))
            self.is_searching = True

        self.input((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_search_input'])), txt=txt)
        self.driver.keyevent(66)

    def close_search(self):
        if self.is_searching:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_search'])))
            self.is_searching = False

    def filter_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_creditnote_filter'])))

    def outstanding_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_creditnote_outstanding'])))
