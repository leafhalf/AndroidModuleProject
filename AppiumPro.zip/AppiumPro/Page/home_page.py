from appium.webdriver import webdriver

from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class HomePage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def notification_cancel_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_dialog_cancel'])))

    def notification_confirm_click(self):
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_dialog_confirm'])))

    def change_page_home(self):
        self.wait_loading(10)
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_navigator_calendar'])))

    def change_page_invoices(self):
        self.wait_loading(10)
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_navigator_invoices'])))

    def change_page_payments(self):
        self.wait_loading(10)
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_navigator_payments'])))

    def change_page_creditnotes(self):
        self.wait_loading(10)
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_navigator_creditnotes'])))

    def change_page_more(self):
        self.wait_loading(10)
        self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_navigator_more'])))
