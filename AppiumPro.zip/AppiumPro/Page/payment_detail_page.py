from appium.webdriver import webdriver

from Common.common_definition import PAYMENT_DETAIL_INVOICE_ITEM_HIGH
from DataSet.EnvData import id_prefix, current_env_flavour, ids_data
from appium.webdriver.common.mobileby import By
from Framework.base_page import BasePage


class PaymentDetailPage(BasePage):

    def __init__(self, driver: webdriver = None):
        self.open(driver)

    def next_click(self):
        try:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_tutorial_next'])))
        finally:
            return

    def skip_click(self):
        try:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_tutorial_skip'])))
        finally:
            return

    def gotit_click(self):
        try:
            self.click((By.ID, "%s.%s:id/%s" % (id_prefix, current_env_flavour, ids_data['id_tutorial_gotit'])))
        finally:
            return

